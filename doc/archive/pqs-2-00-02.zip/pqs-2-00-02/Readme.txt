
*Introduction*

This is the standalone version of pqs-2-00-02. Tested on VC7.1 and gcc3.2.

Please note that the boost_ directory included with the distro 
is a very minimal cut down and modified version of required headers
from the official boost distro. 
If you have the official boost libraries already in your path 
do not overwrite your current boost directory with the boost_ directory 
from the pqs distro. In this case the installation will work if you copy
only the pqs directory to your include as detailed below.

If you do not have the boost libraries, the boost_ directory 
will need to be used, but Must be renamed 'boost'.


(If after installing pqs you install the official boost libraries 
it is obviously fine, in fact recommended, to overwrite my version of boost)


Note: For Use with VC7.1,any combinations of language settings 
should be ok, so pqs can be used in Windows programs.
Note that a couple of the examples may need the compiler settings 
to be set (e.g in Project>properties>C/C++>language ) to:

/Zc:forScope Force conformance in for loops.

*Changes from pqs-2-00-01*

Please see "docs\physical_quantity\pqs-2-00-02-changes.html" for more detailed info on changes from pqs-2-00-01


*Installation*

The library must be placed somewhere in your compilers path.
The easiest way to do this is to copy the 'pqs' directory 
and its contents as a subdirectory of your compilers include files.

If you have already installed the boost libraries, do not copy 
the boost_ directory to the official boost directory.
In order to prevent this error the boost directory has been named "boost_".

If you don't already have the boost libraries, the next step is to
copy the 'boost_' directory to sit alongside the pqs directory and then
rename it to 'boost'


So (where mycompiler/include is your compilers include path) 
the paths after install will look like:

mycompiler/include/pqs

mycompiler/include/boost

*Use*

After installation the simplest way to access the basic part of the 
pqs library type is to just #include "pqs/pqs.hpp".However one downside
is that this can slow compile times.  
See the examples directory comments for other
more optimal methods. Some parts such as complex and angles etc requre
other headers to be #included. See the complex and angles examples for
what to include.

Andy Little










