#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
//modified from "boost/implicit_cast.hpp"
//Andy Little
//Original copyright follows

// Copyright David Abrahams 2003. Permission to copy, use,
// modify, sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.
#ifndef IMPLICIT_CAST_DWA200356_HPP
# define IMPLICIT_CAST_DWA200356_HPP

# include <boost/mpl/identity.hpp>

namespace boost {

// implementation originally suggested by C. Green in
// http://lists.boost.org/MailArchives/boost/msg00886.php

    template <typename T>
    inline T implicit_cast (typename mpl::identity<T>::type x) {
        return x;
    }

}//boost

#endif
