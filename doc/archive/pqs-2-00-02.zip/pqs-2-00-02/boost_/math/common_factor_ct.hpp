#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_MATH_COMMON_FACTOR_CT_HPP
#define BOOST_MATH_COMMON_FACTOR_CT_HPP
//moduified by Andy Little
// original copyright follows

//  Boost common_factor_ct.hpp header file  ----------------------------------//

//  (C) Copyright Daryle Walker and Stephen Cleary 2001-2002.  Permission to
//  copy, use, modify, sell and distribute this software is granted provided
//  this copyright notice appears in all copies.  This software is provided "as
//  is" without express or implied warranty, and with no claim as to its
//  suitability for any purpose. 

//  See http://www.boost.org for updates, documentation, and revision history. 

namespace boost{namespace math {

    template < 
        unsigned long Value1,
        unsigned long Value2 
    >
    struct static_gcd;
    template < 
        unsigned long Value1,
        unsigned long Value2 
    >
    struct static_lcm;
}}//boost::math

 namespace boost{namespace math { namespace detail{
        // Build GCD with Euclid's recursive algorithm
        template <
            unsigned long Value1,
            unsigned long Value2 
        >
        struct static_gcd_helper_t{
        private:
            const static unsigned long new_value1 = Value2;
            const static unsigned long new_value2 = Value1 % Value2;

            typedef static_gcd_helper_t<
                new_value1,
                new_value2
            > next_step_type;
        public:
            static const unsigned long value 
            = next_step_type::value;
        };

        // Non-recursive case
        template < unsigned long Value1 >
        struct static_gcd_helper_t< Value1, 0 >
        {
            static const unsigned long value = Value1;
        };

        // Build the LCM from the GCD
        template < 
            unsigned long Value1,
            unsigned long Value2
        >
        struct static_lcm_helper_t{
            typedef static_gcd_helper_t<
                Value1,
                Value2
            > gcd_type;
            static const unsigned long value 
            =  Value1 / gcd_type::value * Value2;
        };

        // Special case for zero-GCD values
        template <>
        struct static_lcm_helper_t< 0, 0 >{
            static const unsigned long value = 0;
        };
 }}} // boost::math::detail

namespace boost{namespace math {
    //Compile-time greatest common divisor 
    //evaluator class declaration
    template < 
        unsigned long Value1,
        unsigned long Value2 
    >
    struct static_gcd{
        static const unsigned long value 
        = (detail::static_gcd_helper_t<
            Value1,
            Value2
        >::value);
    }; 

    // Compile-time least common multiple
    // evaluator class declaration  
    template < 
        unsigned long Value1,
        unsigned long Value2 
    >
    struct static_lcm {
        static const unsigned long value 
        =  ( detail::static_lcd_helper_t<
                Value1, 
                Value2
            >::value);
    }; 

}}  // namespace boost::math

#endif  // BOOST_MATH_COMMON_FACTOR_CT_HPP
