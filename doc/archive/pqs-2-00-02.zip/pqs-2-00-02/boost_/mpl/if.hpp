#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_MPL_IF_HPP_INCLUDED
#define BOOST_MPL_IF_HPP_INCLUDED

// modified Andy Little 2004
//
// Copyright (c) 2000-03 Boost.org
//
// Permission to use, copy, modify, distribute and sell this software
// and its documentation for any purpose is hereby granted without fee, 
// provided that the above copyright notice appears in all copies and 
// that both the copyright notice and this permission notice appear in 
// supporting documentation. No representations are made about the 
// suitability of this software for any purpose. It is provided "as is" 
// without express or implied warranty.
//
// See http://www.boost.org/libs/mpl for documentation.

#include "boost/mpl/void.hpp"

namespace boost {namespace mpl {

    template<
        bool Condition,
        typename T1,
        typename T2
    >
    struct if_c;

}} //boost::mpl
 
namespace boost {namespace mpl {

    template<
        bool Condition,
        typename T1,
        typename T2
    >
    struct if_c{
        typedef T1 type;
    };

    template<
        typename T1,
        typename T2
    >
    struct if_c<
        false,
        T1,
        T2
    >{
        typedef T2 type;
    };

    template<
        typename Condition,
        typename T1,
        typename T2
    >
    struct if_ : if_c<
            static_cast<bool>(Condition::value),
            T1,
            T2
        > {};

}} //boost::mpl

#endif // BOOST_MPL_IF_HPP_INCLUDED
