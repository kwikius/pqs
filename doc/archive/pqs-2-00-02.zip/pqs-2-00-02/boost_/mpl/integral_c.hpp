#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_MPL_INTEGRAL_C_HPP_INCLUDED
#define BOOST_MPL_INTEGRAL_C_HPP_INCLUDED
// Copyright (c) 2000-03
// Aleksey Gurtovoy
//
// Permission to use, copy, modify, distribute and sell this software
// and its documentation for any purpose is hereby granted without fee, 
// provided that the above copyright notice appears in all copies and 
// that both the copyright notice and this permission notice appear in 
// supporting documentation. No representations are made about the 
// suitability of this software for any purpose. It is provided "as is" 
// without express or implied warranty.
//
// See http://www.boost.org/libs/mpl for documentation.

//modified by Andy Little

#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/ice_binary_operator.hpp"

namespace boost { namespace mpl {

    template< 
        typename T,
        T N 
    >
    struct integral_c{
       
        static const T value = N;
        typedef integral_c type;
        typedef T value_type;
        typedef integral_c< T, static_cast<T>((value + 1)) > next;
        typedef integral_c< T, static_cast<T>((value - 1)) > prior;
        operator T() const { return static_cast<T>(this->value); } 
    };

    template< 
        typename T,
        T N 
    >
    T const integral_c< T, N >::value;

    template< bool C >
    struct integral_c<bool, C> {
        static const bool value = C;
        typedef integral_c type;
        operator bool() const { return this->value; }
    };
}} //boost::mpl

namespace pqs{ namespace meta{

    template< 
       typename IntegerTypeA,
       IntegerTypeA A,
       template <typename> class Op,
       typename IntegerTypeB,
       IntegerTypeB B
    >
    struct binary_operation<
        boost::mpl::integral_c<
            IntegerTypeA,
            A
        >,
        Op,
        boost::mpl::integral_c<
            IntegerTypeB,
            B
        >
    >{
    private:
        typedef ice_binary_operator<
            IntegerTypeA,
            A,
            Op,
            IntegerTypeB,
            B
        > ct_op;
        typedef typename ct_op::result_type      value_type;
        const static value_type value = ct_op::result_value;
    public:
        typedef boost::mpl::integral_c<
            value_type,
            value
        > type;
    };
        
}}//pqs::meta

#endif
