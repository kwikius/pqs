#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
//modified from boost/mpl/or.hpp
//by Andy Little
//original coyright follows
#ifndef BOOST_MPL_OR_HPP_INCLUDED
#define BOOST_MPL_OR_HPP_INCLUDED
// + file: boost/mpl/or.hpp
// + last modified: 25/feb/03

// Copyright (c) 2000-03
// Aleksey Gurtovoy
//
// Permission to use, copy, modify, distribute and sell this software
// and its documentation for any purpose is hereby granted without fee, 
// provided that the above copyright notice appears in all copies and 
// that both the copyright notice and this permission notice appear in 
// supporting documentation. No representations are made about the 
// suitability of this software for any purpose. It is provided "as is" 
// without express or implied warranty.
//
// See http://www.boost.org/libs/mpl for documentation.

#include "boost/mpl/void.hpp"
#include "boost/mpl/bool.hpp"

namespace boost{namespace mpl{

    template<
        typename T1 = void_,
        typename T2 = void_,
        typename T3 = false_, 
        typename T4 = false_,   
        typename T5 = false_
    >
    struct or_ : bool_< 
    ( (T1::type::value  !=0)
       || (T2::type::value !=0) 
       || (T3::type::value !=0)
       || (T4::type::value !=0)
       || (T5::type::value !=0) )
    >{};


}}//boost::mpl

#endif
