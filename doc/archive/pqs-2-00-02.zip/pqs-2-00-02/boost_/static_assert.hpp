#ifndef BOOST_STATIC_ASSERT_HPP
#define BOOST_STATIC_ASSERT_HPP

//  (C) Copyright John Maddock 2000.
//  Use, modification and distribution are subject to the 
//  Boost Software License, Version 1.0. (See accompanying file 
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/static_assert for documentation.

//mods Andy Little

//join macro
#include "pqs/meta/boost_join.hpp"

namespace boost{

    template <
        bool Condition
    > struct STATIC_ASSERTION_FAILURE;

    template<>
    struct STATIC_ASSERTION_FAILURE<
        true
    >
    {
        enum { value = 1 }; 
    };

    template<
        int x
    > struct static_assert_test{};

   #define BOOST_STATIC_ASSERT( B ) \
   typedef ::boost::static_assert_test<\
      sizeof(::boost::STATIC_ASSERTION_FAILURE< (bool)( B ) >)>\
        BOOST_JOIN( boost_static_assert_typedef, __LINE__ )

}//boost

#endif
