#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_TT_IS_ARITHMETIC_HPP_INCLUDED
#define BOOST_TT_IS_ARITHMETIC_HPP_INCLUDED

// modified Andy Little 2004
//
// (C) Copyright Steve Cleary, Beman Dawes, Howard Hinnant & John Maddock 2000.
// Permission to copy, use, modify, sell and distribute this software is 
// granted provided this copyright notice appears in all copies. This software 
// is provided "as is" without express or implied warranty, and with no claim 
// as to its suitability for any purpose.
//
// See http://www.boost.org for most recent version including documentation.

#include "boost/mpl/bool.hpp"
#include "is_integral.hpp"
#include "is_float.hpp"

namespace boost {

    template<typename T>
    struct is_arithmetic
    : mpl::bool_< 
        (is_integral<T>::value 
        || is_float<T>::value) 
    >{};
} // namespace boost



#endif // BOOST_TT_IS_ARITHMETIC_HPP_INCLUDED
