#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_TT_IS_CONST_HPP_INCLUDED
#define BOOST_TT_IS_CONST_HPP_INCLUDED

// modified Andy Little 2004
//
// (C) Copyright Dave Abrahams, Steve Cleary, Beman Dawes, Howard
// Hinnant & John Maddock 2000.  Permission to copy, use, modify,
// sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.
//
// See http://www.boost.org for most recent version including documentation.

#include "boost/mpl/bool.hpp"

namespace boost {

    template <typename T>
    struct  is_const : mpl::false_{};
    
    template <typename T>
    struct  is_const<const T> : mpl::true_{};

}//boost

#endif // BOOST_TT_IS_CONST_HPP_INCLUDED

