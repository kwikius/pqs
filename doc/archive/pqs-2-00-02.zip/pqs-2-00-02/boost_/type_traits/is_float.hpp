#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_TYPE_TRAITS_IS_FLOAT_HPP_INCLUDED
#define BOOST_TYPE_TRAITS_IS_FLOAT_HPP_INCLUDED

// modified Andy Little 2004
//
// (C) Copyright Steve Cleary, Beman Dawes, Howard Hinnant & John Maddock 2000.
// Permission to copy, use, modify, sell and distribute this software is 
// granted provided this copyright notice appears in all copies. This software 
// is provided "as is" without express or implied warranty, and with no claim 
// as to its suitability for any purpose.
//
// See http://www.boost.org for most recent version including documentation.

#include "boost/mpl/bool.hpp"

namespace boost {

    // Is a type T a floating-point type 
    // described in the standard (3.9.1p8)

    template<typename T>
    struct is_float;

}//boost

namespace boost {
  
    template<typename T>
    struct is_float : mpl::false_{};

    template<>
    struct is_float<float> : mpl::true_{};
    template<>
    struct is_float<float const> : mpl::true_{};
    template<>
    struct is_float<float volatile> : mpl::true_{};
    template<>
    struct is_float<float const volatile> : mpl::true_{};

    template<>
    struct is_float<double> : mpl::true_{};
    template<>
    struct is_float<double const> : mpl::true_{};
    template<>
    struct is_float<double volatile> : mpl::true_{};
    template<>
    struct is_float<double const volatile> : mpl::true_{};

    template<>
    struct is_float<long double> : mpl::true_{};
    template<>
    struct is_float<long double const> : mpl::true_{};
    template<>
    struct is_float<long double volatile> : mpl::true_{};
    template<>
    struct is_float<long double const volatile> : mpl::true_{};

} // namespace boost

#endif // BOOST_TYPE_TRAITS_IS_FLOAT_HPP_INCLUDED
