#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_TT_IS_INTEGRAL_HPP_INCLUDED
#define BOOST_TT_IS_INTEGRAL_HPP_INCLUDED

// modified Andy Little 2004
//
// (C) Copyright Steve Cleary, Beman Dawes, Howard Hinnant & John Maddock 2000.
// Permission to copy, use, modify, sell and distribute this software is 
// granted provided this copyright notice appears in all copies. This software 
// is provided "as is" without express or implied warranty, and with no claim 
// as to its suitability for any purpose.
//
// See http://www.boost.org for most recent version including documentation.

#include "boost/mpl/bool.hpp"

namespace boost {

    // Is a type an [cv-qualified-] integral type
    // as described in the standard (3.9.1p3)

    template<typename T>
    struct is_integral;

}//boost

namespace boost {

    template<typename T>
    struct is_integral : mpl::false_{};

    template<>
    struct is_integral<bool> : mpl::true_{};
    template<>
    struct is_integral<const bool> : mpl::true_{};
    template<>
    struct is_integral<volatile bool> : mpl::true_{};
    template<>
    struct is_integral<const volatile bool> : mpl::true_{};

    template<>
    struct is_integral<char> : mpl::true_{};
    template<>
    struct is_integral<const char> : mpl::true_{};
    template<>
    struct is_integral<volatile char> : mpl::true_{};
    template<>
    struct is_integral<const volatile char> : mpl::true_{};
    template<>
    struct is_integral<signed char> : mpl::true_{};
    template<>
    struct is_integral<const signed char> : mpl::true_{};
    template<>
    struct is_integral<volatile signed char> : mpl::true_{};
    template<>
    struct is_integral<const volatile signed char> : mpl::true_{};
    template<>
    struct is_integral<unsigned char> : mpl::true_{};
    template<>
    struct is_integral<const unsigned char> : mpl::true_{};
    template<>
    struct is_integral<volatile unsigned char> : mpl::true_{};
    template<>
    struct is_integral<const volatile unsigned char> : mpl::true_{};

    template<>
    struct is_integral<signed short> : mpl::true_{};
    template<>
    struct is_integral<const signed short> : mpl::true_{};
    template<>
    struct is_integral<volatile signed short> : mpl::true_{};
    template<>
    struct is_integral<const volatile signed short> : mpl::true_{};
    template<>
    struct is_integral<unsigned short> : mpl::true_{};
    template<>
    struct is_integral<const unsigned short> : mpl::true_{};
    template<>
    struct is_integral<volatile unsigned short> : mpl::true_{};
    template<>
    struct is_integral<const volatile unsigned short> : mpl::true_{};

    template<>
    struct is_integral<signed int> : mpl::true_{};
    template<>
    struct is_integral<const signed int> : mpl::true_{};
    template<>
    struct is_integral<volatile signed int> : mpl::true_{};
    template<>
    struct is_integral<const volatile signed int> : mpl::true_{};
    template<>
    struct is_integral<unsigned int> : mpl::true_{};
    template<>
    struct is_integral<const unsigned int> : mpl::true_{};
    template<>
    struct is_integral<volatile unsigned int> : mpl::true_{};
    template<>
    struct is_integral<const volatile unsigned int> : mpl::true_{};

    template<>
    struct is_integral<signed long> : mpl::true_{};
    template<>
    struct is_integral<const signed long> : mpl::true_{};
    template<>
    struct is_integral<volatile signed long> : mpl::true_{};
    template<>
    struct is_integral<const volatile signed long> : mpl::true_{};
    template<>
    struct is_integral<unsigned long> : mpl::true_{};
    template<>
    struct is_integral<const unsigned long> : mpl::true_{};
    template<>
    struct is_integral<volatile unsigned long> : mpl::true_{};
    template<>
    struct is_integral<const volatile unsigned long> : mpl::true_{};

#if !defined(_MSC_VER) || ((defined _MSVC_VER) && (defined _WCHAR_T_DEFINED))

    template<>
    struct is_integral<wchar_t> : mpl::true_{};
 
    template<>
    struct is_integral<const wchar_t> : mpl::true_{};

    template<>
    struct is_integral<volatile wchar_t> : mpl::true_{};
    template<>
    struct is_integral<const volatile wchar_t> : mpl::true_{};

#endif

} //boost

#endif // BOOST_TT_IS_INTEGRAL_HPP_INCLUDED
