#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_TT_IS_SAME_HPP_INCLUDED
#define BOOST_TT_IS_SAME_HPP_INCLUDED
// modified by Andy Little
// original copyright follows

// (C) Copyright Steve Cleary, Beman Dawes, Aleksey Gurtovoy, 
// Howard Hinnant & John Maddock 2000.
// Permission to copy, use, modify, sell and distribute this software is 
// granted provided this copyright notice appears in all copies. This 
// software is provided "as is" without express or implied warranty, and 
// with no claim as to its suitability for any purpose.
//
// See http://www.boost.org for most recent version including documentation.

#include "boost/mpl/bool.hpp"

namespace boost {

    template< 
        typename T,
        typename U 
    > 
    struct is_same : mpl::false_{}; 

    template <typename T>
    struct is_same<T,T> : mpl::true_{}; 
    
} // namespace boost


#endif  // BOOST_TT_IS_SAME_HPP_INCLUDED

