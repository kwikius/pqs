#ifndef BOOST_RESULT_OF_HPP
#define BOOST_RESULT_OF_HPP

// Modified and Much simplified from:

// Boost result_of library

//  Copyright Doug Gregor 2004. Use, modification and
//  distribution is subject to the Boost Software License, Version
//  1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

// For more information, see http://www.boost.org/libs/utility


namespace boost{

    template<typename F> struct result_of{
        typedef typename F::result_type type;
    };
    template<typename F,typename A>
    struct result_of<F(A)>{
        typedef typename F::result<F(A)>::type type;
    };
    template<typename F,typename A, typename B>
    struct result_of<F(A,B)>{
        typedef typename F::result<F(A,B)>::type type;
    };
   
}

#endif
