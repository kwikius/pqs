

// Simple Demo of
// ConceptChecking classes, What they are about and how to use them

// modified from the boost version which is
//
// (C) Copyright Jeremy Siek 2000. Permission to copy, use, modify,
// sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.

// See http://www.boost.org/libs/concept_check


// The "concept" namespace is used here to hold the Concept Checking implementation
// (I have taken liberties with the boost version, for reasons of legibility and to avoid clashes
// with the oficial version in boost namespace in showing the implementation)
#include <iostream>
namespace concept{

    // First, examples of some ConceptChecking classes themselves:
    // C++ doesnt support concept checking natively, so the idea is to
    // come up with something that will test the Concept that is modelled
    // as closely as possible. See the boost link above for other examples

    // The example concept checking classes test the simplest possible concept:
    // whether the input template parameter is true or false

    // "TrueConcept" modelling the Concept that the
    //  boolean template parameter "Assertion" must be true.
    // (for a successful compilation)
    template< bool Assertion>
    struct TrueConcept{ 

        // every concept checking class template has a member function called "constraints"
        // with this signature. 
        void constraints()
        {   // Concept Check Fails if boolean "Assertion" template parameter is false;
            // (because a zero sized array is invalid in C++. (see assertion typedef below ))
            // If Assertion is true converts to 1 sized array so passes.
            // The variable is given a useful name as a hint, 
            // because concept checking is all about
            // trying to provide useful error messages
            assertion assertion_failed;

            // see below for what this is about
            ignore_unused_variable_warning(assertion_failed[0]);   
        }
        typedef char assertion [Assertion] ;
    };

    // "FalseConcept"  same as above but modelling the Concept that
    // the template parameter Assertion must be false 
    // (for a successful compilation)
    template< bool Assertion>
    struct FalseConcept{  
        void constraints()
        {// Concept Check Fails if boolean Assertion template parameter is false;
            // for same reasons as above
            assertion assertion_failed;
            ignore_unused_variable_warning(assertion_failed[0]);   
        }
        typedef char assertion [!Assertion] ;
    };

    // This horribly named function just suppresses unused variable warnings
    //  in Concept Checking classes
    // otherwise clever compiler notices that a variable is never used.
    
    template<typename T> 
    inline void ignore_unused_variable_warning(const T&){};

    // Finally the "function_requires" function which is added in contexts where
    // concept checking is required as shown below.
    // It creates a pointer to the member function
    // "constraints" in the particular concept required
    // but this means that the compiler must search for and compile the function
    // Importantly though the function is never iactually nvoked
    // as only a pointer is created.
    // ignore_unused_variable_warning is described above
    template <typename Concept>
    inline void function_requires()
    {
        void (Concept::*pf_concept_constraints)() = &Concept::constraints;
        ignore_unused_variable_warning(pf_concept_constraints);
    }

}//~concept

// Using a concept involves placing it in an expression.
// The class constructor is used here as the most useful place to test the Concept

template<bool Condition>
struct MyTrueConcept {
    MyTrueConcept()
    {
        concept::function_requires<concept::TrueConcept<Condition> >();
    }
};

template<bool Condition>
struct MyFalseConcept {
    MyFalseConcept()
    {
        concept::function_requires<concept::FalseConcept<Condition> >();
    }
};

// BTW This one will Never compile ;-)
template<bool Condition>
struct MyTrueFalseConcept {
    MyTrueFalseConcept()
    {   
        concept::function_requires<concept::TrueConcept<Condition> >();
        concept::function_requires<concept::FalseConcept<Condition> >();
    }      
};

// testing the Concepts 
int main()
{
/*
    As it stands this wont compile
    Try compiling it and then look at the error messages
    Usually there are quite a few per error as the compiler goes through an
    "instantiation stack", But the one nearer the end should point
    to one of the lines below.(In fact it is usually more useful 
    to start at the bottom of the error message and work up!)
    Comment out the indicated points and eventually it should compile ok.

    BTW You may not think too much of the "improved error messages"
    but it is much better than nothing, ie finding out at runtime.
    
 */

    MyTrueConcept<true> tt;        // ok
    MyTrueConcept<false> tf;       // nope
    MyFalseConcept<false> ff;      // ok
    MyFalseConcept<true> ft;       // nope
    MyTrueFalseConcept<true>tft;   // nope
    MyTrueFalseConcept<false>tff;  // nope

    std::cout << "succesful compile\n";
}
