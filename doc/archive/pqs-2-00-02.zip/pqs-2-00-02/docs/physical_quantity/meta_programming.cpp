 //First create a class-template declaration representing the expression.
 //There is no need to define the class-template here because only specialisations are ever used.
 //the formatting of template parameters helps legibiloity in more complicated meta-programming. 
 //structs rather than classes are usually used because members are designed to be public
 
    template< 
        bool Condition, 
        typename True_type,
        typename False_type
    >
    struct If_else;

//The class-template If_else can now be partially-specialised on the bool Condition parameter,
//for both true and false conditions: 

//The partial-specialisation for true conditions. 
//The member typedef 'type' will be the True_type template parameter:

    template< 
        typename True_type,
        typename False_type
    >
    struct If_else<
        true, 
        True_type, 
        False_type
    >{
        typedef True_type type;
    };

//The partial-specialisation for false conditions. 
//The member typedef 'type' will be the False_type template parameter.

    template<
        typename True_type,
        typename False_type
    >
    struct If_else<
        false,
        True_type, 
        False_type
    >{
        typedef False_type type;
    };


//The template can now be used for compile-time decisions. 
//The specialisation used will depend on the true or false result of the Condition parameter.
//in If_else. The condition parameter can be anything that can be converted to a bool at
//compile-time. Note the frequent use of chained typedefs. 
//This is a much used idiom in meta-programming.
     
// For example Larger_or_eq a class that selects the larger of the two types if not same size 
    template<
        typename A,
        typename B
    >
    struct Larger_or_eq{
        typedef typename If_else<      // note use of 'typedef typename' inside template
            ( sizeof(A) >= sizeof(B) ), // condition is computed at compile time
            A, 
            B
        >::type type;                   // resulting 'type' will be larger of A, B

    };



#include <iostream>
int main()

{
    // the larger of a char and a double
    typedef Larger_or_eq<char, double>::type larger_char_double_type;
    // the larger of a double and a char which should be the same of course
    typedef Larger_or_eq<double, char>::type larger_double_char_type;

    std::cout << typeid(larger_char_double_type).name() << '\n';
    std::cout << typeid(larger_double_char_type).name() << '\n';

}


