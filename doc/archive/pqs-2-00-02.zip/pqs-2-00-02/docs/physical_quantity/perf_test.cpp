#include "test.hpp"
#include "pqs/pqs.hpp"
#include <ctime>
#include <iostream>

int main()
{   
    double double_score = 0;
    double pq_score = 0;
        
    for (int i = 0; i < 10 ; ++i){
 
        std::cout << "pass : " << i <<'\n';
        double_score += double_timing();
        pq_score += pq_timing();
        
    }
    std::cout << "pqs time : " << pq_score <<'\n';
    std::cout << "double time : " << double_score  <<'\n';
    std::cout << "ratio pqs/double = " << pq_score / double_score << "\n";
  
} 

double pq_timing()
{    
    const int n = 10000;

    pqs::q_velocity::m_div_s vpq;

    std::clock_t f0_start = std::clock();
    for (int i = 0 ; i < n ; ++i ){
        std::cout << i << ' ' <<  vpq.numeric_value() <<'\n';
    }
    std::clock_t f0_end = std::clock();
    
    std::clock_t f_start = std::clock();
    for (int i = 0 ; i < n ; ++i ){
        pqs::q_length::mm L1(1);
        pqs::q_time::s  T(200);
        vpq = L1 / T;
        std::cout << i << ' ' <<  vpq.numeric_value() <<'\n';
    }
    std::clock_t f_end = std::clock();

    double pqs_t 
    = static_cast<double>(((f_end - f_start)-(f0_end - f0_start)))/CLOCKS_PER_SEC;
   
    std::cout << "pqs timing :  " << pqs_t << '\n';
    return pqs_t;
  
} 
double  double_timing()
{    
    const int n = 10000;

    double v=0;
    std::clock_t i0_start = std::clock();
    for (int i = 0 ; i < n ; ++i ){
        std::cout << i << ' ' <<  v <<'\n';
    }
    std::clock_t i0_end = std::clock();
    std::clock_t i_start = std::clock();
    for (int i = 0 ; i < n ; ++i ){
        double L1 = 1;
        double T = 200;
        v = L1 / (T *1000);
        std::cout << i << ' ' <<  v <<'\n';
    }
    std::clock_t i_end = std::clock();

    double d_t
    = static_cast<double>(((i_end - i_start)-(i0_end - i0_start)))/CLOCKS_PER_SEC;
    std::cout << "double timing : " << d_t << '\n';
    return d_t;
}