
#include "pqs/pqs.hpp"
#include "pqs/util/timer.hpp"
/*
    After optimisation, times are very similar for double and pq
    The tricky part is to make sure that the compiler doesnt optimise 
    the loop away entirely.
*/
#include <iostream>
pqs::time::ms timing(int n, double (*)(const double &));
inline double pq_func(const double &);
inline double double_func(const double&);
int main()
{   
    pqs::time::ms double_score;
    pqs::time::ms pq_score;
    const int n = 1000000;   
    for (int i = 0; i < 100 ; ++i){
        double_score += timing(n,double_func);
        pq_score += timing(n,pq_func);
        std::cout << i <<'\n'; // just for some display feedback
    }
    std::cout << "pqs time : " << pq_score <<'\n';
    std::cout << "double time : " << double_score  <<'\n';
    if (double_score != pqs::time::ms(0) ){
        std::cout << "ratio pq:double = "  << pq_score / double_score << "\n";
    }
  
} 
inline double pq_func(const double & d)
{
    pqs::length::m length(d);
    pqs::time::s   time(200. + d);
    pqs::velocity::mm_div_s velocity = length / time + pqs::velocity::m_div_s(d);
    return velocity.numeric_value();
}

inline double double_func(const double & d)
{
   double length = d;
   double time = 200. + d;
   double velocity = (length / time  + d) * 1000;
   return velocity;
}

pqs::time::ms timing(int n,double (*pf)(const double &))
{    
    double d = rand();
    pqs::timer timer;
    for (int i = 0 ; i < n ; ++i ){
        double dd = pf(d);
        d = pf(dd);
    }
    timer.stop();
    return timer(); 
} 

