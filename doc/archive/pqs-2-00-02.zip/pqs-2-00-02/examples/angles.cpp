//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.
/*
    angles workout demo
*/
// define following to provide an operator Value_type() in radians class
// This means that radians can be implicitly converted to numeric
// means that eg radians + numeric --> numeric etc
// but other "fraction _of_revolution" angles cannot
#define PQS_IMPLICIT_RADIANS_STRAIGHTENING
#include "pqs/pqs.hpp"
//angles w' output
#include "pqs/math/angles/angles_out.hpp"
#include "pqs/math/constant.hpp"

//######################
// compilation/link of these two required for pi definitions
// for linking. radians strongly associated with pi
// Note: two types of 'pi' here, angle and numeric)
// this is a tricky one ie requires compilation for any calc involving radians
// however probably best for accuracy to have only one definition of pi
// ...to solve
#define NO_PQS_CONSTANTS_LIBRARY

#ifdef NO_PQS_CONSTANTS_LIBRARY
    #include "pqs/math/lib_src/constant.cpp"
    #include "pqs/math/angles/lib_src/angles.cpp"
#endif
//#######################

using pqs::length_;
using pqs::length;
using pqs::math::of_angle;
using pqs::math::of_angle_;
using pqs::math::constant;

int main()
{
    std::cout.setf(std::ios_base::fixed,std::ios_base::floatfield);
    std::cout.precision(6);
    of_angle::rad  angle1(1) ;
    std::cout << "1 radian : " << angle1 << '\n';
    std::cout << "1/of_angle::rad(1): " << 1/of_angle::rad(1) <<'\n';;
    length_<of_angle::rad>::m L1 = length::m(1) * angle1;
    std::cout << "angular quantity : " << L1 << '\n';
    length_<of_angle::rad>::m Lx(of_angle::rad(1));
   // pqs::math::of_angle::one / length::m(1);
    std::cout << " via explicit ctor " <<  Lx << '\n';
    std::cout << "squared : " <<  Lx * Lx << '\n';
    length::m  L2 = L1 / of_angle::rad(1);
    std::cout << "L2 straightened version of L1 = " << L2 << '\n';
    std::cout << length::m(1) / angle1 << '\n';
#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
    std::cout << " using implicit radians straightening\n";
    L2 = L1;
    std::cout << "L1 = " << L1 << ", L2 = " << L2 <<'\n';
#endif
    std::cout << "angularised : " << length::m(1) * angle1 <<'\n';
    std::cout << "angle * angle : " << angle1 * angle1 << '\n';
    std::cout << "angle / angle : " << angle1 / angle1 << '\n';
    length_<of_angle::deg>::m Lxx = length::m(1) * angle1;
    std::cout << "Lxx straightened (auto promotion/conversion to double)  = "
    << Lxx / of_angle::rad(1) << '\n';
    std::cout << " note probably Very unwise ... but doable...\n";
    length_<of_angle_<int>::deg>::m L3(of_angle_<int>::deg(90));
    std::cout << "L3 (degrees value_type)  = " << L3 << '\n';
    std::cout << "L3 \"straightened\" : "<<  L3 / of_angle::rad(1) <<'\n';
#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
    std::cout << " using implicit radians straightening "
    "but must be converted to radians for implicit conversion\n";
    L2 = length_<of_angle::rad>::m(L3);
    std::cout << "L2= " << L2 << ", L3 = " << L3 <<'\n';
#endif

    length_<of_angle::rad>::m L4  = L3;
    std::cout << "L4 (value_type deg to rad) = " << L4 << '\n';
    std::cout << "L3 / L4           = " << L3/L4 <<'\n';
    std::cout << "L3 * (1/L4)       = " << L3 * (1/L4) <<'\n';
  
    of_angle::deg  deg(90);
    of_angle::rad  rad1 = deg;
    std::cout << "deg               = " <<  deg << '\n';
    std::cout << "rad1 (==deg)      = " << rad1 <<'\n';
    std::cout << "deg / rad1        = " << deg / rad1 <<'\n';
    std::cout << "rad1 / deg        = " << rad1 / deg <<'\n';
    std::cout << "1 / deg           = " << 1 / deg <<'\n';
    std::cout << "(1 / deg) * deg   = " << (1/deg) * deg <<'\n';
    std::cout << "deg  * (1/deg)    = " << deg * (1/deg) <<'\n';
    std::cout << "(1 / deg) * rad1  = " << (1/deg) * rad1 <<'\n';
    std::cout << "(1 / rad1) * deg  = " << (1/rad1) * deg <<'\n';

    
#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
    length::m  TestLen(of_angle::rad(1));
#endif

}
