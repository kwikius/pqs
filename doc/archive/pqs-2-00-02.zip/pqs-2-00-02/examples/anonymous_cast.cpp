#include "pqs/pqs.hpp"
using namespace pqs;
int main()
{
    q_length::mm L1(1);
    q_length::m  L2(1);
    
    std::cout << L1 + L2 <<'\n';
    std::cout << L2 + L1 <<'\n';
    q_length::in L3(1);
    std::cout << L2 + L3 <<'\n';
    std::cout << L3 + L2 <<'\n';
    q_length::ft L4(1);
    std::cout << L3 + L4 <<'\n';
    std::cout << L4 + L3 <<'\n';

    q_acceleration::Gal  A1(1);
    q_acceleration::in_div_s2 A2(2);
    std::cout << A1 + A2 <<'\n';
    std::cout << A2 + A1 <<'\n';
    q_torque::mN_m T(1);
    q_energy::J   J (1);
    std::cout << T + anonymous_cast(J) <<'\n';
    std::cout << T + J <<'\n';
    std::cout << anonymous_cast(J)+ T <<'\n';
    std::cout << J + anonymous_cast(T) <<'\n';
    std::cout << anonymous_cast(T)+ J <<'\n';
    std::cout << anonymous_cast(T)+ anonymous_cast(J) <<'\n';
    
    //std::cout << q_energy::J(T + anonymous_cast(J) ) <<'\n';
    
}

