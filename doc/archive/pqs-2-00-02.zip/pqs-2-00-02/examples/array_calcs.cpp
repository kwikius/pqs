//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/* 
    Very basic expression templates for arrays of ct-quantities (or inbuilts)
    using an Array class. The expression template builds the expression 
    and then executes it all at oncein the assignment,(therefore  there 
    must be an assignment for each expression). This reduces copying and 
    hence enables much faster execution.Because these arrays are small,
    the copying outweighs the advantage here,however for large arrays 
    the results should be much faster calc.The actual data is kept externally
    to the 'Array', which is just a pointer to the data.
*/

/* modifiedfrom http://osl.iu.edu/~tveldhui/papers/techniques/ */


#include "pqs/pqs.hpp"
// uses binary_operator to implement the expression templates
// uncomment the following define to show the expression template workings
#define PQS_ARRAY_CALCS_SHOW_WORKING
#include "array_calcs.hpp"
#include <iostream>
#include <fstream>

int main()
{
    // these can be modified .. but check dimensional analysis
    typedef pqs::length::m  type_a;
    typedef pqs::length::m  type_b;
    typedef pqs::length::m  type_c;
    typedef pqs::area::m2   type_d;
    typedef double          type_e;

// also works with other types which have binary_operation<A,Op,B> defined
/*
    typedef double  type_a;
    typedef double  type_b;
    typedef double  type_c;
    typedef double  type_d;
    typedef double  type_e; */
    
    std::ostream& os = std::cout;
   // std::ofstream os("output.txt");
    os << "pqs Array demo\n\n";
    static const int Size = 4; // size of array
    // the array data
    type_a a_data[Size] = { type_a(2),type_a(3),type_a(5),type_a(9)};
    type_b b_data[Size] = { type_b(1),type_b(1),type_b(1),type_b(2)};
    type_c c_data[Size] = { type_c(3),type_c(1),type_c(2),type_c(5)};
    type_d d_data[Size];
    type_e e_data[Size];
    
#ifdef PQS_ARRAY_CALCS_SHOW_WORKING
    pqs::Array<type_a,Size> A(a_data, "A",os);
    pqs::Array<type_b,Size> B(b_data, "B",os);
    pqs::Array<type_c,Size> C(c_data, "C",os);
    pqs::Array<type_d,Size> D(d_data, "D",os);
    pqs::Array<type_e,Size> E(e_data, "E",os);
#else
    pqs::Array<type_a,Size> A(a_data);
    pqs::Array<type_b,Size> B(b_data);
    pqs::Array<type_c,Size> C(c_data);
    pqs::Array<type_d,Size> D(d_data);
    pqs::Array<type_e,Size> E(e_data);
#endif
 
    os << "C = A - B;\n";
    C = A - B;
    for (int i=0; i < 4; ++i){
        os <<  C[i]<< " = " << A[i] << " - " << B[i] <<  "\n";
    }
    os << "\n---\nD = A * B;\n";
    D = A * B;
    
    for (int i=0; i < 4; ++i){
        os << D[i]<< " = " << A[i] << " * " << B[i]   << "\n";
    }
    os << "\n---\nD = A * (B + C);\n";
    D = A * (B + C);
    for (int i=0; i < 4; ++i){
        os << D[i] << " = " << A[i] << " * (" << B[i] << " + " << C[i] << ")\n";
    }
    os << "\n---\nE = A / (B + C);\n";
    E = A / (B + C);
    for (int i=0; i < 4; ++i){
        os << E[i] << " = " << A[i] << " / (" << B[i] << " + " << C[i] << ")\n";
    }
    os << "\n---\nE = (A * B) / ( C* ( A + B));\n"; 
    E = (A * B)/( C* ( A + B));
    
    for (int i=0; i < 4; ++i){
        os << E[i] << " = (" << A[i] << " * " << B[i] << ")" 
        " / ( " << C[i] << " * (" << A[i] << " + " << B[i] << "))\n";
    }
    return 0;
}








