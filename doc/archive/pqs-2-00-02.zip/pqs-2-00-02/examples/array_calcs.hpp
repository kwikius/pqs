#ifndef PQS_ARRAY_CALCS_HPP_INCLUDED
#define PQS_ARRAY_CALCS_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    Very basic expression templates for arrays of ct-quantities or inbuilts
    modified from http://osl.iu.edu/~tveldhui/papers/techniques/ 
    #define PQS_ARRAY_CALCS_SHOW_WORKING in source before the this header
    to get a view of whats happening in the expression template
*/

#include "pqs/operators/binary_operators.hpp"
#include "pqs/operators/operator_symbol_traits.hpp"
#include "boost/mpl/if.hpp"
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
#include <iostream>
#endif

namespace pqs{
    // is this a nominal " l_value"
    template <typename T>
    struct is_concrete_element{
        static const bool value = true;
    };

    template<
        typename Left, 
        template <typename> class Op, 
        typename Right
    >
    struct binary_array_node {

        typedef binary_operator<
            typename Left::element_type,
            Op,
            typename Right::element_type
        > operator_fx;
        typedef typename operator_fx::result_type element_type;
        
        binary_array_node (const binary_array_node& in)
        :left(in.left),right(in.right)
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
        ,name(in.name), os(in.os)
#endif
        {
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING 
            name += ",copy";
            os << "NODE COPY CTOR : " << name << "\n";
#endif     
        }
        binary_array_node(Left & l, Right & r)
        : left(l), right(r)
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
        ,os(l.os)
#endif
        {
#ifdef PQS_ARRAY_CALCS_SHOW_WORKING 
            name = "{";
            name += left.name ;
            name += " ";
            name += operator_symbol<Op>()();
            name += " ";
            name += right.name ;
            name += "}";
#endif
        }

        element_type  operator[](int i)const
        { 
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
           os <<  " get " << name << "[" << i << "]\n";
#endif
           return operator_fx()(left[i],right[i]); 
        }
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
        std::string name;
        std::ostream & os;
#endif
        typename boost::mpl::if_<
            is_concrete_element<Left>,
            Left &,
            Left const
        >::type left;
        typename boost::mpl::if_<
            is_concrete_element<Right>,
            Right &,
            Right const
        >::type right; 
        /*Left left;
        Right right; */
    };

    template<
        typename Left, 
        template <typename> class Op, 
        typename Right
    >
    struct is_concrete_element<
        binary_array_node<Left,Op,Right> 
    >{
        static const bool value = false;
    };
}//pqs

namespace pqs{
    template<typename Elements, int Size>
    struct Array {
    private:
    Array();
    public:
        typedef Elements element_type;
       
        Array(Elements (& d)[Size]
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
        ,const char* name_in, std::ostream& os_in
#endif
        )    : data(d)
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
        ,name(name_in), os(os_in)
#endif
        { }
        template<typename Expr>
        Array& operator=( Expr const & expression)
        {
            for (int i=0; i < Size; ++i){
                data[i] = expression[i];
            } 
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
           
            os << name << " Expr assigned : " 
            << expression.name << "\n..........\n";
#endif
            return *this;
        }

        Array & operator=( Array const&  in)
        {
            for (int i=0; i < Size; ++i){ 
                data[i] = in[i];
            } 
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
            os << name << " Array assigned\n..........\n";
            name = in.name;
#endif
        }
        Array( const Array& in)
        : data (in.data)
#ifdef PQS_ARRAY_CALCS_SHOW_WORKING
            , name(in.name), os(in.os)
#endif
        {
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
            name += ",copy";
           os << "ARRAY COPY CTOR : " << name << "\n";
#endif
        }
        element_type & operator[](int i)const
        {
            return data[i]; 
        }
      
        element_type (& data)[Size];
#ifdef  PQS_ARRAY_CALCS_SHOW_WORKING
        std::string  name;
        std::ostream& os;
#endif
    };

    template<
    typename Elements, int Size
    >
    struct is_concrete_element<
        Array<Elements,Size> 
    >{
        typedef  Array<Elements,Size> array_type;
        static const bool value = false;
    };
}//pqs

namespace pqs{ namespace meta{

/* 
specialisation of binary_operation is the key to these expression templates

*/
    template<
        typename LeftExprL, template <typename> class LeftOp,typename LeftExprR,
        template <typename> class Op,
        typename RightExprL, template <typename> class RightOp,typename RightExprR
    >
    struct binary_operation<
        binary_array_node<LeftExprL,LeftOp,LeftExprR>,
        Op,
        binary_array_node<RightExprL,RightOp,RightExprR>
    >
    {
        typedef binary_array_node<
            binary_array_node<LeftExprL,LeftOp,LeftExprR>,
            Op,
            binary_array_node<RightExprL,RightOp,RightExprR> 
        > result_type;
            
    };
        
    template<
        int Size,typename ElementsA, 
        template<typename> class Op, 
        typename ElementsB
    >
    struct binary_operation<
        Array<ElementsA,Size>,
        Op,
        Array<ElementsB,Size>
    >{
        typedef binary_array_node<
            Array<ElementsA,Size>,
            Op, 
            Array<ElementsB,Size> 
        > result_type;
     };

}}//pqs::meta

namespace pqs{

    template<
        typename LeftExprL, template <typename> class LeftOp,typename LeftExprR,
        typename RightExprL, template <typename> class RightOp,typename RightExprR
    >
    typename  pqs::meta::binary_operation<
        binary_array_node<LeftExprL,LeftOp,LeftExprR>,
        std::plus,
        binary_array_node<RightExprL,RightOp,RightExprR> 
    >::result_type

    operator + (binary_array_node<LeftExprL,LeftOp,LeftExprR> l,
                 binary_array_node<RightExprL,RightOp,RightExprR> r)
    {
        return pqs::meta::binary_operation<
            binary_array_node<LeftExprL,LeftOp,LeftExprR>,
            std::plus,
            binary_array_node<RightExprL,RightOp,RightExprR> 
        >::result_type(l,r);      
    };

    template<
        typename LeftExprL, template <typename> class LeftOp,typename LeftExprR,
        typename RightExprL, template <typename> class RightOp,typename RightExprR
    >
    typename  pqs::meta::binary_operation<
        binary_array_node<LeftExprL,LeftOp,LeftExprR>,
        std::minus,
        binary_array_node<RightExprL,RightOp,RightExprR> 
    >::result_type

    operator - (binary_array_node<LeftExprL,LeftOp,LeftExprR> l,
                 binary_array_node<RightExprL,RightOp,RightExprR> r)
    {
        return pqs::meta::binary_operation<
            binary_array_node<LeftExprL,LeftOp,LeftExprR>,
            std::minus,
            binary_array_node<RightExprL,RightOp,RightExprR> 
        >::result_type(l,r);      
    };

    template<
        typename LeftExprL, template <typename> class LeftOp,typename LeftExprR,
        typename RightExprL, template <typename> class RightOp,typename RightExprR
    >
    typename  pqs::meta::binary_operation<
        binary_array_node<LeftExprL,LeftOp,LeftExprR>,
        std::multiplies,
        binary_array_node<RightExprL,RightOp,RightExprR> 
    >::result_type

    operator *(binary_array_node<LeftExprL,LeftOp,LeftExprR> l,
                 binary_array_node<RightExprL,RightOp,RightExprR> r)
    {
        return pqs::meta::binary_operation<
            binary_array_node<LeftExprL,LeftOp,LeftExprR>,std::multiplies,
            binary_array_node<RightExprL,RightOp,RightExprR> 
        >::result_type(l,r);      
    };

    template<
        typename LeftExprL, template <typename> class LeftOp,typename LeftExprR,
        typename RightExprL, template <typename> class RightOp,typename RightExprR
    >
    typename  pqs::meta::binary_operation<
        binary_array_node<LeftExprL,LeftOp,LeftExprR>,
        std::divides,
        binary_array_node<RightExprL,RightOp,RightExprR> 
    >::result_type

    operator / (binary_array_node<LeftExprL,LeftOp,LeftExprR> l,
                 binary_array_node<RightExprL,RightOp,RightExprR> r)
    {
        return pqs::meta::binary_operation<
            binary_array_node<LeftExprL,LeftOp,LeftExprR>,
            std::divides,
            binary_array_node<RightExprL,RightOp,RightExprR> 
        >::result_type(l,r);      
    };


   // array by array
    template<
        int Size,
        typename ElementsA, 
        typename ElementsB
    >
    typename pqs::meta::binary_operation<
            Array<ElementsA,Size>
            , std::plus, 
            Array<ElementsB,Size> 
    > ::result_type
    operator+(Array<ElementsA,Size> a, Array<ElementsB,Size> b)
    {
        return typename pqs::meta::binary_operation<
            Array<ElementsA,Size>,
            std::plus, 
            Array<ElementsB,Size> 
        >::result_type(a,b);
    }

    template<
        int Size,
        typename ElementsA, 
        typename ElementsB
    >
    typename pqs::meta::binary_operation<
            Array<ElementsA,Size>,
            std::minus, 
            Array<ElementsB,Size> 
    > ::result_type
    operator-(Array<ElementsA,Size> a, Array<ElementsB,Size> b)
    {
        return typename pqs::meta::binary_operation<
            Array<ElementsA,Size>,
            std::minus, 
            Array<ElementsB,Size> 
        >::result_type(a,b);
    }

    template<
        int Size,
        typename ElementsA,
        typename ElementsB
    >
    typename pqs::meta::binary_operation<
            Array<ElementsA,Size>,
            std::multiplies, 
            Array<ElementsB,Size> 
    > ::result_type
    operator*(Array<ElementsA,Size> a, Array<ElementsB,Size> b)
    {
        return pqs::meta::binary_operation<
            Array<ElementsA,Size>,
            std::multiplies, 
            Array<ElementsB,Size> 
        > ::result_type(a,b);
    }
    
    template<
        int Size,
        typename ElementsA,
        typename ElementsB
    >
    typename pqs::meta::binary_operation<
            Array<ElementsA,Size>,
            std::divides, 
            Array<ElementsB,Size> 
    > ::result_type
    operator/(Array<ElementsA,Size> a, Array<ElementsB,Size> b)
    {
        return pqs::meta::binary_operation<
            Array<ElementsA,Size>,
            std::divides, 
            Array<ElementsB,Size> 
        > ::result_type(a,b);
    }
}//pqs

namespace pqs{ namespace meta{

        template <
            typename ArrayElements,int Size,
            template<typename> class Op, 
            typename ExprDataL,
            template<typename>class ExprOp,
            typename ExprDataR
        >
        struct binary_operation<
            Array<ArrayElements,Size>,Op, binary_array_node<ExprDataL,ExprOp, ExprDataR>
        >
        {
            typedef binary_array_node< 
                Array<ArrayElements,Size>,
                Op,
                binary_array_node<ExprDataL,ExprOp, ExprDataR>
            > result_type;
        };

        template <
            typename ExprDataL,
            template<typename>class ExprOp,
            typename ExprDataR,
            template<typename> class Op, 
            typename ArrayElements,int Size
        >
        struct binary_operation<
        binary_array_node<ExprDataL,ExprOp, ExprDataR>,Op, Array<ArrayElements,Size> 
        >
        {
            typedef binary_array_node<
                binary_array_node<ExprDataL,ExprOp, ExprDataR>,
                Op,
                Array<ArrayElements,Size> 
            > result_type;
        };

}}//pqs::meta

namespace pqs{

    template< 
        typename ExprDataL,
        template<typename>class ExprOp,
        typename ExprDataR,
        typename ArrayElements,int Size
    >
    typename pqs::meta::binary_operation<
        binary_array_node<ExprDataL,ExprOp, ExprDataR>,
        std::plus, 
        Array<ArrayElements,Size> 
    >::result_type
    operator +(binary_array_node<ExprDataL,ExprOp, ExprDataR> e ,Array<ArrayElements,Size> a )
    {
        return typename pqs::meta::binary_operation<
            binary_array_node<ExprDataL,ExprOp, ExprDataR>,
            std::plus,
            Array<ArrayElements,Size> 
        >::result_type(e,a);
    }

    template< 
        typename ExprDataL,
        template<typename>class ExprOp,
        typename ExprDataR,
        typename ArrayElements,int Size
    >
    typename pqs::meta::binary_operation<
        binary_array_node<ExprDataL,ExprOp, ExprDataR>,
        std::minus, 
        Array<ArrayElements,Size> 
    >::result_type
    operator -(binary_array_node<ExprDataL,ExprOp, ExprDataR> e ,Array<ArrayElements,Size> a )
    {
        return typename pqs::meta::binary_operation<
            binary_array_node<ExprDataL,ExprOp, ExprDataR>,
            std::minus,
            Array<ArrayElements,Size> 
        >::result_type(e,a);
    } 

    template< 
        typename ExprDataL,
        template<typename>class ExprOp,
        typename ExprDataR,
        typename ArrayElements,int Size
    >
    typename pqs::meta::binary_operation<
        binary_array_node<ExprDataL,ExprOp, ExprDataR>,
        std::multiplies,
        Array<ArrayElements,Size> 
    >::result_type
    operator *(binary_array_node<ExprDataL,ExprOp, ExprDataR> e ,Array<ArrayElements,Size> a )
    {
        return typename pqs::meta::binary_operation<
            binary_array_node<ExprDataL,ExprOp, ExprDataR>,
            std::multiplies,
            Array<ArrayElements,Size> 
        >::result_type(e,a);
    }

    template< 
        typename ExprDataL,
        template<typename>class ExprOp,
        typename ExprDataR,
        typename ArrayElements,int Size
    >
    typename pqs::meta::binary_operation<
        binary_array_node<ExprDataL,ExprOp, ExprDataR>,
        std::divides,
        Array<ArrayElements,Size> 
    >::result_type
    operator /(binary_array_node<ExprDataL,ExprOp, ExprDataR> e ,Array<ArrayElements,Size> a )
    {
        return typename pqs::meta::binary_operation<
            binary_array_node<ExprDataL,ExprOp, ExprDataR>,std::divides, Array<ArrayElements,Size> 
        >::result_type(e,a);
    } 
   
    template< 
        typename ArrayElements,int Size,
         typename ExprDataL,
        template<typename>class ExprOp,
        typename ExprDataR
    >
    typename pqs::meta::binary_operation<
        Array<ArrayElements,Size>,
        std::plus,
        binary_array_node<ExprDataL,ExprOp, ExprDataR>  
    >::result_type
    operator +(Array<ArrayElements,Size> a,binary_array_node<ExprDataL,ExprOp, ExprDataR> e  )
    {
        return typename pqs::meta::binary_operation<
            Array<ArrayElements,Size>,
            std::plus,
            binary_array_node<ExprDataL,ExprOp, ExprDataR>  
        >::result_type(a,e);
    }  

    template< 
        typename ArrayElements,int Size,
         typename ExprDataL,
        template<typename>class ExprOp,
        typename ExprDataR
    >
    typename pqs::meta::binary_operation<
        Array<ArrayElements,Size>,
        std::minus,
        binary_array_node<ExprDataL,ExprOp,ExprDataR>  
    >::result_type
    operator -(Array<ArrayElements,Size> a,binary_array_node<ExprDataL,ExprOp, ExprDataR> e  )
    {
        return typename pqs::meta::binary_operation<
            Array<ArrayElements,Size>,
            std::minus,
            binary_array_node<ExprDataL,ExprOp, ExprDataR>  
        >::result_type(a,e);
    }        

    template< 
        typename ArrayElements,int Size,
        typename ExprDataL,
        template<typename>class ExprOp,
        typename ExprDataR
    >
    typename pqs::meta::binary_operation<
        Array<ArrayElements,Size>,
        std::multiplies,
        binary_array_node<ExprDataL,ExprOp, ExprDataR>  
    >::result_type
    operator *(Array<ArrayElements,Size> a,binary_array_node<ExprDataL,ExprOp, ExprDataR> e  )
    {
        return typename pqs::meta::binary_operation<
            Array<ArrayElements,Size>,
            std::multiplies,
            binary_array_node<ExprDataL,ExprOp, ExprDataR>  
        >::result_type(a,e);
    }  

    template< 
        typename ArrayElements,int Size,
        typename ExprDataL,
        template<typename>class ExprOp,
        typename ExprDataR
    >
    typename pqs::meta::binary_operation<
        Array<ArrayElements,Size>,
        std::divides,
        binary_array_node<ExprDataL,ExprOp, ExprDataR>  
    >::result_type
    operator /(Array<ArrayElements,Size> a,binary_array_node<ExprDataL,ExprOp, ExprDataR> e  )
    {
        return typename pqs::meta::binary_operation<
            Array<ArrayElements,Size>,
            std::divides,
            binary_array_node<ExprDataL,ExprOp, ExprDataR>  
        >::result_type(a,e);
    }
        
}//pqs
#endif
