#include "pqs/pqs.hpp"
#include "pqs/complex/q_complex.hpp"
/*
    functors demo
    binary_operator functors are automatically defined for any type
    for which binary_operation is defined
*/

/* ternary functor with eval order dependent on operator precedence*/
template <
    bool Op1_first,
    typename A,
    template<typename> class Op1,
    typename B,
    template<typename>class Op2,
    typename C
>
struct ternary_if_c;

template <
    typename A,
    template<typename>class Op1,
    typename B,
    template<typename>class Op2,
    typename C 
>
struct ternary_if_c<true,A,Op1,B,Op2,C>{

    typedef typename pqs::binary_operator<
        A,Op1,B
    > first_op;
    typedef typename pqs::binary_operator<
        typename first_op::result_type,Op2,C
    > second_op;
    typedef typename second_op::result_type result_type;
    result_type operator()(A const& a, B const& b, C const & c)
    {
        return second_op()( first_op()(a,b),c);
    }
};

template <
    typename A,
    template<typename>class Op1,
    typename B,
    template<typename>class Op2,
    typename C 
>
struct ternary_if_c<false,A,Op1,B,Op2,C>{

    typedef typename pqs::binary_operator<
        B,Op2,C
    > first_op;
    typedef typename pqs::binary_operator<
        A,Op1,typename first_op::result_type
    > second_op;

    typedef typename second_op::result_type result_type;
    
    result_type operator()(A const& a, B const& b, C const& c)
    {
        return second_op()(a,first_op()(b,c));
    }
};

template <
    typename A,
    template<typename>class Op1,
    typename B,
    template<typename>class Op2,
    typename C
>
struct ternary_operation{
    const static bool a_first =
        (pqs::binary_operator_traits<A,Op1,B>::expression_family >=
        pqs::binary_operator_traits<B,Op2,C>::expression_family);

    typedef ternary_if_c<a_first,A,Op1,B,Op2,C> op;
    typedef typename op::result_type result_type;
    
    result_type operator()(A const& a, B const& b , C const& c)
    {
        return op()(a,b,c);
    }
};
 
using namespace pqs;
int main()
{
    typedef ternary_operation<
        // velocity + distance/time
        q_velocity::m_div_s,std::plus,q_length::m,std::divides,q_time::s
    > tern;
    tern::result_type tt =  tern()(
        q_velocity::m_div_s(1.0),
        q_length::m(1.0),
        q_time::s(2.0));
    std::cout << "ternary " << tt <<'\n';

    //operator_divides is derived from binary_operator
    // hence interchangeable
    typedef pqs::operator_divides<
        q_length::m,
        q_time::s
    > veloc;

    veloc::result_type v = veloc()(
        q_length::m(2.0),
        q_time::s(3.0) );
    std::cout << v <<'\n';
    //or use binary_operator direct
    // which can be used in template expressions as in ternary  above
    typedef pqs::binary_operator<
        std::complex<q_length::m>,
        std::divides,
        std::complex<double>
    > qveloc;

    qveloc::result_type qv = qveloc()(
        std::complex<q_length::m>(q_length::m(1),q_length::m(0)),
        std::complex<double>(3.0) );
    std::cout << qv <<'\n';

}
