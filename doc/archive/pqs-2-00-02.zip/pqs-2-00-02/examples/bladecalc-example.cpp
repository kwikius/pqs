//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    Example works out chord and angle of a wind turbine rotorblade
    as a function of radius,using input parameters in RotorDialog,
    Shows use of pqs in a larger setting
    note: angle result is different from previous versions 
    - angle of incidence subtracted
    New...Improved... now with angles...
*/

// see the header for declarations
// see bottom of this file for definitions
#include <cassert>
#include "bladecalc-example.hpp"
#include "pqs/ct_quantity/operations/arctangent2.hpp"
#include "pqs/ct_quantity/tagged_binary_operation.hpp"
// ideally constants will be put in a library
#define NO_PQS_CONSTANTS_LIBRARY
#ifdef NO_PQS_CONSTANTS_LIBRARY
#include "pqs/math/lib_src/constant.cpp"
#endif

//parse input lines
#include "input_tokens.hpp"
// Y/N question
bool response();

int main()
{   // float output format 2 digits after decimal point
    std::cout.setf(std::ios_base::fixed,std::ios_base::floatfield);
    std::cout.precision(2);

    scratch input; // utility struct for input
    do_boiler(input); // output program preamble
    
    while(1) {
        std::cout << "\nEnter rotor span position...\n"
        "(syntax for input: {integer} {units from above list}\n(e.g " 
        << input.get_span_position() << ") or (\"quit\" to quit) )\n: ";

        pqs::input_tokens tokens(std::cin); // gets input tokens in a vect
        // does user want to quit?
        if (tokens.num_items == 1){
            std::string quit_str;
            tokens.get_at(0,quit_str);
            if (quit_str == "quit"){
                std::cout << "quitting...\n";
                return EXIT_SUCCESS;
            }// not quit
            std::cout << "Only one item found...want to quit {Y/N}?:";
            if(response()){
                std::cout << "quitting\n";
                return EXIT_SUCCESS;
            }
            continue;
        }
        if(tokens.num_items != 2){
                std::cout << "Sorry \""<< tokens.input_line << "\" need 2 items\n";
                continue;
        }
        scratch::raw_value_type raw_value;
        if (!tokens.get_at(0,raw_value)){
            std::cout << "Sorry \""<< tokens.input_line << "\" first item must be a number\n";
                continue;
        }
        std::string units;
        if (!tokens.get_at(1,units)){
            std::cout << tokens.input_line << "Sorry cannot read 2nd item as a string\n";
                continue;
        }
        input.set_span_position(raw_value,units);
        if (input.get_last_error() == scratch::NONE ){
            std::cout << "\nAt span position "
            << input.get_span_position()
            << ", chord = " << input.get_chord()
            << " and angle = " << input.get_angle() << "\n"
            << "...............................................................\n\n"; 
        } 
        else if (input.get_last_error() == scratch::INPUT_VALUE_OUT_OF_RANGE){
            std::cout 
            << "\nSorry Span position " << raw_value << " " << units << " is out of range"
            << "\nmin is " << input.get_min_span_position()
            << "\nmax is " << input.get_max_span_position() << '\n';
            input.clear_error();
        }
        else{
            assert(input.get_last_error() == scratch::INVALID_UNITS);
            std::cout << "\nSorry \""<< units << "\" is not a valid unit";
            input.clear_error();
        }
    }
}

namespace pqs{
// create a type representing mass_flow
    struct mass_flow{
        typedef meta::binary_operation<
            mass::kg,
            std::divides,
            time::s
        >::result_type kg_div_s;
    };
}
/*
    find chord and angle of rotor blade at input span position r
*/
chord_omega getChordOmega(pqs::length::m const& r)
{   
    using pqs::length;
    using pqs::velocity;
    using pqs::mass_flow;
    using pqs::force;
    using pqs::pow;
    using pqs::math::constant;
    using pqs::math::of_angle;

    length::m const tip_r = rotordialog.m_outer_dia / 2.0; 
    double const tsr = rotordialog.m_tsr;
    double const ellipticality = rotordialog.m_ellipticality;
    velocity::m_div_s const Vin_y  = rotordialog.m_vw;
    length::m const  dr = get_dr();
    velocity::m_div_s const  Vout_y
    = Vin_y 
    * ( (r < tip_r)
        ? 1.0 
          -  ((2.0 / 3.0) * (1.0 - ellipticality)
            + (ellipticality * sqrt(1.0 - pow<2>(r / tip_r) )))
        : 1.0 - (2.0/3.0)*(1.0 - ellipticality) );
    velocity::m_div_s const  Vb_y = (Vin_y + Vout_y) / 2.0;
    mass_flow::kg_div_s const  air_mass_flow
    = Vb_y * 2 * constant::pi * r * rotordialog.m_rho_air * dr;
    force::N const Fb_y = air_mass_flow * (Vin_y - Vout_y) ;
    double const  cl = rotordialog.m_cl;
    double const  drag_coeff  = rotordialog.m_cd / cl;

    velocity::m_div_s const epsilon = 0.0001 * abs(Vin_y);
    velocity::m_div_s const Vin_x = Vin_y * tsr * (r / tip_r);
    velocity::m_div_s Vout_x(0);
    velocity::m_div_s oldVout_x(0);
    for (int i = 0 ;i < 1000 ; ++i){
        velocity::m_div_s const Vb_x 
        = Vout_x / 2.0 + Vin_x;
        of_angle::rad const beta = arctangent2(Vb_y,Vb_x);
        double const cos_beta = cos(beta);
        double const sin_beta = sin(beta); 
        force::N const Lift 
        = Fb_y /(cos_beta + drag_coeff * sin_beta);
        force::N const Fb_x 
        = Lift * (sin_beta - drag_coeff * cos_beta);
        oldVout_x = Vout_x;
        Vout_x = Fb_x / air_mass_flow;
       /* if ( abs(Vout_x - oldVout_x) < epsilon){*/
        if (compare(Vout_x,oldVout_x,epsilon) == 0 ){
            length::m const chord 
            = Lift 
            / ( (pow<2>(Vb_x) + pow<2>(Vb_y) ) 
                * 0.5 * rotordialog.m_rho_air
                * cl * dr * rotordialog.m_numblades );
            return chord_omega(chord,beta );
        }
    }//fail
    return chord_omega(length::mm(0.0),of_angle::rad(0.0));
}

scratch::scratch()// ctor sets up min max span position values
:   span_position(pqs::length::mm(300)),
    min_span_position(pqs::length::mm(100)),
    max_span_position(rotordialog.m_outer_dia / 2),
    angle(0),
    last_error(NONE)
{
   using pqs::length;
    // fill the units_map with required user units
    // see rt_unit_map.cpp for info
   units_map.add_unit<length::m>();
   units_map.add_unit<length::mm>();  
   units_map.add_unit<length::in>();  
   units_map.add_unit<length::ft>();  
}

bool scratch::set_units(std::string const & units)
{
    if( units_map.find(units) == units_map.end()){
        last_error = INVALID_UNITS;
        return false;
    }
    units_map.set(this->min_span_position,units);
    units_map.set(this->max_span_position,units);
    units_map.set(this->chord,units);
    units_map.set(this->span_position,units);
    return true;
}

bool scratch::set_span_position(
        scratch::raw_value_type raw_value,
        std::string const & units)
{
    std::string old_units = units_str(this->span_position);
    if (!this->set_units(units)) {
        return false;
    }
    rt_length::value_type old_value = span_position.numeric_value();
    span_position.set_numeric_value(raw_value);
    if (!this->range_ok()){
        span_position.set_numeric_value(old_value);
        this->set_units(old_units);
        this->last_error = INPUT_VALUE_OUT_OF_RANGE;
        return false;
    }
    chord_omega result = getChordOmega(this->span_position);
    this->chord = result.m_chord;
    this->angle = result.m_omega - rotordialog.m_alpha ;
    return true;
}

bool scratch::range_ok()const //check span_position limits
{
    return (this->span_position >= this->min_span_position) 
    && (this->span_position <= this->max_span_position );
}

void do_boiler(scratch & input)
{
    std::cout << "Program calculates setting angle and chord, for "
    "a wind turbine rotor blade as function of span position.\n\n";
    std::cout << "Available units for setting span position are:\n\n";
    scratch::units_map_const_iterator iter = input.units_map.begin();
    while (iter != input.units_map.end()){
        std::cout << iter->first;
        ++iter;
        if (iter != input.units_map.end())
        std::cout << ", ";
    };
    while(1){
        std::cout << "\n\nMinimum span position is: " 
        << input.get_min_span_position() << '\n';
        std::cout << "Maximum span position is: " 
        << input.get_max_span_position() << '\n';
        std::cout << "\nShow min/max in different units {Y}?\n";
        if ( response() ){
            std::cout << "Enter unit: ";
            
            pqs::input_tokens tokens(std::cin);
            if(tokens.num_items != 1){
                std::cout << "Sorry \""<< tokens.input_line << "\" need 1 items\n";
                continue;
            }
            std::string units;
            if(!tokens.get_at(0,units)){
                std::cout << tokens.input_line << "Sorry cannot read 2nd item as a string\n";
                continue;
            }
            if(input.set_units(units)){
                continue;
            }
            else{
                assert(input.get_last_error() == scratch::INVALID_UNITS);
                std::cout << "Sorry \""<< units << "\" is not a valid unit";
                input.clear_error();
                continue;
            }
        }
        else{
            break;
        }
    }
}

bool response()
{
       pqs::input_tokens tokens(std::cin);
       if(tokens.num_items < 1) return false;
       std::string str;
       if(! tokens.get_at(0,str) )return false;
       return ( ( str == "Y" ) || ( str  == "y" ) );
}




