#ifndef BLADECALC_EXAMPLE_HPP_INCLUDED
#define BLADECALC_EXAMPLE_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

// note could include all types... #include "pqs/pqs.hpp"
// but compile-time is reduced if only the required types 
// are included.
#include "pqs/types/time.hpp"
#include "pqs/types/velocity.hpp"
#include "pqs/types/density.hpp"
#include "pqs/types/force.hpp"
#include "pqs/types/mass.hpp"
#include "pqs/math/angles/angles_out.hpp"

// note '_out' file extension
// for ostream output of units
// required for length only here
#include "pqs/types/length_out.hpp"

// for simple stream output of a pq via ostream operator <<
// e.g os << pq << ...;
#include "pqs/util/utility_output.hpp"
#include "pqs/util/utility_input.hpp"

// note: Example requires compilation of "boost/pqs/math/constant.cpp"
// for linking in pi
#include "pqs/math/constant.hpp"
// runtime physical quantities
#include "pqs/rt_quantity/rt_quantity.hpp"
#include "pqs/rt_quantity/rt_units_map.hpp"

struct chord_omega{
   
    chord_omega(pqs::length::m const & chord,
                pqs::math::of_angle::rad const& omega)
    : m_chord(chord), m_omega(omega)
    {}
    pqs::length::m const   m_chord;
    pqs::math::of_angle::rad  const   m_omega;
};

/*
Example
works out chord and angle of a wind turbine rotorblade
as a function of radius,
using input parameters in RotorDialog
*/

inline 
chord_omega 
getChordOmega(pqs::length::m const & r);


// class for info about rotor
struct RotorDialog{

    RotorDialog():
        m_outer_dia(2300),
        m_vw(7.0),
        m_tsr(6.5),
        m_ellipticality(0),
        m_rho_air(1.225),
        m_cd(.01),
        m_cl(0.7),
        m_numblades(3),
        m_alpha (4)
    {}

    // outer diameter of turbine rotor
    pqs::length_<int>::mm  const   m_outer_dia; 
    // free wind velocity
    pqs::velocity::m_div_s const   m_vw;
    // tip speed ratio rel free wind      
    double              const   m_tsr; 
    // blade shape param  (between 0 and 1)
    // nearer 1 gives'elliptical lift gradient 
    // for reduced tip vortex 
    double              const   m_ellipticality;
    // air density
    pqs::density::kg_div_m3 const  m_rho_air;
    // drag coefficient
    double              const   m_cd;
    // lift coefficient     
    double              const   m_cl; 
    // number of blades on rotor   
    int                 const   m_numblades;
    //angle of incidence 
    pqs::math::of_angle::deg          const   m_alpha;     

}rotordialog;

// section spacing
inline pqs::length::mm  get_dr()
{  
    return pqs::length::mm(100.0);
}

// scratch for input of params 
// uses rt_quantities so units can be runtime modified
// via the set_span_position function.
// see cpp file for definition of scratch
struct scratch{
    scratch();
    enum Error{NONE,INVALID_UNITS,INPUT_VALUE_OUT_OF_RANGE};
    
    typedef double raw_value_type;
    bool set_units(std::string const & units);
    Error get_last_error() const {return last_error;}
    void clear_error() {last_error = NONE;}
    // from raw value, set all units to required type
    // set value of span_position to value 
    bool set_span_position(raw_value_type raw_value,std::string const & units);
    bool range_ok()const; //check span_position limits

    typedef pqs::rt_quantity<pqs::of_length::type,double> rt_length;
    pqs::rt_units_map<pqs::of_length::type> units_map;
    typedef pqs::rt_units_map<pqs::of_length::type>::const_iterator units_map_const_iterator;

    rt_length const& get_min_span_position()const {return min_span_position;}
    rt_length const& get_max_span_position()const {return max_span_position;}
    rt_length const& get_span_position()const {return span_position;}
    rt_length const& get_chord()const{ return chord;}
    pqs::math::of_angle::deg const & get_angle() {return angle;}
private:
    rt_length       min_span_position;
    rt_length       max_span_position;
    rt_length       span_position;
    rt_length       chord; 
    pqs::math::of_angle::deg   angle; 
    Error last_error;
};
// output start prog info
void do_boiler(scratch & input);

#endif
