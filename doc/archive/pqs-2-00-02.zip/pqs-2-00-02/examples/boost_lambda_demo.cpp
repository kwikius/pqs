//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    pretty basic boost::lambda support
    NOTE1: requires official boost library
    Note2 : warnings expected from boost::lambda lib during compile

*/

#include "pqs/pqs.hpp"
// interface to lambda
#include "boost_lambda_interface.hpp"
#include <vector>

int main()
{
    using pqs::length;

    std::vector<length::m>  lengths;
    lengths.push_back(length::m(10));
    lengths.push_back(length::m(20));
    lengths.push_back(length::m(30));
    lengths.push_back(length::m(40));
    lengths.push_back(length::m(50));
    
    boost::lambda::placeholder1_type element; 
    for_each(lengths.begin(),lengths.end(), std::cout << element << ' '  );
    std::cout << '\n';
    for_each(lengths.begin(),lengths.end(), element = element + length::m(2) );
    for_each(lengths.begin(),lengths.end(), std::cout << element << ' '  );
    std::cout << '\n';
    for_each(lengths.begin(),lengths.end(), std::cout << element - element / 2 << ' '  );
    std::cout << '\n';
    for_each(lengths.begin(),lengths.end(), std::cout << element * element << ' '  );
    std::cout << '\n';
    for_each(lengths.begin(),lengths.end(), std::cout << element * 2 << ' '  );
    std::cout << '\n';
    for_each(lengths.begin(),lengths.end(), std::cout << element / element << ' '  );
    std::cout << '\n';
    for_each(lengths.begin(),lengths.end(), std::cout << element / 2. << ' '  );
    std::cout << '\n';

}
