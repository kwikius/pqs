#ifndef PQS_BOOST_LAMBDA_INTERFACE_HPP_INCLUDED
#define  PQS_BOOST_LAMBDA_INTERFACE_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/ct_quantity/ct_quantity_fwd.hpp"
#include "pqs/operators/binary_operator_functors.hpp"
#include "boost/lambda/lambda.hpp"

namespace pqs{

    template< typename Op>
    struct lambda_binary_operation_key;

    template<>
    struct lambda_binary_operation_key<
        boost::lambda::other_action<
            boost::lambda::assignment_action 
        >
    >{
        typedef pqs::operator_equals type;
    };

    template<>
    struct lambda_binary_operation_key<
        boost::lambda::arithmetic_action<
            boost::lambda::plus_action 
        >
    >{
        typedef pqs::operator_plus type;
    };
// for stream output
    template<>
    struct lambda_binary_operation_key<
        boost::lambda::bitwise_action<
            boost::lambda::leftshift_action 
        >
    >{
        typedef pqs::operator_shift_left type;
    };

    template<>
    struct lambda_binary_operation_key<
        boost::lambda::arithmetic_action<
            boost::lambda::minus_action 
        >
    >{
        typedef pqs::operator_minus type;
    };

    template<>
    struct lambda_binary_operation_key<
        boost::lambda::arithmetic_action<
            boost::lambda::multiply_action 
        >
    >{
        typedef pqs::operator_multiplies type;
    };

    template<>
    struct lambda_binary_operation_key<
        boost::lambda::arithmetic_action<
            boost::lambda::divide_action 
        >
    >{
        typedef pqs::operator_divides type;
    };
}

namespace boost{namespace lambda{

    template<
        typename Op,
        typename NamedAbstractQuantity, 
        typename QuantityUnit,
        typename Value_type,
        typename Other
    > 
    struct plain_return_type_2< 
        Op,
        pqs::ct_quantity<NamedAbstractQuantity,QuantityUnit,Value_type>,
        Other 
    >{
        typedef typename pqs::lambda_binary_operation_key<
            Op
        >::type pqs_operator_type;
        typedef typename pqs_operator_type
        ::template result<
            pqs_operator_type(
            pqs::ct_quantity<NamedAbstractQuantity,QuantityUnit,Value_type>,
            Other)
        >::type type;
    };

    template<
        typename Op,
        typename Other,
        typename NamedAbstractQuantity, 
        typename QuantityUnit,
        typename Value_type
    > 
    struct plain_return_type_2< 
        Op,
        Other,
        pqs::ct_quantity<NamedAbstractQuantity,QuantityUnit,Value_type>
         
    >{
        typedef typename pqs::lambda_binary_operation_key<
            Op
        >::type pqs_operator_type;
        typedef typename pqs_operator_type
        ::template result<
            pqs_operator_type(
            Other,
            pqs::ct_quantity<NamedAbstractQuantity,QuantityUnit,Value_type>)
        >::type type;
    };

    template<
        typename Op,
        typename Abstract_idL, 
        typename QuantityUnitL,
        typename Value_typeL,
        typename Abstract_idR,
        typename QuantityUnitR,
        typename Value_typeR   
    > 
    struct plain_return_type_2< 
        Op,
        pqs::ct_quantity<Abstract_idL,QuantityUnitL,Value_typeL>,
        pqs::ct_quantity<Abstract_idR,QuantityUnitR,Value_typeR>
    >{
        typedef typename pqs::lambda_binary_operation_key<
            Op
        >::type pqs_operator_type;
        typedef typename pqs_operator_type
        ::template result<
            pqs_operator_type(
            pqs::ct_quantity<Abstract_idL,QuantityUnitL,Value_typeL>,
            pqs::ct_quantity<Abstract_idR,QuantityUnitR,Value_typeR>)
        >::type type;
    };

   
}}//boost::lambda



#endif
