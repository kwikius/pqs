//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    Nominallydemonstrates complex physical_quantities
    and angular velocity using radians value_type

    NOTE Changed from previosu version
    which actually demonstrates problems with complex.
    Result should be infinity. In fact the maths could be vastly reduced.
    I need to do more work on complex

    Whetever FWIW...
    
*/

// must be defined before all  headers
// if defined treats radians as a numeric with more attributes
// that can be ' decayed ' to a numeric
#define PQS_IMPLICIT_RADIANS_STRAIGHTENING
// see header for declarations...
#include "complex_example.hpp"
//comment out NO_PQS_CONSTANTS_LIBRARY if using constants in a library
#define NO_PQS_CONSTANTS_LIBRARY
#ifdef NO_PQS_CONSTANTS_LIBRARY
#include "pqs/math/angles/lib_src/angles.cpp"
#endif

int main()
{ 
    using std::complex;
    using pqs::inductance;
    using pqs::capacitance;
    using pqs::impedance;
    using pqs::frequency;
    using pqs::angular_velocity;
    using pqs::math::of_angle;
   // using pqs::root;
    typedef of_angle angle;

    std::cout << "calculate impedance of a"
    "parallel LC oscillator at resonance\n";
#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
    std::cout << "Using  implicit rad to/from numeric conversion\n";
#endif 
    std::cout << '\n';

    complex<double> const j(0,1) ; //operator j
    


    inductance::uH const L(1);
    std::cout << "With an inductance of " << L << '\n';
    capacitance::uF const C(1);
    std::cout << "And a capacitance of " << C << '\n'; 

//AFAIK This is the start of the problems
// in sqrt (L*C) a rational coherent-exponent results
// eg  L*C has a coherent exponent of -3 + -6 = -9
// taking the sqrt of that gives a coherent-exponent of
// -9 / 2 = 4.5
// in resolving that an error is introduced
#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
    angular_velocity::rad_div_s w = 1 / sqrt(L * C);
#else 
    angular_velocity::rad_div_s w = angle::one / sqrt(L * C) ;
#endif
    std::cout << "Angular velocity omega = " << w <<'\n';
    pqs::meta::binary_operation<
        inductance::uH,
        std::multiplies,
        capacitance::uF
    >::result_type intermed_mult;
    std::cout << typeid(intermed_mult).name() <<'\n';
   std::cout << intermed_mult <<'\n';
    pqs::meta::binary_operation<
        pqs::time::ms,
        std::multiplies,
        pqs::time::ms
    >::result_type modified_result = L*C;
    std::cout <<typeid(modified_result).name() <<'\n';
    angular_velocity::rad_div_s w1 = pqs::pow<-1,2>(modified_result);
    std::cout << w - w1 <<'\n';
    

    std::cout << "Angular velocity omega = " << w <<'\n';
    frequency::kHz f = w /(2 * angle::pi);
    std::cout << "and resonant frequency = " << f <<'\n';
#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
    impedance::R XC = 1 / (j * w * C );
#else
    impedance::R XC = 1 / (j * (w / angle::one) * C );
#endif
    std::cout << "capacitive reactance of " << C << " at " << f << " = " << XC <<'\n';
#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
    impedance::R XL = j * w * L;
#else
    impedance::R XL = j * (w / angle::one) * L;
#endif
    std::cout <<"imags calc error "<< XL.imag() + XC.imag() <<'\n';

    std::cout << "inductive reactance of " << L << " at " << f << " = " << XL <<'\n';
    pqs::meta::binary_operation<
        impedance::R,
        std::multiplies,
        impedance::R    
    >::result_type mult = XL * XC;
    std::cout << "XL * XC" << mult <<'\n';
    pqs::meta::binary_operation<
        impedance::R,
        std::plus,
        impedance::R    
    >::result_type add = XL + XC;
    
    std::cout << "XL + XC" << add <<'\n';
    add.imag() = pqs::resistance::R(0);
    std::cout << "XL + XC" << add <<'\n';
    try{
// gives incorrect result
        impedance::R Z = mult / add;
        std::cout << "impedance = " << Z << '\n';
        std::cout << "(should be infinity of course)\n";
    }
    catch (std::exception e){
        std::cout << e.what();
    }
}
