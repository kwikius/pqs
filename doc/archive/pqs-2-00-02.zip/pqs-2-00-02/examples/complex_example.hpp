#ifndef PQS_EXAMPLES_COMPLEX_EXAMPLE_HPP_INCLUDED
#define PQS_EXAMPLES_COMPLEX_EXAMPLE_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/ct_quantity/complex.hpp"
#include "pqs/types/voltage_out.hpp"
#include "pqs/types/current_out.hpp"
#include "pqs/types/resistance_out.hpp"
#include "pqs/types/inductance_out.hpp"
#include "pqs/types/power_out.hpp"
#include "pqs/types/time_out.hpp"
#include "pqs/types/frequency_out.hpp"
#include "pqs/types/capacitance_out.hpp"
#include "pqs/types/angular_velocity_out.hpp"

// the following could be added to pqs/types/..
namespace pqs{

    struct impedance{
        typedef std::complex<resistance::R> R;
    };
                    
}//pqs
#endif
