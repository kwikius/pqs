//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    rotational motion demo of angles etc, using complex quantities
*/

// quantities
#include "pqs/pqs.hpp"
//complex quantities
#include "pqs/ct_quantity/complex.hpp"
// quantity <-> angle interface w' output of angles
#include "pqs/types/angular_velocity_out.hpp"
//#include "pqs/math/angles/angles_out.hpp"
// for pi
//comment out NO_PQS_CONSTANTS_LIBRARY if using constants in a library
#define NO_PQS_CONSTANTS_LIBRARY
#ifdef NO_PQS_CONSTANTS_LIBRARY
#include "pqs/math/angles/lib_src/angles.cpp"
#endif

namespace pqs{namespace math{
    //trial of rotate complex by angle
    template< 
        typename ComplexValue_type,
        typename RadValue_type
    >
    inline 
    std::complex<ComplexValue_type>
    rotate(
        std::complex<ComplexValue_type> const& cplx,
        radians<meta::rational_c<long,1>,RadValue_type> const& angle
    )
    {
        std::complex<
           typename pqs::meta::to_value_type<ComplexValue_type>::type 
        >rotate_angle(cos(angle),sin(angle));
        return cplx * rotate_angle;
    }
}}//pqs::math
namespace std{
//trial  std::abs (std::complex) for ct_quantity
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline
    pqs::ct_quantity<
        NamedAbstractQuantity,
        QuantityUnit,
        Value_type
    >
    abs(std::complex<
            pqs::ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cplx)
    {
        return pqs::sqrt(pqs::pow<2>(cplx.real()) + pqs::pow<2>(cplx.imag()));
    }

}//std

int main()
{  
    using pqs::length;
    using pqs::time;
    using pqs::angular_velocity;
    using pqs::math::of_angle;

    // show fp errors
    std::cout.setf(std::ios_base::fixed,std::ios_base::floatfield);
    std::cout.precision(6);
    // Assume an entity starting at a point in x,y coordinates, 
    // centre of rotation at (0 m , 0 m)
    // units of metres at 45 degrees
    // using this seed radius is nominally 2m
    length::m const seed = length::m( 2* sin(of_angle::deg(45)));
    std::complex<length::m> const start(seed,seed);

    // calculate radius of arc of revolution
    //ie length::mm radius = sqrt(pow<2>(start.real()) + pow<2>(start.imag()));
    length::mm radius = abs(start);
    std::cout << "radius of arc of revolution = " << radius <<'\n';

    // calc starting angle in radians and output in degrees
    // argument is equivalent to arg(complex) ... but returns angle not numeric
    // convert to degrees for output
    of_angle::deg const starting_angle = argument(start);
    std::cout << "starting angle = " << starting_angle <<'\n';

    // Assume angular velocity of entity of pi/4 radians per sec ( == 45 degrees per sec) 
    angular_velocity::rad_div_s const w(of_angle::pi / 4); 
    //Find the position of the entity t seconds later
    time::s const   t(1);
    of_angle::deg angle_travelled = w * t;
    std::cout << "angle travelled at " << w 
    << " in " << t << " = " << angle_travelled << '\n';

    //one way to do the calculation
    std::cout << "using first calc...\n";
    // calc resulting angle after time t... using degrees here for demo purposes
    of_angle::deg finish_angle = starting_angle + angle_travelled;
    // show finish angle 
    std::cout << "finish angle = " << finish_angle <<'\n';
    // calculate finish point note does sin(degrees) etc
    std::complex<length::m> finish 
    = radius * std::complex<double>(cos(finish_angle),sin(finish_angle));
    std::cout << "finish point = " << finish << "\n";  

    // alternate way to do the calc...
   
    std::cout << "using alternate calc... \n";
    std::complex<length::m> finish1 (
        start.real() * cos(w * t) - start.imag() * sin(w * t),
        start.real() * sin(w * t) + start.imag() * cos(w * t) );
    
    std::cout << "finish_angle = " << of_angle::deg(argument(finish1)) << '\n';
    std::cout << "finish point = " << finish1 << "\n";
    std::cout << "\nnote: Theoretically 'finish point' should be (0 m,2 m) of course...\n";

    // above reduces to
    std::complex<double> rotation(cos(w*t),sin(w*t));
    finish1 = start * rotation;
    std::cout << "finish1 = " << finish1 <<'\n';

    // which reduces to (using above rotate op)
    finish1 = rotate(start ,w * t);
    std::cout << "finish1 = " << finish1 <<'\n';
    std::cout << "rotate same again...\n";
    std::complex<length::m> finish2 = rotate(finish1, w*t);
    std::cout << "finish2 = " << finish2 <<'\n';
    // check
    std::cout << "w * t = " << of_angle::deg(argument(finish2) - argument(finish1)) <<'\n';
    
}
