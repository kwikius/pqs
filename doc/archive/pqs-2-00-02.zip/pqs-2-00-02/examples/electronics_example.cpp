//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
     some basic electronics calcs
*/

//#include "pqs/pqs.hpp"
#include "pqs/types/voltage_out.hpp"
#include "pqs/types/resistance_out.hpp"
#include "pqs/types/current_out.hpp"
#include "pqs/types/time_out.hpp"
#include "pqs/types/power_out.hpp"
#include "pqs/types/energy_out.hpp"

int main()
{
    using pqs::voltage;
    using pqs::current;
    using pqs::resistance;
    using pqs::time;
    using pqs::power;
    using pqs::energy;
    using pqs::pow;

    voltage::V        v(5.0);
    resistance::kR    r(1);
    current::mA       i = v/r;
    time::s           t(1.0);
    power::mW         w = pow<2>(v)/r;
    energy::mJ        e = w * t;
    std::cout 
    << "A current of " << i
    << "\nthrough a voltage of " << v 
    << "\nrequires a resistance of " << r 
    << "\nand produces "  << w << " of heat\n";
    std::cout 
    << "total energy in " << t 
    << " is " <<  e  << '\n';
}
