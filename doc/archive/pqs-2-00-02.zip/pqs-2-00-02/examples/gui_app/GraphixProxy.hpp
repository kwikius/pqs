#ifndef GRAPHIC_PROXY_HPP_INCLUDED
#define GRAPHIC_PROXY_HPP_INCLUDED

#include "basic_world.hpp"

namespace pqs{namespace wtl{namespace two_d{

    template <
        typename WorldPositionType
    >
    struct graphic_proxy{
        
        basic_world<WorldPositionType> & m_world;
        HDC hdc;
        graphic_proxy(basic_world<WorldPositionType> & w,HDC hdc_in)
        :m_world(w),hdc(hdc_in){}
        ////////////////
        typedef WorldPositionType               world_position_type;
        typedef world_element<
            world_position_type
        >                                       element_type;
        typedef basic_world_view<
            basic_world<WorldPositionType>
        >   world_view_type;

        //////////////
    
        world_position_type& min_position()
        {
            return this->m_world.min_position();
        }
        world_position_type const& min_position()const
        {
            return m_world.min_position();
        }
        world_position_type& max_position()
        {
            return this->m_world.max_position();
        }
        world_position_type const & max_position()const
        {
            return this->m_world.max_position();
        }
     /*   world_view_type* current_view()const
        {
            return this->m_world.current_view();
        }*/
    
        inline 
        void move_to ( 
            typename world_position_type::x_type const& x,
            typename world_position_type::y_type const& y
        ){
            this->m_world.move_to(this->hdc,x,y);
        }

        inline 
        void line_to ( 
            typename world_position_type::x_type const& x,
            typename world_position_type::y_type const& y
        ){
            this->m_world.line_to(this->hdc,x,y);
        }
        // set origin relative to world origin
        inline 
        void set_drawing_origin ( 
            typename world_position_type::x_type const& x,
            typename world_position_type::y_type const& y
        ){
            this->m_world.set_drawing_origin(x,y);
        }

        inline 
        void text_out ( 
            typename world_position_type::x_type const& x,
            typename world_position_type::y_type const& y,
            std::string const & str
        ){
            this->m_world.text_out(this->hdc,x,y,str);
        }
    };



}}}//pqs::wtl::two_d

#endif
