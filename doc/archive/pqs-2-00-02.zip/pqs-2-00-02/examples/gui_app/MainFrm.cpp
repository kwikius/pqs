// MainFrm.cpp : implmentation of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "aboutdlg.h"
#include "physical_worldView.h"
#include "MainFrm.h"

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	if(CFrameWindowImpl<CMainFrame>::PreTranslateMessage(pMsg))
		return TRUE;

	return m_world_view.PreTranslateMessage(pMsg);
}

BOOL CMainFrame::OnIdle()
{
	UIUpdateToolBar();
	return FALSE;
}

LRESULT CMainFrame::OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, 
LPARAM /*lParam*/,BOOL& /*bHandled*/)
{
	CreateSimpleToolBar();

    // set up the view
    m_world_view.world.set_current_view(
        new pqs::wtl::two_d::basic_world_view<
            CPhysical_worldView::world_type
        >(
            m_world_view.world,
            new pqs::wtl::two_d::basic_world_viewport
        )   
    );
    m_world_view.world.min_position()
    = pqs::two_d::vect<pqs::length::mm>(pqs::length::mm(0),pqs::length::mm(0));
    m_world_view.world.max_position()
    = pqs::two_d::vect<pqs::length::mm>(pqs::length::mm(350),pqs::length::mm(150));
    m_world_view.world.current_view()->position() 
    = pqs::two_d::vect<pqs::length::mm>(pqs::length::mm(0),pqs::length::mm(0));
    m_world_view.world.current_view()->set_scale(1,1);
	m_hWndClient = m_world_view.Create(
        m_hWnd, 
        rcDefault, 
        NULL, 
        WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS |
        WS_CLIPCHILDREN | WS_HSCROLL |WS_VSCROLL ,
        WS_EX_CLIENTEDGE
    );
    // set y scroll button to 'max position'
    // as coords system is graphic not text
    int minpos,maxpos;
    m_world_view.GetScrollRange(SB_VERT, &minpos, &maxpos);
    m_world_view.SetScrollPos(SB_VERT,maxpos,false);
    
	UIAddToolBar(m_hWndToolBar);
	UISetCheck(ID_VIEW_TOOLBAR, 1);

	// register object for message filtering and idle updates
	CMessageLoop* pLoop = _Module.GetMessageLoop();
	ATLASSERT(pLoop != NULL);
	pLoop->AddMessageFilter(this);
	pLoop->AddIdleHandler(this);

	return 0;
}

LRESULT CMainFrame::OnFileExit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	PostMessage(WM_CLOSE);
	return 0;
}

LRESULT CMainFrame::OnFileNew(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	// TODO: add code to initialize document

	return 0;
}

LRESULT CMainFrame::OnViewToolBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	BOOL bVisible = !::IsWindowVisible(m_hWndToolBar);
	::ShowWindow(m_hWndToolBar, bVisible ? SW_SHOWNOACTIVATE : SW_HIDE);
	UISetCheck(ID_VIEW_TOOLBAR, bVisible);
	UpdateLayout();
	return 0;
}

LRESULT CMainFrame::OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	CAboutDlg dlg;
	dlg.DoModal();
	return 0;
}
