Very crude graphics App using pqs types.
unfinished
requires WTL 
