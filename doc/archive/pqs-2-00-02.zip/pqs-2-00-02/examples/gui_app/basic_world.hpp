#pragma once

#include "world_element.hpp"
#include "basic_world_view.hpp"
#include <cassert>
#include <string>

namespace pqs{namespace wtl{namespace two_d{
   
    template <
        typename WorldPositionType
    >
    class basic_world{
    public:
        typedef WorldPositionType               world_position_type;
        typedef world_element<
            world_position_type
        >                                       element_type;
        typedef basic_world_view<basic_world>   world_view_type;
        basic_world(): mp_view(0){}
        world_position_type& min_position()
        {
            return m_min_position;
        }
        world_position_type const& min_position()const
        {
            return m_min_position;
        }
        world_position_type& max_position()
        {
            return m_max_position;
        }
        world_position_type const & max_position()const
        {
            return m_max_position;
        }
        world_view_type* current_view()const
        {
            return this->mp_view;
        }
        world_view_type* release_current_view()
        {
            assert(this->mp_view !=0 );
            world_view_type* t =  mp_view;
            mp_view = 0;
            return t; 
        }
        void delete_current_view()
        {
            delete mp_view;
            mp_view = 0; 
        }
        void set_current_view(world_view_type* in)
        {
            // keep position?
            assert( mp_view == 0 );
            assert(in !=0 );
            mp_view = in;
        }
        bool has_valid_view()const
        {
           if (!this->mp_view) return false;
           if (!this->mp_view->viewport()) return false;
           return true; 
        }
        
        inline 
        void move_to (
            HDC hdc, 
            typename world_position_type::x_type const& x,
            typename world_position_type::y_type const& y
        );

        inline 
        void line_to (
            HDC hdc, 
            typename world_position_type::x_type const& x,
            typename world_position_type::y_type const& y
        );
        // set origin relative to world origin
        inline 
        void set_drawing_origin ( 
            typename world_position_type::x_type const& x,
            typename world_position_type::y_type const& y
        );

        inline 
        void text_out (
            HDC hdc, 
            typename world_position_type::x_type const& x,
            typename world_position_type::y_type const& y,
            std::string const & str
        );

        ~basic_world(){ delete mp_view;}
    private:
        world_position_type         m_min_position;
        world_position_type         m_max_position;
        world_position_type         m_drawing_origin;
        world_view_type*            mp_view;
    };

    template <
        typename WorldPositionType
    >
    inline 
    void basic_world<WorldPositionType>::move_to (
        HDC hdc, 
        typename world_position_type::x_type const& x_in,
        typename world_position_type::y_type const& y_in
    ){
        if (! this->mp_view){
            ATLTRACE(" invalid view in basic_world<WorldPositionType>::move_to ");
            return;
        }
        typename world_position_type::x_type x
        = x_in + m_drawing_origin.x() - mp_view->position().x();
        typename world_position_type::y_type y
        = y_in + m_drawing_origin.y() - mp_view->position().y();
        this->mp_view->move_to(hdc,x,y);
    }

    template <
        typename WorldPositionType
    >
    inline  
    void basic_world<WorldPositionType>::line_to (
        HDC hdc, 
        typename WorldPositionType::x_type const& x_in,
        typename WorldPositionType::y_type const& y_in
    ){
        if (! this->mp_view){
            ATLTRACE(" invalid view in basic_world<WorldPositionType>::line_to");
            return;
        }
        typename world_position_type::x_type x
        = x_in + m_drawing_origin.x() - mp_view->position().x();
        typename world_position_type::y_type y
        = y_in + m_drawing_origin.y()- mp_view->position().y();
        this->mp_view->line_to(hdc,x,y);
    }
    template <
        typename WorldPositionType
    >
    inline  
    void basic_world<WorldPositionType>::set_drawing_origin (
        typename WorldPositionType::x_type const& x_in,
        typename WorldPositionType::y_type const& y_in
    ){
        if (! this->mp_view){
            ATLTRACE(" invalid view in basic_world<WorldPositionType>::line_to");
            return;
        }
        m_drawing_origin.x() = x_in;
        m_drawing_origin.y() = y_in;
    }

    template <
        typename WorldPositionType
    >
    inline  
    void basic_world<WorldPositionType>::text_out (
        HDC hdc, 
        typename WorldPositionType::x_type const& x_in,
        typename WorldPositionType::y_type const& y_in,
        std::string const & str
    ){
        if (! this->mp_view){
            ATLTRACE(" invalid view in basic_world<WorldPositionType>::text_out");
            return;
        }
        typename world_position_type::x_type x
        = x_in + m_drawing_origin.x() - mp_view->position().x();
        typename world_position_type::y_type y
        = y_in + m_drawing_origin.y() - mp_view->position().y();
        this->mp_view->text_out(hdc,x,y,str);

    }
    

}}}//pqs::wtl::two_d


 