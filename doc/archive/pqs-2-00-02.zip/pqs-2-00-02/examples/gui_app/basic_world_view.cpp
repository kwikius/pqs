#include "stdafx.h"
#include "basic_world_view.hpp"
