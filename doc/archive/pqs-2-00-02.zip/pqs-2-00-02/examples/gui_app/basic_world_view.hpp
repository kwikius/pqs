
# pragma once

#include "pqs/meta/associated_arithmetic.hpp"
#include "viewport.hpp"
#include "pqs/two_d/vect.hpp"

#include "pqs/util/morph.hpp"
#include <string>
/*
    todo add update to scrollbar pos in setscale
*/

namespace pqs{namespace wtl{namespace two_d{

    template <typename BasicWorld>
    class basic_world_view : public BasicWorld::element_type{
    public:
        typedef BasicWorld basic_world_type;
        typedef pqs::wtl::two_d::basic_world_viewport graphics_viewport_type;
        typedef pqs::two_d::vect<
            pqs::morph<
                typename graphics_viewport_type::physical_size_type::x_type,
                typename basic_world_type::world_position_type::x_type
            >,
            pqs::morph<
                typename graphics_viewport_type::physical_size_type::y_type,
                typename basic_world_type::world_position_type::y_type
            >
        > morph_world_to_physical_type;
        
        typedef pqs::two_d::vect<
            pqs::morph<
                typename basic_world_type::world_position_type::x_type,
                typename graphics_viewport_type::physical_size_type::x_type 
            >,
            pqs::morph<
                typename basic_world_type::world_position_type::y_type,
                typename graphics_viewport_type::physical_size_type::y_type
            >
        > morph_physical_to_world_type;
        inline void set_scale(
            typename morph_world_to_physical_type::x_type::intermediate_type const & xscale,
            typename morph_world_to_physical_type::y_type::intermediate_type const & yscale
        ) ;
        inline bool on_vscroll(int cur, int min, int max);
        inline bool on_hscroll(int cur, int min, int max);
        inline LRESULT on_size(int x, int y)
        {
            if ( ! mp_graphics_viewport){
                ATLTRACE("no graphics viewport in basic_world_view<BasicWorld>::on_size");
                return static_cast<LRESULT>(0);
            }
            mp_graphics_viewport->on_size(x,y);
            return static_cast<LRESULT>(0);
        }

        inline void move_to (
            HDC hdc, 
            typename basic_world_type::world_position_type::x_type const& x,
            typename basic_world_type::world_position_type::y_type const& y
        );
        inline void line_to (
            HDC hdc, 
            typename basic_world_type::world_position_type::x_type const& x,
            typename basic_world_type::world_position_type::y_type const& y
        );
        inline void text_out(
            HDC hdc,
            typename basic_world_type::world_position_type::x_type const & x,
            typename basic_world_type::world_position_type::y_type const & y,
            std::string const &
        );
        inline void set_origin ( 
            typename basic_world_type::world_position_type::x_type const& x,
            typename basic_world_type::world_position_type::y_type const& y
        );

        basic_world_view(
            basic_world_type& bb,
            graphics_viewport_type* gg
        ): mp_parent_world(&bb),mp_graphics_viewport(gg){}
        ~ basic_world_view()
        { 
            delete mp_graphics_viewport;
        }
        graphics_viewport_type* viewport()
        {
            return mp_graphics_viewport;
        }
        morph_world_to_physical_type morph_world_to_physical;
        morph_physical_to_world_type morph_physical_to_world; 
    private:
        graphics_viewport_type*                         mp_graphics_viewport;
        basic_world_type*                               mp_parent_world;
        /*typename basic_world_type::world_position_type scrollbar_increment;
        pqs::two_d::vect<int>                          num_scroll_steps;     */   
    };


//////////////////////////////

    template <typename BasicWorld>
    inline 
    void basic_world_view<BasicWorld>::move_to (
        HDC hdc, 
        typename BasicWorld::world_position_type::x_type const& x_in,
        typename BasicWorld::world_position_type::y_type const& y_in
    ){
        if ( ! mp_graphics_viewport){
            ATLTRACE("no graphics viewport in basic_world_view<BasicWorld>::move_to");
            return;
        }
        typename graphics_viewport_type::physical_size_type::x_type x
        = this->morph_world_to_physical.x()(x_in); 
        //    + (this->viewport()->physical_size().x() / 2);
        ATLTRACE("Hello\n");
        typename graphics_viewport_type::physical_size_type::y_type y
        = this->morph_world_to_physical.y()(y_in);
         //   + (this->viewport()->physical_size().y() / 2);
        this->viewport()->move_to(hdc, x, y); 
    }

    template <typename BasicWorld>
    inline 
    void basic_world_view<BasicWorld>::line_to (
        HDC hdc, 
        typename BasicWorld::world_position_type::x_type const& x_in,
        typename BasicWorld::world_position_type::y_type const& y_in
    ){
        if ( ! mp_graphics_viewport){
            ATLTRACE("no graphics viewport in basic_world_view<BasicWorld>::line_to");
            return;
        }
        typename graphics_viewport_type::physical_size_type::x_type x
        = this->morph_world_to_physical.x()(x_in);
        typename graphics_viewport_type::physical_size_type::y_type y
        = this->morph_world_to_physical.y()(y_in);
        this->viewport()->line_to(hdc, x, y); 
    }
    template <typename BasicWorld>
    inline 
    void basic_world_view<BasicWorld>::text_out(
        HDC hdc,
        typename BasicWorld::world_position_type::x_type const & x_in,
        typename BasicWorld::world_position_type::y_type const & y_in,
        std::string const & str
    ){
        if ( ! mp_graphics_viewport){
            ATLTRACE("no graphics viewport in basic_world_view<BasicWorld>::text_out");
            return;
        }
        typename graphics_viewport_type::physical_size_type::x_type x
        = this->morph_world_to_physical.x()(x_in);
        typename graphics_viewport_type::physical_size_type::y_type y
        = this->morph_world_to_physical.y()(y_in);
        this->viewport()->text_out(hdc, x, y,str); 
    }
    template <typename BasicWorld>
    inline 
    void basic_world_view<BasicWorld>::set_origin ( 
        typename BasicWorld::world_position_type::x_type const& x_in,
        typename BasicWorld::world_position_type::y_type const& y_in
    ){
        typename graphics_viewport_type::physical_size_type::x_type x
        = this->morph_world_to_physical.x()(x_in);
        typename graphics_viewport_type::physical_size_type::y_type y
        = this->morph_world_to_physical.y()(y_in);
        this->viewport()->set_origin(x, y); 
    }

    template <typename BasicWorld>
    inline 
    void basic_world_view<BasicWorld>::set_scale(
            typename morph_world_to_physical_type::x_type::intermediate_type const & xscale,
            typename morph_world_to_physical_type::y_type::intermediate_type const & yscale
        )
    {
        typename basic_world_type::world_position_type old_zoom; 
        if(mp_graphics_viewport){
            old_zoom.x() = morph_physical_to_world.x()(mp_graphics_viewport->zoom_origin().x());
            old_zoom.y() = morph_physical_to_world.y()(mp_graphics_viewport->zoom_origin().y());
        }
        // set new scaling
        morph_world_to_physical = morph_world_to_physical_type(
            typename morph_world_to_physical_type::x_type(xscale),
            typename morph_world_to_physical_type::y_type(yscale) 
        );
        morph_physical_to_world = morph_physical_to_world_type(
            typename morph_physical_to_world_type::x_type(1/xscale),
            typename morph_physical_to_world_type::y_type(1/yscale) 
        );
        //update scrollbar pos so zoom is centred
        if(mp_graphics_viewport){
            typename basic_world_type::world_position_type new_zoom;
            new_zoom.x() = morph_physical_to_world.x()(mp_graphics_viewport->zoom_origin().x());
            new_zoom.y() = morph_physical_to_world.y()(mp_graphics_viewport->zoom_origin().y());
            this->position().x() += (old_zoom.x() - new_zoom.x());
            this->position().y() += (old_zoom.y() - new_zoom.y());
            
        }
    }
    // returns true to require redraw
    template <typename BasicWorld>
    inline
    bool basic_world_view<BasicWorld>::on_vscroll(int curpos, int minpos, int maxpos)
    {
        if (!this->mp_parent_world){
            ATLTRACE("invalid parent* in basic_world_view<BasicWorld>::on_hscroll");
            return false;
        }
        typedef typename basic_world_type::world_position_type::y_type y_type;
        y_type world_size 
        = mp_parent_world->max_position().y() - mp_parent_world->min_position().y();
        y_type total_range 
        = world_size - this->morph_physical_to_world.y()(
                    this->mp_graphics_viewport->physical_size().y());
        
        if ( total_range >= y_type(0)){
            y_type incr = total_range  / (maxpos - minpos);
            y_type new_position = incr * ( maxpos - curpos);
            if (new_position != this->position().y()){
                this->position().y() = new_position;
                return true;
            }
            return true;
        }
        return false;
    }

    template <typename BasicWorld>
    inline 
    bool basic_world_view<BasicWorld>::on_hscroll(int cur, int min, int max)
    {
        if (!this->mp_parent_world){
            ATLTRACE("invalid parent* in basic_world_view<BasicWorld>::on_hscroll");
            return false;
        }
        if (!this->mp_graphics_viewport){
            ATLTRACE("invalid viewport* in basic_world_view<BasicWorld>::on_hscroll");
            return false;
        }
        typedef typename basic_world_type::world_position_type::x_type x_type;
        x_type total_range 
        = mp_parent_world->max_position().x() 
            - ( mp_parent_world->min_position().x()
                + this->morph_physical_to_world.x()(
                    this->mp_graphics_viewport->physical_size().x()
                )
              );
        if ( total_range >= x_type(0)){
            x_type incr = total_range  / (max - min);
            x_type new_pos = incr * cur;
            if(new_pos != this->position().x()){
                this->position().x() = new_pos;
                return true;
            }
            return false;
        }
        return false;
    }

}}}//pqs::wtl::two_d


