// physical_worldView.cpp : implementation of the CPhysical_worldView class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "physical_worldView.h"
#include <sstream>
#include "pqs/types/length_out.hpp"
#include "view_abstraction.hpp"
#include "GraphixProxy.hpp"

LRESULT CPhysical_worldView::OnPaint(
    UINT /*uMsg*/, WPARAM /*wParam*/, 
    LPARAM /*lParam*/, BOOL& /*bHandled*/
){
    if (!this->world.has_valid_view() ){
      ATLTRACE("invalid view in CPhysical_worldView::OnPaint");
        return static_cast<LRESULT>(0);
    }
	CPaintDC dc(this->m_hWnd);
    pqs::two_d::drawFunction( pqs::wtl::two_d::graphic_proxy<
        pqs::two_d::vect<pqs::length::mm>
    >(this->world, dc.m_hDC) );
    
	return 0;
}



LRESULT CPhysical_worldView::OnSize(
    UINT /*uMsg*/, WPARAM /*wParam*/,
    LPARAM lParam, BOOL& /*bHandled*/
){
    if (!this->world.has_valid_view() ){
        ATLTRACE("invalid view in CPhysical_worldView::OnSize");
        return static_cast<LRESULT>(0);
    }
    return this->
        world.current_view()->on_size(LOWORD(lParam),HIWORD(lParam));
}

LRESULT CPhysical_worldView::OnHScroll(
    UINT /*uMsg*/, WPARAM wParam ,
    LPARAM lParam , BOOL& /*bHandled*/
){
    int scroll_key = LOWORD(wParam);
    int scroll_pos = HIWORD(wParam);
    int minpos,maxpos;
    this->GetScrollRange(SB_HORZ, &minpos, &maxpos);
    int curpos = this->GetScrollPos(SB_HORZ);
    switch (scroll_key){
        case SB_LEFT:
            curpos = minpos;break;
        case SB_RIGHT:
            curpos = maxpos;break;
        case SB_ENDSCROLL:
            break;
        case SB_LINELEFT:      // Scroll left.
            if (curpos > minpos){curpos--;}
            break;
        case SB_LINERIGHT:   // Scroll right.
            if (curpos < maxpos){curpos++;} 
            break;
        case SB_PAGELEFT:    // Scroll one page left.
            curpos -= 10;
            if(curpos < minpos) {curpos = minpos;}
            break;
        case SB_PAGERIGHT:      // Scroll one page right.
        {
            curpos += 10;
            if(curpos > maxpos) curpos = maxpos;
        }
        break;
        case SB_THUMBPOSITION: // Scroll to absolute position. nPos is the position
            curpos = scroll_pos;      // of the scroll box at the end of the drag operation.
        break;
        case SB_THUMBTRACK:   // Drag scroll box to specified position. nPos is the
            curpos = scroll_pos;     // position that the scroll box has been dragged to.
        break;
        default:
        break;
   }
   if (this->world.current_view()->on_hscroll(curpos,minpos,maxpos)) {
        this->SetScrollPos(SB_HORZ,curpos);
        this->InvalidateRect(NULL);
   }
   return static_cast<LRESULT>(0);
}

LRESULT CPhysical_worldView::OnVScroll(
    UINT /*uMsg*/, WPARAM wParam ,
    LPARAM /*lParam*/, BOOL& /*bHandled*/
)
{
    int scroll_key = LOWORD(wParam);
    int scroll_pos = HIWORD(wParam);
    int minpos,maxpos;
    this->GetScrollRange(SB_VERT, &minpos, &maxpos);
    int curpos = this->GetScrollPos(SB_VERT);
    switch (scroll_key){
        case SB_BOTTOM:
            curpos = maxpos;break;
        case SB_TOP:
            curpos = minpos;break;
        case SB_ENDSCROLL:
            break;
        case SB_LINEDOWN:  
            if (curpos < maxpos){curpos++;}
            break;
        case SB_LINEUP:   // Scroll right.
            if (curpos > minpos){curpos--;} 
            break;
        case SB_PAGEDOWN:    // Scroll one page left.
            curpos += 10;
            if(curpos > maxpos) {curpos = maxpos;}
            break;
        case SB_PAGEUP:      // Scroll one page right.
            curpos -= 10;
            if(curpos < minpos) curpos = minpos;
            break;
        case SB_THUMBPOSITION: // Scroll to absolute position. nPos is the position
            curpos = scroll_pos;      // of the scroll box at the end of the drag operation.
            break;
        case SB_THUMBTRACK:   // Drag scroll box to specified position. nPos is the
            curpos = scroll_pos;     // position that the scroll box has been dragged to.
            break;
        default:
            break;
   }
    if (this->world.current_view()->on_vscroll(curpos,minpos,maxpos)){
        this->SetScrollPos(SB_VERT,curpos);
        this->InvalidateRect(NULL);
    }
    else {
         this->SetScrollPos(SB_VERT,maxpos);
    }
    return static_cast<LRESULT>(0);
}

BOOL CPhysical_worldView::PreTranslateMessage(MSG* pMsg)
{
	pMsg;
	return FALSE;
}

