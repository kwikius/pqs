#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

/*
    draw  the voltage/time discharge curve for a capacitor
*/

#ifndef PQS_TWO_D_VIEW_ABSTRACTION_HPP_INCLUDED
#define PQS_TWO_D_VIEW_ABSTRACTION_HPP_INCLUDED

#include "pqs/util/morph.hpp"
#include "pqs/pqs.hpp"

namespace pqs { namespace two_d{

    template <typename GX>
    inline 
    void  drawFunction(GX & gx)
    {   
        // vect<X,Y> is a general purpose (x,y) container
        // for coords sizes etc
        typedef vect<length::mm> pt;

        // set up size of drawing area in world coordinate sizes
        // This can be scaled and scrolled by the other layers
        // for output on a device
        // world coordinates as used here 
        // are the top layer of the graphics view 
       
        gx.max_position() = pt(length::mm(170),length::mm(120));
        gx.min_position() = pt(length::mm(0), length::mm(0));
        // set up and draw border round the 'canvas'
        length::mm const canvas_border(3);
        gx.set_drawing_origin(length::mm(0), length::mm(0));
        gx.move_to(canvas_border,canvas_border);
        gx.line_to(gx.max_position().x() - canvas_border,canvas_border);
        gx.line_to(gx.max_position().x() - canvas_border, gx.max_position().y() - canvas_border);
        gx.line_to(canvas_border, gx.max_position().y() - canvas_border);
        gx.line_to(canvas_border,canvas_border);

        // set up a drawing rectangle for the graph
        // of  voltage / time
        length::mm const graph_border = length::mm(20) + canvas_border; 
        pt draw_rect;  
        draw_rect.x() = gx.max_position().x() - 2 * graph_border;
        draw_rect.y() = gx.max_position().y() - 2 * graph_border;

        // move origin to (0,0) on graph
        gx.set_drawing_origin(graph_border,graph_border);

         // capacitor time curve data
        capacitance::uF   const C(0.47);      //capacitor
        voltage::V        const V0(5);        //starting voltage across capacitor
        resistance::kR    const R(4.7);       // resistance between terminals
        time_<int>::ms    const max_time(20);

        // draw a border round the graph
        gx.move_to(length::mm(0),length::mm(0));
        gx.line_to(draw_rect.x(),length::mm(0));
        gx.line_to(draw_rect.x(), draw_rect.y());
        gx.line_to(length::mm(0), draw_rect.y());
        gx.line_to(length::mm(0),length::mm(0));

        
        // draw the graph
        // The "morph" functors convert the source physical-quantities to target types
        // (here lengths for drawing obviously) 
        // with correctly dimensioned scaling value
        // as ctor argument
        morph<length::mm,time::ms>    time_x( draw_rect.x() / max_time);
        morph<length::mm,voltage::V>  volts_y( draw_rect.y() / V0);

         // draw y scale
        for (voltage_<int>::V Vt(0); Vt <= V0; ++Vt ){

            gx.move_to(length::mm(-3),volts_y(Vt));
            gx.line_to(length::mm(0),volts_y(Vt));
            std::ostringstream ost;
            ost << Vt;
            gx.text_out(length::mm(-10),volts_y(Vt) + length::mm(2.5) ,ost.str());
        }
        // draw x scale
        for (time_<int>::ms t(0); t <= max_time; t += max_time / 4 ){

            gx.move_to(time_x(t),length::mm(-3));
            gx.line_to(time_x(t),length::mm(-0));
            std::ostringstream ost;
            ost << t;
            gx.text_out(time_x(t) - length::mm(2),length::mm(-5) ,ost.str());
        }
       // draw graph
        gx.move_to( time_x(time_<int>::ms(0)),volts_y(V0)); 
        for ( time_<int>::ms t(1) ; t <= max_time; ++t  ){
            voltage::V  Vt = V0 * std::exp(-t / (R * C));
            gx.line_to( time_x(t), volts_y(Vt)); 
        } 
        
        gx.text_out(length::mm(40),draw_rect.y() + length::mm(12) ,"Capacitor Time Curve" );
        pt text_pos(length::mm(60),draw_rect.y()- length::mm(10));
        std::ostringstream ost;
        ost << "Capacitance = " << C ;
        gx.text_out( text_pos.x(),text_pos.y(),ost.str());
        ost.str("");
        ost << "Resistance  = " << R ;
        text_pos.y() -= length::mm(5);
        gx.text_out( text_pos.x(),text_pos.y(),ost.str());      
        
    }
   
}}//pqs::two_d

#endif


