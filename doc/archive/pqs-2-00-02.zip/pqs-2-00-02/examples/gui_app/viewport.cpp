#include "stdafx.h"
#include "viewport.hpp"

namespace pqs{namespace wtl{namespace two_d{

LRESULT basic_world_viewport::on_size(int x, int y)
{
    HDC hdc = ::CreateIC("DISPLAY", NULL, NULL, NULL);
    if (!hdc){
        ATLTRACE("CreateIC failed in OnSize");
        return static_cast<LRESULT>(-1);
    }
    // get system sizes
    this->m_system_physical_size.x()    = pqs::length::mm(::GetDeviceCaps(hdc,HORZSIZE));
    this->m_system_physical_size.y()    = pqs::length::mm(::GetDeviceCaps(hdc,VERTSIZE));
    this->m_system_extent.x()           = ::GetDeviceCaps(hdc,HORZRES);
    this->m_system_extent.y()           = ::GetDeviceCaps(hdc,VERTRES);
    DeleteDC(hdc);
    // get viewport sizes
    this->m_viewport_extent.x()         = x;
    this->m_viewport_extent.y()         = y;
    this->m_physical_size.x()
    =  ( this->m_viewport_extent.x() * this->m_system_physical_size.x())
        /this->m_system_extent.x();
    this->m_physical_size.y() 
    =   (this->m_viewport_extent.y() * this->m_system_physical_size.y())
        / this->m_system_extent.y();
    if (this->auto_center_zoom){
        m_zoom_origin.x() = this->m_physical_size.x() / 2;
        m_zoom_origin.y() = this->m_physical_size.y() / 2;
    }
    return static_cast<LRESULT>(0);
}
void basic_world_viewport::move_to(
    HDC hdc, 
    physical_size_type::x_type const& x_in,
    physical_size_type::y_type const& y_in
)const
{
    int x = static_cast<int>(this->physical_to_device_x(x_in));
    int y = static_cast<int>(this->physical_to_device_y(y_in));
    ::MoveToEx(hdc, x, y,NULL);
}
void basic_world_viewport::line_to(
    HDC hdc, 
    physical_size_type::x_type const& x_in,
    physical_size_type::y_type const& y_in
)const
{
    int x = static_cast<int>(this->physical_to_device_x(x_in));
    int y = static_cast<int>(this->physical_to_device_y(y_in));
    ::LineTo(hdc, x, y);
}
void basic_world_viewport::text_out(
    HDC hdc, physical_size_type::x_type const& x_in,
    physical_size_type::y_type const& y_in,
    std::string const & str
)const{
    int x = static_cast<int>(this->physical_to_device_x(x_in));
    int y = static_cast<int>(this->physical_to_device_y(y_in));
    ::TextOut(hdc, x, y,str.c_str(),str.length());
}

}}}