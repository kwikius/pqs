#pragma once

#include "pqs/gui/graphics_viewport.hpp"
#include "pqs/types/length.hpp"
#include "pqs/two_d/vect.hpp"
#include <string>
/*
    todo make sure that initial values are not 0
    to avoid division by 0
*/

namespace pqs{namespace wtl{namespace two_d{

    class basic_world_viewport : public pqs::gui::graphics_viewport<
        pqs::two_d::vect<pqs::length::mm>,
        pqs::two_d::vect<int>
    >{
        typedef pqs::gui::graphics_viewport<
                pqs::two_d::vect<pqs::length::mm>,
                pqs::two_d::vect<int>
        > graphics_viewport;
    public:
        typedef  graphics_viewport::physical_size_type   physical_size_type;
        typedef  graphics_viewport::viewport_extent_type viewport_extent_type;    
        basic_world_viewport(
            physical_size_type const& physical_size_in,
            viewport_extent_type const& extent_in )
        :   m_physical_size(physical_size_in), 
            m_viewport_extent(extent_in),
            auto_center_zoom(true){}
        basic_world_viewport():auto_center_zoom(true){}
        viewport_extent_type const &
        viewport_extent()const{ return m_viewport_extent;}        
        physical_size_type const & 
        physical_size()const { return m_physical_size;}
        LRESULT on_size(int x, int y);
        physical_size_type const & 
        zoom_origin()const{return m_zoom_origin;}
        physical_size_type const& 
        origin() {return m_origin;}
        void set_origin(
            physical_size_type::x_type const& x,
            physical_size_type::y_type const& y
        ){ m_origin.x() = x; m_origin.y() = y;}
        inline double physical_to_device_x( physical_size_type::x_type const & x_in)const;
        inline double physical_to_device_y( physical_size_type::y_type const & y_in)const;
        inline physical_size_type::x_type device_to_physical_x( double const & x_in)const;
        inline physical_size_type::y_type device_to_physical_y( double const & y_in)const;
        void move_to (
            HDC hdc,
            physical_size_type::x_type const& x,
            physical_size_type::y_type const& y
        )const;
        void line_to (
            HDC hdc, 
            physical_size_type::x_type const& x,
            physical_size_type::y_type const& y
        )const;
        void text_out(
            HDC hdc,
            physical_size_type::x_type const & x,
            physical_size_type::y_type const & y,
            std::string const &
        )const;
    private:
        physical_size_type   m_physical_size;
        viewport_extent_type m_viewport_extent;
        physical_size_type   m_system_physical_size;
        viewport_extent_type m_system_extent;
        physical_size_type   m_origin;
        physical_size_type   m_zoom_origin;
        bool  auto_center_zoom;
        
    };

    inline 
    double 
    basic_world_viewport::physical_to_device_x( physical_size_type::x_type const& x_in)const
    {
        double ret = ((x_in + m_origin.x()) * this->m_system_extent.x()) / this->m_system_physical_size.x();
        return ret;
    }
    inline 
    double 
    basic_world_viewport::physical_to_device_y( physical_size_type::y_type const& y_in)const
    {
        double ret = this->m_viewport_extent.y() 
        - ( ((y_in + m_origin.y()) * this->m_system_extent.y()) / this->m_system_physical_size.y());
        return ret;
    }
    inline 
    basic_world_viewport::physical_size_type::x_type 
    basic_world_viewport::device_to_physical_x( double const & x_in)const
    {
       physical_size_type::x_type ret
       = ( x_in * this->m_system_physical_size.x())/ this->m_system_extent.x() ;
       return ret - m_origin.x();
    }
    inline 
    basic_world_viewport::physical_size_type::y_type 
    basic_world_viewport::device_to_physical_y( double const & y_in)const
    {
        physical_size_type::y_type ret
        = (( this->m_viewport_extent.y() - y_in ) * this->m_system_physical_size.y())
            / this->m_system_extent.y();
        return ret - m_origin.y();
    }
    
}}}//pqs::wtl::two_d


