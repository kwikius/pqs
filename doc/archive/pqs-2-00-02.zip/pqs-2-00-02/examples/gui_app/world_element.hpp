
# pragma once

namespace pqs{namespace wtl{namespace two_d{

    template <
        typename PositionType
    >
    class world_element{
    public:
        typedef PositionType  position_type;
        position_type&  position(){return m_position;}
        position_type const&   position()const{return m_position;}  
    private:
        position_type   m_position;
    };
        
}}}//pqs::wtl::two_d

