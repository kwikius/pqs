//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    Calculation of amount of substance in a gas using gas constant
    from discussion on www.boost.org
*/

#include "pqs/pqs.hpp"
// comment out NO_PQS_CONSTANTS_LIBRARY 
// if using the constants in a library
#define NO_PQS_CONSTANTS_LIBRARY
#ifdef NO_PQS_CONSTANTS_LIBRARY
#include "pqs/math/lib_src/constant.cpp"
#include "pqs/physics/lib_src/gas_constant.cpp"
#else 
// pi etc
#include "pqs/math/constant.hpp"
// dimensionally correct gas_constant
#include "pqs/physics/gas_constant.hpp"
#endif

using namespace pqs;

int main()
{  
    using pqs::math::constant;
    using pqs::physics::gas_constant;

    temperature::K  T(310);
    pressure::Pa    P(1.01325e5);
    length::m       r(0.5e-6);
    volume::m3      V = 4.0 / 3.0 * constant::pi * pow<3>(r);
    substance::mol  subst = P * V /(gas_constant::R * T);
    std::cout << subst <<'\n';
}


