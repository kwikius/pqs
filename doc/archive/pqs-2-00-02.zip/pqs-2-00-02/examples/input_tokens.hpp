#ifndef PQS_INPUT_TOKEN_LIST_HPP_INCLUDED
#define PQS_INPUT_TOKEN_LIST_HPP_INCLUDED

/*
   parse input line to vector of strings
   only for simple types
*/
#include <iostream>
#include <string>
#include <sstream>
#include <vector>

namespace pqs{

struct input_tokens : public std::vector<std::string>{
   
    int num_items;
    std::string input_line;
    input_tokens(std::istream & in):num_items(0)
    {
        getline(in,input_line);
        std::istringstream ist(input_line);
        while (ist && !ist.eof()){
           std::string str;
           ist >> str; 
           this->push_back(str);
           ++num_items;
        }
    }
    template< typename T>
    bool get_at(int i,T& result)
    {
        if ( (num_items < (i+1)) || ( i < 0 )) return false;
        std::istringstream ist(this->at(i));
        T tt ;
        ist >> tt;
        if(ist.eof() && ! ist.bad()){
            result = tt;
            return true;
        }
        return false;
    }
};


}

#endif
