//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/* 
    This example shows how it is possible to use integer value_types,
    in different units without loss of precision (eg int 1/1000)
    up in the code at compile time the function attempts to decide 
    how to do the adds, subs, divs and muls to give best resolution. 

    NB Only works accurately for coherent-quantities.
    (for incoherent-quantities use a floating point value_type).
    The ideal behaviour would be that incoherent quantities 
    are converted to floating point value-types when necessary.
    pqs-2-00-01 does this internally, but then does a downcast
    back to integer in (say) the addition operator. 
    (compiler should warn). I hope to
    modify this behaviour so that a floating point temporary 
    is returned, but not implemented in pqs-2-00-01.
*/

#include <iostream>
#include "pqs/types/length_out.hpp"
#include "pqs/types/area_out.hpp"

int main()
{
    pqs::length_<int>::m L1(1);
    pqs::length_<int>::mm L2(1000);

    std::cout << L1 + L2 <<'\n';
    std::cout << L2 + L1 <<'\n';
  
    std::cout << L2 - L1 <<'\n';
    std::cout << L1 - L2 <<'\n';
  
    std::cout << L1 / L2 <<'\n';
    std::cout << L2 / L1 <<'\n'; 

    std::cout << L1 * L2 <<'\n';
    std::cout << L2 * L1 <<'\n';    
}


