//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    demo of physical_quantity with interval value-type
    NOTE: requires official boost library

    pqs requires various specialisation for intervals. 
    (See "interval_pq.hpp") No value_type conversions are
    allowed by boost::numeric::interval math so this
    should cover it for double interval value_types. Note 
    that this wont compile :
        numeric::interval<double>() * 2; //  ie  int
    but this will:
        numeric::interval<double>() * 2.0; // ie double
    ie numeric-type must be exact same type as the interval
    value_type. This is similar functionality to std::complex.
    pow function is probably not correct for interval
    ... just compiles and runs ok ... todo

    OTOH perhaps interval<pq> would be better
*/

#include "pqs/pqs.hpp"
#include "interval_pq.hpp"

//interval class requires ostream operator
namespace boost{namespace numeric{

    inline
    std::ostream & operator<<(
        std::ostream &os,
        interval<double> const& value)
    {
        return (empty(value))
        ? os << "||"
        : os <<  '|' << lower(value) << ',' 
            << upper(value) << '|';
    }

}}//boost::numeric

using namespace pqs;
int main()
{
    try{
        typedef boost::numeric::interval<double> interval;

        length_<interval>::m l(2.0,3. );
        length_<interval>::cm  l1(2.0,3.0);
        time_<interval>::s t(1.,2.);
       
        std::cout << l / l1  << '\n';
        std::cout << l / 2.0 << '\n';
        std::cout << 2.0 / l << '\n';
        std::cout << l * 2.0 << '\n';
        std::cout << l * l1  << '\n';
        std::cout << 2.0 * l << '\n';
        std::cout << l1 / t  << '\n';
        // above gives "anonymous units"
        std::cout << velocity_<interval>::cm_div_s(l1 / t)  << '\n';
        std::cout << area_<interval>::dm2(l * l1) << '\n';
        std::cout << l1 + l  << '\n';
        std::cout << l - l1  << '\n';
        std::cout <<  length::m(2) * interval(2.0,3.0) << '\n';
        //note: runs but probably not semantically correct for interval
        std::cout << pow<2>(l)   << '\n';
        std::cout << pow<1,2>(l) << '\n';   
    }
    catch(std::exception e){
        std::cout << e.what() << '\n';
        std::cout << "could be interval.lower > interval.upper?? \n";
    }    
}
