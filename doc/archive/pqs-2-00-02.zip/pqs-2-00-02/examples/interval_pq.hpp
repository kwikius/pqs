#ifndef PQS_INTERVAL_PQ_BINARY_OPERATION_HPP_INCLUDED1
#define PQS_INTERVAL_PQ_BINARY_OPERATION_HPP_INCLUDED1

//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "boost/numeric/interval.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/associated_arithmetic.hpp"
#include "pqs/meta/rational_c.hpp"
#include "pqs/type_traits/is_ct_quantity_value_type.hpp"

namespace pqs{namespace meta{
    
    template<
        typename Value_type,
        typename Policies,
        template <typename> class Op
    >
    struct binary_operation<
        typename boost::numeric::interval<Value_type,Policies>,
        Op,
        typename boost::numeric::interval<Value_type,Policies>
    >{
        typedef  typename boost::numeric::interval<
            typename binary_operation<
                Value_type,Op,Value_type
            >::result_type,
            Policies
        > result_type;
    };

    template<
        typename Value_type,
        typename Policies,
        template <typename> class Op
    >
    struct binary_operation<
        typename boost::numeric::interval<Value_type,Policies>,
        Op, 
        Value_type 
    >{
        typedef typename boost::numeric::interval<
            typename binary_operation<
                Value_type,Op,Value_type
            >::result_type
            ,Policies
        > result_type;
    };
    template<
        typename Value_type,
        typename Policies,
        template <typename> class Op
    >
    struct binary_operation<
        Value_type,
        Op,
        typename boost::numeric::interval<Value_type,Policies>
    >{
        typedef  typename boost::numeric::interval<
            typename binary_operation<
                Value_type,Op,Value_type
            >::result_type,
            Policies
        > result_type;
    };

    template<
        typename Value_type,
        typename Policies,
        int N, 
        int D
    >
    struct binary_operation<
        typename boost::numeric::interval<Value_type,Policies>,
        pqs::to_power,
        typename pqs::meta::rational_c<int, N, D>
    >{
        typedef  typename boost::numeric::interval<
            typename binary_operation<
                Value_type,
                to_power,
                typename pqs::meta::rational_c<int, N, D>::type
            >::result_type,
            Policies
        >  result_type;
    };

   /* template<
        typename Value_type,
        typename Policies
    >
    struct binary_operation<
        typename boost::numeric::interval<Value_type,Policies>,
        pqs::to_power,
        int
    >{
        typedef  typename boost::numeric::interval<
            typename binary_operation<
                Value_type,to_power,int
            >::result_type,
            Policies
        >  result_type;
    };*/

    template<typename T, typename P>
    struct to_arithmetic< typename boost::numeric::interval<T,P> >{
       typedef  typename to_arithmetic<T>::type  type;
    };
    template<typename T, typename P>
    struct to_value_type< typename boost::numeric::interval<T,P> >{
       typedef  T type;
    };
}} // pqs::meta

namespace pqs{

    template <
        int N,
        int D,
        typename Value_type,
        typename Policies
    >
    inline
    typename pqs::meta::binary_operation<
        typename boost::numeric::interval<Value_type,Policies>,
        pqs::to_power,
        pqs::meta::rational_c<int,N,D>
    >::result_type
        
    pow(boost::numeric::interval<Value_type,Policies> const& r)
    {
        typedef  typename pqs::meta::binary_operation<
            boost::numeric::interval<Value_type>,
            pqs::to_power,
            pqs::meta::rational_c<int,N,D>
        >::result_type result_type;
        return result_type(pow<N,D>(r.lower()), pow<N,D>(r.upper()));
       
    }

    namespace type_traits{

        template <typename Value_type, typename P>
        struct is_ct_quantity_value_type<
            boost::numeric::interval<Value_type, P> 
        >{
            enum{value = true};
            typedef is_ct_quantity_value_type  type; 
        };
    }
    
}// pqs

#endif
