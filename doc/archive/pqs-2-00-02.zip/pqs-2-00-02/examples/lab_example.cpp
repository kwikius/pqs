//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    This example was originally presented on the boost mailing list:
    http://lists.boost.org/MailArchives/boost/msg55344.php
*/

#include "pqs/pqs.hpp"


// function works in standard units
pqs::force::N  Force(
    pqs::mass::kg           const& mass,
    pqs::velocity::m_div_s  const& initial_veloc,
    pqs::velocity::m_div_s  const& final_veloc,
    pqs::time::s            const& t)
{
    return   mass * (final_veloc - initial_veloc) / t;
}

int main()
{
    //lab technician works in "odd units"...

    pqs::mass::g               const mass(0.1f);
    pqs::velocity::mm_div_min  const initial_v(5);
    pqs::velocity::mm_div_min  const final_v(5.5);
    pqs::time::min             const t_min(10);
    pqs::time::s               const t_sec( 12);

    // function does the work ... he doesnt have to...

    std::cout << "force on mass = " << Force(mass,initial_v, final_v, t_min + t_sec) << '\n';

    return 0;
}
