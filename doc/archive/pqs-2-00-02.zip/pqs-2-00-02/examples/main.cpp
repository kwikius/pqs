//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
     demonstrates complex physical_quantities
    and angular velocity using radians value_type
*/

// must be defined before all  headers
// if defined treats radians as a numeric with more attributes
// that can be ' decayed ' to a numeric

#include "pqs/pqs.hpp"
#include "pqs/types/mass_flow_out.hpp"
int main()
{
    std::cout << pqs::mass_flow::kg_div_s(20) - pqs::mass_flow::g_div_s(20)<<'\n';
    pqs::length::ft ft = pqs::length::fathom(1);
    std::cout << ft <<'\n';
    ft = pqs::length::fathom_us(1);
     std::cout << ft <<'\n';
}
