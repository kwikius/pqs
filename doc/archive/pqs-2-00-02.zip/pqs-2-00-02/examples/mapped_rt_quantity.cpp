//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    rt_quantity including a static units map
    application is simple command line units converter
    note: This one may take some time to compile!
*/

#include "pqs/rt_quantity/mapped_rt_quantity.hpp"

// could include pqs/pqs.hpp" but very slow to compile
#include "pqs/types/length_out.hpp"
#include "pqs/types/area_out.hpp"
#include "pqs/types/volume_out.hpp"
#include "pqs/types/mass_out.hpp"
#include "pqs/types/velocity_out.hpp"
#include "pqs/types/force_out.hpp"
#include <utility>
#include <sstream>

namespace pqs{

    // definition of static rt_units_map member
    template<
        typename NamedAbstractQuantity,
        typename Value_type,
        typename CharType
    >
    rt_units_map<NamedAbstractQuantity,CharType> 
    mapped_rt_quantity<NamedAbstractQuantity,Value_type,CharType>::units_map;
    
// derive  classes from mapped_rt_quantity<of_xx> fill units in ctor
// could use check in ctor as only need add units on first instantiation
/// better impl might not use static member
  
    class mapped_length : public mapped_rt_quantity<of_length::type>{
    public:
        mapped_length()
        {
            if (this->units_map.size() == static_cast<size_t>(0)){
                this->add_unit<length::m>();
                this->add_unit<length::km>();
                this->add_unit<length::mi>();
                this->add_unit<length::yd>();
                this->add_unit<length::in>();
                this->add_unit<length::ft>();
                this->add_unit<length::cm>();
                this->add_unit<length::mm>();
            }
        }
    };

    class mapped_area : public mapped_rt_quantity<of_area::type>{
    public:
        mapped_area()
        {
            if (this->units_map.size() == static_cast<size_t>(0)){
                this->add_unit<area::m2>();
                this->add_unit<area::cm2>();
                this->add_unit<area::a>();
                this->add_unit<area::dam2>();
                this->add_unit<area::ft2>();
                this->add_unit<area::in2>();  
                this->add_unit<area::km2>();  
                this->add_unit<area::mi2>(); 
            } 
        }
    };
    
    class mapped_volume : public mapped_rt_quantity<of_volume::type>{
    public:
        mapped_volume()
        {
            if (this->units_map.size() == static_cast<size_t>(0)){
                this->add_unit<volume::m3>();
                this->add_unit<volume::cm3>();
                this->add_unit<volume::gal>();
                this->add_unit<volume::ft3>();
                this->add_unit<volume::yd3>();
            }            
        }
    };

    class mapped_mass : public mapped_rt_quantity<of_mass::type>{
    public:
        mapped_mass()
        {
            if (this->units_map.size() == static_cast<size_t>(0)){
                this->add_unit<mass::kg>();
                this->add_unit<mass::g>();       
                this->add_unit<mass::lb>();
                this->add_unit<mass::oz>(); 
            }     
        }
    };

    class mapped_velocity : public mapped_rt_quantity<of_velocity::type>{
    public:
        mapped_velocity()
        {
            if (this->units_map.size() == static_cast<size_t>(0)){
                this->add_unit<velocity::m_div_s>();
                this->add_unit<velocity::km_div_h>();
                this->add_unit<velocity::mi_div_h>();
                this->add_unit<velocity::ft_div_s>();
                this->add_unit<velocity::knot>();
            }
        }
    };

    class mapped_force : public mapped_rt_quantity<of_force::type>{
    public:
        mapped_force()
        {
            if (this->units_map.size() == static_cast<size_t>(0)){
                this->add_unit<force::N>();
                this->add_unit<force::kgf>();
                this->add_unit<force::lbf>();  
            }
        }
    };
 
    template <
        typename NamedAbstractQuantity,
        typename Value_type
    >
    bool unit_convert(mapped_rt_quantity<
            NamedAbstractQuantity,
            Value_type
    > & map,
        Value_type const & v, 
        std::string const& src_str);
}//pqs

using namespace pqs;
std::pair<bool,double> num_convert(std::string const& str);
bool do_another();

int main()
{
    mapped_length       length;
    mapped_area         area;
    mapped_volume       volume;
    mapped_mass         mass;
    mapped_velocity     velocity;
    mapped_force        force;
    
    bool user_continue = true;
    while (user_continue){
        std::cout << "Select units from the lists:\n\n";
        length.list_units(std::cout);
        std::cout <<'\n';
        area.list_units(std::cout);
        std::cout <<'\n';
        volume.list_units(std::cout);
        std::cout <<'\n';
        velocity.list_units(std::cout);
        std::cout <<'\n';
        force.list_units(std::cout);

        std::cout <<"\n\n";

        std::cout << "Enter Value and Units to convert from (e.g: 1 m.s-1 ) :\n";
        std::string num_str; 
        std::cin >> num_str;
        std::pair<bool,double> numgood = num_convert(num_str);
        if (!numgood.first){
            std::cout << "sorry \"" << num_str << "\" invalid number\n";
        }
        else{ 
            double v = numgood.second; 
            std::string str;    std::cin >> str;
            if (length.units_map.find(str) != length.units_map.end()){ 
                unit_convert(length, v ,str);
            }
            else if (area.units_map.find(str) != area.units_map.end()){ 
                unit_convert(area, v ,str);
            } 
            else if (volume.units_map.find(str) != volume.units_map.end()){ 
                unit_convert(volume, v ,str);
            } 
            else if (velocity.units_map.find(str) != velocity.units_map.end()){ 
                unit_convert(velocity, v ,str);
            } 
            else if (force.units_map.find(str) != force.units_map.end()){ 
                unit_convert(force, v ,str);
            } 
            else{
                std::cout << "sorry unit \"" << str << "\" not found\n";
            }
        }
        user_continue = do_another();
    }
}


namespace pqs{

    template <typename NamedAbstractQuantity,typename Value_type>
    bool unit_convert(
        mapped_rt_quantity<NamedAbstractQuantity,Value_type> & mrt,
        Value_type const & v, 
        std::string const& src_str)
    {
        if ( mrt.set_quantity(v, src_str) ){
            std::cout << "\nEnter Units to convert to :\n";
            std::string dest_str;   std::cin >> dest_str;
            std::cout <<'\n';
            if(mrt.set_units(dest_str)){
                std::cout << v << ' ' << src_str << " = " << mrt <<'\n';
                return true;
            }
            else{
                std::cout << "sorry, \"" << dest_str <<  "\" invalid units " ;
            }     
        }
        else {
            std::cout << "sorry, \"" << src_str <<  "\" invalid units " ;
        }
        return false;
    }
}//pqs

std::pair<bool,double> num_convert(std::string const & str)
{
    if (str.length() ==0) return std::pair<bool,double>(false,0.);
    std::string::const_iterator iter = str.begin();
    int points=0;
    while (iter != str.end()){
        if ( !isdigit(*iter) ) {
            if ( *iter == '.'){
                if ( ++points > 1 ){
                    return std::pair<bool,double>(false,0.);
                }
            }
            else return std::pair<bool,double>(false,0.);
        }
        ++iter;
    }
    std::istringstream istr(str);
    double res;
    istr >> res;
    return std::pair<bool,double>(true,res);      
}

bool do_another()
{
        std::cin.sync();
        std::cout << "\nTry another Y/N?\n";
        std::string str;
        std::cin >> str;
        return ( ( str == "Y" ) || ( str  == "y" ) );
}
