//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*  
    morph demo
    morph SourceType into TargetType
    ie for converting (say) force to length in graphics
    set scale in morph ctor, or =1 by default
    use as a functor
    Note that this is preferable to low level stuff
    because it preserves scaling and works for all types
    An object can be morphed for use where
    (say) a function requires a double
    then morphed back to the original type
*/

#include "pqs/pqs.hpp"
#include "pqs/math/angles/angles_out.hpp"
#include "pqs/util/morph.hpp"

int main()
{
    // works on any two types that have binary_operation
    // defined
   // typedef velocity::m_div_s source_type;// could be ct_quantity etc
    typedef pqs::time::s source_type;
    typedef pqs::length::mm target_type; 
    source_type s_ext (10); 
    target_type t_ext(1000);

    source_type s(2);
    std::cout << "source " << s << '\n';
    pqs::morph<target_type,source_type>::intermediate_type   scale(t_ext/s_ext);
    std::cout << "scale = " << scale <<'\n';
    pqs::morph<target_type,source_type> morph_to(scale);
    
    target_type t = morph_to(s);
    std::cout << "morphed " << t << '\n';
    pqs::morph<source_type,target_type> morph_from(1/scale);
    s = morph_from(t);
    std::cout << "unmorphed " << s << '\n';
   
}
   
