// pqs pqs-1-00-02 03:50 29/11/2003
//pq_complex.cpp
//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    some tests on complex operators
    +,-,*,/
    hmmm... still require power and root
*/

#include "pqs/ct_quantity/complex.hpp"

//although "pqs/pqs.hpp" could be included
//including only required type headers
//can reduce compilation time significantly:
#include "pqs/types/voltage_out.hpp"
#include "pqs/types/current_out.hpp"
#include "pqs/types/resistance_out.hpp"
#include "pqs/types/inductance_out.hpp"
#include "pqs/types/power_out.hpp"
#include "pqs/types/time_out.hpp"
#include "pqs/types/frequency_out.hpp"

//impedance in style of other types
namespace pqs{
    struct impedance{
        typedef std::complex<resistance::R> R;
    };
}

int main()
{  
   /* using pqs::voltage;
    using pqs::current;
    using pqs::frequency;
    using pqs::resistance;
    using pqs::inductance;
    using pqs::power;
    using pqs::time;
    using pqs::impedance;
    using std::complex;*/
    using namespace pqs;
#if defined __GNUC__
// required for gcc
    using pqs::time;
#endif
//
   using std::complex;
    voltage::V            V(1);
    std::cout << "V         = " << V <<'\n';
    complex<voltage::V>   CV (voltage::V(1),voltage::V(0));
    std::cout << "CV        = " << CV << '\n';
    complex<voltage::mV>  CmV (voltage::mV(0),voltage::mV(1000));
    std::cout << "CmV       = " << CmV <<'\n';
    current::A            I(1);
    complex<current::A>   CI(current::A(1.0),current::A(0.0));
    complex<current::mA>   CmI (current::A(1.0),current::A(0.0));
    
    std::cout << "+\n"; 
    std::cout << "CV + CV   = " << CV + CV  << '\n';
    std::cout << "CV + CmV  = " << CV + CmV << '\n';
    std::cout << "CV + V    = " << CV + V   << '\n';
    std::cout << "CmV + V   = " << CmV + V  << '\n';
    std::cout << "V + CV    = " << V + CV   << '\n';
    std::cout << "V + CmV   = " << V + CmV  << '\n';

    std::cout << "-\n"; 
    std::cout << "CV - CV   = " << CV - CV  << '\n';
    std::cout << "CV - CmV  = " << CV - CmV << '\n';
    std::cout << "CV - V    = " << CV - V   << '\n';
    std::cout << "CmV - V   = " << CmV - V  << '\n';
    std::cout << "V - CV    = " << V - CV   << '\n';
    std::cout << "V - CmV   = " << V - CmV  << '\n';

    std::cout << "*\n";
    std::cout << "V * V     = " << V * V    << '\n';

//1	complex<pq>, Op,complex<pq> 
    std::cout << "CV * CV   = " << CV * CV  << '\n';
//2	complex<pqL>,Op,complex<pqR>
    std::cout << "CV * CmV  = " << CV * CmV << '\n';

//3	complex<pqL>,Op,complex<vR>
    std::cout << "CV * complex<double>(0,1)= " 
    << CV * complex<double>(0,1) << '\n';

//4	complex<vL>,Op,complex<pqR>
   std::cout << "complex<double>(0,1)* CV  " 
    << complex<double>(0,1) * CV << '\n';

//5	complex<pq>, Op, pq 
    std::cout << "CV * V    = " << CV * V   << '\n';

//7	pq,Op,complex<pq> 
    std::cout << "V * CV    = " << V * CV   << '\n';

//8	pqL,Op,complex<pqR>
    std::cout << "V * CmV   = " << V * CmV  << '\n';

//6	complex<pqL>,Op,pqR
    std::cout << "CmV * V   = " << CmV * V  << '\n';

//9	 complex<vL>,Op,pqR
   std::cout << "complex<double>(0,1)* V  " 
    << complex<double>(0,1) * V << '\n';

//10 pqL, Op,complex<vR>
      std::cout << "V * complex<double>(1,0)= " 
    << V * complex<double>(1,0) << '\n';

//11 complex<pqL>,Op,vR
    std::cout << "CV * 2    = " << CV * 2   << '\n';
//12	vL,Op,complex<pqR>
    std::cout << "2 * CV    = " << 2 * CV   << '\n';
//13 check dimensionless calc
    std::cout << "complex<time::s>(time::s(1),time::s(0))"
    "* complex<frequency::Hz>(frequency::Hz(1),frequency::Hz(0)) =";
    std::cout << complex<time::s>(time::s(1),time::s(0))
    * complex<frequency::Hz>(frequency::Hz(1),frequency::Hz(0)) <<'\n';
    std::cout << complex<time::us>(time::s(1),time::s(0)) * frequency::Hz(1) <<'\n';
std::cout << "*\n";
  
//1	    complex<pq>, Op,complex<pq>
    std:: cout << " CV / CV = " << CV / CV <<'\n';
//2	    complex<pqL>,Op,complex<pqR>
    std::cout << "CV / CmV = "  << CV / CmV <<'\n';
    impedance::R Z = CV / CI;
    std::cout << "CV / CI = "   << Z <<'\n';
//3	    complex<pqL>,Op,complex<vR>
    std:: cout << "CV / complex<double>(1,0) = "
    << CV/complex<double>(1,0) <<'\n';
//4	    complex<vL>,Op,complex<pqR>
    std::cout << "complex<double>(1,0) / CV = "
    << complex<double>(1,0) / CV <<'\n';
//5	    complex<pq>, Op, pq
    std::cout << "CV / V = " << CV / V <<'\n';
//6	    complex<pqL>,Op,pqR
    impedance::R Z1 = CV / I;
    std::cout << "CV / I = " << Z1 <<'\n';
//7	    pq,Op,complex<pq>
    std::cout << "V / CV = " << V / CV << '\n';
//8	    pqL,Op,complex<pqR>
    impedance::R Z2 = V / CI;
    std::cout << "Z2 = V / CI = " << Z2 << '\n';
//9	    complex<vL>,Op,pqR
    std::cout << "complex<double>(1,0) / V = "
    << complex<double>(1,0) / V <<'\n';
//10	pqL, Op,complex<vR>
   std::cout << "V / complex<double>(1,0) = "
    << V / complex<double>(1,0)<<'\n';
//11	complex<pqL>,Op,vR
    std::cout << "CV / 2.0 = " << CV / 2.0 <<'\n';     
//12	vL,Op,complex<pqR>
    std::cout << "2.0 / CV = " << 2.0 / CV << '\n';
    std::cout << "CV * 2 = " << CV * 2 <<'\n';
    std::cout << "2 * CV = " << 2 * CV <<'\n';

    complex<current::A> CI1 = CV / Z2;
    std::cout << "CV / Z2 = "<<  CI1 <<'\n';
    std::cout << pqs::pow<0>(pqs::voltage::V(1000))<<'\n';
}


