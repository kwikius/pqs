//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    rotational motion demo of angles, quantities etc
    also see alternate version "complex_rotary_motion.cpp"
    which uses complex instead of Point defined below

*/

// quantities
#include "pqs/pqs.hpp"
// quantity <-> angle interface w' output of angles
#include "pqs/math/angles/angles_out.hpp"
// for pi
#define NO_PQS_CONSTANTS_LIBRARY

#ifdef NO_PQS_CONSTANTS_LIBRARY
    #include "pqs/math/lib_src/constant.cpp"
    #include "pqs/math/angles/lib_src/angles.cpp"
#endif
// for overloaded atan2 currently called arctangent2 but could change
// to atan2
#include "pqs/ct_quantity/operations/arctangent2.hpp"

namespace pqs{
// create angular velocity type, with radians value_type
    struct angular_velocity{
        typedef ct_quantity<
            named_abstract_quantity<  
                of_frequency::anonymous_abstract_quantity_type
                // tag defaults to anonymous named_quantity_tag 
                // hence dont get Hz units in output
            >,
            si_unit::none,
            math::of_angle::rad
        > rad_div_s;
    };
}
// hold a coordinate .. alternative to complex
template<typename T>
struct Point{
    Point (T const& x_in, T const& y_in)
    : x(x_in),y(y_in){}
    T x;
    T y;
};



int main()
{  
    using pqs::length;
    using pqs::time;
    using pqs::math::of_angle;
    using pqs::angular_velocity;
    using pqs::pow;
    using pqs::sqrt;

    // show fp errors
    std::cout.precision(32);
    // Assume centre of rotation at (0 m , 0 m)
    // using this seed radius is nominally 1m 
    length::m seed = length::m(sin(of_angle::deg(45)));

   // Assume an entity starting at a point in x,y coordinates, units of metres at 45 degrees
    Point<length::m> const  start(seed,seed);

     // calc radius of arc of revolution
    length::mm radius = sqrt(pow<2>(start.x) + pow<2>(start.y));
    std::cout << "radius of arc of revolution = " << radius <<'\n';
   // calc starting angle in radians and output in degrees
    // note arctangent2 could be renamed atan2 but freezes VC7.1 if
    // parameter information drop down ticked in IDE
    of_angle::rad const starting_angle = arctangent2(start.y, start.x);
    std::cout << "starting angle = " << of_angle::deg(starting_angle) <<'\n';

    // Assume angular velocity of entity of pi/4 radians per sec ( == 45 degrees per sec)
  //  angular_velocity::rad_div_s const w(pqs::math::constant::pi / 4); 
    angular_velocity::rad_div_s const w(pqs::math::of_angle::pi / 4);
    //find position of entity 1 second later
    time::s const   t(1);
    std::cout << "angle travelled at " << w << " in " << t << " = " << of_angle::deg(w * t) << '\n';

    //one way to do the calc

    std::cout << "using first calc...\n";
    // calc resulting angle after time t... using degrees herefor demo purposes
    of_angle::deg finish_angle = starting_angle + w * t;
    // show finish angle 
    std::cout << "finish angle = " << finish_angle <<'\n';
    // calculate finish point note does sin(degrees) etc
    Point<length::m> finish = Point<length::m>(radius * cos(finish_angle),radius * sin(finish_angle)); 
    
    std::cout << "finish point = (" << finish.x << "," << finish.y << ")\n";  

    // alternate way to do the calc...

    std::cout << "using alternate calc... \n";
    Point<length::m> finish1 
    = Point<length::m>(
        start.x * cos(w * t) - start.y * sin(w * t),
        start.x * sin(w * t) + start.y * cos(w * t) );
    std::cout << "finish_angle = " << of_angle::deg(arctangent2(finish1.y, finish1.x)) << '\n';
    std::cout << "finish point = (" << finish1.x << "," << finish1.y << ")\n";
    std::cout << "\nnote: Theoretically 'finish point' should be (0 m,1 m) of course...\n";
    
}
