//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    rt_quantity
    A runtime modifiable physical_quantity
    using the ct-quantity as a building block
*/

#include "pqs/rt_quantity/rt_quantity.hpp"
#include "pqs/types/length_out.hpp"

using namespace pqs;
int main()
{
    //rt-quantity default constructor example
    typedef rt_quantity<of_length::type> rt_length;
    std::cout <<"rt-quantity(length) with default ctor: "
    << rt_length() <<'\n';

    // rt_quantity initialised by ct-quantity
    rt_length length(length::ft(1));
    std::cout <<"rt-quantity(length) ctor with length::ft(1) arg : "
    << length << '\n';

    std::cout << "put units to ostream : ";
    length.put_units(std::cout);
    std::cout << '\n';

    std::cout << "get units to string : " << length.units_str() <<'\n';
    std::cout << "get numeric_value : " << length.numeric_value() <<'\n';

    // set the numeric_value of the quantity
    length.set_numeric_value(2.0);
    std::cout << "set_numeric_value(2.0) : " << length <<'\n';

    //change rt_quantity internal units - pq value scaled to new units
    length.set_units<length::um>();
    std::cout << "set units set to um : " << length << '\n';
       
    // assign rt_quantity from length of arbitrary units
    // internal value changed, but units not changed (here miles)
    length = length::mi(1);
    std::cout << "assign from length::mi(1) : " 
    << length <<'\n';

    // install rt_quantity from length of arbitrary units
    // internally pq replaced by new type
    length.install( length::mi(1));
    std::cout << "install length::mi(1) : "
    << length <<'\n';

    // return a ct_quantity cast from rt_quantity
    // rt_quantity value unaffected
    length::yd  yds = length;
    std::cout << "cast to a length::yd : " 
    << yds << '\n';

    //init rt_quantity by another rt_quantity
    std::cout << "\ninitialise by other rt-quantity...\n";
    rt_length length1(length::yd(1));
    std::cout << "rt_length length1(length::yd(1)); : " 
    << length1 << '\n';
//
    rt_length length2 = length1;
    std::cout << "rt_length length2(length1); : " 
    << length2 << '\n';

    // assignment to change units or not ?
    // probably not but assign != initialise
    std::cout << "\nassign from other rt-quantity...\n";
    rt_length length3;
    std::cout << "rt_length length3; : " <<  length3 << '\n';
    length3 = length1;
    std::cout << "length3 = length1; : " << length3 << '\n';
   
    //install does the job
    std::cout << "\ninstall other rt_quantity...\n";
     rt_length length4;
    std::cout << "rt_length length4; : " <<  length4 << '\n';
    length4.install(length1);
    std::cout << "length4.install(length1); : " << length4 << '\n';

    // how much memory is used?
    // rt_quantity allocates 1 detail::member_pq
    std::cout << "\nmemory footprints:\n";
    unsigned int rt_length_size = static_cast<unsigned int>(sizeof(rt_length));
    unsigned int  member_pq_size 
    = static_cast<unsigned int>(
    sizeof(pqs::detail::member_pq<of_length::type,quantity_unit<>,double >) );
    std::cout 
    << "sizeof(rt_length) = "<<  rt_length_size <<'\n';
   
    std::cout 
    << "sizeof(pqs::detail::member_pq<of_length::type,quantity_unit<>,double >) = "
    <<   member_pq_size <<'\n';
    std::cout << "total  = " << rt_length_size + member_pq_size <<'\n';
   
}



