//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    runtime modifiable physical_quantity
    using the ct-quantity as a building block
    with units map for setting units via strings
*/

#include "pqs/rt_quantity/rt_units_map.hpp"
#include "pqs/types/velocity_out.hpp"

using namespace pqs;

int main()
{
    //the rt_units_map holds valid units for an rt-quantity
    rt_units_map<velocity::type>  velocity_units;

    // velocity_units needs to be filled with units before use
    // using the ct-quantity in the required unit as the parameter
    // different instances of rt_units_map<..> can therefore hold different sets of units
   // for different quantities
    velocity_units.add_unit<velocity::m_div_s>();
    velocity_units.add_unit<velocity::knot>();
    velocity_units.add_unit<velocity::km_div_h>();
    velocity_units.add_unit<velocity::mi_div_h>();
    velocity_units.add_unit<velocity::ft_div_s>();
    
    // create an rt-quantity for v1
    rt_quantity<velocity::type>  v1;
    // now units of v1 can be changed via velocity_units
    // using unit-symbol string.
    // internally map looks up units as a string for each ct-quantity entered
    // (via units_str(pq)  ), which is mapped to rt_quantity member function ptr
    // map is then used to set units for an instance of rt-quantity
    // from the unit string

    // NOTE "velocity_units" now looks like a function 
    // but is an object of type rt_units_map<of_velocity::type>
    // "velocity_units" can be called whatever you like
    velocity_units.set(v1, "m.s-1");
    // the raw value of the rt-quantity can be modified
    v1.set_numeric_value(1);
    std::cout << v1 <<'\n';
    // but subsequent changes in unit change it so set units first...
    std::cout << "change units which updates value to new units\n";
    velocity_units.set(v1, "km.h-1");
    std::cout << "= "<< v1 <<'\n';

    velocity_units.set(v1, "mi.h-1");
    std::cout << "= "<< v1 <<'\n';

    velocity_units.set(v1, "knot");
    std::cout << "= "<< v1 <<'\n';

    velocity_units.set(v1, "ft.s-1");
    std::cout << "= "<< v1 <<'\n';

    // or set both value and units as desired for simplicity
    std::cout << "Or set units and value to (say) 20 knots\n";
    velocity_units.set(v1, 20, "knot");
    std::cout << "new value, units = "<< v1 <<'\n';


    // returns bool so if string invalid can be checked:
    if(!velocity_units.set(v1, "unknown unit"))
        std:: cout << "invalid units strings return false, leave units unchanged\n";

    rt_units_map<velocity::type>::const_iterator iter = velocity_units.begin(); 
    std::cout << "\nlist of quantity-unit-symbols in map\n---------------\n";
    while (iter != velocity_units.end()){
        std::cout << iter->first <<'\n';
        ++iter;
    };

    std::cout << "---------------\n";       
}
