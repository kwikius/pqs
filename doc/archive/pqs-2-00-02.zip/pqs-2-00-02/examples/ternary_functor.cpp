//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    demo of a ternary operator functor,
    evaluation order dependent on operator precedence.
    definition in ternary_functor.hpp
    probably a bit screwy... see also array_calcs.cpp
    for ET version
*/

#include "ternary_functor.hpp"
#include "pqs/types/length.hpp"
#include "pqs/types/time.hpp"
#include "pqs/types/velocity_out.hpp"
#include "pqs/types/force_out.hpp"
#include "pqs/types/mass.hpp"


int main()
{
    pqs::velocity::m_div_s     v(1.0);
    pqs::length::m             l(1.0);
    pqs::time::s               t(1.0);

    typedef pqs::ternary_operation<
        // velocity + distance/time
        pqs::velocity::m_div_s,
        std::plus,
        pqs::length::m,
        std::divides,
        pqs::time::s
    > ternary1;
    ternary1::result_type tt1 =  ternary1()(v,l,t);
    std::cout << tt1 <<'\n';

   // f = m((v - u)/t);
    pqs::velocity::m_div_s     u(0);
    pqs::mass::kg              m(1);
    typedef pqs::ternary_operation<
        pqs::mass::kg,
        std::multiplies,
        pqs::binary_operator<
            pqs::velocity::m_div_s,
            std::minus,
            pqs::velocity::m_div_s
        >::result_type,
        std::divides,
        pqs::time::s
    > ternary2;

    ternary2::result_type tt2 = ternary2()(
        m,  pqs::binary_operator<  
                pqs::velocity::m_div_s,
                std::minus,
                pqs::velocity::m_div_s
            >()(v,u), t);
       std::cout << tt2 <<'\n';  
}
