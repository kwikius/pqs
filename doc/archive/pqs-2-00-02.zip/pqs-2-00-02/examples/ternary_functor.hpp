#ifndef PQS_EXAMPLES_TERNARY_FUNCTOR_HPP_INCLUDED
#define PQS_EXAMPLES_TERNARY_FUNCTOR_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/* ternary functor with eval order dependent on operator precedence*/
#include "pqs/operators/binary_operators.hpp"

namespace pqs{

    template <
        bool Op1_first,
        typename A,
        template<typename> class Op1,
        typename B,
        template<typename>class Op2,
        typename C
    >
    struct ternary_if_c;

    template <
        typename A,
        template<typename>class Op1,
        typename B,
        template<typename>class Op2,
        typename C 
    >
    /* execed if Op1 first*/
    struct ternary_if_c<true,A,Op1,B,Op2,C>{

        typedef binary_operator<
            A,Op1,B
        > first_op;
        typedef binary_operator<
            typename first_op::result_type,Op2,C
        > second_op;
        typedef typename second_op::result_type result_type;
        result_type operator()(A const& a, B const& b, C const & c)
        {
            return second_op()( first_op()(a,b),c);
        }
    };

    template <
        typename A,
        template<typename>class Op1,
        typename B,
        template<typename>class Op2,
        typename C 
    >
    /* exweced if Op2 first */
    struct ternary_if_c<false,A,Op1,B,Op2,C>{

        typedef binary_operator<
            B,Op2,C
        > first_op;
        typedef binary_operator<
            A,Op1,typename first_op::result_type
        > second_op;

        typedef typename second_op::result_type result_type;
        
        result_type operator()(A const& a, B const& b, C const& c)
        {
            return second_op()(a,first_op()(b,c));
        }
    };

    template <
        typename A,
        template<typename>class Op1,
        typename B,
        template<typename>class Op2,
        typename C
    >
    struct ternary_operation{
        enum{ a_first =
            (binary_operator_traits<Op1>::expression_family >=
            binary_operator_traits<Op2>::expression_family)};

        typedef ternary_if_c<a_first,A,Op1,B,Op2,C> op;
        typedef typename op::result_type result_type;
        
        result_type operator()(A const& a, B const& b , C const& c)
        {
            return op()(a,b,c);
        }
    };
}//pqs
 




#endif
