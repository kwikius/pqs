/*
    demo of using a system timer using pqs::time::s 
    as a type
*/
#include "pqs/util/timer.hpp"
#include "pqs/types/time_out.hpp"

namespace pqs{
   
    void sleep( time::s const & duration )
    {
        pqs::timer stop_watch;      
        while( stop_watch() < duration ){
            ;
        }
    } 
}

int main( void )
{
   using pqs::time;
   /*keep the user waiting for a while... */
   int const n_waits = 5;
   time::s const wait_interval(1); 
   for (time::s time_left = wait_interval * n_waits;
            time_left > time::s(0);
                time_left -= wait_interval){
        std::cout << "\n\tHang on just " << time_left << '\n';
        sleep(wait_interval); 
   }
   std::cout << "\n\t...Apologies for keeping you waiting!\n" ;
   
}


