//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    The new version of pqs has slightly changed semantics 
    from previous versions up to and including pqs-1-01-04.
    This example shows the new semantics affecting dimensionally-equivalent 
    but different concrete-quantities.
    Here torque and energy are used as examples
    Basically torque and energy are named-concrete-quantities
    with same underlying dimensions, but different phenomena
    therefore by default Warning is given if one type is assigned to the other
    cast to anonymous type by anonymous_cast to remove warnings
*/

#include "pqs/pqs.hpp"
#include "pqs/ct_quantity/operations/atan2.hpp"
#include "pqs/types/energy_out.hpp"
#include "pqs/types/torque_out.hpp"
#include "pqs/types/force_out.hpp"
#include "pqs/types/length_out.hpp"
#include "pqs/types/area_out.hpp"
#include "pqs/types/volume_out.hpp"

namespace si = pqs;
int main()
{
    si::torque::N_m torque = si::force::N(1) * si::length::m(1);
    si::energy::J   energy = si::force::N(1) * si::length::m(1);

// this (should) give a warning
   std::cout << atan2(torque,energy) <<'\n';

// use anonymous_cast to remove warning
// (anonymous quantity results from many calculations on two quantities
// see semantics.html for more information on which ones
// (Should be rarely needed)
    std::cout << atan2(torque,anonymous_cast(energy)) <<'\n';
//or
    std::cout << atan2(anonymous_cast(torque),energy ) <<'\n';
//or
    std::cout << atan2(anonymous_cast(torque),anonymous_cast(energy) ) <<'\n';



// Ok.. division by anonymous quantity here
    std::cout << torque / (si::force::N(1) * si::length::m(1) ) <<'\n';
    std::cout << energy / (si::force::N(1) * si::length::m(1) ) <<'\n'; 

// warning given on division by named-quantity here
    std::cout << torque / energy <<'\n';
    std::cout << energy / torque  <<'\n';  

}
