#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_ARRAY_HPP_INCLUDED
#define PQS_ARRAY_HPP_INCLUDED

namespace pqs {

    template<typename T , int Size>
    struct array{
        T elements[Size];
        T operator [](int i)const {return elements[i];}
        T& operator [](int i){return elements[i];}
    };

}
#endif
