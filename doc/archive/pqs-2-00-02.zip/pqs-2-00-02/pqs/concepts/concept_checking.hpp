#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CONCEPTS_CONCEPT_CHECKING_HPP_INCLUDED
#define PQS_CONCEPTS_CONCEPT_CHECKING_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

// modified from the boost version which is
//
// (C) Copyright Jeremy Siek 2000. Permission to copy, use, modify,
// sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.

// See http://www.boost.org/libs/concept_check

/*
    concept checking classes
*/

#include "boost/type_traits/is_arithmetic.hpp"
#include "boost/type_traits/is_integral.hpp"
#include "pqs/meta/associated_arithmetic.hpp"
#include <limits>

namespace pqs{ namespace concept_checking{


    template<typename T>
    inline void ignore_unused_variable_warning(const T&){};

    template <typename Concept>
    inline void function_requires()
    {
        void (Concept::*x)() = &Concept::constraints;
        ignore_unused_variable_warning(x);
    }


    template< bool Assertion>struct Assert;

    template<>struct Assert<true>{};

    template<typename ArithmeticType>
    struct AssertIsArithmetic 
    : Assert<boost::is_arithmetic<ArithmeticType>::value >{};

    template<typename ArithmeticTypeA, typename ArithmeticTypeB>
    struct AssertAreBothArithmetic 
    : Assert<
        (boost::is_arithmetic<ArithmeticTypeA>::value 
        && boost::is_arithmetic<ArithmeticTypeB>::value)  >{};

    template<typename IntegralType>
    struct AssertIsIntegral 
    : Assert<boost::is_integral<IntegralType>::value >{};

    template<typename IntegralTypeA, typename IntegralTypeB>
    struct AssertAreBothIntegral 
    : Assert<
        (boost::is_integral<IntegralTypeA>::value 
        && boost::is_integral<IntegralTypeB>::value)  >{};

    template<typename FundamentalType>
    struct AssertIsFundamentalType 
    : Assert<std::numeric_limits<FundamentalType>::is_specialized>{};

    template<typename FundamentalTypeA, typename FundamentalTypeB>
    struct AssertAreBothFundamentalTypes 
    : Assert< (std::numeric_limits<FundamentalTypeA>::is_specialized &&
        std::numeric_limits<FundamentalTypeB>::is_specialized) >{};

   
    // assert that the parameter can be converted to an arithmetic type via the 
    // pqs::meta::to_arithmetic metafunction
    template<typename ToArithmeticType>
    struct AssertToArithmetic 
    : Assert<
         boost::is_arithmetic< 
            typename pqs::meta::to_arithmetic<ToArithmeticType>::type
        >::value 
    >{};
        
}}//~pqs::concept_checking

namespace pqs{

    template<typename Target, typename Source>
    struct ImplicitInitialisableConcept{

        void constraints()
        {
            Target t = *ps;
        }
        Source* ps;
    };

    template<typename Target, typename Source>
    struct ExplicitInitialisableConcept{

        void constraints()
        {
            Target t(*ps);

            concept_checking::ignore_unused_variable_warning(t);
        }
        Source * ps;
    };

    template<typename Target, typename Source>
    struct AssignableConcept{

        void constraints()
        {
            *pt = *ps;
        }
        Source* ps;
        Target* pt;

    };

   /* template<typename Target>
    struct ConstructibleConcept{

        void constraints()
        {
            Source s = Source();
            Target t = Target();
            t = s;

            concept_checking::ignore_unused_variable_warning(t);
        }

    };*/

}

#endif
