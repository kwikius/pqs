#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CONFIG_HPP_INCLUDED
#define PQS_CONFIG_HPP_INCLUDED

/*
    configuration settings for pqs-2-00-02
*/
//********** DEPRECATING THE Q_ PREFIX ********
/*
    The q_ prefix on types has been deprecated in pqs-2-00-02.
    eg pqs::q_length::mm ---> pqs::length::mm ;
    However for backward compatibility uncomment the following MACRO
    if you require only the q_ prefix versions to be available.
*/
// #define PQS_USE_Q_PREFIX_ON_CT_QUANTITY_TYPES

//********** CONVERSION POLICY *****************

// defaults to pqs::numeric::converter 
// if neither of the following defined
// Only one or the other of the following should be defined

/*  
    boost::numeric::converter Is  
    superior to the pqs::numeric::converter
    Recomended if you have the official boost libraries
    should be available in boost-1.32.0 
    note also that it throws different exception to pqs::numeric::converter
    // however pqs::conversion_range is now derived from boost version
// ultimately now derived from std::bad_cast
    see the boost/numeric/converter docs for details
*/
  //  #define  PQS_USE_BOOST_NUMERIC_CONVERTER

/* 
    For no checks on conversions
    useful for no exception support
    default C++ rounding modes
*/
//    #define   PQS_USE_UNCHECKED_CONVERTER

/************** COMPARISON POLICY **********************/
// all comparison functions for quantities and angles
// use this value of epsilon by default
// though comapare has extra param for user def epsilon of particular type
// for equivalence <, <=,>, >=  != etc
// quantity with numeric value in range +- PQS_COMPARISON_EPSILON
// of other is equivalent.
// conversion makes this zero on ints

#ifndef PQS_COMPARISON_EPSILON
#define PQS_COMPARISON_EPSILON  0.0
#endif

#endif
