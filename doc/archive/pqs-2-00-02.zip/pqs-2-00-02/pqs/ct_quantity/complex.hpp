#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CT_QUANTITY_COMPLEX_HPP_INCLUDED
#define PQS_CT_QUANTITY_COMPLEX_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    complex binary_operations
*/

#include <complex>
#include "pqs/ct_quantity/complex/arspecialize.hpp"
#include "pqs/ct_quantity/complex/plus.hpp"
#include "pqs/ct_quantity/complex/minus.hpp"
#include "pqs/ct_quantity/complex/divide.hpp"
#include "pqs/ct_quantity/complex/multiply.hpp"
#include "pqs/ct_quantity/complex/argument.hpp"

#endif

