#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_COMPLEX_ARGUMENT_HPP_INCLUDED
#define PQS_COMPLEX_ARGUMENT_HPP_INCLUDED

/*
    arg for complex quantity but returns angle
    hence called argument
*/

#include "pqs/ct_quantity/operations/arctangent2.hpp"
#include "pqs/ct_quantity/complex/complex_binary_operation.hpp"

namespace pqs{

   template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
   >
   inline
    typename pqs::math::radians<
        pqs::meta::rational_c<long,1>,
        typename pqs::of_quantity::min_real<
            typename pqs::meta::binary_operation<
                Value_type,
                std::divides,
                Value_type
            >::result_type
        >::type
    >::type
    argument(
        std::complex<
            pqs::ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & c)
    {
        return arctangent2(c.imag(), c.real());
    }  
}//pqs


#endif
