#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_COMPLEX_SPECIALISE_HPP_INCLUDED
#define PQS_COMPLEX_SPECIALISE_HPP_INCLUDED

#include <complex>
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"
#include "pqs/ct_quantity/operations/detail/convert.hpp"
#include "pqs/dimensional_analysis/concept_checking.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/array/array.hpp"
#include "pqs/type_traits/is_complex_value_type.hpp"
#include "boost/type_traits/is_same.hpp"

/*
    specialisation of std::complex
    for ct_quantity
    array version
*/

namespace std{

    template< 
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    class complex<
        pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    > : private pqs::array<
            pqs::ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >,
            2
    >{
     
        typedef pqs::array<
            pqs::ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >,
            2
        > array;
        using array::elements;
    public:
        typedef pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > value_type;

        complex(){}

        complex( value_type const& re )
        {
            elements[0] = re;
        }

        complex( value_type const& re, value_type const& im )
        {
            elements[0] = re;
            elements[1] = im;
        }

        template<
            typename NamedAbstractQuantity1,
            typename QuantityUnit1,
            typename Value_type1
        >
        complex(
                pqs::ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& re )
        {
            elements[0] = re;
        }

        template<
            typename NamedAbstractQuantity1,
            typename NamedAbstractQuantity2,
            typename QuantityUnit1,
            typename QuantityUnit2,
            typename Value_type1,
            typename Value_type2
        >
        complex(
                pqs::ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& re ,
                pqs::ct_quantity<
                    NamedAbstractQuantity2,
                    QuantityUnit2,
                    Value_type1
                >const& im )
        { 
            elements[0] = re;
            elements[1] = im;
        }

        complex(complex const& in)
        {
            elements[0] = in.real();
            elements[1] = in.imag();
        }

        template <
            typename NamedAbstractQuantity1,
            typename QuantityUnit1,
            typename Value_type1
        >
        complex(complex<
                    pqs::ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1, 
                        Value_type1
                    >
                > const& in)
        {
            elements[0] = in.real();
            elements[1] = in.imag(); 
        } 

        complex& operator =(complex const& in)
        {
            elements[0] = in.real();
            elements[1] = in.imag();
            return *this;
        }

        template <
            typename NamedAbstractQuantity1,
            typename QuantityUnit1,
            typename Value_type1
        >
        complex& operator = (
            complex<
                pqs::ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                >
            > const & in)
        {
            elements[0] = in.real();
            elements[1] = in.imag();
        }

        template <
            typename NamedAbstractQuantity1,
            typename QuantityUnit1,
            typename Value_type1
        >
        complex& operator = (
                pqs::ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const & in)
        {
            elements[0] = in;
            return *this;
        }
//// += 
        complex& operator +=(complex const& in)
        {
            elements[0] += in.real();
            elements[1] += in.imag();
            return *this;
        }

        template <
            typename NamedAbstractQuantity1,
            typename QuantityUnit1,
            typename Value_type1
        >
        complex& operator += (
            complex<
                pqs::ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                >
            > const & in)
        {
            elements[0] += in.real();
            eleemnts[1] += in.imag();
            return *this;
        }

        template <
            typename NamedAbstractQuantity1,
            typename QuantityUnit1,
            typename Value_type1
        >
        complex& operator += (
                pqs::ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const & in)
        {
            elements[0] += in;
            return *this;
        }

//// -= 
        complex& operator -=(complex const& in)
        {
            elements[0] -= in.real();
            elements[1] -= in.imag();
            return *this;
        }

        template <
            typename NamedAbstractQuantity1,
            typename QuantityUnit1,
            typename Value_type1
        >
        complex& operator -= (
            complex<
                pqs::ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                >
            > const & in)
        {
            elements[0] -= in.real();
            elements[1] -= in.imag();
            return *this;
        }

        template <
            typename NamedAbstractQuantity1,
            typename QuantityUnit1,
            typename Value_type1
        >
        complex& operator -= (
                pqs::ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const & in)
        {
            elements[0] -= in;
            return *this;
        }

    /// *=
        template <typename Value_type1>
        complex & operator *= ( complex<Value_type1> const & in)
        {
            Value_type t_real = this->real_part * in.real()  -  this->imag() * in.imag();
            (elements[1] *= in.real() ) += (this->real() * in.imag());
            elements[0] = t_real;
            return * this;
        }
        template <typename Value_type1>
        complex & operator *= ( Value_type1 const & in)
        {
            elements[0] *= in;
            elements[1] *= in;
            return * this;
        }

    // /=
        template <typename Value_type1>
        complex & operator /= ( complex<Value_type1> const & in)
        {
            typename pqs::meta::binary_operation<
                    Value_type1,
                    std::multiplies,
                    Value_type1
            >::result_type denom = in.real() * in.real() + in.imag() * in.imag(); 
            Value_type t_real
            =(this->real() * in.real() + this->imag() * in.imag()) / denom;
            elements[1] 
            = (in.real() * this->imag() - this->real() * in.imag()) / denom;
            elements[0] = t_real;
            return * this;
        }

        template <typename Value_type1>
        complex & operator /= ( Value_type1 const & in)
        {
            elements[0] /= in;
            elements[1] /= in;
            return * this;
        }
        
        value_type real() const {return elements[0];}
        value_type imag() const {return elements[1];}  
    };

}//std

namespace pqs{namespace type_traits{

    template <
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    struct is_complex_value_type<
        pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    >{
        enum{value 
        = ( pqs::type_traits::is_complex_value_type<Value_type>::value !=0)};
        typedef is_complex_value_type  type; 
    };
}}

#endif
