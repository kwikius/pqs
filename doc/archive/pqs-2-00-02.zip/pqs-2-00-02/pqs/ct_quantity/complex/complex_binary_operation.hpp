#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_COMPLEX_BINARY_OPERATION_HPP_INCLUDED
#define PQS_COMPLEX_BINARY_OPERATION_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    generic binary_operation for complex
*/

#include <complex>
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"
#include "pqs/meta/is_valid_binary_operation.hpp"
#include "pqs/type_traits/is_complex_value_type.hpp"
#include "boost/utility/enable_if.hpp"
#include "boost/mpl/and.hpp"
#include <complex>

namespace pqs{ namespace meta{

    template <
        template <typename> class Op,
        typename Value_type
    >
    struct unary_operation<
        Op,
        std::complex<
           Value_type
        >
    >{
        typedef std::complex<
            typename unary_operation<
                Op,
                Value_type
            >::result_type
        > result_type;
    };

    template<
        typename Value_typeL,
        template <typename> class Op,
        typename Value_typeR
    >
    struct binary_operation<
        typename std::complex<
           Value_typeL
        >,
        Op,
        typename std::complex<
          Value_typeR
        >        
    >{    
        typedef typename std::complex< 
            typename binary_operation<
                Value_typeL,
                Op,
                Value_typeR
            >::result_type
        > result_type;
    };

    template<
        typename Value_typeL,
        template <typename> class Op,
        typename Value_typeR
    >
    struct binary_operation<
        typename std::complex<
           Value_typeL
        >,
        Op, 
        Value_typeR ,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::type_traits::is_complex_value_type<Value_typeR>,
                pqs::meta::is_valid_binary_operation<
                    Value_typeL,
                    Op,
                    Value_typeR
                >
            >
        >::type 
    >{    
        typedef typename std::complex< 
            typename binary_operation<
                Value_typeL,
                Op,
                Value_typeR
            >::result_type
        > result_type;
    };

    template<
        typename Value_typeL,
        template <typename> class Op,
        typename Value_typeR
    >
    struct binary_operation<
        Value_typeL,
        Op,
        typename std::complex<
          Value_typeR
        >,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::type_traits::is_complex_value_type<Value_typeL>,
                pqs::meta::is_valid_binary_operation<
                    Value_typeL,
                    Op,
                    Value_typeR
                >
            >
        >::type
    >{    
        typedef typename std::complex< 
            typename binary_operation<
                Value_typeL,
                Op,
                Value_typeR
            >::result_type
        > result_type;
    };

}}//boost::pqs::meta

#endif
