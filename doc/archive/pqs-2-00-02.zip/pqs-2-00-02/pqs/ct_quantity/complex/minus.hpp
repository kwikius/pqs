#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_COMPLEX_MINUS_HPP_INCLUDED
#define PQS_COMPLEX_MINUS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    binary_operation permutations for complex subtraction
*/

#include "pqs/ct_quantity/complex/complex_binary_operation.hpp"
#include "pqs/ct_quantity/ct_quantity.hpp"

namespace pqs{

  //1 complex<pq> - complex<pq> 
    template< 
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline
    typename meta::binary_operation<
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >,
        std::minus,
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >
    >::result_type
    operator - ( 
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cpqL,
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cpqR )
    {
        typedef  ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > pq_type;
     
        typedef typename meta::binary_operation<
            pq_type,
            std::minus,
            pq_type
        >::result_type result_value_type;
        
        return typename std::complex<
            result_value_type
        > (cpqL.real() - cpqR.real(),cpqL.imag() - cpqR.imag()); 
    } 

    // 2 complex<pqL> - complex<pqR>
    template< 
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >
        >,
        std::minus,
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        >
    >::result_type
    operator - ( 
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >
        > const & cpqL,
       typename  std::complex<
            ct_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        > const & cpqR )
    {
        typedef ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        > pq_typeA;
        typedef ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        > pq_typeB;
            
        typedef typename meta::binary_operation<
            pq_typeA,
            std::minus,
            pq_typeB
        >::result_type result_value_type;
        
        return typename std::complex<
            result_value_type
        > (cpqL.real() - cpqR.real(), cpqL.imag() - cpqR.imag()); 
    }

    //3 complex<pq> - pq
    template < 
        typename NamedAbstractQuantity,     
        typename QuantityUnit,
        typename Value_type
    >
    inline
    typename meta::binary_operation<
        std::complex<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >,
        std::minus,
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    >::result_type
    operator - (
        std::complex<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cpqL,
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const& pqR )
    {
        typedef  ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > pq_type;
        typedef meta::binary_operation<
           pq_type,
           std::minus,
           pq_type
        >::result_type result_value_type;

        return std::complex<
            result_value_type
        >(cpqL.real() -  pqR, cpqL.imag() );
    }

    //4	complex<pqL> - pqR
     template< 
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >
        >,
        std::minus,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >
    >::result_type
    operator - ( 
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >
        > const & cpqL,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        > const & pqR )
    {
        typedef ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        > pq_typeA;
        typedef ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        > pq_typeB;
            
        typedef typename meta::binary_operation<
            pq_typeA,
            std::minus,
            pq_typeB
        >::result_type result_value_type;
        
        return typename std::complex<
            result_value_type
        > (cpqL.real() - pqR,cpqL.imag() ); 
    }

    // 5 pq - complex<pq>
    template< 
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline
    typename meta::binary_operation<
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        std::minus,
        std::complex<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >
    >::result_type
    operator - ( 
       ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & pqL,
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cpqR )
    {
        typedef  ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > pq_type;
     
        typedef typename meta::binary_operation<
            pq_type,
            std::minus,
            pq_type
        >::result_type result_value_type;
        
        return typename std::complex<
            result_value_type
        > (pqL - cpqR.real(),-cpqR.imag()); 
    } 

    // 6 pqL - complex<pqR>
    template< 
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >,
        std::minus,
        typename std::complex<
            ct_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        >
    >::result_type
    operator - ( 
        ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        > const & pqL,
       typename  std::complex<
            ct_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        > const & cpqR )
    {
        typedef ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        > pq_typeA;
        typedef ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        > pq_typeB;
            
        typedef typename meta::binary_operation<
            pq_typeA,
            std::minus,
            pq_typeB
        >::result_type result_value_type;
        
        return typename std::complex<
            result_value_type
        > (pqL - cpqR.real(), -cpqR.imag()); 
    }

}//pqs

#endif
