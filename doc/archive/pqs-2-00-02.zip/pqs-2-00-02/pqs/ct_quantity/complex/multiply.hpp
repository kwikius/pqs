#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_COMPLEX_MULTIPLY_HPP_INCLUDED
#define PQS_COMPLEX_MULTIPLY_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
// required to overload std::complex
    1	complex<pq> * complex<pq>  
    2	complex<pq> * pq   
    3	pq * complex<pq>               

// if TL or TR or both is a ct_quantity      
    4  complex<TL> * complex<TR>
    5  complex<TL> * TR
    6  TL * complex<TR>    
*/

#include "pqs/ct_quantity/complex/complex_binary_operation.hpp"
#include "pqs/meta/binary_operation_if.hpp"
#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/type_traits/is_ct_quantity.hpp"
#include "boost/mpl/or.hpp"

namespace pqs{

// 1 complex<pq> * complex<pq>
    template< 
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename meta::binary_operation<
        std::complex<
            pqs::ct_quantity< 
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >,
        std::multiplies,
        std::complex<
            pqs::ct_quantity< 
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >
    >::result_type
    operator * ( 
        std::complex<
           pqs::ct_quantity< 
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cpqL,
        std::complex<
            pqs::ct_quantity< 
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cpqR )
    {
        typedef  ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > pq_type;
            
        typedef typename meta::binary_operation<
            pq_type,
            std::multiplies,
            pq_type
        >::result_type result_value_type;

        result_value_type const& real_value 
        = ( cpqL.real() * cpqR.real() - cpqL.imag() * cpqR.imag() );
       
        result_value_type const& imag_value 
        = ( cpqL.real() * cpqR.imag() + cpqR.real() * cpqL.imag() );
     
        return std::complex<result_value_type> (real_value, imag_value); 
    }  
// 2 complex<pq> * pq
    template< 
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename meta::binary_operation<
        std::complex<
            pqs::ct_quantity< 
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >,
        std::multiplies,
        pqs::ct_quantity< 
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    >::result_type
    operator * ( 
        std::complex<
           pqs::ct_quantity< 
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cpqL,
        pqs::ct_quantity< 
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const & pqR )
    {
        typedef  ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > pq_type;
            
        typedef typename meta::binary_operation<
            pq_type,
            std::multiplies,
            pq_type
        >::result_type result_value_type;

        result_value_type const& real_value 
        =  cpqL.real() * pqR;
       
        result_value_type const& imag_value 
        = cpqL.imag() * pqR ;
     
        return std::complex<result_value_type> (real_value, imag_value); 
    } 
 
//3 pq * complex<pq>

    template< 
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename meta::binary_operation<
        pqs::ct_quantity< 
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
     
        >,
        std::multiplies,
        std::complex<
            pqs::ct_quantity< 
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >
    >::result_type
    operator * ( 
        pqs::ct_quantity< 
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const & pqL,
        std::complex<
            pqs::ct_quantity< 
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        > const & cpqR )
    {
        typedef  ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > pq_type;
            
        typedef typename meta::binary_operation<
            pq_type,
            std::multiplies,
            pq_type
        >::result_type result_value_type;

        result_value_type const& real_value 
        = pqL * cpqR.real();
       
        result_value_type const& imag_value 
        = pqL * cpqR.imag() ;
     
        return std::complex<result_value_type> (real_value, imag_value); 
    }  

// 4 complex<TL> * complex<TR>
// if TL or  TR (or both) is a ct_quantity
    template< 
        typename TL,
        typename TR
    >
    inline 
    typename meta::binary_operation_if<
        boost::mpl::or_<
            pqs::type_traits::is_ct_quantity<TL>,
            pqs::type_traits::is_ct_quantity<TR>
        >,
        std::complex<
            TL
        >,
        std::multiplies,
        std::complex<
            TR
        >
    >::result_type
    operator * ( 
        std::complex<
           TL
        > const & lhs,
        std::complex<
           TR
        > const & rhs )
    { 
        typedef typename meta::binary_operation<
            TL,
            std::multiplies,
            TR
        >::result_type result_value_type;

        result_value_type const& real_value 
        = ( lhs.real() * rhs.real() - lhs.imag() * rhs.imag() );
       
        result_value_type const& imag_value 
        = ( lhs.real() * rhs.imag() + rhs.real() * lhs.imag() );
     
        return std::complex<result_value_type> (real_value, imag_value); 
    }  

////////////////
// 5 complex<TL> * TR
// if TL or  TR (or both) is a ct_quantity
    template< 
        typename TL,
        typename TR
    >
    inline 
    typename meta::binary_operation_if<
        boost::mpl::or_<
            pqs::type_traits::is_ct_quantity<TL>,
            pqs::type_traits::is_ct_quantity<TR>
        >,
        std::complex<
           TL
        >,
        std::multiplies,
        TR
    >::result_type
    operator * ( 
        std::complex<
          TL
        > const & lhs,
       TR const & rhs )
    {
        typedef typename meta::binary_operation<
            TL,
            std::multiplies,
            TR
        >::result_type result_value_type;

        result_value_type const& real_value 
        =  lhs.real() * rhs;
       
        result_value_type const& imag_value 
        = lhs.imag() * rhs ;
     
        return std::complex<result_value_type> (real_value, imag_value); 
    }  

//3 TL * complex<TR>
// if TL or TR (or both) is a ct_quantity
    template< 
        typename TL,
        typename TR
    >
    inline 
    typename meta::binary_operation_if<
        boost::mpl::or_<
            pqs::type_traits::is_ct_quantity<TL>,
            pqs::type_traits::is_ct_quantity<TR>
        >,
        TL,
        std::multiplies,
        std::complex<
            TR
        >
    >::result_type
    operator * ( 
        TL const& lhs,
        std::complex<
            TR
        > const & rhs )
    {
        typedef typename meta::binary_operation<
            TL,
            std::multiplies,
            TR
        >::result_type result_value_type;

        result_value_type const& real_value 
        = lhs * rhs.real();
       
        result_value_type const& imag_value 
        = lhs * rhs.imag() ;
     
        return std::complex<result_value_type> (real_value, imag_value); 
    }

}//pqs

#endif
