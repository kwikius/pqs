#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_GENERIC_CLASS_HPP_INCLUDED2911030401
#define PQS_CLASS_TEMPLATE_GENERIC_CLASS_HPP_INCLUDED2911030401

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    ct_quantity class - defines a compile-time physical_quantity
*/
/*
    modified 02 Aug 04 to remove "forwarding" Value_type explicit ctors
*/

#include "pqs/ct_quantity/of_quantity.hpp"
#include "pqs/meta/associated_arithmetic.hpp"
#include "pqs/ct_quantity/detail/coherent_quantity.hpp"
#include "pqs/ct_quantity/units_out.hpp"
#include "pqs/ct_quantity/operations/detail/convert.hpp"
#include "pqs/ct_quantity/operations/detail/value_cast.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include "pqs/dimensional_analysis/concept_checking.hpp"
#include "boost/mpl/if.hpp"
#include "pqs/meta/rational_c.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/binary_operation_if.hpp"

namespace pqs{

    template<
        typename AbstractQuantity,
        typename QuantityUnit /* = quantity_unit<> */,
        typename Value_type /* = double */
    >
    class ct_quantity 
   {
    public:
        typedef AbstractQuantity   named_abstract_quantity_type;
        typedef QuantityUnit            units_type;
        typedef Value_type              value_type;
        typedef typename boost::mpl::if_c<
            AbstractQuantity::anonymous_abstract_quantity_type::is_dimensionless,
            Value_type,
            ct_quantity
        >::type                         type;

    // default ctor

        ct_quantity(): m_value(static_cast<Value_type>(0)){}

    // explicit value_type ctors

        explicit ct_quantity(Value_type const& value_in)
        : m_value(value_in){}
        template< typename Value_type1>
        explicit ct_quantity(Value_type1 const& value_in)
        : m_value(pqs::detail::implicit_initialise<Value_type>(value_in)){}

        template<typename Value_type1>
        explicit ct_quantity(Value_type1 const& value_inl,Value_type1 const& value_inr )
        : m_value(
            pqs::detail::implicit_initialise<typename pqs::meta::to_value_type<Value_type>::type>(value_inl),
            pqs::detail::implicit_initialise<typename pqs::meta::to_value_type<Value_type>::type>(value_inr) ){}

    // copy ctor

        ct_quantity(ct_quantity const& pq_in)
        : m_value(pq_in.m_value){}
    
    // conversion ctors
 
        // dimensionally-equivalent type with same units & value_type,
        // but different tag
        template<typename AbstractQuantityIn>
        ct_quantity( 
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit,
                Value_type
            > const & pq_in ) 
        : m_value(pq_in.numeric_value())
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();
        }

        // dimensionally-equivalent type with same units,
        // but different value_type but different tag
        template <
            typename AbstractQuantityIn,
            typename Value_type_in
        >
        ct_quantity( 
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit,
                Value_type_in
            > const& pq_in)
        :m_value( pqs::detail::implicit_initialise<Value_type>(pq_in.numeric_value()))
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();
        };

        // dimensionally-equivalent type
        // different units value_type and tag
        template<
            typename AbstractQuantity_in,
            typename QuantityUnit_in,
            typename Value_type_in
        >
        ct_quantity( 
            ct_quantity<
                AbstractQuantity_in,
                QuantityUnit_in,
                Value_type_in
            > const& pq_in)
        : m_value( pqs::detail::implicit_initialise_value_cast<type>(pq_in) )
        {
            //dimension checked in implicit_initialise_value_cast
        }

  // assignment

        // exact same type
        ct_quantity& operator = (const ct_quantity& pq_in)
        {
            this->m_value = pq_in.m_value;
            return *this;
        }

        // dimensionally equivalent, same units & value_type
        // but different tag
        template<
            typename AbstractQuantityIn
        >
        ct_quantity&
        operator = (
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit,
                Value_type
            > const& pq_in)
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();
            this->m_value = pq_in.numeric_value();
            return *this;
        }

        // dimensionally-equivalent, same units 
        // different value_type and tag
        template<
            typename AbstractQuantityIn,
            typename Value_type_in
        >
        ct_quantity&
        operator = (
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit,
                Value_type_in
            > const& pq_in)
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();
            this->m_value = pqs::detail::implicit_assign<Value_type>(pq_in.numeric_value());
            return *this;
        }
       
        //dimensionally-equivalent
        //but different unit, value_type & tag
        template< 
            typename AbstractQuantity_in,
            typename QuantityUnit_in,
            typename Value_type_in
        >
        ct_quantity &
        operator =( 
            ct_quantity<
                AbstractQuantity_in,
                QuantityUnit_in,
                Value_type_in
            > const& pq_in )
        {
            //dimension checked in implicit_assign_value_cast
            this->m_value = pqs::detail::implicit_assign_value_cast<type>(pq_in);
            return *this;
        }

      // +=
        // exact same type  
        ct_quantity&
        operator += (ct_quantity const & pq_in)
        {
            this->m_value += pq_in.m_value;
            return *this;
        }
        // dimensionally-equivalent type same units value_type
        // but different tag
        template<
            typename AbstractQuantityIn            
        >
        ct_quantity&
        operator +=( 
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit,
                Value_type
            > const & pq_in )
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();
            this->m_value += pq_in.numeric_value();
            return *this;
        }

        // dimensionally-equivalent type same units,
        // but different value_type & tag
        template<
            typename AbstractQuantityIn,
            typename Value_type_in            
        >
        ct_quantity&
        operator +=( 
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit,
                Value_type_in
            > const & pq_in )
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();

            this->m_value += pqs::detail::implicit_assign<Value_type>(pq_in.numeric_value());
            return *this;
        }

        // dimensionally-equivalent type
        // but different units, value_type & tag
        template<
            typename AbstractQuantityIn,
            typename QuantityUnit_in,
            typename Value_type_in
        >
        ct_quantity&
        operator +=( 
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit_in,
                Value_type_in
            > const& pq_in )
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();
            this->m_value += pqs::detail::implicit_assign_value_cast<type>(pq_in);
            return *this;
        }
 // -=
        // exact same type
        ct_quantity&
        operator -= (ct_quantity const & pq_in)
        {
            this->m_value -= pq_in.m_value;
            return *this;
        }

        // dimensionally-equivalent type same units & value_type
        // different tag 
        template<
            typename AbstractQuantityIn
        >
        ct_quantity&
        operator -=(
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit,
                Value_type
            > const & pq_in)
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();
            this->m_value -= pq_in.numeric_value();
            return *this;
        }

        // dimensionally-equivalent type same units
        // different value_type & tag
        template<
            typename AbstractQuantityIn,
            typename Value_type_in
        >
        ct_quantity&
        operator -=(
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit,
                Value_type_in
            > const & pq_in)
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();

            this->m_value -= pqs::detail::implicit_assign<Value_type>(pq_in.numeric_value());
            return *this;
        }

        // dimensionally-equivalent type
        // different units, value_type & tag
        template<
            typename AbstractQuantityIn,
            typename QuantityUnit_in,
            typename Value_type_in
        >
        ct_quantity&
        operator -=(
            ct_quantity<
                AbstractQuantityIn,
                QuantityUnit_in,
                Value_type_in
            > const& pq_in)
        {
            pqs::concept_checking::function_requires<
                pqs::CompatibleQuantityWarningConcept<
                    AbstractQuantity,
                    AbstractQuantityIn
                >
            >();
            this->m_value -= pqs::detail::implicit_assign_value_cast<type>(pq_in);
            return *this;
        }

        template<
            typename Value_type_in
        >
        ct_quantity&
        operator *=(Value_type_in const& v)
        {
            this->m_value *= v;
            return *this;
        }

        template<
            typename Value_type_in
        >
        ct_quantity&
        operator /=(Value_type_in const& v)
        {
            this->m_value /= v;
            return *this;
        }
      
       //unary + 
        ct_quantity
        operator +()const
        {
            return  ct_quantity(m_value);
        }

        //unary -
        ct_quantity
        operator -()const
        {
            return  ct_quantity(-m_value);
        }

        bool operator!()const
        {
            return this->m_value == 0;
        }

        ct_quantity& operator++()
        {
            ++this->m_value;
            return *this;
        }

        ct_quantity operator++(int)
        {
            ct_quantity t(*this);
            ++this->m_value;
            return t;
        }

        ct_quantity& operator--()
        {
            --this->m_value;
            return *this;
        }

        ct_quantity  operator--(int)
        {
            ct_quantity t(*this);
            --this->m_value;
            return t;
        }
        //fails on gcc
       /* template<int N>
        typename pqs::meta::binary_operation_if_c<
            (N !=0),
            ct_quantity,
            pqs::to_power,
            pqs::meta::rational_c<int,N,1>
        >::result_type
        pow()const;*/

        template<int N, int D>
        typename pqs::meta::binary_operation<
            ct_quantity,
            pqs::to_power,
            pqs::meta::rational_c<int,N,D>
        >::result_type
        pow()const;

        Value_type const& numeric_value()const{return m_value;}
        static 
        pqs::physical_quantity_basic_units_out<
            AbstractQuantity,
            QuantityUnit
        >  
        units()
        {
            return pqs::physical_quantity_basic_units_out<
                AbstractQuantity,
                QuantityUnit
            >();
        }
        
    private:
        Value_type m_value;
    }; 


}//pqs


#endif
