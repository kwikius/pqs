#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_COHERENT_QUANTITY_HPP_INCLUDED
#define PQS_CLASS_TEMPLATE_COHERENT_QUANTITY_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/ct_quantity/detail/transform_coherent.hpp"
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"

/*
    For more info on coherent and incoherent quantities see
    PhysicalQuantities1.html#coherent-quantity
    in the documentation.
*/
/*
      transforms the type of a ct-quantity
      a physical_quantity to a coherent type
*/

namespace pqs{namespace detail{
  
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    struct transform_coherent<
        pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    >{
        typedef ct_quantity<
            NamedAbstractQuantity,
            typename pqs::detail::transform_coherent<
                QuantityUnit
            >::type,
            Value_type
        > type;
    };

}}//pqs::detail

#endif
