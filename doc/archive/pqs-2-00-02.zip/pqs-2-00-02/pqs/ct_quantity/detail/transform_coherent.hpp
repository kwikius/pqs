#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_TRANSFORM_COHERENT_HPP_INCLUDED
#define PQS_CLASS_TEMPLATE_TRANSFORM_COHERENT_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    transform type of a ct_quantity to a coherent ct_quantity.
    For more info on coherent and incoherent quantities see
    PhysicalQuantities1.html and Concepts.html
    in the documentation.
*/

namespace pqs{namespace detail{

    template <typename T>
    struct transform_coherent;

}}//pqs::detail

#endif
