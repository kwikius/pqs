#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_AUX_UNITS_OUT_HPP_INCLUDED
#define PHYSICAL_QUANTITIES_AUX_UNITS_OUT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
   overloaded stream output of the units of a ct_quantity
   via the units(pq) function.
*/

#include <iostream>
#include "boost/utility/enable_if.hpp"
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"
#include "pqs/ct_quantity/named_abstract_quantity.hpp"
#include "pqs/ct_quantity/units_out.hpp"
#include "pqs/ct_quantity/types/components/adjusted_coherent_prefix.hpp"
#include "pqs/ct_quantity/quantity_unit/si_prefix.hpp"
#include "pqs/ct_quantity/io/detail/units_out_impl.hpp"
#include "pqs/ct_quantity/io/units_ostream.hpp"

namespace pqs{
    
    // units(pq) simply returns a physical_quantity_units_out <..> object
    // which is what the ostream operator actually picks up.
    // The function is limited to types
    // with a named_quantity_tag less than
    // of_quantity::max_default_named_quantity_tag
    // in "pqs/ct_quantity/of_quantity.hpp"
    // to allow for expansion on custom types
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline
    typename boost::enable_if_c<
        (NamedAbstractQuantity::tag_type::value <
        static_cast<int>(of_quantity::max_default_named_quantity_tag)),
        physical_quantity_units_out < 
            NamedAbstractQuantity,
            QuantityUnit
        >
    >::type  
    units(ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
           > const & )
    {
        return physical_quantity_units_out< 
            NamedAbstractQuantity,
            QuantityUnit
        >();
    }

    // the ostream << operator for the 
    // physical_quantity_units_out<..> object returned by the above function
    //
    template<
        typename AbstractQuantity,
        typename QuantityUnit,
        typename CharType
    >
    inline std::basic_ostream<CharType>& 
    operator << (  
        std::basic_ostream<CharType>& os,
        physical_quantity_units_out< 
            AbstractQuantity,
            QuantityUnit
        > const&  
    )
    {
        typedef  typename pqs::si_unit::prefix<
            typename adjusted_coherent_prefix< 
                AbstractQuantity,
                QuantityUnit
            >::type 
        > adjusted_prefix_type;
              
        return  pqs::detail::physical_quantity_units_output_impl<
            ( pqs::is_named_abstract_quantity<AbstractQuantity>::value
            && adjusted_prefix_type::value ),
            AbstractQuantity,
            QuantityUnit
        >::put(os);
    }
}//pqs

#endif
