#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_UTIL_DETAIL_PUT_RATIONAL_HPP_INCLUDED
#define PQS_UTIL_DETAIL_PUT_RATIONAL_HPP_INCLUDED
// pqs-2-00-02,Sep 19 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    output a rational in eg 1/2 style
    explicit + for powers
*/
#include <iosfwd>

namespace pqs{namespace detail{

    inline 
    std::ostream& 
    put_rational(std::ostream& os,int n, int d)
    {
        if (!n) return os;
        if (d==1){
            if( n != 1){
                if (n > 1)
                    os << '+';
                os << n;
            }
            return os;
        }
        else {
            if (n > 0) os <<'+';
            os << n << '/' << d;
        }
        return os;           
    }

    template<typename T>
    inline 
    std::ostream&  
    put_rational_type(std::ostream& os)
    {
        return put_rational(os,T::numerator,T::denominator);
    }

}}//pqs::detail


#endif
