#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_UTIL_DETAIL_PHYSICAL_QUANTITY_UNITS_OUT_IMPL_HPP_INCLUDED
#define PQS_UTIL_DETAIL_PHYSICAL_QUANTITY_UNITS_OUT_IMPL_HPP_INCLUDED
// pqs-2-00-02,Sep 19 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    implementation called by the 
    ostream& operator << (ostream&,physical_quantity_units_out< ..>);
    defined in "pqs/util/aux_units_out.hpp"
*/

#include <iosfwd>
#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/ct_quantity/units_out.hpp"
#include "pqs/ct_quantity/quantity_unit/si_prefix.hpp"
//#include "pqs/ct_quantity/types/components/unprefixed_symbol.hpp"
#include "pqs/ct_quantity/types/components/of_named_quantity_for.hpp"

namespace pqs{ namespace detail{

    // specialised differently for
    //1) named And coherent types
    //2) anonymous Or incoherent types
    // via NamedCoherent condition
    template < 
        bool NamedCoherent, 
        typename NamedAbstractQuantity, 
        typename QuantityUnit
    > struct physical_quantity_units_output_impl;

    // This version is for use with
    // named-quantities that are also coherent-quantities
    template <
        typename NamedAbstractQuantity, 
        typename QuantityUnit
    > struct physical_quantity_units_output_impl<
        true,
        NamedAbstractQuantity,
        QuantityUnit
    >{
        typedef typename si_unit::prefix<
            typename adjusted_coherent_prefix< 
                NamedAbstractQuantity,
                QuantityUnit
            >::type 
        > adjusted_prefix_type;

        typedef of_named_quantity_for<
            NamedAbstractQuantity
        > of_type;
        
        template<typename CharType>
        static std::basic_ostream<CharType>&  put(std::basic_ostream<CharType>& os)
        {
                os << adjusted_prefix_type::template symbol<CharType>()
                << of_type::template unprefixed_symbol<CharType>();
                return os;
        }

    };

    // this version simply uses the pq.units() function
    // It is usually used for anonymous ct_quanties
    // though will also be invoked for incoherent named quantities
    // which have not had an overload of 
    // ostream operator << (ostream&, physical_quantity_units_out<..>)
    // provided by including the "pqs/types/*_mx.hpp" header for the quantity
    template < 
        typename NamedAbstractQuantity, 
        typename QuantityUnit
    > 
    struct physical_quantity_units_output_impl<
        false,
        NamedAbstractQuantity,
        QuantityUnit
    >{
        template<typename CharType>
        static std::basic_ostream<CharType>&  put(std::basic_ostream<CharType>& os)
        {
            os << ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                of_quantity::default_value_type
            >::units(); 
            return os;
        }
    };
}}//pqs::detail

#endif
