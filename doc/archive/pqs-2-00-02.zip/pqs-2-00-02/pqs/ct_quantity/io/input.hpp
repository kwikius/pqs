#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_UTILITY_INTPUT_HPP_INCLUDED2911030401
#define PHYSICAL_QUANTITIES_UTILITY_INTPUT_HPP_INCLUDED2911030401

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    simple input routine for ct-quantity.
    sets badbit on invalid input
     
*/

#include <sstream>
#include "pqs/ct_quantity/io/output.hpp"

 namespace pqs{
// after C++ 3rd ed p 621
// input of a ct-quantity
// basically compares the format of the units in operator <<

    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename CharType
    >
    inline std::basic_istream<CharType>& 
    operator >> (std::basic_istream<CharType>& is,
                    ct_quantity<
                        NamedAbstractQuantity,
                        QuantityUnit,
                        Value_type
                    >& pq )
    {
        // use output for type to compare units
        std::basic_ostringstream<CharType> ost;
        ost << units(ct_quantity<NamedAbstractQuantity,QuantityUnit,Value_type>());
        std::basic_string<CharType> str = ost.str();
        Value_type v;
        is >> v;
        CharType ch=0;
        int space_count = 0;
        while (is.get(ch)){
            if (ch  == is.widen(' ')){
                space_count++;
                continue;
            }
            else {
                is.putback(ch);
                break;
            }
        }
        if (!space_count){
            is.clear(std::ios_base::badbit);
            return is;
        }
        
        typename std::basic_string<CharType>::const_iterator iter = str.begin();
        while (iter != str.end()){
            is.get(ch);
            if (ch != *iter){
                is.clear(std::ios_base::badbit);
                break;
            }
            ++iter;
        }
        if (is){
          pq = ct_quantity<NamedAbstractQuantity,QuantityUnit,Value_type>(v);
        }
        return is; 
    } 
}//pqs
#endif
