#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_UTILITY_OUTPUT_HPP_INCLUDED2911030401
#define PHYSICAL_QUANTITIES_UTILITY_OUTPUT_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    basic utility output 
    of a physical_quantity for demo purposes
    useage
    pq is physical_quantity
    os << pq ;
    outputs value of pq and units
*/

#include <iostream>
#include <sstream>
#include "pqs/ct_quantity/io/aux_units_out.hpp"

namespace  pqs{
    // This function provides output of ct_quantities
    // Note that the units implementation is much more complex
    // than would appear from this definition.
    // See the documentation for more details
    // OTOH look at the implementation of
    // units(pq) in "pqs/ct_quantity/io/aux_units_out.hpp"
    template <
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename CharType
    >
    inline 
    std::basic_ostream<CharType>& 
    operator << 
        (std::basic_ostream<CharType>& os,
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            > const& pq )
    {
        os << pq.numeric_value() << ' ' << units(pq);
        return os;
    }

    // This function simply returns the stream output of a ct_quantity
    // as in os << pq above, as a std::string
    template <
        typename CharType,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    std::basic_string<CharType>
    units_str( 
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const& pq 
    )
    {
        std::basic_ostringstream<CharType> ost;
        ost << units(pq);
        return ost.str();
    }

    template <
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    std::string
    units_str( 
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const& pq 
    )
    {
        std::ostringstream ost;
        ost << units(pq);
        return ost.str();
    }
 
}//pqs

//useful specialisation of binary_operation stream output
// eg  for boost::lambda with ct_quantities
namespace pqs{namespace meta{

    template < 
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,    
        typename CharType
    >
    struct binary_operation< 
        std::basic_ostream<CharType>,
        pqs::shift_left, 
        pqs::ct_quantity<NamedAbstractQuantity,QuantityUnit,Value_type>
    >{
        typedef std::basic_ostream<CharType>& result_type;
    };

}}//pqs::meta

#endif


    

