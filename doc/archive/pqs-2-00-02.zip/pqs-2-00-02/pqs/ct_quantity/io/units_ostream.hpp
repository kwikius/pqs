#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_UTIL_UNITS_OSTREAM_HPP_INCLUDED2911030401
#define PQS_UTIL_UNITS_OSTREAM_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.
/*
    default stream output of ct-quantity.
    defines std::ostream& operator << (std::ostream& ,
         physical_quantity_basic_units_out<...> );
    where physical_quantity_basic_units_out<...>
    is the dummy object returned by invoking pq.units()
*/
#include <iostream>
#include <sstream>
#include <cstring>
#include <string>
#include "pqs/ct_quantity/of_quantity.hpp"
#include "pqs/ct_quantity/io/detail/put_rational.hpp"
#include "pqs/ct_quantity/units_out.hpp"

namespace pqs{

// This ostream operator << picks up the physical_quantity_basic_units_out class
// returned by pq.units(). The general idea is to use the p.units() form for
// output of the basic units (and any scaling). The units(pq) form is meant
// for overloading on  eg for a pqs::force::kgf pq;
// pq.units() gives  "[kg.m.s-2 * 9.8XX]"
// units(pq) gives   "kgf"
// this is the pq.units() format definition

    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit
    >
    inline std::ostream& 
    operator << 
        (std::ostream& os,
            physical_quantity_basic_units_out< 
                NamedAbstractQuantity,
                QuantityUnit
            > const&  )
    {
        typedef typename NamedAbstractQuantity::anonymous_abstract_quantity_type Abstract_pq;
        const bool P_mass = Abstract_pq::mass_pwr_type::numerator !=0;
        const bool P_time = Abstract_pq::time_pwr_type::numerator !=0;
        const bool P_len = Abstract_pq::length_pwr_type::numerator !=0;
        const bool P_temp = Abstract_pq::temperature_pwr_type::numerator !=0;
        const bool P_current = Abstract_pq::current_pwr_type::numerator !=0;
        const bool P_substance = Abstract_pq::substance_pwr_type::numerator !=0;
        const bool P_intensity = Abstract_pq::intensity_pwr_type::numerator !=0;

        const long Incoh_mux = QuantityUnit::incoherent_multiplier_type::value;
        const int Coh_nume = QuantityUnit::coherent_exponent_type::numerator;
        const int Coh_denom = QuantityUnit::coherent_exponent_type::denominator;
        // could add formatting here
        std::ostringstream ost;
        if ((Incoh_mux!= of_quantity::incoherent_multiplier_scale) || (Coh_denom != 1)){
             ost << '[';
        }
        if (P_mass){
            ost << "kg";
            detail::put_rational_type<typename Abstract_pq::mass_pwr_type>(ost);
            if (P_len ||P_time || P_temp ||P_current ||P_substance || P_intensity)
                ost <<'.';
        }
        if (P_len) {
            ost << 'm';
            detail::put_rational_type<typename Abstract_pq::length_pwr_type>(ost);
            if (P_time || P_temp ||P_current ||P_substance || P_intensity)
                ost << '.';
        }
        if (P_time){
            ost << 's';
            detail::put_rational_type<typename Abstract_pq::time_pwr_type>(ost);
            if ( P_temp ||P_current ||P_substance || P_intensity)
                ost << '.';
        }
        if (P_temp){
            ost << 'K';
            detail::put_rational_type<typename Abstract_pq::temperature_pwr_type>(ost);
            if ( P_current ||P_substance || P_intensity)
                ost << '.';
        }
        if (P_current){
            ost << 'A';
             detail::put_rational_type<typename Abstract_pq::current_pwr_type>(ost);
            if ( P_substance || P_intensity)
            ost << '.';
        }
        if (P_substance){
            ost << "mol";
            detail::put_rational_type<typename Abstract_pq::substance_pwr_type>(ost);
            if (P_intensity)
            ost << '.';
        }
        if (P_intensity){
            ost << "cd";
            detail::put_rational_type<typename Abstract_pq::intensity_pwr_type>(ost);
        }
        if (Incoh_mux != of_quantity::incoherent_multiplier_scale){
            // messy multiplier
            ost << " * " 
            << typename QuantityUnit::
                    incoherent_multiplier_type::
                        template eval<double>()() 
                * typename QuantityUnit::
                    coherent_exponent_type::
                        template eval<double>()()<< ']' ;
        } 
        else if(Coh_nume ){
            if (Coh_denom == 1){
                // neat exponent
                ost << " * 1e" 
                << QuantityUnit::coherent_exponent_type::numerator ;//<< ']'; 
            }
            else {
                // messy exponent
                ost << " * " 
                << typename QuantityUnit::
                        coherent_exponent_type::
                            template eval<double>()()<< ']' ;
            } 
        }
        os << ost.str();
        return os;
    }
}//pqs

#endif

