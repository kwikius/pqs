#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_ABSTRACT_ID_HPP_INCLUDED
#define PQS_CLASS_TEMPLATE_ABSTRACT_ID_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    The named-abstract-quantity includes the
    anonymous-abstract-quantity as well as a 
    named-quantity-tag, whose sole purpose is to
    differentiate (for example) torque from 
    energy for stream output.
    Should really be called abstract_quantity 
    and maybe will someday...
    
*/

#include "pqs/ct_quantity/named_abstract_quantity/anonymous_abstract_quantity.hpp"
#include "pqs/ct_quantity/named_abstract_quantity/named_quantity_tag.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"
#include "pqs/ct_quantity/types/components/of_named_quantity_for_fwd.hpp"

/*
    30 /09/04
   removed default template params
    
*/
namespace pqs{

    template <
        typename AnonymousAbstractQuantity  = anonymous_abstract_quantity<>,    
        typename Tag = pqs::named_quantity_tag<0> 
    >
    struct named_abstract_quantity{
       typedef AnonymousAbstractQuantity    anonymous_abstract_quantity_type;
       typedef Tag                          tag_type;
       typedef named_abstract_quantity      type;
    };

    //Is this abstrcat quantity a named AbstractaQuantity
    // with a specialisation of the OfNamedQuantityComponents concept
    template <
        typename AbstractQuantity
    >
    struct is_named_abstract_quantity{
        enum{ 
            value 
            = (AbstractQuantity::tag_type::value != 0)
            && (
                boost::is_same<
                    typename pqs::of_named_quantity_for<
                        AbstractQuantity
                    >::type,
                    boost::mpl::void_
                >::type::value == false
                )
        };
        typedef is_named_abstract_quantity type;
    };

}//pqs

/*
    binary_operations on named_abstract_quanities
*/
namespace pqs{namespace meta{
    template <
        typename AnonymousAbstractQuantity,
        typename Tag,
        int N,
        int D
    >
    struct binary_operation<
        pqs::named_abstract_quantity<
            AnonymousAbstractQuantity,
            Tag
        >,
        pqs::to_power,
        pqs::meta::rational_c<int,N,D>
    >{
        typedef pqs::named_abstract_quantity<
            typename binary_operation<
                AnonymousAbstractQuantity,
                pqs::to_power,
                typename pqs::meta::rational_c<int,N,D>::type
            >::result_type,
            typename boost::mpl::if_c<
               ( (N==1) && (D==1) ),
                Tag,
                typename Tag::anonymous_type
            >::type
        > result_type;
    };
                
    template< 
        typename AnonymousAbstractQuantityA,
        typename TagA,
        template <typename> class Op,
        typename AnonymousAbstractQuantityB,
        typename TagB
    >
    struct binary_operation<
        pqs::named_abstract_quantity<
            AnonymousAbstractQuantityA,
            TagA
        >,
        Op,
        pqs::named_abstract_quantity<
            AnonymousAbstractQuantityB,
            TagB
        >
    >{
        typedef pqs::named_abstract_quantity<
            typename pqs::meta::binary_operation<
                AnonymousAbstractQuantityA,Op,AnonymousAbstractQuantityB
            >::result_type,
            typename pqs::meta::binary_operation<
                TagA,Op,TagB
            >::result_type
        > result_type;
    };

    template <
        typename AnonymousAbstractQuantity,
        typename Tag
    > 
    struct unary_operation<
        reciprocal,
        typename pqs::named_abstract_quantity<
            AnonymousAbstractQuantity,
            Tag
        >
    >{
        typedef pqs::named_abstract_quantity<
            typename unary_operation<
                reciprocal,
                AnonymousAbstractQuantity
            >::result_type,
            typename Tag::anonymous_type
        > result_type;
    };
    
        
}}//pqs::meta

#endif
