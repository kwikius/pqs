#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CT_QUANTITY_ANONYMOUS_ABSTRACT_QUANTITY_HPP_INCLUDED
#define PQS_CT_QUANTITY_ANONYMOUS_ABSTRACT_QUANTITY_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    anonymous-abstract-quantity class template param.
    members represent powers of prime-dimensions of a quantity
*/

#include "pqs/ct_quantity/named_abstract_quantity/anonymous_abstract_quantity/prime_dimension_exp.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"
#include "pqs/meta/binary_log_transform.hpp"
#include "pqs/meta/rational_c.hpp"

namespace pqs{

    template<
        typename LengthExponent = pqs::length_pwr<0>,
        typename TimeExponent = pqs::time_pwr<0>,
        typename MassExponent = pqs::mass_pwr<0>,
        typename TemperatureExponent = pqs::temperature_pwr<0>,
        typename CurrentExponent = pqs::current_pwr<0>,
        typename SubstanceExponent = pqs::substance_pwr<0>,
        typename IntensityExponent = pqs::intensity_pwr<0>
    >
    struct anonymous_abstract_quantity{
        typedef typename LengthExponent::length_pwr_type          length_pwr_type;
        typedef typename TimeExponent::time_pwr_type              time_pwr_type ;
        typedef typename MassExponent::mass_pwr_type              mass_pwr_type;
        typedef typename TemperatureExponent::temperature_pwr_type       temperature_pwr_type;
        typedef typename CurrentExponent::current_pwr_type        current_pwr_type;
        typedef typename SubstanceExponent::substance_pwr_type    substance_pwr_type;
        typedef typename IntensityExponent::intensity_pwr_type    intensity_pwr_type;

        typedef anonymous_abstract_quantity<
            length_pwr_type,
            time_pwr_type,
            mass_pwr_type,
            temperature_pwr_type,
            current_pwr_type,
            substance_pwr_type,
            intensity_pwr_type
        > type;
        enum{ is_dimensionless 
        =    length_pwr_type::is_zero
        &&  time_pwr_type::is_zero
        &&  mass_pwr_type::is_zero
        &&  temperature_pwr_type::is_zero
        &&  current_pwr_type::is_zero
        &&  substance_pwr_type::is_zero
        &&  intensity_pwr_type::is_zero } ;
    };
}//pqs

namespace pqs { namespace meta{

     template < 
        typename LengthExponent,
        typename TimeExponent,
        typename MassExponent,
        typename TemperatureExponent,
        typename CurrentExponent,
        typename SubstanceExponent,
        typename IntensityExponent,
        int N,
        int D
    >
    struct binary_operation<
        typename pqs::anonymous_abstract_quantity<
            LengthExponent,
            TimeExponent,
            MassExponent,
            TemperatureExponent,
            CurrentExponent,
            SubstanceExponent,
            IntensityExponent
        >,
        pqs::to_power,
        pqs::meta::rational_c<int, N,D>
    >{
        typedef typename pqs::meta::rational_c<int, N,D>::type rat;
         typedef pqs::anonymous_abstract_quantity<
            typename binary_operation<LengthExponent,std::multiplies,rat>::result_type,
            typename binary_operation<TimeExponent,std::multiplies,rat>::result_type,
            typename binary_operation<MassExponent,std::multiplies,rat>::result_type,
            typename binary_operation<TemperatureExponent,std::multiplies,rat>::result_type,
            typename binary_operation<CurrentExponent,std::multiplies,rat>::result_type,
            typename binary_operation<SubstanceExponent,std::multiplies,rat>::result_type,
            typename binary_operation<IntensityExponent,std::multiplies,rat>::result_type
        > result_type;
    };
        
     template < 
        typename LengthExponentA,
        typename TimeExponentA,
        typename MassExponentA,
        typename TemperatureExponentA,
        typename CurrentExponentA,
        typename SubstanceExponentA,
        typename IntensityExponentA,
        template <typename> class Op,
        typename LengthExponentB,
        typename TimeExponentB,
        typename MassExponentB,
        typename TemperatureExponentB,
        typename CurrentExponentB,
        typename SubstanceExponentB,
        typename IntensityExponentB
   >        
    struct binary_operation<
        typename pqs::anonymous_abstract_quantity<
            LengthExponentA,
            TimeExponentA,
            MassExponentA,
            TemperatureExponentA,
            CurrentExponentA,
            SubstanceExponentA,
            IntensityExponentA
        >,
        Op,
        typename pqs::anonymous_abstract_quantity<
            LengthExponentB,
            TimeExponentB,
            MassExponentB,
            TemperatureExponentB,
            CurrentExponentB,
            SubstanceExponentB,
            IntensityExponentB
        >
   >{
        typedef pqs::anonymous_abstract_quantity<
            typename pqs::meta::binary_log_transform<LengthExponentA,Op,LengthExponentB>::result_type,
            typename pqs::meta::binary_log_transform<TimeExponentA,Op,TimeExponentB>::result_type,
            typename pqs::meta::binary_log_transform<MassExponentA,Op,MassExponentB>::result_type,
            typename pqs::meta::binary_log_transform<TemperatureExponentA,Op,TemperatureExponentB>::result_type,
            typename pqs::meta::binary_log_transform<CurrentExponentA,Op,CurrentExponentB>::result_type,
            typename pqs::meta::binary_log_transform<SubstanceExponentA,Op,SubstanceExponentB>::result_type,
            typename pqs::meta::binary_log_transform<IntensityExponentA,Op,IntensityExponentB>::result_type
        > result_type;
            
   };

    template<
        typename LengthExponent ,
        typename TimeExponent,
        typename MassExponent,
        typename TemperatureExponent,
        typename CurrentExponent,
        typename SubstanceExponent,
        typename IntensityExponent
    >
    struct unary_operation<
        pqs::reciprocal,
        typename pqs::anonymous_abstract_quantity<
            LengthExponent,
            TimeExponent,
            MassExponent,
            TemperatureExponent,
            CurrentExponent,
            SubstanceExponent,
            IntensityExponent
        >
    >{
        typedef typename pqs::anonymous_abstract_quantity<
            typename unary_operation<std::negate,LengthExponent>::result_type,
            typename unary_operation<std::negate,TimeExponent>::result_type,
            typename unary_operation<std::negate,MassExponent>::result_type,
            typename unary_operation<std::negate,TemperatureExponent>::result_type,
            typename unary_operation<std::negate,CurrentExponent>::result_type,
            typename unary_operation<std::negate,SubstanceExponent>::result_type,
            typename unary_operation<std::negate,IntensityExponent>::result_type
      > result_type;
   };

}}// pqs::meta

#endif
