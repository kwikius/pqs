#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_INTENSITY_EXP_HPP_INCLUDED
#define PQS_INTENSITY_EXP_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.
//

/*
    intensity_pwr represents the luninous intensity
    dimension-power member of an SI abstract-physical-quantity.
    basically its a rational_c but designed to catch typos
    and user friendly name
*/

#include "pqs/meta/rational_c.hpp"

namespace pqs{

    template<int N, int D=1>
    struct intensity_pwr { 
        typedef typename meta::rational_c<int,N,D>::type base_type;
         enum{ 
            numerator = base_type::numerator,
            denominator = base_type::denominator,
            is_zero = numerator == 0
        };
        typedef intensity_pwr<
            numerator,
            denominator  
        >intensity_pwr_type;
     };
}//pqs
/*
    binary_operations on intensity_pwr
    intensity_pwr,Op,intensity_pwr
    intensity_pwr,Op,rational_c
    rational_c,Op,intensity_pwr
    
*/

namespace pqs{ namespace meta{

    template<
        int N1,
        int D1,
        template <typename> class Op,
        int N2,
        int D2
    > 
    struct binary_operation<
        intensity_pwr<N1,D1>,
        Op,
        intensity_pwr<N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<int,N1,D1>::type,
            Op,
            typename rational_c<int,N2,D2>::type
        >::result_type base_type;
    public:
        typedef intensity_pwr<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

   template<
        int N1,
        int D1,
        template <typename> class Op,
        typename RatValueType,
        int N2,
        int D2
    > 
    struct binary_operation<
        intensity_pwr<N1,D1>,
        Op,
        rational_c<RatValueType,N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<int,N1,D1>::type,
            Op,
            typename rational_c<int,static_cast<int>(N2),
            static_cast<int>(D2)>::type
        >::result_type base_type;
    public:
        typedef intensity_pwr<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

    template<
        typename Rat_Value_type,
        int N1,
        int D1,
        template <typename> class Op,
        int N2,
        int D2
    > 
    struct binary_operation<
        rational_c<Rat_Value_type,N1,D1>,
        Op,
        intensity_pwr <N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<
                int,
                static_cast<int>(N1),
                static_cast<int>(D1)
            >::type,
            Op,
            typename rational_c<int,N2,D2>::type
        >::result_type base_type;
    public:
        typedef intensity_pwr<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

    template <int N, int D>
    struct unary_operation<
        std::negate,
        intensity_pwr<N,D>
    >{
        typedef typename intensity_pwr<
            -N,D
        >::intensity_pwr_type result_type;
    };
      
}}//pqs::meta


#endif
