#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_PRIME_DIMENSION_EXP_HPP_INCLUDED
#define PQS_PRIME_DIMENSION_EXP_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
     distinctive rationals for prime-dimension-exponents
*/

#include "length_pwr.hpp"
#include "time_pwr.hpp"
#include "mass_pwr.hpp"
#include "temperature_pwr.hpp"
#include "current_pwr.hpp"
#include "substance_pwr.hpp"
#include "intensity_pwr.hpp"

#endif

