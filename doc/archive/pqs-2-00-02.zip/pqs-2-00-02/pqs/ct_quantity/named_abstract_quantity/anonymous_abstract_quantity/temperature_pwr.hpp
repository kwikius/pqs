#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TEMPERATURE_EXP_HPP_INCLUDED
#define PQS_TEMPERATURE_EXP_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    temperature_pwr represents the temperature
    dimension-power member of an SI abstract-physical-quantity.
    basically its a rational_c but designed to catch typos
    and user friendly name
*/

#include "pqs/meta/rational_c.hpp"

namespace pqs{

    template<int N, int D=1>
    struct temperature_pwr{   
        typedef typename meta::rational_c<int,N,D>::type base_type;
        enum{ 
            numerator = base_type::numerator,
            denominator = base_type::denominator,
            is_zero = numerator == 0
        };
        typedef temperature_pwr<
           numerator,denominator
        > temperature_pwr_type;
     };
}//pqs

/*
    binary_operations on temperature_pwr
    temperature_pwr,Op,temperature_pwr
    temperature_pwr,Op,rational_c
    rational_c,Op,temperature_pwr
    
*/

namespace pqs{ namespace meta{

    template<
        int N1,
        int D1,
        template <typename> class Op,
        int N2,
        int D2
    > 
    struct binary_operation<
        temperature_pwr<N1,D1>,
        Op,
        temperature_pwr<N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<int,N1,D1>::type,
            Op,
            typename rational_c<int,N2,D2>::type
        >::result_type base_type;
    public:
        typedef typename pqs::temperature_pwr<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

   template<
        int N1,
        int D1,
        template <typename> class Op,
        typename RatValueType,
        int N2,
        int D2
    > 
    struct binary_operation<
        temperature_pwr<N1,D1>,
        Op,
        rational_c<RatValueType,N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<int,N1,D1>::type,
            Op,
            typename rational_c<int,static_cast<int>(N2),
            static_cast<int>(D2)>::type
        >::result_type base_type;
    public:
        typedef typename pqs::temperature_pwr<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

    template<
        typename Rat_Value_type,
        int N1,
        int D1,
        template <typename> class Op,
        int N2,
        int D2
    > 
    struct binary_operation<
        rational_c<Rat_Value_type,N1,D1>,
        Op,
        temperature_pwr <N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<
                int,
                static_cast<int>(N1),
                static_cast<int>(D1)
            >::type,
            Op,
            typename rational_c<int,N2,D2>::type
        >::result_type base_type;
    public:
        typedef typename pqs::temperature_pwr<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

    template <int N, int D>
    struct unary_operation<
        std::negate,
        temperature_pwr<N,D>
    >{
        typedef typename pqs::temperature_pwr<
            -N,D
        >::temperature_pwr_type result_type;
    };

}}//pqs::meta


#endif
