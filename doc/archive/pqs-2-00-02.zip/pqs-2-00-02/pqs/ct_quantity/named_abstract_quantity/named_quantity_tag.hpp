#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_NAMED_QUANTITY_TAG_HPP_INCLUDED
#define PHYSICAL_QUANTITIES_NAMED_QUANTITY_TAG_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    tag for distinguishing (say) energy from torque
    in a named-abstract-quantity
*/

#include "pqs/meta/binary_operation.hpp"

namespace pqs{

    template< int Output_id =0>
    struct named_quantity_tag{
        enum{ value = Output_id};
        typedef named_quantity_tag      type;
        typedef named_quantity_tag<0>   anonymous_type;
    };
   

}//pqs

namespace pqs{namespace meta{
        
     namespace detail {
        template<int A, int B>
        struct compute_plus_minus_tag{
            enum{ value 
            = (A==B) 
            ? A 
            :   (((A == 0) && (B != 0))
                ? B 
                :   (((B==0) && (A!=0))
                    ? A 
                    : 0))};
        };
    }

    template<
        int A,
        int B
    >
    struct binary_operation<
        pqs::named_quantity_tag<A>,
        std::plus,  
        pqs::named_quantity_tag<B>
    >{
        typedef named_quantity_tag<
            pqs::meta::detail::compute_plus_minus_tag<A,B>::value
        > result_type;
    };

    template<
        int A
    >
    struct binary_operation<
        pqs::named_quantity_tag<A>,
        std::plus,  
        pqs::named_quantity_tag<A>
    >{
        typedef pqs::named_quantity_tag<A> result_type;
    };

     template<
        int A,
        int B
    >
    struct binary_operation<
        pqs::named_quantity_tag<A>,
        std::minus,  
        pqs::named_quantity_tag<B>
    >{
        typedef pqs::named_quantity_tag< 
            pqs::meta::detail::compute_plus_minus_tag<
                A,B
            >::value
        > result_type;
    };

    template<
        int A
    >
    struct binary_operation<
        pqs::named_quantity_tag<A>,
        std::minus,  
        pqs::named_quantity_tag<A>
    >{
        typedef pqs::named_quantity_tag<A> result_type;
    };

    template<
        int A,
        template <typename> class Op,
        int B
    >
     struct binary_operation<
        pqs::named_quantity_tag<A>,
        Op,  
        pqs::named_quantity_tag<B>
    >{
        typedef pqs::named_quantity_tag<0> result_type;
    };
    
}}//pqs::meta

#endif
