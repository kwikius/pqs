#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_OF_QUANTITY_HPP_INCLUDED2911030401
#define PQS_OF_QUANTITY_HPP_INCLUDED2911030401

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.
/*
    config const in of_quantity struct.
    currently not very portable...todo

*/

#include "pqs/config.hpp"
#include <limits>

#ifdef  PQS_USE_BOOST_NUMERIC_CONVERTER
#include "boost/numeric/converter.hpp"
#else
#ifdef PQS_USE_UNCHECKED_CONVERTER
// no checks no nearest neighbour rounding
namespace pqs {

        template<typename T, typename S>
        struct unchecked_converter{

            T operator()(S const& s)const
            {   
                return static_cast<T>(s);
            }
        };
}
#else
#include "pqs/numeric/converter.hpp"
#endif
#endif
#include "pqs/meta/promotion_traits.hpp"
#include "pqs/meta/associated_arithmetic.hpp"

/*
    config,traits and scaling functions for all ct_quantities
*/

namespace pqs{

    struct of_quantity {
        enum{
        // potentially could be used for(say) hex
            exponent_base = 10,
            max_int_exponent  = 8,
            max_long_exponent = 8,
            max_float_exponent  
            = std::numeric_limits<float>::max_exponent10,
            max_double_exponent  
            = std::numeric_limits<double>::max_exponent10,
            max_long_double_exponent  
            = std::numeric_limits<long double>::max_exponent10,
            incoherent_multiplier_scale
            = 1000000,
            min_int_coherent_exponent = -60,
            max_int_coherent_exponent = 67,
            min_rat_coherent_exponent = -63,
            max_rat_coherent_exponent = 63,
        // If you define ct_quantities with
        // named_quantity_tag > than this value
        // then you need to write your own  
        // units functions
           max_default_named_quantity_tag = 100
        };    
        // minimum float type for eval ie float or double etc
        // unwise to set less than float
        typedef double     min_real_eval_type;
        template <typename Value_type>
        struct  min_real{
            typedef typename pqs::meta::arithmetic_promote<
                Value_type,
                min_real_eval_type
            >::type type;
        };
        // for use as the default value_type for ct_quantities
        // should probably stay in sync with min_real_eval_type above
        // in fact they should probably be the same typedef.
        typedef double default_value_type;
        template<typename T, typename S>
        struct value_type_converter{
        #ifdef  PQS_USE_BOOST_NUMERIC_CONVERTER
            // boost converter with nearest neighbour rounding
            typedef typename boost::numeric::converter<
                T,
                S,
                boost::numeric::conversion_traits<T,S>,
                boost::numeric::def_overflow_handler,
                boost::numeric::RoundEven<S>
            > type;
        #else  
        #ifdef  PQS_USE_UNCHECKED_CONVERTER     
            typedef typename pqs::unchecked_converter<T,S> type;
        #else  
            typedef typename pqs::numeric::converter<T,S> type;
        #endif
        #endif
        };
       
        // for comparison ==,< etc
        // The MACRO PQS_COMPARISON_EPSILON is 
        // defined in pqs/config.hpp" and is actually used
        // raw as default ep in the compare(pqa,pqb,ep) function,
        //  which is basis for all comp ops
        // see "pqs/ct_quantity/operations/compare.hpp"
        // so in practise the function below is not used
        template<typename T>
        static T epsilon()
        {
            return static_cast<T>(PQS_COMPARISON_EPSILON);
        }  
          
    };
  
}//pqs

#endif
