#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CT_QUANTITY_OPERATIONS_HPP__INCLUDED
#define PQS_CT_QUANTITY_OPERATIONS_HPP__INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

// ct_quantity components
#include "pqs/ct_quantity/named_abstract_quantity.hpp"
#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/ct_quantity/quantity_unit/si_prefix.hpp"
// operations
#include "pqs/ct_quantity/operations/add_subtract.hpp"
#include "pqs/ct_quantity/operations/divide.hpp"
#include "pqs/ct_quantity/operations/multiply.hpp"
#include "pqs/ct_quantity/operations/power_root.hpp"
#include "pqs/ct_quantity/operations/compare.hpp"
#include "pqs/ct_quantity/operations/anonymous_cast.hpp"


#endif
