#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

#ifndef PHYSICAL_QUANTITY_CLASS_TEMPLATE_ADD_SUB1_HPP_INCLUDED2911030401
#define PHYSICAL_QUANTITY_CLASS_TEMPLATE_ADD_SUB1_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    addition and subtraction of ct-quantities
*/

#include "pqs/ct_quantity/operations/generic_binary_operation.hpp"
#include "pqs/meta/binary_operation_if.hpp"
#include "pqs/ct_quantity/ct_quantity.hpp"
#include "boost/type_traits/is_same.hpp"

namespace pqs{

    template < 
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline  
    typename meta::binary_operation_if<
        boost::is_same<
            typename NamedAbstractQuantityA::anonymous_abstract_quantity_type,
            typename NamedAbstractQuantityB::anonymous_abstract_quantity_type
        >,
        ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >,
        std::plus,
        ct_quantity<
            NamedAbstractQuantityB, // ab_B D.A checked below
            QuantityUnitB,
            Value_typeB
        >
    >::result_type
    operator + (
        ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const& a
        ,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {   
         concept_checking::function_requires<
            CompatibleQuantityWarningConcept<
                NamedAbstractQuantityA,
                NamedAbstractQuantityB
            >
        >();  
        typename meta::binary_operation<
            ct_quantity<
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >,
            std::plus,
            ct_quantity<
                NamedAbstractQuantityB, 
                QuantityUnitB,
                Value_typeB
            >
        >::result_type t = a;
        t += b;
        return t;
    }
   
    template < 
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline  
    typename meta::binary_operation_if<
         boost::is_same<
            typename NamedAbstractQuantityA::anonymous_abstract_quantity_type,
            typename NamedAbstractQuantityB::anonymous_abstract_quantity_type
        >,
        ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >,
        std::minus,
        ct_quantity<
            NamedAbstractQuantityB, // ab_B D.A checked below
            QuantityUnitB,
            Value_typeB
        >
    >::result_type
    operator - (ct_quantity<
                    NamedAbstractQuantityA,
                    QuantityUnitA,
                    Value_typeA
                > const & a ,
                ct_quantity<
                    NamedAbstractQuantityB,
                    QuantityUnitB,
                    Value_typeB
                >const& b)
    {   
        concept_checking::function_requires<
            CompatibleQuantityWarningConcept<
                NamedAbstractQuantityA,
                NamedAbstractQuantityB
            >
        >(); 
        typename meta::binary_operation<
            ct_quantity<
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >,
            std::minus,
            ct_quantity<
                NamedAbstractQuantityB, 
                QuantityUnitB,
                Value_typeB
            >
        >::result_type t = a;
        t -= b;
        return t;
    }
   
}//pqs

#endif

