#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_OPERATIONS_ANONYMOUS_CAST_HPP_INCLUDED
#define PQS_OPERATIONS_ANONYMOUS_CAST_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    function to cast a named-concrete-quantity
    to an anonymous_concrete_quantity
*/

#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/ct_quantity/named_abstract_quantity.hpp"

namespace pqs{

    template < 
        template<typename,typename > class NamedAbstractQuantity,
        typename AnonymousAbstractQuantity,
        typename NamedQuantityTag,
        typename QuantityUnit,
        typename Value_type
    >
    inline
    ct_quantity<
        NamedAbstractQuantity< 
            AnonymousAbstractQuantity,    
            typename NamedQuantityTag::anonymous_type
        >,
        QuantityUnit,
        Value_type
    >
    anonymous_cast(
            ct_quantity<
                NamedAbstractQuantity<
                    AnonymousAbstractQuantity,
                    NamedQuantityTag
                >,
                QuantityUnit,
                Value_type
            > const& pq_in)
    {
        ct_quantity<
            NamedAbstractQuantity< 
                AnonymousAbstractQuantity,    
                typename NamedQuantityTag::anonymous_type
            >,
            QuantityUnit,
            Value_type
        > t(pq_in.numeric_value());
        return t;
    }
}

#endif
