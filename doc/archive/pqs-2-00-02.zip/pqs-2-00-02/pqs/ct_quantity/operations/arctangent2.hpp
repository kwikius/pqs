
#ifndef PQS_CT_QUANTITY_OPERATIONS_ARCTANGENT2_HPP_INCLUDED
#define PQS_CT_QUANTITY_OPERATIONS_ARCTANGENT2_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    arctangent2(pqa,pqb);
like atan2  but returns a pqs::math::of_angle::rad
*/

#include "pqs/ct_quantity/operations/atan2.hpp"
#include "pqs/math/angles/radians.hpp"

namespace pqs{

     template < 
        typename NamedAbstractQuantityA,
        typename UnitsA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    typename pqs::math::radians<
        pqs::meta::rational_c<long,1>,
        typename pqs::of_quantity::min_real<
            typename pqs::meta::binary_operation<
                Value_typeA,
                std::divides,
                Value_typeB
            >::result_type
        >::type
    >::type

    arctangent2( pqs::ct_quantity<
            NamedAbstractQuantityA,
            UnitsA,
            Value_typeA
        >const& pqa
        ,
        pqs::ct_quantity<
            NamedAbstractQuantityB,
            UnitsB,
            Value_typeB
        >const& pqb )
    {

        pqs::concept_checking::function_requires<
            pqs::CompatibleQuantityWarningConcept<
                NamedAbstractQuantityA,
                NamedAbstractQuantityB
            >
        >();

        typedef typename pqs::of_quantity::min_real<
            typename pqs::meta::binary_operation<
                Value_typeA,
                std::divides,
                Value_typeB
            >::result_type
        >::type  result_value_type;

        return typename pqs::math::radians<
            pqs::meta::rational_c<long,1>,
            result_value_type
        >::type (pqs::atan2(pqa,pqb));
    }

}//pqs

#endif

