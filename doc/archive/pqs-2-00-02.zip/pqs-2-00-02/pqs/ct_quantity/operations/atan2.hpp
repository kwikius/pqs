#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_MATH_ATAN2_HPP_INCLUDED
#define PQS_MATH_ATAN2_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    atan2 for ct-quantities
    atan2 returns numeric
    arctangent2 returns pqs::math::angle::rad
*/
#include "pqs/ct_quantity/ct_quantity.hpp"
#include <cmath>

namespace pqs{

    template < 
        typename NamedAbstractQuantityA,
        typename UnitsA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    
    typename pqs::of_quantity::min_real<
        typename pqs::meta::binary_operation<
            Value_typeA,
            std::divides,
            Value_typeB
        >::result_type
    >::type
  
    atan2( pqs::ct_quantity<
            NamedAbstractQuantityA,
            UnitsA,
            Value_typeA
        >const& pqa
        ,
        pqs::ct_quantity<
            NamedAbstractQuantityB,
            UnitsB,
            Value_typeB
        >const& pqb )
    {

        pqs::concept_checking::function_requires<
            pqs::CompatibleQuantityWarningConcept<
                NamedAbstractQuantityA,
                NamedAbstractQuantityB
            >
        >();

        typedef typename pqs::of_quantity::min_real<
            typename pqs::meta::binary_operation<
                Value_typeA,
                std::divides,
                Value_typeB
            >::result_type
        >::type  result_type;
        // should do "finest_grained" here
        typedef typename pqs::meta::binary_operation<
            pqs::ct_quantity<
                NamedAbstractQuantityA,
                UnitsA,
                result_type
            >,
            std::plus,
            pqs::ct_quantity<
                NamedAbstractQuantityB,
                UnitsB,
                result_type
            >
        >::result_type promoted_type;

        promoted_type ta = pqa;
        promoted_type tb = pqb;

        using std::atan2;
        return result_type(atan2(ta.numeric_value(),tb.numeric_value()));
    }
}

#endif
