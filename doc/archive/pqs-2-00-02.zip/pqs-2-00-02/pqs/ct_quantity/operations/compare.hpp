#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_COMP_HPP_INCLUDED2911030401
#define PQS_CLASS_TEMPLATE_COMP_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    compare(pqa,pqb) works like strcmp and string::compare:
    if( a == b ) return 0;
    if( a > b ) return 1;
    if( a < b ) return -1;

    compare is basis of all other comp functions
    added 23/09/04 optional 'epsilon' arg to compare
    modified config so default param is type(0)
*/

#include "pqs/ct_quantity/ct_quantity.hpp"

namespace pqs{

    // abs(pq)
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    ct_quantity<
        NamedAbstractQuantity,
        QuantityUnit,
        Value_type
    >
    abs(
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & in)
    {
        return (in.numeric_value() >=0 )
        ? in
        : -in;
    }  

    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    int 
    compare(
        ct_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b,
        //ouch :-)
        typename pqs::meta::binary_operation<
            ct_quantity< 
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >,
            std::minus,
            ct_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        >::result_type const &  ep
        = typename pqs::meta::binary_operation<
            ct_quantity< 
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >,
            std::minus,
            ct_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        >::result_type(
            static_cast<
                typename pqs::meta::binary_operation<
                    Value_typeA,
                    std::minus,
                    Value_typeB
                >::result_type
            >(PQS_COMPARISON_EPSILON))   
        )
    {
        typedef typename pqs::meta::binary_operation<
                Value_typeA,std::minus,Value_typeB
        >::result_type comp_type;
        return ((abs(a-b)).numeric_value() <= ep.numeric_value()) // should be  ep/2 ??
        ? 0 
        :(((a-b).numeric_value() < static_cast<comp_type>(0))
            ? -1
            : 1 );
    }

    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator == (  
        ct_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {
        return (compare(a,b) == 0); 
    }
    
    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator != (
        ct_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b)
    {
        return (compare(a,b)!= 0);
    }

 // PQa < PQb
    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator<(
        ct_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b) 
    {
        return (compare(a,b) < 0);
    }

    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator >(
        ct_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {
        return (compare(a,b) > 0);
    }

    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator <=(
        ct_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {
        return (compare(a,b) <= 0);
    }

   template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator >=(
        ct_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {
        return (compare(a,b) >= 0);
    }

}//pqs

#endif
