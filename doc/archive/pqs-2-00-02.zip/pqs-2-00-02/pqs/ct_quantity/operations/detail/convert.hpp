#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_OPERATIONS_CONVERT_HPP_INCLUDED
#define PQS_OPERATIONS_CONVERT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    various conversions
    in fact could probably be replaced by boost::implicit_cast
   todo
*/

#include "pqs/ct_quantity/of_quantity.hpp"
#include "pqs/meta/associated_arithmetic.hpp"
#include "pqs/concepts/concept_checking.hpp"

namespace pqs{namespace detail{

    // for use where implicit conversion is required
    template <
        typename T,
        typename S
    >
    inline T implicit_initialise(S const &  s)
    {  
        concept_checking::function_requires<
                ImplicitInitialisableConcept<T, S>
        >();
        return typename of_quantity::template value_type_converter<T,S>::type()(s);
      
    }
    template<>
    inline double implicit_initialise<double, int>(int const & s)
    {
        return  static_cast<double>(s);
    }
    template<>
    inline double implicit_initialise<double, long>(long const & s)
    {
        return  static_cast<double>(s);
    }

    template<>
    inline float implicit_initialise<float, int>(int const & s)
    {
        return  static_cast<float>(s);
    }
    
    template <
        typename T,
        typename S
    >
    inline T implicit_assign(S const &  s)
    {  
        concept_checking::function_requires<
                AssignableConcept<T, S>
        >();
        return typename of_quantity::template value_type_converter<T,S>::type()(s);
    }
    template<>
    inline double implicit_assign<double, int>(int const & s)
    {
        return  static_cast<double>(s);
    }
    template<>
    inline double implicit_assign<double, long>(long const & s)
    {
        return  static_cast<double>(s);
    }

    template<>
    inline float implicit_assign<float, int>(int const & s)
    {
        return  static_cast<float>(s);
    }
   
}}//pqs::detail

#endif
