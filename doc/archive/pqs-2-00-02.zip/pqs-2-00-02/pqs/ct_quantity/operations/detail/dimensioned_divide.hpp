#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_OPERATIONS_DIMENSIONED_DIVIDE_HPP_INCLUDED
#define PQS_OPERATIONS_DIMENSIONED_DIVIDE_HPP_INCLUDED

#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/ct_quantity/operations/generic_binary_operation.hpp"
#include "pqs/ct_quantity/operations/detail/incoherent_mx.hpp"

/*
    divide low level calcs
*/

namespace pqs{namespace detail{

    template<
        typename PQa, 
        typename PQb,
        typename Result_type,
        typename Eval_Fx,
        bool Eval_fx_Required
    >
    struct dimensioned_divide_eval;

    template< 
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    > struct dimensioned_divide{
        typedef pqs::ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        > pqA_type;
        typedef pqs::ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        > pqB_type;
        typedef typename meta::binary_operation<
            pqA_type,
            std::divides,
            pqB_type
        >::result_type result_type;
        typedef typename result_type::value_type value_type;
        typedef typename detail::divide_incoherent_mx<  
            typename meta::to_arithmetic<value_type>::type,
            QuantityUnitA::incoherent_multiplier_type::value,
            QuantityUnitB::incoherent_multiplier_type::value
        > incoherent_div_fx;
        enum{ fx_required = incoherent_div_fx::required};
        struct eval : dimensioned_divide_eval<
            pqA_type,
            pqB_type,
            result_type,
            incoherent_div_fx,
            fx_required
        >{};
    
    };
        template<
            typename PQa, 
            typename PQb,
            typename Result_type,
            typename Eval_Fx
         >
         struct dimensioned_divide_eval<
            PQa,PQb,Result_type,Eval_Fx, true
         >{
            Result_type operator()(PQa const & a, PQb const & b)const
            {
              Result_type t(a.numeric_value() * Eval_Fx()() / b.numeric_value());
              return t;
            }
         };

        template<
            typename PQa, 
            typename PQb,
            typename Result_type,
            typename Eval_Fx
         >
         struct dimensioned_divide_eval<
            PQa,PQb,Result_type,Eval_Fx, false
         >{
            Result_type operator()(PQa const & a, PQb const & b)const
            {
                Result_type t( a.numeric_value() / b.numeric_value());
                return t;
            }
         };
        
}}//pqs::detail

#endif
