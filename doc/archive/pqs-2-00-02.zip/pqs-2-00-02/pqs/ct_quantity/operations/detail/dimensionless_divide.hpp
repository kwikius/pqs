#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_DIMENSIONLESS_DIVIDE_TRAITS_HPP_INCLUDED
#define PQS_DIMENSIONLESS_DIVIDE_TRAITS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.


#include "pqs/ct_quantity/operations/detail/quantity_conversion_traits.hpp"

 namespace pqs{ namespace detail{
    
    template<
        typename DimensionlessDivideTraits,
        bool Incoh, bool Delog, bool PosAlg
    >
    struct dimensionless_divide_traits_fx;
    
    template <
        typename Value_typeA,
        typename UnitsA,
        typename Value_typeB,
        typename UnitsB
    > 
    struct dimensionless_divide_traits{

        typedef quantity_conversion_traits<
            Value_typeB,                //Target_value_type,
            UnitsB,                     //Target_unit,
            Value_typeA,                //Source_value_type,
            UnitsA                      //Source_unit
        > conversion_traits;

        typedef typename conversion_traits::source_value_type value_typeA;
        typedef typename conversion_traits::target_value_type value_typeB;
        typedef typename conversion_traits::incoherent_divide_fx incoherent_divide_fx;
        typedef typename conversion_traits::abs_difference_delog_fx abs_difference_delog_fx;
        typedef typename conversion_traits::first_difference_exponent first_difference_exponent;

        typedef typename pqs::meta::binary_operation<
            value_typeA,
            std::divides,
            value_typeB
        >::result_type result_type;

        struct eval : dimensionless_divide_traits_fx<
                    dimensionless_divide_traits,
                    incoherent_divide_fx::required,
                    abs_difference_delog_fx::required,
                    first_difference_exponent::is_positive
        >{};

    };
  
    //incoherent_fx_required                    == true
    //abs_difference_delog_fx_required          == true 
    //first_difference_exponent::is_positive    == true 
    template<typename DimensionlessDivideTraits>
    struct dimensionless_divide_traits_fx<DimensionlessDivideTraits,true,true,true>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
        typename DimensionlessDivideTraits::value_typeA const& pq_vala,
        typename DimensionlessDivideTraits::value_typeB const& pq_valb)const
        {
            return pq_vala 
            * (typename DimensionlessDivideTraits::incoherent_divide_fx()() 
            * (typename DimensionlessDivideTraits::abs_difference_delog_fx()() / pq_valb));
        }
    };
    
    //incoherent_fx_required                    == true
    //abs_difference_delog_fx_required          == false 
    //first_difference_exponent::is_positive    == X 
    template<typename DimensionlessDivideTraits,bool X>
    struct dimensionless_divide_traits_fx<DimensionlessDivideTraits,true,false,X>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
        typename DimensionlessDivideTraits::value_typeA const& pq_vala,
        typename DimensionlessDivideTraits::value_typeB const& pq_valb)const
        {
            return pq_vala * typename DimensionlessDivideTraits::incoherent_divide_fx()() / pq_valb ;
        }
    };
    
    //incoherent_fx_required                    == false
    //abs_difference_delog_fx_required          == true 
    //first_difference_exponent::is_positive    == true 
    template<typename DimensionlessDivideTraits>
    struct dimensionless_divide_traits_fx<DimensionlessDivideTraits,false,true,true>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
        typename DimensionlessDivideTraits::value_typeA const& pq_vala,
        typename DimensionlessDivideTraits::value_typeB const& pq_valb)const
        {
            return pq_vala * typename DimensionlessDivideTraits::abs_difference_delog_fx()() 
            / pq_valb;
        }
    };
    
    //incoherent_fx_required                    == true
    //abs_difference_delog_fx_required          == true 
    //first_difference_exponent::is_positive    == false 
    template<typename DimensionlessDivideTraits>
    struct dimensionless_divide_traits_fx<DimensionlessDivideTraits,true,true,false>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
        typename DimensionlessDivideTraits::value_typeA const& pq_vala,
        typename DimensionlessDivideTraits::value_typeB const& pq_valb)const
        {
            return pq_vala 
            / ( pq_valb * typename DimensionlessDivideTraits::abs_difference_delog_fx()() 
                / typename DimensionlessDivideTraits::incoherent_divide_fx()());

        }
    };

    //incoherent_fx_required                    == false
    //abs_difference_delog_fx_required          == true 
    //first_difference_exponent::is_positive    == false 
    template<typename DimensionlessDivideTraits>
    struct dimensionless_divide_traits_fx<DimensionlessDivideTraits,false,true,false>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
        typename DimensionlessDivideTraits::value_typeA const& pq_vala,
        typename DimensionlessDivideTraits::value_typeB const& pq_valb)const
        {
            return pq_vala 
            / ( pq_valb * typename DimensionlessDivideTraits::abs_difference_delog_fx()());
        }
    };

    //incoherent_fx_required                    == false
    //abs_difference_delog_fx_required          == false 
    //first_difference_exponent::is_positive    == X 
    template<typename DimensionlessDivideTraits,bool X>
    struct dimensionless_divide_traits_fx<DimensionlessDivideTraits,false,false,X>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
        typename DimensionlessDivideTraits::value_typeA const& pq_vala,
        typename DimensionlessDivideTraits::value_typeB const& pq_valb)const
        {
            return  pq_vala / pq_valb;
        }
    };
   
}}//pqs::detail

#endif
