#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_DIMENSIONLESS_MULTIPLY_TRAITS_HPP_INCLUDED
#define PQS_DIMENSIONLESS_MULTIPLY_TRAITS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/ct_quantity/operations/detail/quantity_conversion_traits.hpp"

 namespace pqs{ namespace detail{

    template<
        typename DimlessMulTraits,
        bool Incoh, bool Delog,bool PosAlg
    >
    struct dimensionless_multiply_traits_fx;

    template <
        typename Value_typeA,
        typename UnitsA,
        typename Value_typeB,
        typename UnitsB
    > 
    struct dimensionless_multiply_traits{

        typedef quantity_conversion_traits<
            Value_typeB,                //Target_value_type,
            UnitsB,                     //Target_unit,
            Value_typeA,                //Source_value_type,
            UnitsA                      //Source_unit
        > conversion_traits;
        typedef typename conversion_traits::source_value_type value_typeA;
        typedef typename conversion_traits::target_value_type value_typeB;
        typedef typename conversion_traits::incoherent_multiply_fx incoherent_multiply_fx;
        typedef typename conversion_traits::abs_sum_delog_fx abs_sum_delog_fx;
        typedef typename conversion_traits::first_sum_exponent first_sum_exponent;
        typedef typename pqs::meta::binary_operation<
            value_typeA,
            std::multiplies,
            value_typeB
        >::result_type result_type;

        struct eval : dimensionless_multiply_traits_fx<
                    dimensionless_multiply_traits,
                    incoherent_multiply_fx::required,
                    abs_sum_delog_fx::required,
                    first_sum_exponent::is_positive
        >{};
    };

    //incoherent_fx_required             == true
    //abs_sum_delog_fx_required          == true 
    //first_sum_exponent::is_positive    == true 
    template<typename DimlessMulTraits>
    struct dimensionless_multiply_traits_fx<DimlessMulTraits,true,true,true>{
        typename DimlessMulTraits::result_type 
        operator()(
        typename DimlessMulTraits::value_typeA const& pq_vala,
        typename DimlessMulTraits::value_typeB const& pq_valb)const
        {
            return pq_vala * pq_valb
            * typename DimlessMulTraits::incoherent_multiply_fx()() 
            * typename DimlessMulTraits::abs_sum_delog_fx()();
        }
    };
    
    //incoherent_fx_required             == true
    //abs_sum_delog_fx_required          == false 
    //first_sum_exponent::is_positive    == X 
    template<typename DimlessMulTraits,bool X>
    struct dimensionless_multiply_traits_fx<DimlessMulTraits,true,false,X>{
        typename DimlessMulTraits::result_type
        operator()(
            typename DimlessMulTraits::value_typeA const& pq_vala,
            typename DimlessMulTraits::value_typeB const& pq_valb)const
        {
            return pq_vala  * pq_valb 
            * typename DimlessMulTraits::incoherent_multiply_fx()();
        }
    };
    
    //incoherent_fx_required             == false
    //abs_sum_delog_fx_required          == true 
    //first_sum_exponent::is_positive    == true 
    template<typename DimlessMulTraits>
    struct dimensionless_multiply_traits_fx<DimlessMulTraits,false,true,true>{
        typename DimlessMulTraits::result_type
        operator()(
            typename DimlessMulTraits::value_typeA const& pq_vala,
            typename DimlessMulTraits::value_typeB const& pq_valb)const
        {
            return pq_vala * pq_valb * typename DimlessMulTraits::abs_sum_delog_fx()()  ;
        }
    };
    
    //incoherent_fx_required             == true
    //abs_sum_delog_fx_required          == true 
    //first_sum_exponent::is_positive    == false 
    template<typename DimlessMulTraits>
    struct dimensionless_multiply_traits_fx<DimlessMulTraits,true,true,false>{
        typename DimlessMulTraits::result_type
        operator()(
            typename DimlessMulTraits::value_typeA const& pq_vala,
            typename DimlessMulTraits::value_typeB const& pq_valb)const
        {
            return pq_vala * pq_valb * typename DimlessMulTraits::incoherent_multiply_fx()()
            /  typename DimlessMulTraits::abs_sum_delog_fx()() ;
        }
    };

    //incoherent_fx_required             == false
    //abs_sum_delog_fx_required          == true 
    //first_sum_exponent::is_positive    == false 
    template<typename DimlessMulTraits>
    struct dimensionless_multiply_traits_fx<DimlessMulTraits,false,true,false>{
        typename DimlessMulTraits::result_type
        operator()(
            typename DimlessMulTraits::value_typeA const& pq_vala,
            typename DimlessMulTraits::value_typeB const& pq_valb)const
        {
            return pq_vala * pq_valb
            /  typename DimlessMulTraits::abs_sum_delog_fx()() ;
        }
    };

    //incoherent_fx_required             == false
    //abs_sum_delog_fx_required          == false 
    //first_sum_exponent::is_positive    == X 
    template<typename DimlessMulTraits,bool X>
    struct dimensionless_multiply_traits_fx<DimlessMulTraits,false,false,X>{
        typename DimlessMulTraits::result_type 
        operator()(
            typename DimlessMulTraits::value_typeA const& pq_vala,
            typename DimlessMulTraits::value_typeB const& pq_valb)const
        {
            return  pq_vala * pq_valb;
        }
    };
    
}}//pqs::detail

#endif
