#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_DETAIL_INCOHERENT_MX_HPP_INCLUDED
#define PHYSICAL_QUANTITIES_DETAIL_INCOHERENT_MX_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    get incoherent multiplier /divide value
*/

#include "pqs/ct_quantity/of_quantity.hpp"
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"
#include "pqs/meta/promotion_traits.hpp"
#include "pqs/meta/min_type.hpp"
#include "pqs/concepts/concept_checking.hpp"

namespace pqs{ namespace detail{
 // restricted to arithmetic types only
    template<
        typename Value_type,
        long Incoherent_mx_nume,
        long Incoherent_mx_denom
    >
    struct divide_incoherent_mx 
    : pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required = true};
        typedef typename pqs::of_quantity::min_real<
                Value_type
        >::type result_type;
        result_type  operator()()const throw()
        {   
            return  static_cast<result_type>(Incoherent_mx_nume)
                    /Incoherent_mx_denom;
        } 
    };

    template<
        typename Value_type,
        long Incoherent_mx
    >
    struct divide_incoherent_mx <
        Value_type,
        Incoherent_mx,
        Incoherent_mx
    > : pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required = false};
        typedef typename pqs::meta::int_promote<
            Value_type
        >::type result_type;
        result_type operator ()()const throw()
        {   
            return  static_cast<result_type>(1);
        } 
    };

  
    template<
        typename Value_type,
        long Incoherent_mx_L,
        long Incoherent_mx_R
     >
     struct multiply_incoherent_mx 
     : pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required = true,exponent = -12};
        typedef typename pqs::of_quantity::min_real<
                Value_type
        >::type  result_type;
  
        result_type  operator()() throw()
        {   
            return (static_cast<result_type>(Incoherent_mx_L) 
                    / of_quantity::incoherent_multiplier_scale )
                    * (static_cast<result_type>(Incoherent_mx_R) 
                        / of_quantity::incoherent_multiplier_scale);
        } 
    };

    template<
        typename Value_type,
        long Incoherent_mx
    >
    struct multiply_incoherent_mx <
        Value_type,
        Incoherent_mx,
        of_quantity::incoherent_multiplier_scale
    > : pqs::concept_checking::AssertIsArithmetic<Value_type> 
    {
        enum{required = true,exponent = -6};
        typedef typename pqs::of_quantity::min_real<
            Value_type
        >::type result_type;
        result_type operator ()()const throw()
        {   
            return   static_cast<result_type>(Incoherent_mx) 
                    / of_quantity::incoherent_multiplier_scale;
        } 
    };

    
    template<
        typename Value_type,
        long Incoherent_mx
    >
    struct multiply_incoherent_mx<
        Value_type,
        of_quantity::incoherent_multiplier_scale,
        Incoherent_mx
    > : pqs::concept_checking::AssertIsArithmetic<Value_type>
    {
        enum{required = true,exponent = -6};
        typedef typename pqs::of_quantity::min_real<
            Value_type
        >::type result_type;
        result_type operator()()const throw()
        {   
            return  static_cast<result_type>(Incoherent_mx)
                    /of_quantity::incoherent_multiplier_scale;
        } 
    };

     template<
        typename Value_type
     >
     struct multiply_incoherent_mx<
        Value_type,
        of_quantity::incoherent_multiplier_scale,
        of_quantity::incoherent_multiplier_scale
    > : pqs::concept_checking::AssertIsArithmetic<Value_type>
    {
        enum{required = false, exponent = 0};
        typedef typename pqs::meta::int_promote<
            Value_type
        >::type result_type;
        result_type  operator()()const throw()
        {   
           return  static_cast<result_type>(1);
        } 
    };


}}//pqs::detail

#endif



