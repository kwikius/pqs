#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_QUANTITY_CONVERSION_TRAITS_HPP_INCLUDED
#define PQS_QUANTITY_CONVERSION_TRAITS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/meta/promotion_traits.hpp"
#include "pqs/meta/associated_arithmetic.hpp"
#include "pqs/meta/unary_operation.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/ct_quantity/operations/detail/incoherent_mx.hpp"

 namespace pqs{namespace detail {
        
    template <
        typename Target_value_type,
        typename Target_unit,
        typename Source_value_type,
        typename Source_unit

    > struct quantity_conversion_traits{

        typedef Source_value_type  source_value_type;
        typedef Target_value_type  target_value_type;
        typedef typename pqs::meta::arithmetic_promote<
            typename pqs::meta::to_arithmetic<
                source_value_type
            >::type,
            typename pqs::meta::to_arithmetic<
                target_value_type
            >::type
        >::type                 min_in_arith_value_type;
        
        // result of adding input exponents
        typedef typename pqs::meta::binary_operation<
            typename Source_unit::coherent_exponent_type,
            std::plus,
            typename Target_unit::coherent_exponent_type
        >::result_type first_sum_exponent;

        // also get negated version, use if first < 0
        typedef typename pqs::meta::unary_operation<
            std::negate,
            first_sum_exponent
        >::result_type second_sum_exponent;

        // always positive version
        typedef typename boost::mpl::if_c<
            first_sum_exponent::is_positive,
            first_sum_exponent,
            second_sum_exponent
        >::type abs_sum_exponent;

        // difference of exponents
        typedef typename pqs::meta::binary_operation<
            typename Source_unit::coherent_exponent_type,
            std::minus,
            typename Target_unit::coherent_exponent_type
        >::result_type first_difference_exponent;

        // also get negated version, use if first < 0
        typedef typename pqs::meta::unary_operation<
            std::negate,
            first_difference_exponent
        >::result_type second_difference_exponent;

        // always positive version
        typedef typename boost::mpl::if_c<
            first_difference_exponent::is_positive,
            first_difference_exponent,
            second_difference_exponent
        >::type abs_difference_exponent;

        //set up for division of incoherent_mxes
        typedef divide_incoherent_mx<
            min_in_arith_value_type,
            Source_unit::incoherent_multiplier_type::value,
            Target_unit::incoherent_multiplier_type::value
        > incoherent_divide_fx;
        
        typedef typename boost::mpl::if_c<
            incoherent_divide_fx::required,
            typename incoherent_divide_fx::result_type,
            min_in_arith_value_type
        >::type min_incoherent_divide_value_type;

         typedef multiply_incoherent_mx<
            min_in_arith_value_type,
            Source_unit::incoherent_multiplier_type::value,
            Target_unit::incoherent_multiplier_type::value
        > incoherent_multiply_fx;
        
         typedef typename boost::mpl::if_c<
            incoherent_multiply_fx::required,
            typename incoherent_multiply_fx::result_type,
            min_in_arith_value_type
        >::type min_incoherent_multiply_value_type;
            
        typedef typename abs_difference_exponent::eval<
            typename  pqs::meta::arithmetic_promote<
                min_in_arith_value_type,
                min_incoherent_divide_value_type
            >::type
        > abs_difference_delog_fx;
        
        typedef typename abs_sum_exponent::eval<
            typename  pqs::meta::arithmetic_promote<
                min_in_arith_value_type,
                min_incoherent_multiply_value_type
            >::type
        > abs_sum_delog_fx;

        typedef typename pqs::meta::arithmetic_promote<
            typename abs_difference_delog_fx::result_type,
            typename incoherent_divide_fx::result_type 
        >::type promoted_difference_divide_working_type;

         typedef typename pqs::meta::arithmetic_promote<
            typename abs_sum_delog_fx::result_type,
            typename incoherent_multiply_fx::result_type 
        >::type promoted_sum_multiply_working_type;
        
     };

}}//pqs::detail

#endif
 