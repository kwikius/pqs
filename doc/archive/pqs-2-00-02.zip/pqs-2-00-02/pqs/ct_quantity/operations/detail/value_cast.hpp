#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_VALUE_CAST_HPP_INCLUDED
#define PQS_VALUE_CAST_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    compute result value in scaling two ct-quantities
*/


#include "pqs/ct_quantity/operations/detail/value_cast_traits.hpp"
#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/dimensional_analysis/concept_checking.hpp"
#include "pqs/ct_quantity/operations/detail/convert.hpp"

namespace pqs {namespace detail{

    template <
        typename Target_pq,
        typename Source_NamedAbstractQuantity,
        typename Source_unit,
        typename Source_value_type
    > 
    inline 
    typename Target_pq::value_type     
    implicit_initialise_value_cast(
        ct_quantity<
            Source_NamedAbstractQuantity,
            Source_unit,
            Source_value_type
        >const & source_pq)
    {   
        pqs::concept_checking::function_requires<
            CompatibleQuantityWarningConcept<
                typename Target_pq::named_abstract_quantity_type,
                Source_NamedAbstractQuantity
            >
        >(); 

        typedef  typename detail::value_cast_traits<
                typename Target_pq::value_type,
                typename Target_pq::units_type,
                Source_value_type,
                Source_unit
        > value_cast_traits;
     
        return pqs::detail::implicit_initialise<typename Target_pq::value_type>(
            typename value_cast_traits::eval()( source_pq.numeric_value() ) );
    }

    //template <
    //    typename Target_pq,
    //    typename Source_NamedAbstractQuantity,
    //    typename Source_unit,
    //    typename Source_value_type
    //> 
    //inline 
    //typename Target_pq::value_type     
    //explicit_initialise_value_cast(
    //    ct_quantity<
    //        Source_NamedAbstractQuantity,
    //        Source_unit,
    //        Source_value_type
    //    >const & source_pq)
    //{   
    //    pqs::concept_checking::function_requires<
    //        CompatibleQuantityWarningConcept<
    //            typename Target_pq::named_abstract_quantity_type,
    //            Source_NamedAbstractQuantity
    //        >
    //    >(); 

    //    typedef  typename detail::value_cast_traits<
    //           typename Target_pq::value_type,
    //           // Source_value_type,
    //            typename Target_pq::units_type,
    //            Source_value_type,
    //            Source_unit
    //    > value_cast_traits;
    // 
    //    return explicit_initialise<typename Target_pq::value_type>(
    //        typename value_cast_traits::eval()( source_pq() ) );
    //}


    template <
        typename Target_pq,
        typename Source_NamedAbstractQuantity,
        typename Source_unit,
        typename Source_value_type
    > 
    inline 
    typename Target_pq::value_type     
    implicit_assign_value_cast(
        ct_quantity<
            Source_NamedAbstractQuantity,
            Source_unit,
            Source_value_type
        >const & source_pq)
    {   
        pqs::concept_checking::function_requires<
            CompatibleQuantityWarningConcept<
                typename Target_pq::named_abstract_quantity_type,
                Source_NamedAbstractQuantity
            >
        >(); 

        typedef  typename detail::value_cast_traits<
                typename Target_pq::value_type,
                typename Target_pq::units_type,
                Source_value_type,
                Source_unit
        > value_cast_traits;
     
        return pqs::detail::implicit_assign<typename Target_pq::value_type>(
            typename value_cast_traits::eval()( source_pq.numeric_value() ) );
    }

}}//pqs::detail

#endif
