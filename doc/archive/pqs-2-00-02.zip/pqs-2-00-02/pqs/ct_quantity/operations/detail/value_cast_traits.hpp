#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_OPERATIONS_VALUE_CAST_IMPL_HPP_INCLUDED
#define PQS_OPERATIONS_VALUE_CAST_IMPL_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/ct_quantity/operations/detail/quantity_conversion_traits.hpp"
 
namespace pqs {namespace detail{

    template<
        typename ValueCastTraits,
        bool Incoh, bool Delog,bool PosAlg
    >
    struct value_cast_traits_fx;
    
    template <
        typename Target_value_type,
        typename Target_unit,
        typename Source_value_type,
        typename Source_unit

    > struct value_cast_traits{
        
        typedef quantity_conversion_traits<
            Target_value_type,
            Target_unit,
            Source_value_type,
            Source_unit
        > conversion_traits;
        typedef typename conversion_traits::source_value_type source_value_type;
        typedef typename conversion_traits::min_in_arith_value_type min_in_arith_value_type;

        typedef typename conversion_traits::promoted_difference_divide_working_type numeric_working_type;
        
        typedef typename conversion_traits::incoherent_divide_fx incoherent_divide_fx;
        typedef typename conversion_traits::abs_difference_delog_fx abs_difference_delog_fx;
        typedef typename conversion_traits::first_difference_exponent first_difference_exponent;
      
        typedef Target_value_type result_type;
        struct eval : value_cast_traits_fx<
                    value_cast_traits,
                    incoherent_divide_fx::required,
                    abs_difference_delog_fx::required,
                    first_difference_exponent::is_positive
        >{};
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required  == true;
    //abs_difference_delog_fx::required              == true;
    //use_positive_alg                == true;
    template<typename ValueCastTraits>
    struct value_cast_traits_fx <ValueCastTraits,true, true, true>{
    
        typename ValueCastTraits::result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_pq_val)const
        {
            return typename ValueCastTraits::incoherent_divide_fx()() 
            * typename ValueCastTraits::abs_difference_delog_fx()() * source_pq_val;
        }
    };
    
    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == true
    //abs_difference_delog_fx::required ==true;
    //use_positive_alg ==false
    template<typename ValueCastTraits>
    struct value_cast_traits_fx <ValueCastTraits,true, true, false>{
    
        typename ValueCastTraits::result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_pq_val)const
        {
            return typename ValueCastTraits::incoherent_divide_fx()() 
            / typename ValueCastTraits::abs_difference_delog_fx()() * source_pq_val;
        }
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == true
    //abs_difference_delog_fx::required ==false;
    //use_positive_alg  == dont_care
    template<typename ValueCastTraits,bool X>
    struct value_cast_traits_fx <ValueCastTraits,true, false, X>{
    
        typename ValueCastTraits::result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_pq_val)const
        {
            return typename ValueCastTraits::incoherent_divide_fx()() * source_pq_val ;
        }
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == false
    //abs_difference_delog_fx::required ==true;
    //use_positive_alg == true
    template<typename ValueCastTraits>
    struct value_cast_traits_fx <ValueCastTraits,false, true, true>{
    
        typename ValueCastTraits::result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_pq_val)const
        {
            return  source_pq_val 
            * typename ValueCastTraits::abs_difference_delog_fx()();
        }
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == false
    //abs_difference_delog_fx::required ==true;
    //use_positive_alg == false
    template<typename ValueCastTraits>
    struct value_cast_traits_fx <ValueCastTraits,false, true, false>{
    
        typename ValueCastTraits::result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_pq_val)const
        {
            return    source_pq_val / typename ValueCastTraits::abs_difference_delog_fx()(); 
        }
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == false
    //abs_difference_delog_fx::required ==false;
    //use_positive_alg == dont_care
    template<typename ValueCastTraits,bool X>
    struct value_cast_traits_fx <ValueCastTraits,false, false, X>{
    
        typename ValueCastTraits::result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_pq_val)const
        {
            return    source_pq_val;
        }
    };



}}//pqs::detail


#endif
