#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_DIV_HPP_INCLUDED2911030401
#define PQS_CLASS_TEMPLATE_DIV_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    division of ct-quantities
*/

#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/ct_quantity/operations/generic_binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"
//#include "pqs/meta/promotion_traits.hpp"
#include "pqs/ct_quantity/operations/scalar_divide.hpp"
//#include "pqs/ct_quantity/operations/detail/incoherent_mx.hpp"
//#include "pqs/ct_quantity/operations/detail/dimensionless_divide.hpp"
#include "pqs/ct_quantity/operations/detail/dimensioned_divide.hpp"
#include "pqs/dimensional_analysis/concept_checking.hpp"
#include "pqs/ct_quantity/operations/detail/dimensionless_divide.hpp"

namespace pqs{

    //dimensionless result
    template< 
        template <typename, typename> class NamedAbstractQuantity,
        typename AnonymousAbstractQuantity,
        typename TagA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename TagB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        Value_typeA,
        std::divides,
        Value_typeB
    >::result_type
    operator / ( 
        ct_quantity<
            NamedAbstractQuantity<
                AnonymousAbstractQuantity,
                TagA
            >,
            QuantityUnitA,
            Value_typeA
        > const & pqa,
        ct_quantity<
           NamedAbstractQuantity<
                AnonymousAbstractQuantity,
                TagB
            >,
            QuantityUnitB,
            Value_typeB
        > const & pqb )
    {
         concept_checking::function_requires<
            CompatibleQuantityWarningConcept<
                 NamedAbstractQuantity<
                    AnonymousAbstractQuantity,
                    TagA
                 >,
                 NamedAbstractQuantity<
                    AnonymousAbstractQuantity,
                    TagB
                 >
            >
         >();
         typename meta::binary_operation< 
            Value_typeA,
            std::divides,
            Value_typeB
        >::result_type t
        = typename detail::dimensionless_divide_traits<
            Value_typeA,
            QuantityUnitA,
            Value_typeB,
            QuantityUnitB
        >::eval()(pqa.numeric_value(),pqb.numeric_value()); 
        return t;
    }
    
    //dimensioned result
    template< 
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >,
        std::divides,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >
    >::result_type
    operator / ( 
        ct_quantity<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        > const & pqa,
        ct_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        > const & pqb )
    {
        typename meta::binary_operation<
            ct_quantity<
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >,
            std::divides,
            ct_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        >::result_type t
        = typename detail::dimensioned_divide<
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA,
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >::eval()(pqa,pqb);
        return t;
    }
        
}//pqs

#endif
