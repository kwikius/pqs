#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_GENERIC_BINARY_OPERATION_HPP_INCLUDED
#define PHYSICAL_QUANTITIES_GENERIC_BINARY_OPERATION_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
   generic binary_operations on ct_quantities
   Note other specialisations are used per op
*/

#include "pqs/operators/binary_operators.hpp"
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"
#include "pqs/meta/unary_operation.hpp"

namespace pqs{ namespace meta{

    template <
        template <typename> class Op,
        typename NamedAbstractQuantity,
        typename Units,
        typename Value_type
    >
    struct unary_operation<
        Op,
        ct_quantity<
            NamedAbstractQuantity,
            Units,
            Value_type
        >
    >{
        typedef ct_quantity<
            typename unary_operation<
                Op,
                NamedAbstractQuantity
            >::result_type,
            typename unary_operation<
                Op,
                Units
            >::result_type,
            typename unary_operation<
                Op,
                Value_type
            >::result_type
        > result_type;
    };

    template < 
        typename NamedAbstractQuantityA,
        typename UnitsA,
        typename Value_typeA,
        template <typename> class Op,
        typename NamedAbstractQuantityB,
        typename UnitsB,
        typename Value_typeB
    >
    struct binary_operation<
        ct_quantity<
            NamedAbstractQuantityA,
            UnitsA,
            Value_typeA
        >,
        Op,
        ct_quantity<
            NamedAbstractQuantityB, 
            UnitsB,
            Value_typeB
        >,
        typename boost::disable_if<
            boost::mpl::or_<
                boost::mpl::or_<
                    pqs::is_conditional_operator<Op>,
                    pqs::is_equality_operator<Op>,
                    pqs::is_relational_operator<Op>
                >,
                boost::mpl::or_<
                    pqs::is_logical_or_operator<Op>,
                    pqs::is_logical_and_operator<Op>,
                    pqs::is_assignment_operator<Op>
                >
            >
        >::type
    >{
        typedef typename ct_quantity<
            typename binary_operation<
                NamedAbstractQuantityA,
                Op,
                NamedAbstractQuantityB
            >::result_type,
            typename binary_operation<
                UnitsA,Op,UnitsB
            >::result_type,
            typename binary_operation<
                Value_typeA,
                Op,
                Value_typeB
            >::result_type
        >::type result_type;
    };
            
}}//pqs::meta

#endif
