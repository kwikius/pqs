#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_OPERATIONS_MORPH_HPP_INCLUDED
#define PQS_OPERATIONS_MORPH_HPP_INCLUDED

/*
    morph SourceType into TargetType
    ie for converting (say) force to length in graphics
    set scale in morph ctor
    use as a functor
*/

#include "pqs/meta/binary_operation.hpp"

namespace pqs{ 

    template<
        typename TargetType, 
        typename SourceType
    >
    struct morph{
        typedef TargetType target_type;
        typedef SourceType source_type;
        typedef typename pqs::meta::binary_operation<
                TargetType,
                std::divides,
                SourceType
        >::result_type intermediate_type;
        /*typedef typename pqs::meta::to_value_type<
            intermediate_type
        >::type intermediate_type_value_type;*/
        morph():scale(1){}
        template<typename Value_type1>
        explicit morph(Value_type1 const & scale_in )
        :scale(static_cast<intermediate_type>(scale_in)){}
        TargetType operator()(SourceType const& in)
        {
            TargetType t = in * scale;
            return t;
        }

    private:
        const intermediate_type scale;
    };
}

#endif
