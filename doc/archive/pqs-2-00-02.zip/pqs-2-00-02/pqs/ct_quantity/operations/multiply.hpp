#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_MUL_HPP_INCLUDED2911030401
#define PQS_CLASS_TEMPLATE_MUL_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    multiply two ct-quantities
*/

#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/ct_quantity/operations/scalar_multiply.hpp"
//#include "pqs/meta/associated_arithmetic.hpp"
#include "pqs/ct_quantity/operations/generic_binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"
//#include "pqs/ct_quantity/operations/detail/incoherent_mx.hpp"
//#include "pqs/ct_quantity/operations/detail/dimensionless_multiply.hpp"
#include "pqs/ct_quantity/operations/detail/dimensioned_multiply.hpp"
#include "pqs/dimensional_analysis/concept_checking.hpp"
#include "pqs/ct_quantity/operations/detail/dimensionless_multiply.hpp"

namespace pqs{
    template< 
        template<typename ,typename> class NamedAbstractQuantity,
        typename Abstract_pq,
        typename TagA,
        typename UnitsA,
        typename Value_typeA,
        typename TagB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        Value_typeA,
        std::multiplies,
        Value_typeB
    >::result_type
    operator *( 
        ct_quantity<
            NamedAbstractQuantity<
                Abstract_pq,
                TagA
            >,
            UnitsA,
            Value_typeA
        > const & pqa,
        ct_quantity<
            NamedAbstractQuantity<
                typename meta::unary_operation<
                    reciprocal,
                    Abstract_pq
                >::result_type,
                TagB
            >,
            UnitsB,
            Value_typeB
        > const & pqb )
    {
        typename pqs::meta::binary_operation<
            Value_typeA,
            std::multiplies,
            Value_typeB
        >::result_type t
        = typename detail::dimensionless_multiply_traits<
                Value_typeA,
                UnitsA,
                Value_typeB,
                UnitsB
            >::eval()(pqa.numeric_value(),pqb.numeric_value());
        return t;      
    }
    
////////////non dimensionless//////////////////////////
    template< 
        typename NamedAbstractQuantityA,
        typename UnitsA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
            ct_quantity<
                NamedAbstractQuantityA,
                UnitsA,
                Value_typeA
            >,
            std::multiplies,
            ct_quantity<
                NamedAbstractQuantityB,
                UnitsB,
                Value_typeB
            >
    >::result_type
    operator * ( 
        ct_quantity<
            NamedAbstractQuantityA,
            UnitsA,
            Value_typeA
        > const & pqa ,
        ct_quantity<
            NamedAbstractQuantityB,
            UnitsB,
            Value_typeB
        > const & pqb )
        {
            typedef ct_quantity<
                NamedAbstractQuantityA,
                UnitsA,
                Value_typeA
            > pqA_type;
            typedef ct_quantity<
                NamedAbstractQuantityB,
                UnitsB,
                Value_typeB
            > pqB_type;
            typename meta::binary_operation<
                pqA_type,
                std::multiplies,
                pqB_type
            >::result_type t 
            = typename detail::dimensioned_multiply<
                 NamedAbstractQuantityA,
                 UnitsA,
                Value_typeA,
                NamedAbstractQuantityB,
                UnitsB,
                Value_typeB
            >::eval()(pqa,pqb);
            return t;
          
        }
}//pqs

#endif
