#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITY_CLASS_TEMPLATE_POWER_ROOT_HPP_INCLUDED2911030401
#define PHYSICAL_QUANTITY_CLASS_TEMPLATE_POWER_ROOT_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    power and root functions for inbuilts and ct-quantities
    for inbuilts pow<N>(v) to bring in to line with
*/

#include <cmath>
#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/ct_quantity/quantity_unit.hpp"
#include "pqs/operators/binary_operators.hpp"
#include "pqs/meta/unary_operation.hpp"
#include "pqs/meta/rational_c.hpp"
#include "pqs/meta/min_type.hpp"
#include "pqs/ct_quantity/detail/coherent_quantity.hpp"
#include "pqs/concepts/concept_checking.hpp"

namespace pqs{namespace meta{
 
    template <
        typename IntegerType,
        long N,
        long D,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    struct binary_operation<
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        pqs::to_power,
        pqs::meta::rational_c<IntegerType,N,D>  
    >{
        typedef  typename pqs::meta::rational_c<
            IntegerType,N,D
        >::type exponent_type;
         
        typedef typename ct_quantity <
            typename binary_operation<
                NamedAbstractQuantity,
                to_power,
                exponent_type
            >::result_type,
            typename binary_operation<
                 QuantityUnit,
                 to_power,
                 exponent_type
            >::result_type,
            typename meta::binary_operation<
                Value_type,
                to_power,
                exponent_type
            >::result_type
        >::type result_type;
    };

}}//pqs::meta

namespace pqs{

    template<int N> struct deduced_int{};
    template<int N, int D> struct deduced_fraction{};

    template <
        int N,
        typename T
    >
    inline 
    typename pqs::meta::binary_operation_if<
        boost::is_arithmetic<T>,
        T,
        pqs::to_power,
        pqs::meta::rational_c<int,N,1>
    >::result_type
    pow(T const& v)
    {
        typedef  typename pqs::meta::binary_operation<
            T,
            pqs::to_power,
            pqs::meta::rational_c<int,N,1>
        >::result_type result_type;
        return std::pow(static_cast<result_type>(v),N);
    }

    template <
        int N,
        int D,
        typename T
    >
    inline
    typename pqs::meta::binary_operation_if<
        boost::is_arithmetic<T>,
        T,
        pqs::to_power,
        pqs::meta::rational_c<int,N,D>        
    >::result_type
    pow(T const& v)
    {
        typedef typename meta::binary_operation<
            T,
            pqs::to_power,
            pqs::meta::rational_c<int,N,D>        
        >::result_type result_type;
        typedef typename meta::rational_c<int,N,D>::eval eval;
        
        return std::pow(static_cast<result_type>( v ),eval()());
    }

    template <
        int N,
        int D,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename pqs::meta::binary_operation<
        pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        to_power,
        meta::rational_c<int,N,D>
    >::result_type
    pow(
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const & pq )
    {   //scale to coherent temporary version
        typedef typename pqs::detail::transform_coherent<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >::type coherent_pq;
        coherent_pq t(pq);
        typedef typename meta::rational_c<int,N,D>::type exponent_type;
        typedef typename meta::binary_operation<
            coherent_pq,
            to_power,
            exponent_type
        >::result_type result_type;
         return result_type( pow<N,D>(t.numeric_value()));
    }

    template <
        int N,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename ::pqs::meta::binary_operation<
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        ::pqs::to_power,
        typename meta::rational_c<int,N,1>
    >::result_type
    pow(
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const & pq )
    {   
        return pow<N,1>(pq);
    }


//root
    template <
        int N,
        int D,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename meta::binary_operation<
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        to_power,
        meta::rational_c<int,D,N>
    >::result_type
    root(ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const & pq )
    {   
        return pow<D,N>(pq);
    }

//root
    template <
        int N,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename meta::binary_operation<
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        to_power,
        meta::rational_c<int,1,N>
    >::result_type
    root(ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const & pq )
    {   
        return pow<1,N>(pq);
    }

    template <
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename meta::binary_operation<
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        to_power,
        meta::rational_c<int,1,2>
    >::result_type
    sqrt(ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        > const & pq )
    {   
        return pow<1,2>(pq);
    }

    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    template<
        int N, int D
    >
    inline
    typename pqs::meta::binary_operation<
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        pqs::to_power,
        pqs::meta::rational_c<int,N,D>
    >::result_type
    ct_quantity<
        NamedAbstractQuantity,
        QuantityUnit,
        Value_type
    >::pow()const
    {
        return pqs::pow<
            N,D,
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >(*this);
    }

    //template<
    //    typename NamedAbstractQuantity,
    //    typename QuantityUnit,
    //    typename Value_type
    //>
    //template<
    //    int N
    //>
    //inline
    //typename pqs::meta::binary_operation_if_c<
    //    (N !=0),
    //    ct_quantity<
    //        NamedAbstractQuantity,
    //        QuantityUnit,
    //        Value_type
    //    >,
    //    pqs::to_power,
    //    pqs::meta::rational_c<int,N,1>
    //>::result_type
    //ct_quantity<
    //    NamedAbstractQuantity,
    //    QuantityUnit,
    //    Value_type
    //>::pow()const
    //{
    //    return pqs::pow<
    //        N,1,
    //        NamedAbstractQuantity,
    //        QuantityUnit,
    //        Value_type
    //    >(*this);
    //}

    template<
        int N, 
        int D, 
        typename T, 
        template<int,int> class Exponent
    >
    inline 
    typename pqs::meta::binary_operation<
            T,
            pqs::to_power,
            pqs::meta::rational_c<int,N,D>
    >::result_type
    pow(T const & t, Exponent<N,D>)
    {
        return pow<N,D>(t);
    }

    template<
        int N,
        typename T, 
        template<int> class Exponent
    >
    inline 
    typename pqs::meta::binary_operation<
            T,
            pqs::to_power,
            pqs::meta::rational_c<int,N,1>
    >::result_type
    pow(T const & t, Exponent<N>)
    {
        return pow<N,1>(t);
    }
    
   
}//pqs

#endif

