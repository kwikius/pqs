#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITY_CLASS_TEMPLATE_SCALAR_DIV_HPP_INCLUDED2911030401
#define PHYSICAL_QUANTITY_CLASS_TEMPLATE_SCALAR_DIV_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    division of ct-quantity by numeric
*/

#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/operators/binary_operators.hpp"
#include "pqs/meta/binary_operation_if.hpp"
#include "pqs/type_traits/is_ct_quantity_value_type.hpp"
#include "pqs/meta/is_valid_binary_operation.hpp"
#include "boost/utility/enable_if.hpp"
#include "boost/mpl/and.hpp"

namespace pqs{namespace meta{
    //value_type / pq
    template<
        typename Value_type1,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    struct binary_operation<
        Value_type1,
        std::divides,
        pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::type_traits::is_ct_quantity_value_type<Value_type1>,
                pqs::meta::is_valid_binary_operation<
                    Value_type1,std::divides,Value_type
                >
            >
        >::type
        
    >{
        typedef typename ::pqs::ct_quantity<
            typename ::pqs::meta::unary_operation<
                reciprocal,
                NamedAbstractQuantity
            >::result_type,
            typename ::pqs::meta::unary_operation<
                reciprocal,
                QuantityUnit
            >::result_type,
            typename ::pqs::meta::binary_operation<
                Value_type1,
                std::divides,
                Value_type
            >::result_type
        > result_type;
     };   

    //pq / value_type
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename Value_type1
    >
    struct binary_operation<
        typename ::pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        std::divides,
        Value_type1,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::type_traits::is_ct_quantity_value_type<Value_type1>,
                pqs::meta::is_valid_binary_operation<
                    Value_type,std::divides,Value_type1
                >
            >
        >::type
    >{
        typedef typename ::pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            typename ::pqs::meta::binary_operation<
                Value_type,std::divides,Value_type1
            >::result_type
        > result_type;
     };
         
}}//pqs::meta

namespace pqs{

    //scalar / PQ 
    template<
        typename Value_type1,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type 
    >
    inline 
    typename ::pqs::meta::binary_operation_if<
        ::pqs::type_traits::is_ct_quantity_value_type<Value_type1>,
        Value_type1,
        std::divides,
        ::pqs::ct_quantity<
            NamedAbstractQuantity,
            typename ::pqs::detail::transform_coherent<
                QuantityUnit
            >::type,
            Value_type
        >
    >::result_type
    operator / (
        Value_type1 const & v,
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & pq)
    {   
        typedef ct_quantity<
            NamedAbstractQuantity,
            typename pqs::detail::transform_coherent<
                QuantityUnit
            >::type,
            Value_type
        >coherent_type;
        coherent_type coh(pq);
            
        return typename meta::binary_operation<
            Value_type1,
            std::divides,
            ct_quantity<
                NamedAbstractQuantity,
                typename pqs::detail::transform_coherent<
                    QuantityUnit
                >::type,
                Value_type
            >
        >::result_type(v/coh.numeric_value() );
    }

    // PQ / scalar
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename Value_type1
    >
    inline 
    typename meta::binary_operation_if<
        type_traits::is_ct_quantity_value_type<Value_type1>,
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        std::divides,
        Value_type1
    >::result_type
    operator / (
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & pq,
        Value_type1 const& v)
    {
        typename meta::binary_operation<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >,
            std::divides,
            Value_type1
        >::result_type t(pq.numeric_value() / v);
        return t;
    }

}//pqs
#endif
