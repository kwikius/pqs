#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_SCALAR_MUL_HPP_INCLUDED2911030401
#define PQS_CLASS_TEMPLATE_SCALAR_MUL_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    multiply ct-quantity by numeric
*/

#include "pqs/ct_quantity/ct_quantity.hpp"
#include "pqs/operators/binary_operators.hpp"
#include "pqs/meta/binary_operation_if.hpp"
#include "pqs/type_traits/is_ct_quantity_value_type.hpp"
#include "pqs/meta/is_valid_binary_operation.hpp"
#include "boost/utility/enable_if.hpp"
#include "boost/mpl/and.hpp"

namespace pqs{namespace meta{

    //pq * value_type
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename Value_type1
    >
    struct binary_operation<
        pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        std::multiplies,
        Value_type1,
        typename boost::enable_if<
            boost::mpl::and_<
                type_traits::is_ct_quantity_value_type<Value_type1>,
                pqs::meta::is_valid_binary_operation<
                    Value_type,std::multiplies,Value_type1
                >
            >
        >::type
    >{
        typedef typename pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            typename binary_operation<
                Value_type,
                std::multiplies,
                Value_type1
            >::result_type
        > result_type;
     };

    //value_type * pq
    template<
            typename Value_type1,
            typename NamedAbstractQuantity,
            typename QuantityUnit,
            typename Value_type
    >
    struct binary_operation<
        Value_type1,
        std::multiplies,
        typename pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        typename boost::enable_if<
            boost::mpl::and_<
                type_traits::is_ct_quantity_value_type<Value_type1>,
                pqs::meta::is_valid_binary_operation<
                    Value_type1,std::multiplies,Value_type
                >
            >
        >::type
    >{
        typedef typename pqs::ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            typename binary_operation<
                Value_type1,
                std::multiplies,
                Value_type
            >::result_type
        > result_type;
     };            

}}//pqs::meta

namespace pqs{
    // PQ * scalar generic
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename Value_type1
    >
    inline 
    typename meta::binary_operation_if<
        type_traits::is_ct_quantity_value_type<Value_type1>,
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        std::multiplies,
        Value_type1
    >::result_type   
    operator *( 
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & pq,
        Value_type1 const& v)
    {
       typename meta::binary_operation<
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >,
            std::multiplies,
            Value_type1
        >::result_type t( pq.numeric_value() * v );
        return t;
    }

    //scalar * PQ 
    template<
        typename Value_type1,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename ::pqs::meta::binary_operation_if< 
        type_traits::is_ct_quantity_value_type<Value_type1>,
        Value_type1,
        std::multiplies,
        ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    >::result_type   
    operator * ( Value_type1 const & v,
                ct_quantity<
                    NamedAbstractQuantity,
                    QuantityUnit,
                    Value_type
                >const & pq)
    {
        typename meta::binary_operation<
            Value_type1,
            std::multiplies,
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >::result_type t( v * pq.numeric_value());
        return t;
    }

}//pqs

#endif
