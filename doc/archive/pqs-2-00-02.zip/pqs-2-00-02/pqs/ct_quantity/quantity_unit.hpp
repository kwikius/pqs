#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_QUANTITY_UNIT_HPP_INCLUDED
#define PQS_QUANTITY_UNIT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    quantity_unit combines the coherent-exponent 
    and incoherent-multiplier to provide a 
    common type for coherent and incoherent quantities,
    Tag diistinguishes corner cases
    QuantityUnit Concept
*/

#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"
#include "pqs/ct_quantity/quantity_unit/detail/quantity_unit_detail.hpp"
#include "pqs/meta/binary_log_transform.hpp"
#include "pqs/ct_quantity/detail/transform_coherent.hpp"
#include "pqs/meta/rational_c.hpp"

namespace pqs{

    template <
        typename CoherentExponent  
        = pqs::coherent_exponent<0,1>,
        typename IncoherentMultiplier     
        =   pqs::incoherent_multiplier<
                pqs::of_quantity::incoherent_multiplier_scale
            >,
        typename QuantityUnitTag = pqs::quantity_unit_tag<0> 
    >
    struct quantity_unit{
        typedef typename CoherentExponent::type    coherent_exponent_type;
        typedef IncoherentMultiplier               incoherent_multiplier_type;
        typedef QuantityUnitTag                    tag_type;
        typedef quantity_unit                      type;        
    };

    namespace detail{
        template<
            typename CoherentExponent,
            typename IncoherentMultiplier,
            typename QuantityUnitTag
        >
        struct transform_coherent<
            pqs::quantity_unit<
                CoherentExponent,
                IncoherentMultiplier,
                QuantityUnitTag
            >
        >{
            typedef pqs::quantity_unit<
                CoherentExponent
            > type;
        };
    }//detail
     
}//pqs
/*
    binary_operations on quantity_units
*/
namespace pqs{ namespace meta{

    template<
        typename CoherentExponentA,
        typename IncoherentMultiplierA,
        typename QuantityUnitTagA,
        typename CoherentExponentB,
        typename IncoherentMultiplierB,
        typename QuantityUnitTagB
    >
    struct binary_operation<
        pqs::quantity_unit<
            CoherentExponentA,
            IncoherentMultiplierA,
            QuantityUnitTagA
        >,
        std::plus,
        pqs::quantity_unit<
            CoherentExponentB,
            IncoherentMultiplierB,
            QuantityUnitTagB
        >
    >{
        typedef typename pqs::detail::binary_operation_plus_minus<
            CoherentExponentA,
            IncoherentMultiplierA,
            QuantityUnitTagA,
            CoherentExponentB,
            IncoherentMultiplierB,
            QuantityUnitTagB
        >::type result_type;
    };
    
    template<
        typename CoherentExponentA,
        typename IncoherentMultiplierA,
        typename QuantityUnitTagA,
        typename CoherentExponentB,
        typename IncoherentMultiplierB,
        typename QuantityUnitTagB
    >
    struct binary_operation<
        pqs::quantity_unit<
            CoherentExponentA,
            IncoherentMultiplierA,
            QuantityUnitTagA
        >,
        std::minus,
        pqs::quantity_unit<
            CoherentExponentB,
            IncoherentMultiplierB,
            QuantityUnitTagB
        >
    >{
        typedef typename pqs::detail::binary_operation_plus_minus<
            CoherentExponentA,
            IncoherentMultiplierA,
            QuantityUnitTagA,
            CoherentExponentB,
            IncoherentMultiplierB,
            QuantityUnitTagB
        >::type result_type;
    };

    template <
        typename CoherentExponent,
        typename IncoherentMultiplier,
        typename QuantityUnitTag,
        int N,
        int D
    >
    struct binary_operation<
        pqs::quantity_unit<
            CoherentExponent,
            IncoherentMultiplier,
            QuantityUnitTag
        >,
        pqs::to_power,
        pqs::meta::rational_c<int, N, D>
    >{
        typedef typename  pqs::meta::rational_c<int, N, D>::type rat;
        typedef pqs::quantity_unit<
             typename binary_operation<
                CoherentExponent,
                std::multiplies,
                rat
            >::result_type
         > result_type;
    };

    template <
        typename CoherentExponent,
        typename IncoherentMultiplier,
        typename QuantityUnitTag
    >
    struct binary_operation<
        pqs::quantity_unit<
            CoherentExponent,
            IncoherentMultiplier,
            QuantityUnitTag
        >,
        pqs::to_power,
        pqs::meta::rational_c<int, 1,1>
    >{
        typedef pqs::quantity_unit<
            CoherentExponent,  
            IncoherentMultiplier,
            QuantityUnitTag
         > result_type;
    };

    template<
        typename CoherentExponentA,
        typename IncoherentMultiplierA,
        typename QuantityUnitTagA,
        template <typename> class Op,
        typename CoherentExponentB,
        typename IncoherentMultiplierB,
        typename QuantityUnitTagB
    >
    struct binary_operation<
        pqs::quantity_unit<
            CoherentExponentA,
            IncoherentMultiplierA,
            QuantityUnitTagA
        >,
        Op,
        pqs::quantity_unit<
            CoherentExponentB,
            IncoherentMultiplierB,
            QuantityUnitTagB
        >
    >{
       typedef pqs::quantity_unit<
            typename pqs::meta::binary_log_transform<
                CoherentExponentA,
                Op,
                CoherentExponentB
            >::result_type
        > result_type;      
    };

//unary reciprocal
    template <
        typename CoherentExponent,
        typename IncoherentMultiplier,
        typename QuantityUnitTag
    >
    struct unary_operation<
        pqs::reciprocal,
        pqs::quantity_unit<
            CoherentExponent,
            IncoherentMultiplier,
            QuantityUnitTag
        >
    >{
        typedef typename pqs::quantity_unit<
            typename pqs::meta::unary_operation<
                std::negate,
                CoherentExponent
            >::result_type
        >::type result_type;
    };   
    
}
}//pqs::meta

#endif
