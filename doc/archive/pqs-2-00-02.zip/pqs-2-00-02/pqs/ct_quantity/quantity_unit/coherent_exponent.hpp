#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_COHERENT_EXPONENT_HPP_INCLUDED
#define PQS_COHERENT_EXPONENT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    the coherent exponent represents the exponent 
    of the unit of a coherent quantity.
    e.g kilometers has a coherent exponent of 3.
    Rational exponents are also valid.
    The is_integer and is_positive are used 
    to determine how to best optimise when evaluating.
    IOW where possible an int result_type is returned.
*/

#include "pqs/meta/rational_c.hpp"
#include "pqs/ct_quantity/quantity_unit/detail/coherent_exponent_eval.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"
#include "pqs/ct_quantity/of_quantity.hpp"

namespace pqs{namespace concept_checking{
    // used to check that a coherent-exponent is computable
    namespace detail {
         template< int Expnume, int Expdenom>
         struct  CoherentExponentInRangeImpl{
            enum{ value 
            = (( (Expdenom == 1 ) 
            &&(Expnume >= pqs::of_quantity::min_int_coherent_exponent) 
            && (Expnume <= pqs::of_quantity::max_int_coherent_exponent)) 
                || ((Expnume <= pqs::of_quantity::max_rat_coherent_exponent * Expdenom)
                && (Expnume >= pqs::of_quantity::min_rat_coherent_exponent * Expdenom)) )
            };
         };

    }// detail

      template< int Expnume, int Expdenom>
    ////////////////////////////////////////////////////////
     struct AssertCoherentExponentInRange
    ///////////////////////////////////////////////////////
     // Assertion fails if the coherent-exponent in a quantity_unit 
    // is too big or too small to be evaluated
    : Assert < (detail::CoherentExponentInRangeImpl<Expnume,Expdenom>::value)>{};
}}//pqs::concept_checking

namespace pqs{

    template <int N, int D=1>
    struct coherent_exponent 
    {
        typedef typename    meta::rational_c<int,N,D>::type base_type;
        enum{
            numerator = base_type::numerator,
            denominator = base_type::denominator,
            is_integer = ( denominator == 1 ),
            is_positive = ( numerator >= 0 ),
            is_zero  = ( numerator == 0)
        };
        typedef coherent_exponent<0,1> zero_type; 

        template<
            typename ResultType
        >
        struct eval 
        // check in range of eval functions
        : concept_checking::AssertCoherentExponentInRange< numerator , denominator>
        ,  detail::coherent_exponent_eval<
            ResultType,
            numerator,
            denominator,
            (is_positive 
            && is_integer 
            && (((is_positive ) ? numerator : -numerator) 
                            <= of_quantity::max_int_exponent))
        >{};
        
        typedef coherent_exponent<
            numerator,
            denominator
        > type; 
    };
    
/* 
    finest_grained struct is used 
    in addition or subtraction of two 
    dimensionally similar physical-quantities.
    the one with the finest grained units 
    is selected for the result_type
    e.g mm would be selected over m
*/
    namespace detail{

        template<typename A, typename B>
        struct finest_grained{
            enum{ a_finer =
            (((A::coherent_exponent_type::numerator 
            * B::coherent_exponent_type::denominator)<
             (B::coherent_exponent_type::numerator 
            * A::coherent_exponent_type::denominator)) 
            ||
            ((A::coherent_exponent_type::numerator 
            * B::coherent_exponent_type::denominator)==
             (B::coherent_exponent_type::numerator 
            * A::coherent_exponent_type::denominator) 
            && (A::incoherent_multiplier_type::value 
                <= B::incoherent_multiplier_type::value))) };
            
            typedef typename boost::mpl::if_c<
                a_finer,
                A,
                B
            >::type type;

        };

    }// detail
}//pqs

/*
    binary_operations on coherent_exponents
    (at other layers because they represent powers 
    the binary_log_transform metafunction is used
    ie multiplication becomes addition etc.
    Here howver add means add etc
*/
namespace pqs{ namespace meta {

    template<
        int N1,
        int D1,
        template <typename> class Op,
        int N2,
        int D2
    > 
    struct binary_operation<
        coherent_exponent<N1,D1>,
        Op,
        coherent_exponent<N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<int,N1,D1>::type,
            Op,
            typename rational_c<int,N2,D2>::type
        >::result_type base_type;
    public:
        typedef coherent_exponent<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

   template<
        int N1,
        int D1,
        template <typename> class Op,
        typename RatValueType,
        int N2,
        int D2
    > 
    struct binary_operation<
        coherent_exponent<N1,D1>,
        Op,
        rational_c<RatValueType,N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<int,N1,D1>::type,
            Op,
            typename rational_c<int,N2,D2>::type
        >::result_type base_type;
    public:
        typedef coherent_exponent<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

    template<
        typename Rat_Value_type,
        int N1,
        int D1,
        template <typename> class Op,
        int N2,
        int D2
    > 
    struct binary_operation<
        rational_c<Rat_Value_type,N1,D1>,
        Op,
        coherent_exponent<N2,D2> 
    >{ 
    private:
        typedef typename binary_operation<
            typename rational_c<
                int,N1,D1
            >::type,
            Op,
            typename rational_c<int,N2,D2>::type
        >::result_type base_type;
    public:
        typedef coherent_exponent<
            base_type::numerator,
            base_type::denominator
        > result_type;
    };

    template<
        int N,
        int D
    >
    struct unary_operation<
        std::negate,
        coherent_exponent<N,D>
    >{
        typedef typename coherent_exponent<-N,D>::type result_type;
    };
        
}}//pqs::meta

 
#endif
