#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_DETAIL_COHERENT_EXPONENT_EVAL_INCLUDED
#define PQS_DETAIL_COHERENT_EXPONENT_EVAL_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    functors to evaluate the value of a coherent-exponent
*/

#include "pqs/meta/ice_binary_operator.hpp"
#include "pqs/ct_quantity/of_quantity.hpp"
#include "pqs/meta/min_type.hpp"
#include <cmath>

namespace pqs{ namespace detail{

        // default  instantiated for any non-integer exponent
        // wants Arithmetic Type ??
        template <typename ResultType,int N, int D, bool WantInt>
        struct coherent_exponent_eval{

            enum{ required = true};
            typedef float min_result_type;
            typedef typename pqs::of_quantity::min_real<
                min_result_type
            >::type result_type;
            result_type operator()()const 
            {
                return std::pow(static_cast<result_type>(10),static_cast<result_type>(N)/D);
            }

        };

        // instantiated for very large/small integer powers but not used
        // really requires a mod
        template <typename ResultType,int N, bool WantInt>
        struct coherent_exponent_eval<
            ResultType,N,1, WantInt
        >{
            enum{ required = true};
            typedef void min_result_type;
            typedef void result_type;
            result_type operator()()const ;
        };

        template<typename ResultType,int N>
        struct coherent_exponent_eval<ResultType,N,1,true>{
            enum{ required = ( N !=0 ) };
            typedef int min_result_type;
            typedef typename meta::int_promote<ResultType>::type result_type;
            result_type operator()()const 
            {
                return static_cast<result_type>(
                    pqs::meta::ice_binary_operator<
                    int,pqs::of_quantity::exponent_base,pqs::to_power,int,N
                    >::result_value);
            }
        };

       template <>
       struct coherent_exponent_eval<double,-60,1,false>{
           enum{ required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-60;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-59,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-59;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-58,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-58;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-57,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-57;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-56,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-56;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-55,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-55;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-54,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-54;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-53,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-53;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-52,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-52;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-51,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-51;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-50,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-50;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-49,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-49;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-48,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-48;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-47,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-47;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-46,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-46;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-45,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-45;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-44,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-44;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-43,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-43;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-42,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-42;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-41,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-41;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-40,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-40;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-39,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-39;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-38,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-38;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-37,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-37;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-37,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-37f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-36,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-36;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-36,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-36f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-35,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-35;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-35,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-35f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-34,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-34;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-34,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-34f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-33,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-33;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-33,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-33f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-32,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-32;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-32,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-32f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-31,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-31;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-31,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-31f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-30,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-30;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-30,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-30f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-29,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-29;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-29,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-29f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-28,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-28;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-28,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-28f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-27,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-27;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-27,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-27f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-26,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-26;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-26,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-26f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-25,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-25;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-25,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-25f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-24,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-24;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-24,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-24f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-23,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-23;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-23,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-23f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-22,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-22;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-22,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-22f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-21,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-21;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-21,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-21f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-20,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-20;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-20,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-20f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-19,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-19;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-19,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-19f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-18,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-18;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-18,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-18f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-17,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-17;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-17,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-17f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-16,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-16;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-16,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-16f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-15,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-15;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-15,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-15f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-14,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-14;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-14,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-14f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-13,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-13;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-13,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-13f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-12,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-12;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-12,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-12f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-11,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-11;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-11,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-11f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-10,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-10;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-10,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-10f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-9,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-9;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-9,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-9f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,-8,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-8;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-8,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-8f;
           }
       };

      template <>
       struct coherent_exponent_eval<int,-8,1,false>{
           enum{required = true};
           typedef float min_result_type;
           //  typedef float result_type;
           typedef pqs::of_quantity::min_real<
                min_result_type
           >::type result_type;
           result_type operator()()const 
           {
                return coherent_exponent_eval<result_type,-8,1,false>()();
           }
       };

       template <>
       struct coherent_exponent_eval<double,-7,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-7;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-7,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-7f;
           }
       };

      template <>
       struct coherent_exponent_eval<int,-7,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef pqs::of_quantity::min_real<
                min_result_type
           >::type result_type;
           //typedef float result_type;
           result_type operator()()const 
           {
               return coherent_exponent_eval<result_type,-7,1,false>()();
           }
       };

       template <>
       struct coherent_exponent_eval<double,-6,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-6;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-6,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-6f;
           }
       };

      template <>
       struct coherent_exponent_eval<int,-6,1,false>{
           enum{required = true};
           typedef float min_result_type;
           // typedef float result_type;
           typedef pqs::of_quantity::min_real<
                min_result_type
            >::type result_type;
           result_type operator()()const 
           {
                return coherent_exponent_eval<result_type,-6,1,false>()();
           }
       };

       template <>
       struct coherent_exponent_eval<double,-5,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-5;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-5,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-5f;
           }
       };

      template <>
       struct coherent_exponent_eval<int,-5,1,false>{
           enum{required = true};
           typedef float min_result_type;
           //  typedef float result_type;
           typedef pqs::of_quantity::min_real<
               min_result_type
           >::type result_type;
           result_type operator()()const 
           {
                return coherent_exponent_eval<result_type,-5,1,false>()();
           }
       };

       template <>
       struct coherent_exponent_eval<double,-4,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-4;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-4,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-4f;
           }
       };

      template <>
       struct coherent_exponent_eval<int,-4,1,false>{
           enum{required = true};
           typedef float min_result_type;
           //  typedef float result_type;
           typedef pqs::of_quantity::min_real<
                min_result_type
           >::type result_type;
           result_type operator()()const 
           {
                return coherent_exponent_eval<result_type,-4,1,false>()();
           }
       };

       template <>
       struct coherent_exponent_eval<double,-3,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-3;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-3,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-3f;
           }
       };

      template <>
       struct coherent_exponent_eval<int,-3,1,false>{
           enum{required = true};
           typedef float min_result_type;
           //typedef float result_type;
           typedef pqs::of_quantity::min_real<
                min_result_type
           >::type result_type;
           result_type operator()()const 
           {
             return coherent_exponent_eval<result_type,-3,1,false>()();
           }
       };

       template <>
       struct coherent_exponent_eval<double,-2,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-2;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-2,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-2f;
           }
       };

      template <>
       struct coherent_exponent_eval<int,-2,1,false>{
           enum{required = true};
           typedef float min_result_type;
          // typedef float result_type;
           typedef pqs::of_quantity::min_real<
                min_result_type
           >::type result_type;
           result_type operator()()const 
           {
                return coherent_exponent_eval<result_type,-2,1,false>()();
           }
       };

       template <>
       struct coherent_exponent_eval<double,-1,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e-1;
           }
       };

       template <>
       struct coherent_exponent_eval<float,-1,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e-1f;
           }
       };

      template <>
       struct coherent_exponent_eval<int,-1,1,false>{
           enum{required = true};
           typedef float min_result_type;
          // typedef float result_type;
           typedef pqs::of_quantity::min_real<
                min_result_type
           >::type result_type;
           result_type operator()()const 
           {
               return coherent_exponent_eval<result_type,-1,1,false>()();
           }
       };

       template <>
       struct coherent_exponent_eval<double,0,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e0;
           }
       };

       template <>
       struct coherent_exponent_eval<float,0,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e0f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,1,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e1;
           }
       };

       template <>
       struct coherent_exponent_eval<float,1,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e1f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,2,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e2;
           }
       };

       template <>
       struct coherent_exponent_eval<float,2,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e2f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,3,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e3;
           }
       };

       template <>
       struct coherent_exponent_eval<float,3,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e3f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,4,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e4;
           }
       };

       template <>
       struct coherent_exponent_eval<float,4,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e4f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,5,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e5;
           }
       };

       template <>
       struct coherent_exponent_eval<float,5,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e5f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,6,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e6;
           }
       };

       template <>
       struct coherent_exponent_eval<float,6,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e6f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,7,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e7;
           }
       };

       template <>
       struct coherent_exponent_eval<float,7,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e7f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,8,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e8;
           }
       };

       template <>
       struct coherent_exponent_eval<float,8,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e8f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,9,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e9;
           }
       };

       template <>
       struct coherent_exponent_eval<float,9,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e9f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,10,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e10;
           }
       };

       template <>
       struct coherent_exponent_eval<float,10,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e10f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,11,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e11;
           }
       };

       template <>
       struct coherent_exponent_eval<float,11,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e11f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,12,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e12;
           }
       };

       template <>
       struct coherent_exponent_eval<float,12,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e12f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,13,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e13;
           }
       };

       template <>
       struct coherent_exponent_eval<float,13,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e13f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,14,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e14;
           }
       };

       template <>
       struct coherent_exponent_eval<float,14,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e14f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,15,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e15;
           }
       };

       template <>
       struct coherent_exponent_eval<float,15,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e15f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,16,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e16;
           }
       };

       template <>
       struct coherent_exponent_eval<float,16,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e16f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,17,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e17;
           }
       };

       template <>
       struct coherent_exponent_eval<float,17,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e17f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,18,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e18;
           }
       };

       template <>
       struct coherent_exponent_eval<float,18,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e18f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,19,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e19;
           }
       };

       template <>
       struct coherent_exponent_eval<float,19,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e19f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,20,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e20;
           }
       };

       template <>
       struct coherent_exponent_eval<float,20,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e20f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,21,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e21;
           }
       };

       template <>
       struct coherent_exponent_eval<float,21,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e21f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,22,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e22;
           }
       };

       template <>
       struct coherent_exponent_eval<float,22,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e22f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,23,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e23;
           }
       };

       template <>
       struct coherent_exponent_eval<float,23,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e23f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,24,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e24;
           }
       };

       template <>
       struct coherent_exponent_eval<float,24,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e24f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,25,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e25;
           }
       };

       template <>
       struct coherent_exponent_eval<float,25,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e25f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,26,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e26;
           }
       };

       template <>
       struct coherent_exponent_eval<float,26,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e26f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,27,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e27;
           }
       };

       template <>
       struct coherent_exponent_eval<float,27,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e27f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,28,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e28;
           }
       };

       template <>
       struct coherent_exponent_eval<float,28,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e28f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,29,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e29;
           }
       };

       template <>
       struct coherent_exponent_eval<float,29,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e29f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,30,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e30;
           }
       };

       template <>
       struct coherent_exponent_eval<float,30,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e30f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,31,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e31;
           }
       };

       template <>
       struct coherent_exponent_eval<float,31,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e31f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,32,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e32;
           }
       };

       template <>
       struct coherent_exponent_eval<float,32,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e32f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,33,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e33;
           }
       };

       template <>
       struct coherent_exponent_eval<float,33,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e33f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,34,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e34;
           }
       };

       template <>
       struct coherent_exponent_eval<float,34,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e34f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,35,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e35;
           }
       };

       template <>
       struct coherent_exponent_eval<float,35,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e35f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,36,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e36;
           }
       };

       template <>
       struct coherent_exponent_eval<float,36,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e36f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,37,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e37;
           }
       };

       template <>
       struct coherent_exponent_eval<float,37,1,false>{
           enum{required = true};
           typedef float min_result_type;
           typedef float result_type;
           result_type operator()()const 
           {
               return  1e37f;
           }
       };

       template <>
       struct coherent_exponent_eval<double,38,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e38;
           }
       };

       template <>
       struct coherent_exponent_eval<double,39,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e39;
           }
       };

       template <>
       struct coherent_exponent_eval<double,40,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e40;
           }
       };

       template <>
       struct coherent_exponent_eval<double,41,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e41;
           }
       };

       template <>
       struct coherent_exponent_eval<double,42,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e42;
           }
       };

       template <>
       struct coherent_exponent_eval<double,43,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e43;
           }
       };

       template <>
       struct coherent_exponent_eval<double,44,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e44;
           }
       };

       template <>
       struct coherent_exponent_eval<double,45,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e45;
           }
       };

       template <>
       struct coherent_exponent_eval<double,46,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e46;
           }
       };

       template <>
       struct coherent_exponent_eval<double,47,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e47;
           }
       };

       template <>
       struct coherent_exponent_eval<double,48,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e48;
           }
       };

       template <>
       struct coherent_exponent_eval<double,49,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e49;
           }
       };

       template <>
       struct coherent_exponent_eval<double,50,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e50;
           }
       };

       template <>
       struct coherent_exponent_eval<double,51,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e51;
           }
       };

       template <>
       struct coherent_exponent_eval<double,52,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e52;
           }
       };

       template <>
       struct coherent_exponent_eval<double,53,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e53;
           }
       };

       template <>
       struct coherent_exponent_eval<double,54,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e54;
           }
       };

       template <>
       struct coherent_exponent_eval<double,55,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e55;
           }
       };

       template <>
       struct coherent_exponent_eval<double,56,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e56;
           }
       };

       template <>
       struct coherent_exponent_eval<double,57,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e57;
           }
       };

       template <>
       struct coherent_exponent_eval<double,58,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e58;
           }
       };

       template <>
       struct coherent_exponent_eval<double,59,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e59;
           }
       };

       template <>
       struct coherent_exponent_eval<double,60,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e60;
           }
       };
       
       template <>
       struct coherent_exponent_eval<double,61,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e61;
           }
       };

       template <>
       struct coherent_exponent_eval<double,62,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e62;
           }
       };

       template <>
       struct coherent_exponent_eval<double,63,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e63;
           }
       };

       template <>
       struct coherent_exponent_eval<double,64,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e64;
           }
       };

       template <>
       struct coherent_exponent_eval<double,65,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e65;
           }
       };

       template <>
       struct coherent_exponent_eval<double,66,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e66;
           }
       };

       template <>
       struct coherent_exponent_eval<double,67,1,false>{
           enum{required = true};
           typedef double min_result_type;
           typedef double result_type;
           result_type operator()()const 
           {
               return  1e67;
           }
       };

}}//pqs::detail

#endif

