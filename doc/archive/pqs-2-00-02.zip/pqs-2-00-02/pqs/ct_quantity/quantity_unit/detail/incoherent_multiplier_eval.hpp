#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_UNITS_INCOHERENT_MULTIPLIER_EVAL_HPP_INCLUDED
#define PQS_UNITS_INCOHERENT_MULTIPLIER_EVAL_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    functors to evaluate the incoherent multiplier of a quantity unit
*/

#include "pqs/ct_quantity/of_quantity.hpp"
#include "pqs/meta/min_type.hpp"

namespace pqs{namespace detail{

    template<typename ResultType, long Value>
    struct incoherent_multiplier_eval{
        enum{required = true};
        typedef float min_result_type;
        typedef typename of_quantity::min_real<
            ResultType
        >::type result_type;
        result_type operator()()const throw()
        {
           return  static_cast<result_type>(Value)
            / of_quantity::incoherent_multiplier_scale; 
        }
    };

    template<typename ResultType>
    struct incoherent_multiplier_eval<
            ResultType,
            of_quantity::incoherent_multiplier_scale
    >{
        enum{ required = false};
        typedef int min_result_type;
        typedef typename meta::int_promote<
            ResultType
        >::type result_type;
        result_type operator()()const throw()
        {
           return static_cast<result_type>(1L); 
        }
    };
    


}}//pqs::detail

#endif
