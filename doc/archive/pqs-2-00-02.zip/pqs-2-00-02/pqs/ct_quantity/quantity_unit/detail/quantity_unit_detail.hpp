#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_QUANTITY_UNIT_DETAIL_HPP_INCLUDED
#define PQS_QUANTITY_UNIT_DETAIL_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    resulting units for addition/subtraction of two ct_quantities 
*/

#include "boost/mpl/if.hpp"
#include "pqs/ct_quantity/of_quantity.hpp"
#include "pqs/ct_quantity/quantity_unit/quantity_unit_tag.hpp"
#include "pqs/ct_quantity/quantity_unit/incoherent_multiplier.hpp"
#include "pqs/ct_quantity/quantity_unit/coherent_exponent.hpp"
#include "pqs/ct_quantity/quantity_unit_fwd.hpp"

namespace pqs{ namespace detail{

    template<
        typename Coherent_exponentA,
        typename IncoherentMultiplierA,
        typename QuantityUnitTagA,
        typename Coherent_exponentB,
        typename IncoherentMultiplierB,
        typename QuantityUnitTagB
    >
    struct binary_operation_plus_minus{
       
        typedef typename finest_grained< 
                quantity_unit<
                    Coherent_exponentA,
                    IncoherentMultiplierA,
                    QuantityUnitTagA
                >,
                quantity_unit<
                    Coherent_exponentB,
                    IncoherentMultiplierB,
                    QuantityUnitTagB 
                >
        >::type finest_grained_type;

        typedef typename finest_grained_type::coherent_exponent_type coherent_exponent_type;
        
        typedef quantity_unit<
            coherent_exponent_type,
            incoherent_multiplier<>,
            quantity_unit_tag<0>
        > coherent_type;

        typedef typename boost::mpl::if_c<
        // add check for incoh !!
          ( (IncoherentMultiplierA::value == static_cast<int>(of_quantity::incoherent_multiplier_scale)) 
            && (QuantityUnitTagA::value ==0) )
            || ((IncoherentMultiplierB::value == static_cast<int>(of_quantity::incoherent_multiplier_scale))
            && (QuantityUnitTagB::value ==0)),
            coherent_type,
            finest_grained_type
        >::type type;  

     }; 
 
}}//pqs::detail

#endif
