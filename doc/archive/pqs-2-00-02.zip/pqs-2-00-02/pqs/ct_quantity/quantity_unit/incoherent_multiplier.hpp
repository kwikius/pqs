#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_INCOHERENT_MULTIPLIER_HPP_INCLUDED
#define PQS_INCOHERENT_MULTIPLIER_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    represents the incoherent-multiplier 
    for units of a physical-quantity
*/

#include "pqs/ct_quantity/of_quantity.hpp"
#include "detail/incoherent_multiplier_eval.hpp"

namespace pqs{

    template< long Value = of_quantity::incoherent_multiplier_scale >
    struct incoherent_multiplier{
        enum{ value = Value};
        typedef incoherent_multiplier<Value>    type;
        typedef incoherent_multiplier<
            of_quantity::incoherent_multiplier_scale
        > one_type;
        template<typename ResultType>
        struct eval : detail::incoherent_multiplier_eval<
            ResultType,
            value
        >{};    
    };

}//pqs

#endif
