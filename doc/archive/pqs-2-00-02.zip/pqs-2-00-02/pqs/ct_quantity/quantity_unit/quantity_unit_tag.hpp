#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_AUXILIARY_TAG_HPP_INCLUDED
#define PHYSICAL_QUANTITIES_AUXILIARY_TAG_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    tag for distinguishing quantity_units
*/

namespace pqs{

    template< int Output_id =0>
    struct quantity_unit_tag{
        enum {value = Output_id};
        typedef quantity_unit_tag       type;
        
    };

}//pqs


#endif
