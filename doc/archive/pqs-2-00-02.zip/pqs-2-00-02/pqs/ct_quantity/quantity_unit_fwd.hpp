#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_QUANTITY_UNIT_FWD_HPP_INCLUDED
#define PQS_QUANTITY_UNIT_FWD_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    forward declaration of quantity_unit
*/

namespace pqs{

    template <
        typename Coherent_exponent,
        typename Incoherent_mux,
        typename Tag
    >
    struct quantity_unit;

}//pqs

#endif
