#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_TAGGED_BINARY_OPERATION_HPP_INCLUDED
#define PQS_META_TAGGED_BINARY_OPERATION_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    binary_operation with tag facility for use with ct_quantities
    to make non-anonymous ct_quantity types by division etc
*/

#include "pqs/meta/binary_operation.hpp"
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"

namespace pqs{
    
    namespace detail{

        template <
            typename L, 
            template<typename>class Op,
            typename R, 
            int QuantityUnitTag 
        >
        struct tagged_binary_operation_impl{
            
            typedef typename pqs::meta::binary_operation<
                L,Op,R
            >::result_type basic_type;

            typedef typename pqs::ct_quantity<
                pqs::named_abstract_quantity<
                    typename basic_type::
                        named_abstract_quantity_type::
                            anonymous_abstract_quantity_type,
                    pqs::named_quantity_tag<QuantityUnitTag>
                >,
                typename basic_type::units_type,
                typename basic_type::value_type
            >::type result_type;         
        }; 


    }//detail

    template <
        typename L, 
        template<typename>class Op,
        typename R, 
        int QuantityUnitTag = 1
    >
    struct tagged_binary_operation{
       typedef typename pqs::detail::tagged_binary_operation_impl<
            L,Op,R,QuantityUnitTag
       >::result_type result_type;
    };

}//pqs

#endif
