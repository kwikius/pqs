#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_AREA_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_AREA_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_area.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct area_ : of_area{
    private:
        friend void detail::dummy_friend_function();
        area_();
        area_(area_ const&);
        area_ operator =(area_ const &);
    public:
        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-48>
            >,
            Value_type
        > ym2;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-42>
            >,
            Value_type
        > zm2;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-36>
            >,
            Value_type
        > am2;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-30>
            >,
            Value_type
        > fm2;

        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > pm2;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > nm2;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > um2;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > mm2;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-4>
            >,
            Value_type
        > cm2;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > dm2;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > m2;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > dam2;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<4>
            >,
            Value_type
        > hm2;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > km2;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > Mm2;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > Gm2;

        typedef ct_quantity<
            type,
            typename si_unit::yotta, // coherent-exponent 24
            Value_type
        > Tm2;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<30>
            >,
            Value_type
        > Pm2;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<36>
            >,
            Value_type
        > Em2;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<42>
            >,
            Value_type
        > Zm2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::acre,
            Value_type
        > acre;

        typedef ct_quantity<
            type,
            typename incoherent_unit::a,
            Value_type
        > a;

        typedef ct_quantity<
            type,
            typename incoherent_unit::b,
            Value_type
        > b;

        typedef ct_quantity<
            type,
            typename incoherent_unit::circular_mil,
            Value_type
        > circular_mil;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ha,
            Value_type
        > ha;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ft2,
            Value_type
        > ft2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::in2,
            Value_type
        > in2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::mi2,
            Value_type
        > mi2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::mi2_us_survey,
            Value_type
        > mi2_us_survey;

        typedef ct_quantity<
            type,
            typename incoherent_unit::yd2,
            Value_type
        > yd2;

    };

    struct area : area_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        area();
        area( area const&);
        area operator =(area const &);
    };

}//pqs

#endif
