#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CT_QUANTITY_ADHUSTED_COHERENT_OUTPUT_PREFIX_UNITS_HPP_INCLUDED
#define PQS_CT_QUANTITY_ADHUSTED_COHERENT_OUTPUT_PREFIX_UNITS_HPP_INCLUDED

#include "pqs/ct_quantity/types/components/of_named_quantity_for.hpp"
#include "pqs/ct_quantity/named_abstract_quantity.hpp"
#include "pqs/ct_quantity/quantity_unit_fwd.hpp"
#include "boost/type_traits/is_same.hpp"
#include "boost/mpl/void.hpp"
#include "pqs/concepts/concept_checking.hpp"

namespace pqs{
/*
   adjusts the prefix for types such as mass, area etc
    dependent on the values in the OfNamedQuantityComponents Concept
    for getting the correct si prefix for output
*/
    template <
        typename AbstractQuantity, 
        typename QuantityUnit,
        typename Enable = void
    >
    struct adjusted_coherent_prefix;

    template <
        typename AbstractQuantity, 
        typename QuantityUnit
    >
    struct adjusted_coherent_prefix<
        AbstractQuantity,
        QuantityUnit,
        typename boost::disable_if<
            pqs::is_named_abstract_quantity<AbstractQuantity>
        >::type
    >
    {
        typedef  void type ;//QuantityUnit type;
    };

    // specialised for named-abstract_quantity,quantity_units combo
    // note assumes that the
    // of_named_quantity_for meta-function
    // has been specialised  
 

    template<
        typename AbstractQuantity,
        typename CoherentExponent,
        typename IncoherentMultiplier,
        typename QuantityUnitTag
    >
    struct adjusted_coherent_prefix<
        AbstractQuantity,
        pqs::quantity_unit<
            CoherentExponent,
            IncoherentMultiplier,
            QuantityUnitTag
        >,
        typename boost::enable_if<
                pqs::is_named_abstract_quantity<AbstractQuantity>    
        >::type
    >
    {
        // get OfNamedQuantityComponents concept
        typedef typename pqs::of_named_quantity_for<
            AbstractQuantity
        > of_type;
    /////////////////// CONCEPT CHECK ///////////////////////////
    // You may arrive here if you have created a named ct-quantity
    // without a (correct) specialisation of
    // pqs::of_named_quantity_for
    // to access its OfNamedQuantityComponents concept.
    // The unspecialised version has a member 'type of boost::mpl::void_
    // see the "pqs/ct_quantity/components/of_xxx.hpp" headers
    // And docs/Concepts/OfNamedQuantityComponents for more details
        pqs::concept_checking::Assert<
        (
            (boost::is_same<of_type,boost::mpl::void_>::value == false)
            && CoherentExponent::is_integer
            && ((CoherentExponent::numerator % of_type::extent) == 0)  
        )
        > assert_valid_OfNamedQuantityComponentsConcept;
    ///////////CONCEPT_CHECK///////////////////////////
        enum{ 
          /*  valid_prefix = ((CoherentExponent::is_integer)
                && ((CoherentExponent::numerator % of_type::extent) == 0)),*/
            adjusted_numerator
            = (CoherentExponent::numerator / of_type::extent)
                + of_type::prefix_offset
        };
        typedef pqs::quantity_unit<
            coherent_exponent<
                adjusted_numerator
            >
         > type;
        /*typedef typename boost::mpl::if_c<
            valid_prefix,
            pqs::quantity_unit<
                coherent_exponent<
                    adjusted_numerator
                >
            >,
            void 
        >::type  type;*/
    };

}//pqs


#endif
