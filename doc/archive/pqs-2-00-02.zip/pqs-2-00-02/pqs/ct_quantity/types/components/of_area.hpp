#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_AREA_MX_HPP_INCLUDED2911030401
#define PQS_AREA_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_area{
    private:
        friend void detail::dummy_friend_function();
        of_area();
        of_area( of_area const&);
        of_area operator = ( of_area const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "area";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 2,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<2>,
            time_pwr<0>,
            mass_pwr<0>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<4046873>
            > acre;

            typedef quantity_unit<
                coherent_exponent<2>,
                incoherent_multiplier<1000000>,
                quantity_unit_tag<1>
            > a;

            typedef quantity_unit<
                coherent_exponent<-28>,
                incoherent_multiplier<1000000>,
                quantity_unit_tag<1>
            > b;

            typedef quantity_unit<
                coherent_exponent<-10>,
                incoherent_multiplier<5067075>
            > circular_mil;

            typedef quantity_unit<
                coherent_exponent<4>,
                incoherent_multiplier<1000000>,
                quantity_unit_tag<1>
            > ha;

            typedef quantity_unit<
                coherent_exponent<-2>,
                incoherent_multiplier<9290304>
            > ft2;

            typedef quantity_unit<
                coherent_exponent<-4>,
                incoherent_multiplier<6451600>
            > in2;

            typedef quantity_unit<
                coherent_exponent<6>,
                incoherent_multiplier<2589988>
            > mi2;

            typedef quantity_unit<
                coherent_exponent<6>,
                incoherent_multiplier<2589998>
            > mi2_us_survey;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<8361274>
            > yd2;

        };
        typedef  of_area of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_area::unprefixed_symbol<char>()
    {
        return "m2";
    }

    //The following enables use of of_area data
    //as a traits class for abstract quantity area
    template <>
    struct of_named_quantity_for<
        of_area::type
    > : of_area{};


}//pqs

#endif

