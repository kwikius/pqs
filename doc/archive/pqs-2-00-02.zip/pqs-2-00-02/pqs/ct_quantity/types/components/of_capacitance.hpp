#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CAPACITANCE_MX_HPP_INCLUDED2911030401
#define PQS_CAPACITANCE_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_capacitance{
    private:
        friend void detail::dummy_friend_function();
        of_capacitance();
        of_capacitance( of_capacitance const&);
        of_capacitance operator = ( of_capacitance const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "capacitance";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<-2>,
            time_pwr<4>,
            mass_pwr<-1>,
            temperature_pwr<0>,
            current_pwr<2>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

        };
        typedef  of_capacitance of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_capacitance::unprefixed_symbol<char>()
    {
        return "F";
    }

    //The following enables use of of_capacitance data
    //as a traits class for abstract quantity capacitance
    template <>
    struct of_named_quantity_for<
        of_capacitance::type
    > : of_capacitance{};


}//pqs

#endif

