#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CHARGE_MX_HPP_INCLUDED2911030401
#define PQS_CHARGE_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_charge{
    private:
        friend void detail::dummy_friend_function();
        of_charge();
        of_charge( of_charge const&);
        of_charge operator = ( of_charge const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "charge";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<0>,
            time_pwr<1>,
            mass_pwr<0>,
            temperature_pwr<0>,
            current_pwr<1>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<3600000>
            > A_h;

        };
        typedef  of_charge of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_charge::unprefixed_symbol<char>()
    {
        return "C";
    }

    //The following enables use of of_charge data
    //as a traits class for abstract quantity charge
    template <>
    struct of_named_quantity_for<
        of_charge::type
    > : of_charge{};


}//pqs

#endif

