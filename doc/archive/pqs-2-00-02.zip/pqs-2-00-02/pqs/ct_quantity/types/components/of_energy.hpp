#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_ENERGY_MX_HPP_INCLUDED2911030401
#define PQS_ENERGY_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_energy{
    private:
        friend void detail::dummy_friend_function();
        of_energy();
        of_energy( of_energy const&);
        of_energy operator = ( of_energy const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "energy";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<2>,
            time_pwr<-2>,
            mass_pwr<1>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

        };
        typedef  of_energy of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_energy::unprefixed_symbol<char>()
    {
        return "J";
    }

    //The following enables use of of_energy data
    //as a traits class for abstract quantity energy
    template <>
    struct of_named_quantity_for<
        of_energy::type
    > : of_energy{};


}//pqs

#endif

