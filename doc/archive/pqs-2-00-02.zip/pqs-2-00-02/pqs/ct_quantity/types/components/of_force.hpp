#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_FORCE_MX_HPP_INCLUDED2911030401
#define PQS_FORCE_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_force{
    private:
        friend void detail::dummy_friend_function();
        of_force();
        of_force( of_force const&);
        of_force operator = ( of_force const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "force";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<1>,
            time_pwr<-2>,
            mass_pwr<1>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<-5>,
                incoherent_multiplier<1000000>,
                quantity_unit_tag<1>
            > dyn;

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<9806650>
            > kgf;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<4448222>
            > kip;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<2780139>
            > ozf;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<1382550>
            > poundal;

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<4482222>
            > lbf;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<8896443>
            > ton_force;

        };
        typedef  of_force of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_force::unprefixed_symbol<char>()
    {
        return "N";
    }

    //The following enables use of of_force data
    //as a traits class for abstract quantity force
    template <>
    struct of_named_quantity_for<
        of_force::type
    > : of_force{};


}//pqs

#endif

