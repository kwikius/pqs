#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_LENGTH_MX_HPP_INCLUDED2911030401
#define PQS_LENGTH_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_length{
    private:
        friend void detail::dummy_friend_function();
        of_length();
        of_length( of_length const&);
        of_length operator = ( of_length const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "length";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<1>,
            time_pwr<0>,
            mass_pwr<0>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<1828804>
            > fathom_us;

            typedef quantity_unit<
                coherent_exponent<11>,
                incoherent_multiplier<1495979>
            > AU;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<2011684>
            > ch;

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<1828800>
            > fathom;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<3048000>
            > ft;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<3048006>
            > ft_us;

            typedef quantity_unit<
                coherent_exponent<-2>,
                incoherent_multiplier<2540000>
            > in;

            typedef quantity_unit<
                coherent_exponent<15>,
                incoherent_multiplier<9460730>
            > l_y_;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1609344>
            > mi;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1852000>
            > naut_mile;

            typedef quantity_unit<
                coherent_exponent<16>,
                incoherent_multiplier<3085678>
            > pc;

            typedef quantity_unit<
                coherent_exponent<-3>,
                incoherent_multiplier<4233333>
            > pica_comp;

            typedef quantity_unit<
                coherent_exponent<-3>,
                incoherent_multiplier<4217518>
            > pica_prn;

            typedef quantity_unit<
                coherent_exponent<-4>,
                incoherent_multiplier<3527778>
            > point_comp;

            typedef quantity_unit<
                coherent_exponent<-4>,
                incoherent_multiplier<3514598>
            > point_prn;

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<5029210>
            > rd;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<9144000>
            > yd;

        };
        typedef  of_length of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_length::unprefixed_symbol<char>()
    {
        return "m";
    }

    //The following enables use of of_length data
    //as a traits class for abstract quantity length
    template <>
    struct of_named_quantity_for<
        of_length::type
    > : of_length{};


}//pqs

#endif

