#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_MASS_MX_HPP_INCLUDED2911030401
#define PQS_MASS_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_mass{
    private:
        friend void detail::dummy_friend_function();
        of_mass();
        of_mass( of_mass const&);
        of_mass operator = ( of_mass const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "mass";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 3
        };

        typedef anonymous_abstract_quantity<
            length_pwr<0>,
            time_pwr<0>,
            mass_pwr<1>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<-2>,
                incoherent_multiplier<2916667>
            > AT;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1016047>
            > ton_long;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1000000>,
                quantity_unit_tag<1>
            > t;

            typedef quantity_unit<
                coherent_exponent<-4>,
                incoherent_multiplier<2000000>
            > carat;

            typedef quantity_unit<
                coherent_exponent<-5>,
                incoherent_multiplier<6479891>
            > grain;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<5080235>
            > hundredwgt_short;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<4535924>
            > hundredwgt_long;

            typedef quantity_unit<
                coherent_exponent<-2>,
                incoherent_multiplier<2834952>
            > oz;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<3110348>
            > troy_oz;

            typedef quantity_unit<
                coherent_exponent<-3>,
                incoherent_multiplier<1555174>
            > dwt;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<4535924>
            > lb;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<3732417>
            > troy_lb;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<1459390>
            > slug;

        };
        typedef  of_mass of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_mass::unprefixed_symbol<char>()
    {
        return "g";
    }

    //The following enables use of of_mass data
    //as a traits class for abstract quantity mass
    template <>
    struct of_named_quantity_for<
        of_mass::type
    > : of_mass{};


}//pqs

#endif

