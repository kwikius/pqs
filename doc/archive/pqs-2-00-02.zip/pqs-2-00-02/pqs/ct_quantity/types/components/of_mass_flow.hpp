#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    this TEMPLATE header is designed for 
    Specialising the OfNamedQuantity Concept
    Its one of a set of three
    The other two are 
     "pqs/types/NamedQuantityScopeTEMPLATE.hpp"
     "pqs/types/NamedQuantityOutTEMPLATE.hpp" 

    Compare with other similar headers with the of_ prefix in this directory for
    examples of actual use.

*/
/////////////////////////////////////////
//rename the include quard
#ifndef PQS_OF_MASS_FLOW_MX_HPP_INCLUDED
#define PQS_OF_MASS_FLOW_MX_HPP_INCLUDED
//////////////////////////////////////////

// this include is always required 
#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{
// the of_ struct is just a useful container for constituent parts 
// of a set of ct-quantities with a similar named-abstract-quantity
// It is designed to follow a standard format for all ct-quantities
   struct of_mass_flow{
    
        //function meant for returning the name rather 
        //than symbol of the named-abstract-quantity
        static const char* abstract_quantity_name()
        {
            return "mass_flow";
        }

        // the unprefixed coherent symbol for output
        //This is used for output of the default (SI)
        //name for the quantity ie for length it would be "m".
        //Note for mass it would be "g" not "kg", because the
        //prefix is resolved using the prefix_offset below
        // requires explicit specialisation below the of_ struct definition
        template<typename CharType>
        static const CharType* unprefixed_symbol();
       
        enum{
        //examples
        // length has an extent of 1, 
        // area has an extent of 2,
        // volume has an extent of 3
        //ie usually only !=1 where the quantity is comprised
        //of 1 non-zero prime-dimension
        //It is used to calculate the output units from the coherent-exponent.
        //Usually  1
            extent = 1, // usually 1

        //The prefix offset is used for
        //quantities such as mass and density which
        //are expressed in kg as a base-unit rather than g etc
        //e.g for mass this value == 3;
        //usually 0
            prefix_offset = 3 //usually 0
        }; 

        // replace the ??? for the powers of dimension of the
        // named-abstract-quantity
        // note trailing XX_pwr<???> params default to XX_pwr<0> so can be omitted
        typedef anonymous_abstract_quantity<
            length_pwr<0>,
            time_pwr<-1>,
            mass_pwr<1>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type; // the name
       // should not be changed from 'anonymous_abstract_quantity_type'

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type, // ok as above
        // The named_quantity_tag is used to distinguish dimensionally-equivalent
        // but different named-abstract-quantities and also
        // to mark anonymous-abstract-quantities in which case it has a value of 0
        // Hence it should not be 0 here. If there are no clashes with dimensionally
        // equivalent quantities then a value of 1 is fine.
            named_quantity_tag<1> 
        > type; // the typedef name should not be changed from 'type'

        // this member struct is used to describe incoherent-units
        struct incoherent_unit{

        //    typedef quantity_unit<
        //    //The coherent exponent is actually a rational number 
        //    //but generally speaking the denominator(second int parameter)
        //    //will be one and will default to 1 if omitted. (rational exponents
        //    //only usually arise when taking odd powers of a quantity)
        //    //The numerator represents the power of the base-unit
        //    //So for example to represent  a pressure in atmospheres
        //    //which has an exponent of 5 compared to Pa in si terms
        //    //The numerator value here would be 5.  
        //    coherent_exponent<???numerator???>,

        //    //The incoherent_multiplier represents the numeric value
        //    //of the scaling to a coherent quantity (at the power of
        //    //the coherent exponent), but multiplied by 1000000
        //    //Hence for a pressure in atmospheres which has an
        //    //incoherent-multiplier of 1.013250
        //    //the value in here would be 1013250
        //    //Note that the value must be somewhere in the range of
        //    //1,000,00 to 10,000,000. If its not the
        //    //coherent exponent value can be adjusted to bring it into
        //    //this range
        //    incoherent_multiplier<???>, 

        //    //This tag_type is used to resolve clashes
        //    //when two quantity units have the same values
        //    //but actually represent different units for output.
        //    //If the quantity unit is unique in this named-abstract-quantity
        //    //it can be left to default to 0
        //    quantity_unit_tag<???> 
        //    > ??? ; //put here programmatic name for the incoherent-unit
        //    // not critical but conveniently named as for the
        //    // actual programmatic extension ie atm for atmosphere etc

        ///*
        //    ...

        //    Add  more incoherent units in above style as required 
        //    ....
        //*/

        }; // end of incoherent_unit struct

   }; // end of of_mass_flow struct

    //explicit specialisation for char
    // eg for masss would be "g", for length "m" etc
    template<>
    inline
    const char*
    of_mass_flow::unprefixed_symbol<char>()
    {
        return "g.ms-1";
    }
   // required to provide a common access to the
   // OfNamedQuantity concept
   // for this named_abstract_quantity.
   // Also required for stream output of coherent-quantities.
   // of_mass_flow is base class
   // which 'forwards it members to this class-template
   template <>
   struct of_named_quantity_for<
      of_mass_flow::type
    > : of_mass_flow {};


}//pqs

#endif

