#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
#ifndef PQS_CT_QUANTITY_COMPONENTS_OF_NAMED_QUANTITY_HPP_INCLUDED
#define PQS_CT_QUANTITY_COMPONENTS_OF_NAMED_QUANTITY_HPP_INCLUDED
// pqs-2-00-02,Sep 26 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    common include for headers reqd by OfNamedQuantityComponents concept
    eg the of_xxx structs
*/

#include "pqs/ct_quantity/of_quantity.hpp"
#include "pqs/detail/dummy_friend_function.hpp"
#include "pqs/ct_quantity/named_abstract_quantity.hpp"
#include "pqs/ct_quantity/quantity_unit.hpp"
#include "pqs/ct_quantity/types/components/of_named_quantity_for.hpp"
#include "pqs/ct_quantity/types/components/adjusted_coherent_prefix.hpp"

#endif
