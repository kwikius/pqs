
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CT_QUANTITY_OF_NAMED_QUANTITY_COMPONENTS_HPP_INCLUDED
#define PQS_CT_QUANTITY_OF_NAMED_QUANTITY_COMPONENTS_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/ct_quantity/types/components/of_named_quantity_for_fwd.hpp"
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"
#include "boost/mpl/void.hpp"

/*
    required to be specialised for 
    each OfNamedAbstractQuantity Concept
*/

namespace pqs{

    template <
        typename NamedAbstractQuantity   
    >
    struct of_named_quantity_for{
        typedef boost::mpl::void_ type;
    };

    // to get at the OfNamedQuantity via ct_quantity
    // will fail on anonymous type
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    struct of_named_quantity_for<
       ct_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    > : of_named_quantity_for<
          NamedAbstractQuantity 
    >::of_type{};
        
}//pqs

#endif
