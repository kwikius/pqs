#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CT_QUANTITY_OF_NAMED_QUANTITY_COMPONENTS_FWD_HPP_INCLUDED
#define PQS_CT_QUANTITY_OF_NAMED_QUANTITY_COMPONENTS_FWD_HPP_INCLUDED

namespace pqs{

    template <typename Quantity>
    struct of_named_quantity_for;

}//pqs

#endif
