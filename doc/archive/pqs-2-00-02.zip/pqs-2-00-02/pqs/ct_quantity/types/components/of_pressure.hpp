#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_PRESSURE_MX_HPP_INCLUDED2911030401
#define PQS_PRESSURE_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_pressure{
    private:
        friend void detail::dummy_friend_function();
        of_pressure();
        of_pressure( of_pressure const&);
        of_pressure operator = ( of_pressure const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "pressure";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<-1>,
            time_pwr<-2>,
            mass_pwr<1>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<5>,
                incoherent_multiplier<1013250>
            > atm;

            typedef quantity_unit<
                coherent_exponent<4>,
                incoherent_multiplier<9806650>
            > at;

            typedef quantity_unit<
                coherent_exponent<5>,
                incoherent_multiplier<1000000>,
                quantity_unit_tag<1>
            > bar;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1333220>
            > cm_mercury0C;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1333224>
            > cmHg;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<9806380>
            > cm_water4C;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<9806650>
            > cmH20;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<1000000>,
                quantity_unit_tag<1>
            > dyn_div_cm2;

            typedef quantity_unit<
                coherent_exponent<4>,
                incoherent_multiplier<4063666>
            > ftHg;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<2988980>
            > ft_water39_2F;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<2989067>
            > ftH20;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<9806650>,
                quantity_unit_tag<1>
            > gf_div_cm2;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<3386380>
            > in_mercury32F;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<3376850>
            > in_mercury60F;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<3386389>
            > inHg;

            typedef quantity_unit<
                coherent_exponent<2>,
                incoherent_multiplier<2490820>
            > in_water39_2F;

            typedef quantity_unit<
                coherent_exponent<2>,
                incoherent_multiplier<2490889>
            > inH20;

            typedef quantity_unit<
                coherent_exponent<4>,
                incoherent_multiplier<9806650>,
                quantity_unit_tag<1>
            > kgf_div_cm2;

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<9806650>
            > kgf_div_m2;

            typedef quantity_unit<
                coherent_exponent<6>,
                incoherent_multiplier<9806650>
            > kgf_div_mm2;

            typedef quantity_unit<
                coherent_exponent<6>,
                incoherent_multiplier<6894757>
            > ksi;

            typedef quantity_unit<
                coherent_exponent<2>,
                incoherent_multiplier<1000000>,
                quantity_unit_tag<2>
            > mbar;

            typedef quantity_unit<
                coherent_exponent<2>,
                incoherent_multiplier<1333224>
            > mmHg;

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<9806650>,
                quantity_unit_tag<1>
            > mmH20;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<4788026>
            > lbf_div_ft2;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<6894757>
            > psi;

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<1488164>
            > poundal_div_ft2;

            typedef quantity_unit<
                coherent_exponent<2>,
                incoherent_multiplier<1333224>,
                quantity_unit_tag<1>
            > torr;

        };
        typedef  of_pressure of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_pressure::unprefixed_symbol<char>()
    {
        return "Pa";
    }

    //The following enables use of of_pressure data
    //as a traits class for abstract quantity pressure
    template <>
    struct of_named_quantity_for<
        of_pressure::type
    > : of_pressure{};


}//pqs

#endif

