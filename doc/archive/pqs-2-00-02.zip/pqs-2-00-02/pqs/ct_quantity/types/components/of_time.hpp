#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_TIME_MX_HPP_INCLUDED2911030401
#define PQS_TIME_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_time{
    private:
        friend void detail::dummy_friend_function();
        of_time();
        of_time( of_time const&);
        of_time operator = ( of_time const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "time";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<0>,
            time_pwr<1>,
            mass_pwr<0>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<4>,
                incoherent_multiplier<8640000>
            > d;

            typedef quantity_unit<
                coherent_exponent<4>,
                incoherent_multiplier<8616409>
            > d_sid;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<3600000>
            > h;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<3590170>
            > h_sid;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<6000000>
            > min;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<5983617>
            > min_sid;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<9972696>
            > s_sid;

            typedef quantity_unit<
                coherent_exponent<5>,
                incoherent_multiplier<6048000>
            > wk;

            typedef quantity_unit<
                coherent_exponent<7>,
                incoherent_multiplier<3153600>
            > yr;

            typedef quantity_unit<
                coherent_exponent<7>,
                incoherent_multiplier<3155815>
            > yr_sid;

            typedef quantity_unit<
                coherent_exponent<7>,
                incoherent_multiplier<3155693>
            > yr_trop;

        };
        typedef  of_time of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_time::unprefixed_symbol<char>()
    {
        return "s";
    }

    //The following enables use of of_time data
    //as a traits class for abstract quantity time
    template <>
    struct of_named_quantity_for<
        of_time::type
    > : of_time{};


}//pqs

#endif

