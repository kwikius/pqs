#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_VELOCITY_MX_HPP_INCLUDED2911030401
#define PQS_VELOCITY_MX_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types/components/of_named_quantity.hpp"

namespace pqs{

    struct of_velocity{
    private:
        friend void detail::dummy_friend_function();
        of_velocity();
        of_velocity( of_velocity const&);
        of_velocity operator = ( of_velocity const &);
    public:
        static const char* abstract_quantity_name()
        {
            return "velocity";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef anonymous_abstract_quantity<
            length_pwr<1>,
            time_pwr<-1>,
            mass_pwr<0>,
            temperature_pwr<0>,
            current_pwr<0>,
            substance_pwr<0>,
            intensity_pwr<0>
        > anonymous_abstract_quantity_type;

        typedef named_abstract_quantity<
            anonymous_abstract_quantity_type,
            named_quantity_tag<1>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<-5>,
                incoherent_multiplier<8466667>
            > ft_div_h;

            typedef quantity_unit<
                coherent_exponent<-3>,
                incoherent_multiplier<5080000>
            > ft_div_min;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<3048000>
            > ft_div_s;

            typedef quantity_unit<
                coherent_exponent<-2>,
                incoherent_multiplier<2540000>
            > in_div_s;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<2777778>
            > km_div_h;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<5144444>
            > knot;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<4470400>
            > mi_div_h;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<2682240>
            > mi_div_min;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1609344>
            > mi_div_s;

            typedef quantity_unit<
                coherent_exponent<-5>,
                incoherent_multiplier<1666667>
            > mm_div_min;

        };
        typedef  of_velocity of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_velocity::unprefixed_symbol<char>()
    {
        return "m.s-1";
    }

    //The following enables use of of_velocity data
    //as a traits class for abstract quantity velocity
    template <>
    struct of_named_quantity_for<
        of_velocity::type
    > : of_velocity{};


}//pqs

#endif

