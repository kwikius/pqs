#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_DENSITY_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_DENSITY_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_density.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct density_ : of_density{
    private:
        friend void detail::dummy_friend_function();
        density_();
        density_(density_ const&);
        density_ operator =(density_ const &);
    public:
        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-27>
            >,
            Value_type
        > yg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > zg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > ag_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > fg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > pg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > ng_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > ug_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > mg_div_m3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-5>
            >,
            Value_type
        > cg_div_m3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-4>
            >,
            Value_type
        > dg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > g_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > dag_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > hg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > kg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > Mg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > Gg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > Tg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > Pg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > Eg_div_m3;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > Zg_div_m3;

    };

    struct density : density_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        density();
        density( density const&);
        density operator =(density const &);
    };

}//pqs

#endif
