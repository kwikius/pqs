#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_INDUCTANCE_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_INDUCTANCE_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_inductance.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct inductance_ : of_inductance{
    private:
        friend void detail::dummy_friend_function();
        inductance_();
        inductance_(inductance_ const&);
        inductance_ operator =(inductance_ const &);
    public:
        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > yH;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > zH;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > aH;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > fH;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > pH;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > nH;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > uH;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > mH;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > cH;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > dH;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > H;

        typedef ct_quantity<
            type,
            typename si_unit::deka, // coherent-exponent 1
            Value_type
        > daH;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > hH;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > kH;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > MH;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > GH;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > TH;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > PH;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > EH;

        typedef ct_quantity<
            type,
            typename si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZH;

    };

    struct inductance : inductance_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        inductance();
        inductance( inductance const&);
        inductance operator =(inductance const &);
    };

}//pqs

#endif
