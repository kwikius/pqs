#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_LENGTH_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_LENGTH_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_length.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct length_ : of_length{
    private:
        friend void detail::dummy_friend_function();
        length_();
        length_(length_ const&);
        length_ operator =(length_ const &);
    public:
        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > ym;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > zm;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > am;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > fm;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > pm;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > nm;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > um;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > mm;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > cm;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > dm;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > m;

        typedef ct_quantity<
            type,
            typename si_unit::deka, // coherent-exponent 1
            Value_type
        > dam;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > hm;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > km;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > Mm;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > Gm;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > Tm;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > Pm;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > Em;

        typedef ct_quantity<
            type,
            typename si_unit::zetta, // coherent-exponent 21
            Value_type
        > Zm;

        typedef ct_quantity<
            type,
            typename incoherent_unit::fathom_us,
            Value_type
        > fathom_us;

        typedef ct_quantity<
            type,
            typename incoherent_unit::AU,
            Value_type
        > AU;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ch,
            Value_type
        > ch;

        typedef ct_quantity<
            type,
            typename incoherent_unit::fathom,
            Value_type
        > fathom;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ft,
            Value_type
        > ft;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ft_us,
            Value_type
        > ft_us;

        typedef ct_quantity<
            type,
            typename incoherent_unit::in,
            Value_type
        > in;

        typedef ct_quantity<
            type,
            typename incoherent_unit::l_y_,
            Value_type
        > l_y_;

        typedef ct_quantity<
            type,
            typename incoherent_unit::mi,
            Value_type
        > mi;

        typedef ct_quantity<
            type,
            typename incoherent_unit::naut_mile,
            Value_type
        > naut_mile;

        typedef ct_quantity<
            type,
            typename incoherent_unit::pc,
            Value_type
        > pc;

        typedef ct_quantity<
            type,
            typename incoherent_unit::pica_comp,
            Value_type
        > pica_comp;

        typedef ct_quantity<
            type,
            typename incoherent_unit::pica_prn,
            Value_type
        > pica_prn;

        typedef ct_quantity<
            type,
            typename incoherent_unit::point_comp,
            Value_type
        > point_comp;

        typedef ct_quantity<
            type,
            typename incoherent_unit::point_prn,
            Value_type
        > point_prn;

        typedef ct_quantity<
            type,
            typename incoherent_unit::rd,
            Value_type
        > rd;

        typedef ct_quantity<
            type,
            typename incoherent_unit::yd,
            Value_type
        > yd;

    };

    struct length : length_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        length();
        length( length const&);
        length operator =(length const &);
    };

}//pqs

#endif
