#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_MAGNETIC_FLUX_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_MAGNETIC_FLUX_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_magnetic_flux.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct magnetic_flux_ : of_magnetic_flux{
    private:
        friend void detail::dummy_friend_function();
        magnetic_flux_();
        magnetic_flux_(magnetic_flux_ const&);
        magnetic_flux_ operator =(magnetic_flux_ const &);
    public:
        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > yWb;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > zWb;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > aWb;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > fWb;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > pWb;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > nWb;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > uWb;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > mWb;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > cWb;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > dWb;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > Wb;

        typedef ct_quantity<
            type,
            typename si_unit::deka, // coherent-exponent 1
            Value_type
        > daWb;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > hWb;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > kWb;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > MWb;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > GWb;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > TWb;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > PWb;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > EWb;

        typedef ct_quantity<
            type,
            typename si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZWb;

    };

    struct magnetic_flux : magnetic_flux_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        magnetic_flux();
        magnetic_flux( magnetic_flux const&);
        magnetic_flux operator =(magnetic_flux const &);
    };

}//pqs

#endif
