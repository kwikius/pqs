#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_MASS_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_MASS_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_mass.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct mass_ : of_mass{
    private:
        friend void detail::dummy_friend_function();
        mass_();
        mass_(mass_ const&);
        mass_ operator =(mass_ const &);
    public:
        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-27>
            >,
            Value_type
        > yg;

        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > zg;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > ag;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > fg;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > pg;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > ng;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > ug;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > mg;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-5>
            >,
            Value_type
        > cg;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-4>
            >,
            Value_type
        > dg;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > g;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > dag;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > hg;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > kg;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > Mg;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > Gg;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > Tg;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > Pg;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > Eg;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > Zg;

        typedef ct_quantity<
            type,
            typename incoherent_unit::AT,
            Value_type
        > AT;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ton_long,
            Value_type
        > ton_long;

        typedef ct_quantity<
            type,
            typename incoherent_unit::t,
            Value_type
        > t;

        typedef ct_quantity<
            type,
            typename incoherent_unit::carat,
            Value_type
        > carat;

        typedef ct_quantity<
            type,
            typename incoherent_unit::grain,
            Value_type
        > grain;

        typedef ct_quantity<
            type,
            typename incoherent_unit::hundredwgt_short,
            Value_type
        > hundredwgt_short;

        typedef ct_quantity<
            type,
            typename incoherent_unit::hundredwgt_long,
            Value_type
        > hundredwgt_long;

        typedef ct_quantity<
            type,
            typename incoherent_unit::oz,
            Value_type
        > oz;

        typedef ct_quantity<
            type,
            typename incoherent_unit::troy_oz,
            Value_type
        > troy_oz;

        typedef ct_quantity<
            type,
            typename incoherent_unit::dwt,
            Value_type
        > dwt;

        typedef ct_quantity<
            type,
            typename incoherent_unit::lb,
            Value_type
        > lb;

        typedef ct_quantity<
            type,
            typename incoherent_unit::troy_lb,
            Value_type
        > troy_lb;

        typedef ct_quantity<
            type,
            typename incoherent_unit::slug,
            Value_type
        > slug;

    };

    struct mass : mass_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        mass();
        mass( mass const&);
        mass operator =(mass const &);
    };

}//pqs

#endif
