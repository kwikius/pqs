#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_PRESSURE_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_PRESSURE_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_pressure.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct pressure_ : of_pressure{
    private:
        friend void detail::dummy_friend_function();
        pressure_();
        pressure_(pressure_ const&);
        pressure_ operator =(pressure_ const &);
    public:
        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > yPa;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > zPa;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > aPa;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > fPa;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > pPa;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > nPa;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > uPa;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > mPa;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > cPa;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > dPa;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > Pa;

        typedef ct_quantity<
            type,
            typename si_unit::deka, // coherent-exponent 1
            Value_type
        > daPa;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > hPa;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > kPa;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > MPa;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > GPa;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > TPa;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > PPa;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > EPa;

        typedef ct_quantity<
            type,
            typename si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZPa;

        typedef ct_quantity<
            type,
            typename incoherent_unit::atm,
            Value_type
        > atm;

        typedef ct_quantity<
            type,
            typename incoherent_unit::at,
            Value_type
        > at;

        typedef ct_quantity<
            type,
            typename incoherent_unit::bar,
            Value_type
        > bar;

        typedef ct_quantity<
            type,
            typename incoherent_unit::cm_mercury0C,
            Value_type
        > cm_mercury0C;

        typedef ct_quantity<
            type,
            typename incoherent_unit::cmHg,
            Value_type
        > cmHg;

        typedef ct_quantity<
            type,
            typename incoherent_unit::cm_water4C,
            Value_type
        > cm_water4C;

        typedef ct_quantity<
            type,
            typename incoherent_unit::cmH20,
            Value_type
        > cmH20;

        typedef ct_quantity<
            type,
            typename incoherent_unit::dyn_div_cm2,
            Value_type
        > dyn_div_cm2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ftHg,
            Value_type
        > ftHg;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ft_water39_2F,
            Value_type
        > ft_water39_2F;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ftH20,
            Value_type
        > ftH20;

        typedef ct_quantity<
            type,
            typename incoherent_unit::gf_div_cm2,
            Value_type
        > gf_div_cm2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::in_mercury32F,
            Value_type
        > in_mercury32F;

        typedef ct_quantity<
            type,
            typename incoherent_unit::in_mercury60F,
            Value_type
        > in_mercury60F;

        typedef ct_quantity<
            type,
            typename incoherent_unit::inHg,
            Value_type
        > inHg;

        typedef ct_quantity<
            type,
            typename incoherent_unit::in_water39_2F,
            Value_type
        > in_water39_2F;

        typedef ct_quantity<
            type,
            typename incoherent_unit::inH20,
            Value_type
        > inH20;

        typedef ct_quantity<
            type,
            typename incoherent_unit::kgf_div_cm2,
            Value_type
        > kgf_div_cm2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::kgf_div_m2,
            Value_type
        > kgf_div_m2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::kgf_div_mm2,
            Value_type
        > kgf_div_mm2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ksi,
            Value_type
        > ksi;

        typedef ct_quantity<
            type,
            typename incoherent_unit::mbar,
            Value_type
        > mbar;

        typedef ct_quantity<
            type,
            typename incoherent_unit::mmHg,
            Value_type
        > mmHg;

        typedef ct_quantity<
            type,
            typename incoherent_unit::mmH20,
            Value_type
        > mmH20;

        typedef ct_quantity<
            type,
            typename incoherent_unit::lbf_div_ft2,
            Value_type
        > lbf_div_ft2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::psi,
            Value_type
        > psi;

        typedef ct_quantity<
            type,
            typename incoherent_unit::poundal_div_ft2,
            Value_type
        > poundal_div_ft2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::torr,
            Value_type
        > torr;

    };

    struct pressure : pressure_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        pressure();
        pressure( pressure const&);
        pressure operator =(pressure const &);
    };

}//pqs

#endif
