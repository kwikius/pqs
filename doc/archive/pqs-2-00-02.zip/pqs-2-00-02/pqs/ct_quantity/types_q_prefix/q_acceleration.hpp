#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_Q_ACCELERATION_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_Q_ACCELERATION_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_acceleration.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct q_acceleration_ : of_acceleration{
    private:
        friend void detail::dummy_friend_function();
        q_acceleration_();
        q_acceleration_( q_acceleration_ const&);
        q_acceleration_ operator =(q_acceleration_ const &);
    public:
        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > ym_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > zm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > am_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > fm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > pm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > nm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > um_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > mm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > cm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > dm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > m_div_s2;

        static m_div_s2 const& g;

        typedef ct_quantity<
            type,
            typename si_unit::deka, // coherent-exponent 1
            Value_type
        > dam_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > hm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > km_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > Mm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > Gm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > Tm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > Pm_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > Em_div_s2;

        typedef ct_quantity<
            type,
            typename si_unit::zetta, // coherent-exponent 21
            Value_type
        > Zm_div_s2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::g_s,
            Value_type
        > g_s;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ft_div_s2,
            Value_type
        > ft_div_s2;

        typedef ct_quantity<
            type,
            typename incoherent_unit::Gal,
            Value_type
        > Gal;

        typedef ct_quantity<
            type,
            typename incoherent_unit::in_div_s2,
            Value_type
        > in_div_s2;

    };

    struct q_acceleration : q_acceleration_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        q_acceleration();
        q_acceleration( q_acceleration const&);
        q_acceleration operator =(q_acceleration const &);
    };

}//pqs

#endif
