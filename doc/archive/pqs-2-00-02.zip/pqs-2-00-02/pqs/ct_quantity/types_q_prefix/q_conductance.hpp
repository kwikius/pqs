#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_Q_CONDUCTANCE_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_Q_CONDUCTANCE_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_conductance.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct q_conductance_ : of_conductance{
    private:
        friend void detail::dummy_friend_function();
        q_conductance_();
        q_conductance_( q_conductance_ const&);
        q_conductance_ operator =(q_conductance_ const &);
    public:
        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > yS;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > zS;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > aS;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > fS;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > pS;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > nS;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > uS;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > mS;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > cS;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > dS;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > S;

        typedef ct_quantity<
            type,
            typename si_unit::deka, // coherent-exponent 1
            Value_type
        > daS;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > hS;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > kS;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > MS;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > GS;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > TS;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > PS;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > ES;

        typedef ct_quantity<
            type,
            typename si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZS;

    };

    struct q_conductance : q_conductance_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        q_conductance();
        q_conductance( q_conductance const&);
        q_conductance operator =(q_conductance const &);
    };

}//pqs

#endif
