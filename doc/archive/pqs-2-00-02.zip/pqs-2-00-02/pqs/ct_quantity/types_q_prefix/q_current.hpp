#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_Q_CURRENT_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_Q_CURRENT_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_current.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct q_current_ : of_current{
    private:
        friend void detail::dummy_friend_function();
        q_current_();
        q_current_( q_current_ const&);
        q_current_ operator =(q_current_ const &);
    public:
        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > yA;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > zA;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > aA;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > fA;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > pA;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > nA;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > uA;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > mA;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > cA;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > dA;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > A;

        typedef ct_quantity<
            type,
            typename si_unit::deka, // coherent-exponent 1
            Value_type
        > daA;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > hA;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > kA;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > MA;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > GA;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > TA;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > PA;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > EA;

        typedef ct_quantity<
            type,
            typename si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZA;

        typedef ct_quantity<
            type,
            typename incoherent_unit::abampere,
            Value_type
        > abampere;

    };

    struct q_current : q_current_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        q_current();
        q_current( q_current const&);
        q_current operator =(q_current const &);
    };

}//pqs

#endif
