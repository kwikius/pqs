#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_Q_TIME_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_Q_TIME_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_time.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct q_time_ : of_time{
    private:
        friend void detail::dummy_friend_function();
        q_time_();
        q_time_( q_time_ const&);
        q_time_ operator =(q_time_ const &);
    public:
        typedef ct_quantity<
            type,
            typename si_unit::yocto, // coherent-exponent -24
            Value_type
        > ys;

        typedef ct_quantity<
            type,
            typename si_unit::zepto, // coherent-exponent -21
            Value_type
        > zs;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > as;

        typedef ct_quantity<
            type,
            typename si_unit::femto, // coherent-exponent -15
            Value_type
        > fs;

        typedef ct_quantity<
            type,
            typename si_unit::pico, // coherent-exponent -12
            Value_type
        > ps;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > ns;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > us;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > ms;

        typedef ct_quantity<
            type,
            typename si_unit::centi, // coherent-exponent -2
            Value_type
        > cs;

        typedef ct_quantity<
            type,
            typename si_unit::deci, // coherent-exponent -1
            Value_type
        > ds;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > s;

        typedef ct_quantity<
            type,
            typename si_unit::deka, // coherent-exponent 1
            Value_type
        > das;

        typedef ct_quantity<
            type,
            typename si_unit::hecto, // coherent-exponent 2
            Value_type
        > hs;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > ks;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > Ms;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > Gs;

        typedef ct_quantity<
            type,
            typename si_unit::tera, // coherent-exponent 12
            Value_type
        > Ts;

        typedef ct_quantity<
            type,
            typename si_unit::peta, // coherent-exponent 15
            Value_type
        > Ps;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > Es;

        typedef ct_quantity<
            type,
            typename si_unit::zetta, // coherent-exponent 21
            Value_type
        > Zs;

        typedef ct_quantity<
            type,
            typename incoherent_unit::d,
            Value_type
        > d;

        typedef ct_quantity<
            type,
            typename incoherent_unit::d_sid,
            Value_type
        > d_sid;

        typedef ct_quantity<
            type,
            typename incoherent_unit::h,
            Value_type
        > h;

        typedef ct_quantity<
            type,
            typename incoherent_unit::h_sid,
            Value_type
        > h_sid;

        typedef ct_quantity<
            type,
            typename incoherent_unit::min,
            Value_type
        > min;

        typedef ct_quantity<
            type,
            typename incoherent_unit::min_sid,
            Value_type
        > min_sid;

        typedef ct_quantity<
            type,
            typename incoherent_unit::s_sid,
            Value_type
        > s_sid;

        typedef ct_quantity<
            type,
            typename incoherent_unit::wk,
            Value_type
        > wk;

        typedef ct_quantity<
            type,
            typename incoherent_unit::yr,
            Value_type
        > yr;

        typedef ct_quantity<
            type,
            typename incoherent_unit::yr_sid,
            Value_type
        > yr_sid;

        typedef ct_quantity<
            type,
            typename incoherent_unit::yr_trop,
            Value_type
        > yr_trop;

    };

    struct q_time : q_time_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        q_time();
        q_time( q_time const&);
        q_time operator =(q_time const &);
    };

}//pqs

#endif
