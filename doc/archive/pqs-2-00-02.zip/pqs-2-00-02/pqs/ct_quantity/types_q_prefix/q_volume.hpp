#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_CT_QUANTITY_TYPES_Q_VOLUME_HPP_INCLUDED
#define PQS_CT_QUANTITY_TYPES_Q_VOLUME_HPP_INCLUDED

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_volume.hpp"

namespace pqs{

    template<
        typename Value_type
    >
    struct q_volume_ : of_volume{
    private:
        friend void detail::dummy_friend_function();
        q_volume_();
        q_volume_( q_volume_ const&);
        q_volume_ operator =(q_volume_ const &);
    public:
        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-54>
            >,
            Value_type
        > am3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-45>
            >,
            Value_type
        > fm3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-36>
            >,
            Value_type
        > pm3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<-27>
            >,
            Value_type
        > nm3;

        typedef ct_quantity<
            type,
            typename si_unit::atto, // coherent-exponent -18
            Value_type
        > um3;

        typedef ct_quantity<
            type,
            typename si_unit::nano, // coherent-exponent -9
            Value_type
        > mm3;

        typedef ct_quantity<
            type,
            typename si_unit::micro, // coherent-exponent -6
            Value_type
        > cm3;

        typedef ct_quantity<
            type,
            typename si_unit::milli, // coherent-exponent -3
            Value_type
        > dm3;

        typedef ct_quantity<
            type,
            typename si_unit::none, // coherent-exponent 0
            Value_type
        > m3;

        typedef ct_quantity<
            type,
            typename si_unit::kilo, // coherent-exponent 3
            Value_type
        > dam3;

        typedef ct_quantity<
            type,
            typename si_unit::mega, // coherent-exponent 6
            Value_type
        > hm3;

        typedef ct_quantity<
            type,
            typename si_unit::giga, // coherent-exponent 9
            Value_type
        > km3;

        typedef ct_quantity<
            type,
            typename si_unit::exa, // coherent-exponent 18
            Value_type
        > Mm3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<27>
            >,
            Value_type
        > Gm3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<36>
            >,
            Value_type
        > Tm3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<45>
            >,
            Value_type
        > Pm3;

        typedef ct_quantity<
            type,
            quantity_unit<
                coherent_exponent<54>
            >,
            Value_type
        > Em3;

        typedef ct_quantity<
            type,
            typename incoherent_unit::acre_foot,
            Value_type
        > acre_foot;

        typedef ct_quantity<
            type,
            typename incoherent_unit::bbl,
            Value_type
        > bbl;

        typedef ct_quantity<
            type,
            typename incoherent_unit::bu,
            Value_type
        > bu;

        typedef ct_quantity<
            type,
            typename incoherent_unit::cord,
            Value_type
        > cord;

        typedef ct_quantity<
            type,
            typename incoherent_unit::ft3,
            Value_type
        > ft3;

        typedef ct_quantity<
            type,
            typename incoherent_unit::in3,
            Value_type
        > in3;

        typedef ct_quantity<
            type,
            typename incoherent_unit::mi3,
            Value_type
        > mi3;

        typedef ct_quantity<
            type,
            typename incoherent_unit::yd3,
            Value_type
        > yd3;

        typedef ct_quantity<
            type,
            typename incoherent_unit::cup,
            Value_type
        > cup;

        typedef ct_quantity<
            type,
            typename incoherent_unit::fl_oz_US,
            Value_type
        > fl_oz_US;

        typedef ct_quantity<
            type,
            typename incoherent_unit::gal,
            Value_type
        > gal;

        typedef ct_quantity<
            type,
            typename incoherent_unit::gal_US,
            Value_type
        > gal_US;

    };

    struct q_volume : q_volume_<of_quantity::default_value_type>{
    private:
        friend void detail::dummy_friend_function();
        q_volume();
        q_volume( q_volume const&);
        q_volume operator =(q_volume const &);
    };

}//pqs

#endif
