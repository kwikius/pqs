#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CLASS_TEMPLATE_UNITS_OUT_HPP_INCLUDED2911030401
#define PQS_CLASS_TEMPLATE_UNITS_OUT_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    utility "dummy" classes used for output of units of a physical quantity
    which can be overloaded for special units
    e.g "N" (newtons),"kgf" (kilograms force )
*/

 namespace pqs{

    template<   
        typename NamedAbstractQuantity,
        typename QuantityUnit
    >
    class physical_quantity_units_out{
    
    };

/*
    utility class used for output of units of a physical quantity  as
    QuantityUnit::si_exponent * QuantityUnit::incoherent_mx  version
    e.g "kg.m.s-2" (newtons), "kg.m.s-2 * 9.8" (kilograms force )
*/
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit
    > 
    class physical_quantity_basic_units_out{};

}//pqs

#endif

