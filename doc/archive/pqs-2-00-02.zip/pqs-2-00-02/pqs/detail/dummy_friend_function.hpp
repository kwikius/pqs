#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_DETAIL_DUMMY_FRIEND_FUNCTION_HPP_INCLUDED
#define PQS_DETAIL_DUMMY_FRIEND_FUNCTION_HPP_INCLUDED

namespace pqs{namespace detail{
    // to avoid warnings on gcc
        void  dummy_friend_function();
}}//pqs::detail

#endif
