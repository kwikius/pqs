#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_CONCEPT_CHECKING_HPP_INCLUDED2911030401
#define PQS_CONCEPT_CHECKING_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/* 
    concept checking dimensional equivalence
*/

/* modified from boost Concept Checking.hpp 
which is
// (C) Copyright Jeremy Siek 2000. Permission to copy, use, modify,
// sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.

// See http://www.boost.org/libs/concept_check for documentation.
*/

#include "pqs/concepts/concept_checking.hpp"
#include "boost/mpl/if.hpp"
#include "boost/type_traits/is_same.hpp"

namespace pqs{
   
    template <
        typename NamedAbstractQuantityA,
        typename NamedAbstractQuantityB
    >
    struct DimensionallyEquivalentQuantityConcept{

        void constraints()  
        {  
            anonymous_abstract_quantityA = anonymous_abstract_quantityB;
        }

        typename NamedAbstractQuantityA::anonymous_abstract_quantity_type anonymous_abstract_quantityA;
        typename NamedAbstractQuantityB::anonymous_abstract_quantity_type anonymous_abstract_quantityB;

    }; 

    template <
        typename NamedAbstractQuantity,
        typename OtherNamedAbstractQuantity
    >
    struct CompatibleQuantityConcept{  
        
        
        void constraints()
        {    
            concept_checking::function_requires<
                DimensionallyEquivalentQuantityConcept<
                    NamedAbstractQuantity,
                    OtherNamedAbstractQuantity
                >
            >(); 

            compatible_typeA = compatible_typeB;
           
        }
        // utility for types
        template <typename First, typename Second>
        struct Pair{
            typedef First first;
            typedef Second second;
        };

        typedef typename boost::mpl::if_c<
            ((NamedAbstractQuantity::tag_type::value !=0 ) &&
                (OtherNamedAbstractQuantity::tag_type::value ==0)),
            Pair<NamedAbstractQuantity,NamedAbstractQuantity>,
                typename boost::mpl::if_c<
                    ((NamedAbstractQuantity::tag_type::value == 0 ) &&
                        (OtherNamedAbstractQuantity::tag_type::value !=0)),
                    Pair<OtherNamedAbstractQuantity,OtherNamedAbstractQuantity>,
                    Pair<NamedAbstractQuantity,OtherNamedAbstractQuantity>
                >::type 
        >::type pair_type;
        typename pair_type::first    compatible_typeA;
        typename pair_type::second   compatible_typeB;
                
    };

    template <
        typename NamedAbstractQuantity,
        typename OtherNamedAbstractQuantity
    >
    struct CompatibleQuantityWarningConcept{

        void constraints()
        {
        //////check dimensionally equivalent
           concept_checking::function_requires<
                DimensionallyEquivalentQuantityConcept<
                    NamedAbstractQuantity,
                    OtherNamedAbstractQuantity
                >
            >();
        ////////check dimensionally equivalent/////
        // also give warning on dimensionally-equivalent 
        // but different quantities being assigned
        // NOTE: warning can be removed by using anonymous_cast(q_XXX); 
            conversion_to = possibly_unsafe_from;
        }

       template <typename ConversionToWarningFlaggerAlias,
         typename ConversionFromWarningFlaggerAlias>
        struct ToFromPair{
            typedef ConversionToWarningFlaggerAlias to_type;
            typedef ConversionFromWarningFlaggerAlias from_type;
        };
    
        typedef typename boost::mpl::if_c<
            ((NamedAbstractQuantity::tag_type::value !=0 ) &&
                (OtherNamedAbstractQuantity::tag_type::value ==0)),
            ToFromPair<int,int>,
            typename boost::mpl::if_c<
                ((NamedAbstractQuantity::tag_type::value == 0 ) &&
                    (OtherNamedAbstractQuantity::tag_type::value !=0)),
                 ToFromPair<int,int>,
                 typename boost::mpl::if_c<
                    ((NamedAbstractQuantity::tag_type::value == 
                    static_cast<int>(OtherNamedAbstractQuantity::tag_type::value) ) ||
                    boost::is_same<
                        typename NamedAbstractQuantity::anonymous_abstract_quantity_type ,
                        typename OtherNamedAbstractQuantity::anonymous_abstract_quantity_type
                    >::value == 0),
                    ToFromPair<int,int>,
                    ToFromPair<int,long double>
                >::type
            >::type
        >::type conversion_type;
        typename conversion_type::to_type conversion_to; 
        typename conversion_type::from_type possibly_unsafe_from; 
       
    };
   
}//pqs

#endif

