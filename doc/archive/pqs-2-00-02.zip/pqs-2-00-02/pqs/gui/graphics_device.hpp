#ifndef PQS_GUI_GRAPHICS_DEVICE_HPP_INCLUDED
#define PQS_GUI_GRAPHICS_DEVICE_HPP_INCLUDED
/*
    ABC interface for graphics device
*/

namespace pqs{namespace gui{

    template<
        typename PhysicalSizeType, // eg vect<length::mm>
        typename DeviceExtentType  // eg vect<int>
    >
    class graphics_device {
    public:
        typedef PhysicalSizeType    physical_size_type;
        typedef DeviceExtentType    device_extent_type;    
    
        virtual device_extent_type const &
        device_extent()const =0;
        virtual device_extent_type&
        device_extent() = 0;
        virtual physical_size_type const & 
        physical_size()const =0;
        virtual physical_size_type& 
        physical_size() = 0;
    };
}}//pqs::gui

#endif
