#ifndef PQS_GUI_GRAPHICS_DEVICE_HPP_INCLUDED
#define PQS_GUI_GRAPHICS_DEVICE_HPP_INCLUDED
/*
    ABC interface for graphics viewport
*/

namespace pqs{namespace gui{

    template<
        typename PhysicalSizeType,  // eg vect<length::mm>
        typename ViewportExtentType  // eg vect<int>
    >
    class graphics_viewport {
    public:
        typedef PhysicalSizeType    physical_size_type;
        typedef ViewportExtentType  viewport_extent_type;    
    
        virtual viewport_extent_type const &
        viewport_extent()const =0;
       /* virtual viewport_extent_type&
        viewport_extent() = 0;*/
        virtual physical_size_type const & 
        physical_size()const =0;
       /* virtual physical_size_type& 
        physical_size() = 0;*/
        virtual ~graphics_viewport(){}
    };

}}//pqs::gui

#endif
