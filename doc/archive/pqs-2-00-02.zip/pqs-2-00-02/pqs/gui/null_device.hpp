#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_GUI_NULL_DEVICE_HPP_INCLUDED
#define PQS_GUI_NULL_DEVICE_HPP_INCLUDED

/*
    a null device ie window for testing
*/

#include "pqs/gui/graphics_device.hpp"

namespace pqs{namespace gui{
    
    template<
        typename PhysicalSizeType,
        typename DeviceExtentType
    >
    class null_device : 
    public graphics_device<
        PhysicalSizeType,
        DeviceExtentType
    >{
    public:
        typedef  typename graphics_device<
            PhysicalSizeType,
            DeviceExtentType
        >::physical_size_type physical_size_type;
        typedef  typename graphics_device<
            PhysicalSizeType,
            DeviceExtentType
        >::device_extent_type device_extent_type;    
        null_device(
            physical_size_type const& physical_size_in,
            device_extent_type const& extent_in )
        :m_physical_size(physical_size_in), m_device_extent(extent_in){}
        null_device(){}
        device_extent_type const &
        device_extent()const
        {
            return m_device_extent;
        }        
        device_extent_type&
        device_extent()
        {
            return m_device_extent;
        }
        physical_size_type const & 
        physical_size()const
        { 
            return m_physical_size;
        }
        physical_size_type& 
        physical_size()
        { 
            return m_physical_size;
        }
    private:
        physical_size_type m_physical_size;
        device_extent_type m_device_extent;
    };

}}//pqs::gui





#endif
