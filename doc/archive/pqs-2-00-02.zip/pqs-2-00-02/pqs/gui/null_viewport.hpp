#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_GUI_NULL_DEVICE_HPP_INCLUDED
#define PQS_GUI_NULL_DEVICE_HPP_INCLUDED

/*
    a null viewport for testing
*/

#include "pqs/gui/graphics_viewport.hpp"

namespace pqs{namespace gui{
    
    template<
        typename PhysicalSizeType,
        typename DeviceExtentType
    >
    class null_viewport : 
    public graphics_viewport<
        PhysicalSizeType,
        DeviceExtentType
    > {
        
    public:
        typedef  typename graphics_viewport<
            PhysicalSizeType,
            DeviceExtentType
        >::physical_size_type physical_size_type;
        typedef  typename graphics_viewport<
            PhysicalSizeType,
            DeviceExtentType
        >::viewport_extent_type viewport_extent_type;    
        null_viewport(
            physical_size_type const& physical_size_in,
            viewport_extent_type const& extent_in )
        :m_physical_size(physical_size_in), m_viewport_extent(extent_in){}
        null_viewport(){}
        viewport_extent_type const &
        viewport_extent()const
        {
            return m_viewport_extent;
        }        
        viewport_extent_type&
        viewport_extent()
        {
            return m_viewport_extent;
        }
        physical_size_type const & 
        physical_size()const
        { 
            return m_physical_size;
        }
        physical_size_type& 
        physical_size()
        { 
            return m_physical_size;
        }
    private:
        physical_size_type m_physical_size;
        viewport_extent_type m_viewport_extent;
    };

}}//pqs::gui





#endif
