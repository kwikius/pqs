#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

#ifndef PQS_GUI_WORLD_VIEWPORT_HPP_INCLUDED
#define PQS_GUI_WORLD_VIEWPORT_HPP_INCLUDED

#include "pqs/two_d/vect.hpp"

namespace pqs{namespace gui{

    template< typename WorldElement,typename Device>
    class world_viewport : public WorldElement{
    public:
        typedef typename WorldElement::x_type           world_x_type;
        typedef typename WorldElement::y_type           world_y_type;
        typedef typename WorldElement::angle_type       world_angle_type;
        typedef typename WorldElement::position_type    world_position_type;

        typedef typename Device::physical_size_type     device_physical_size_type;
        typedef typename Device::device_x_type          device_x_type;
        typedef typename Device::device_y_type          device_y_type;
        world_viewport():m_scale(1.){}
        double scale()const {return m_scale;}
        double & scale() {return m_scale;}
        Device const& device()const {return m_device;}
        Device& device() {return m_device;}
        template <typename Tx,typename Ty, typename Tt>
        pqs::two_d::vect<device_physical_size_type>
        world_to_physical(pqs::two_d::vect<Tx,Ty,Tt>const & vect_in)const
        {
          pqs::two_d::vect<device_physical_size_type> t ;
          t.x() = ( vect_in.x() - this->position().x()) * this->m_scale;
          t.y() = ( vect_in.y() - this->position().y()) * this->m_scale;  
          return t;
        }
    private:    
        double m_scale;
        Device m_device;
        
    };

}}

#endif
 