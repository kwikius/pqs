#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_MATH_ANGLES_HPP_INCLUDED
#define PQS_MATH_ANGLES_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    interface betweeen radians and fraction_of_revoultion
*/

#include "pqs/math/constant.hpp"
#include "pqs/meta/min_type.hpp"
#include "pqs/meta/promotion_traits.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/binary_log_transform.hpp"
#include "pqs/ct_quantity/operations/detail/convert.hpp"
#include "pqs/math/angles/radians.hpp"
#include "pqs/math/angles/fraction_of_revolution.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include "pqs/ct_quantity/of_quantity.hpp"

namespace pqs{namespace math{
// ctor for rad from fraction of rev
    template<
        typename Extent,
        typename Value_type
    >
    template<
        typename ReciprocalFraction,
        typename Value_type1
    >
    inline
    radians<
        Extent,
        Value_type
    > ::radians(
        fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            Value_type1
        > const & fr)
    : m_value ((Extent::numerator == 1)
        ?(fr.numeric_value() * 2 * constant::pi / typename ReciprocalFraction::eval()())
        :(fr.numeric_value() /( 2 * constant::pi * typename ReciprocalFraction::eval()())) ){
    ///////////////////////////Concept Check//////////////////////////////////////
    // limit conversion to radians and radians ^-1
        pqs::concept_checking::Assert<
             (((Extent::numerator == 1) && (Extent::denominator == 1)) 
            ||  ((Extent::numerator == -1) && (Extent::denominator == 1))) >();
    //////////////////////Concept Check //////////////////////////////////////////
    }
}}//pqs::math

namespace pqs{namespace meta{

// rad * fr
    template<
        typename ExtentL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::radians<ExtentL,Value_typeL>,
        std::multiplies,
        pqs::math::fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>
    >
    {
        typedef typename pqs::math::radians<
            typename binary_log_transform<
                ExtentL,
                std::multiplies,
                ExtentR
            >::result_type,
            typename binary_operation<
                Value_typeL,
                std::multiplies,
                Value_typeR
            >::result_type
        >::type result_type;
    };
// rad / fr
    template<
        typename ExtentL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::radians<ExtentL,Value_typeL>,
        std::divides,
        pqs::math::fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>
    >
    {
        typedef typename pqs::math::radians<
            typename binary_log_transform<
                ExtentL,
                std::divides,
                ExtentR
            >::result_type,
            typename binary_operation<
                Value_typeL,
                std::divides,
                Value_typeR
            >::result_type
        >::type result_type;
    };

//fr * rad    
    template<
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
        std::multiplies,
        pqs::math::radians<ExtentR,Value_typeR>
    >
    {
        typedef typename pqs::math::radians<
            typename binary_log_transform<
                ExtentL,
                std::multiplies,
                ExtentR
            >::result_type,
            typename binary_operation<
                Value_typeL,
                std::multiplies,
                Value_typeR
            >::result_type
        >::type result_type;
    };
// fr / rad
    template<
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
        std::divides,
        pqs::math::radians<ExtentR,Value_typeR>
    >
    {
        typedef typename pqs::math::radians<
            typename binary_log_transform<
                ExtentL,
                std::divides,
                ExtentR
            >::result_type,
            typename binary_operation<
                Value_typeL,
                std::divides,
                Value_typeR
            >::result_type
        >::type result_type;
    };
// fr + rad
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
        std::plus,
        pqs::math::radians<Extent,Value_typeR>
    >
    {
        typedef typename pqs::math::radians<
            Extent,
            typename binary_operation<
                Value_typeL,
                std::plus,
                Value_typeR
            >::result_type
        >::type result_type;
    };

// rad + fr
    template<
        typename Extent,
        typename Value_typeL,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::radians<Extent,Value_typeL>,
        std::plus,
        pqs::math::fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
    >
    {
        typedef typename pqs::math::radians<
            Extent,
            typename binary_operation<
                Value_typeL,
                std::plus,
                Value_typeR
            >::result_type
        >::type result_type;
    };

//rad-fr
    template<
        typename Extent,
        typename Value_typeL,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::radians<Extent,Value_typeL>,
        std::minus,
        pqs::math::fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
    >
    {
        typedef typename pqs::math::radians<
            Extent,
            typename binary_operation<
                Value_typeL,
                std::minus,
                Value_typeR
            >::result_type
        >::type result_type;
    };

// fr - rad
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
        std::minus,
        pqs::math::radians<Extent,Value_typeR>
    >
    {
        typedef typename pqs::math::radians<
            Extent,
            typename binary_operation<
                Value_typeL,
                std::minus,
                Value_typeR
            >::result_type
        >::type result_type;
    };


}}//pqs::meta

namespace pqs{namespace math{

// fr + rad
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
        std::plus,
        radians<Extent,Value_typeR>
    >::result_type     
    operator +(fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL> const&  lhs,
               radians<Extent,Value_typeR> const& rhs)
    {
        typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
            std::plus,
            radians<Extent,Value_typeR>
        >::result_type t(lhs);
        t += rhs;
        return t;    
    }

// rad + fr
    template<
        typename Extent,
        typename Value_typeL,
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        radians<Extent,Value_typeL>,
        std::plus,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
    >::result_type     
    operator +(radians<Extent,Value_typeL> const& lhs,
               fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR> const& rhs)
    {
        typedef typename pqs::meta::binary_operation<
            radians<Extent,Value_typeL>,
            std::plus,
            fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
        >::result_type rad;
        rad t(lhs);
        t += rad(rhs);
        return t;    
    } 
    
// rad - fr
    template<
        typename Extent,
        typename Value_typeL,
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        radians<Extent,Value_typeL>,
        std::minus,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
    >::result_type     
    operator -(radians<Extent,Value_typeL> const& lhs,
               fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR> const& rhs)
    {
        typedef typename pqs::meta::binary_operation<
            radians<Extent,Value_typeL>,
            std::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
        >::result_type rad;
        rad t(lhs);
        t -= rad(rhs);
        return t;    
    }
 
// fr - rad   
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
        std::minus,
        radians<Extent,Value_typeR>
    >::result_type     
    operator -(fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL> const&  lhs,
               radians<Extent,Value_typeR> const& rhs)
    {
        typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
            std::minus,
            radians<Extent,Value_typeR>
        >::result_type t(lhs);
        t -= rhs;
        return t;    
    } 

// rad * fr
    template<
        typename ExtentL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        pqs::math::radians<ExtentL,Value_typeL>,
        std::multiplies,
        pqs::math::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >::result_type
    operator * (pqs::math::radians<ExtentL,Value_typeL> const & lhs,
        pqs::math::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > const & rhs)
    {
        typedef typename pqs::meta::binary_log_transform<
            ExtentL,
            std::multiplies,
            ExtentR
        >::result_type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only multiplication  by angles
        // with resulting Extent of 0 is valid currently
        pqs::concept_checking::Assert<extent_type::is_zero>();
        //////////////////////CONCEPT CHECK/////////////////////////////
        typedef typename pqs::meta::binary_operation<
            pqs::math::radians<ExtentL,Value_typeL>,
            std::multiplies,
            pqs::math::fraction_of_revolution<
                ExtentR,
                ReciprocalFractionR,
                Value_typeR
            >
        >::result_type result_type;
        typedef typename pqs::meta::binary_operation<
            Value_typeL,
            std::multiplies,
            Value_typeR
        >::result_type result_value_type;
        pqs::math::radians<ExtentR,result_value_type> t(rhs);
        return (lhs.numeric_value() * t.numeric_value() );
    }
// fr * rad
    template<
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
         pqs::math::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        std::multiplies,
        pqs::math::radians<ExtentR,Value_typeR>
    >::result_type
    operator * ( pqs::math::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        > const  & lhs,
        pqs::math::radians<ExtentR,Value_typeR> const& rhs)
    {
        typedef typename pqs::meta::binary_log_transform<
            ExtentL,
            std::multiplies,
            ExtentR
        >::result_type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only multiplication  by non rad angles
        // with resulting Extent of 0 is valid currently
        pqs::concept_checking::Assert<extent_type::is_zero>();
        //////////////////////CONCEPT CHECK/////////////////////////////
        typedef typename pqs::meta::binary_operation<
            pqs::math::fraction_of_revolution<
                ExtentL,
                ReciprocalFractionL,
                Value_typeL
            >,
            std::multiplies,
            pqs::math::radians<ExtentR,Value_typeR>
        >::result_type result_type;
        typedef typename pqs::meta::binary_operation<
            Value_typeL,
            std::multiplies,
            Value_typeR
        >::result_type result_value_type;
        pqs::math::radians<ExtentL,result_value_type> t(lhs);
        return (t.numeric_value() * rhs.numeric_value()  );
    }
// rad / fr
    template<
        typename ExtentL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        pqs::math::radians<ExtentL,Value_typeL>,
        std::divides,
        pqs::math::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >::result_type
    operator / (pqs::math::radians<ExtentL,Value_typeL> const & lhs,
        pqs::math::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > const & rhs)
    {
        typedef typename pqs::meta::binary_log_transform<
            ExtentL,
            std::divides,
            ExtentR
        >::result_type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only multiplication  by different angles
        // with resulting Extent of 0 is valid currently
        pqs::concept_checking::Assert<extent_type::is_zero>();
        //////////////////////CONCEPT CHECK/////////////////////////////
        typedef typename pqs::meta::binary_operation<
        pqs::math::radians<ExtentL,Value_typeL>,
        std::divides,
        pqs::math::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
        >::result_type result_type;
        typedef typename pqs::meta::binary_operation<
            Value_typeL,
            std::divides,
            Value_typeR
        >::result_type result_value_type;
        pqs::math::radians<ExtentR,result_value_type> t(rhs);
        return (lhs.numeric_value() / t.numeric_value() );
    }
// fr / rad
    template<
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
         pqs::math::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        std::divides,
        pqs::math::radians<ExtentR,Value_typeR>
    >::result_type
    operator / ( pqs::math::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        > const  & lhs,
        pqs::math::radians<ExtentR,Value_typeR> const& rhs)
    {
         typedef typename pqs::meta::binary_log_transform<
            ExtentL,
            std::divides,
            ExtentR
         >::result_type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only multiplication  by non rad angles
        // with resulting Extent of 0 is valid currently
        pqs::concept_checking::Assert<extent_type::is_zero>();
        //////////////////////CONCEPT CHECK/////////////////////////////
        typedef typename pqs::meta::binary_operation<
            pqs::math::fraction_of_revolution<
                ExtentL,
                ReciprocalFractionL,
                Value_typeL
            >,
            std::divides,
            pqs::math::radians<ExtentR,Value_typeR>
        >::result_type result_type;
        typedef typename pqs::meta::binary_operation<
            Value_typeL,
            std::divides,
            Value_typeR
        >::result_type result_value_type;
        pqs::math::radians<ExtentL,result_value_type> t(lhs);
        return result_value_type(t.numeric_value() / rhs.numeric_value()  );
    }

    template<typename ReciprocalFraction,typename Value_type>
    inline
    Value_type cos(fraction_of_revolution<pqs::meta::rational_c<long,1>,ReciprocalFraction,Value_type>const& r)
    {
        radians<pqs::meta::rational_c<long,1>,Value_type> t(r);
        return cos(t);
    }
    template<typename ReciprocalFraction,typename Value_type>
    inline
    Value_type sin(fraction_of_revolution<pqs::meta::rational_c<long,1>,ReciprocalFraction,Value_type>const& r)
    {
        radians<pqs::meta::rational_c<long,1>,Value_type> t(r);
        return sin(t);
    }
    template<typename ReciprocalFraction,typename Value_type>
    inline
    Value_type tan(fraction_of_revolution<pqs::meta::rational_c<long,1>,ReciprocalFraction,Value_type>const& r)
    {
        radians<pqs::meta::rational_c<long,1>,Value_type> t(r);
        return tan(t);
    }

   
//comparisons
    
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline int compare( 
        radians<Extent,Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>const& rhs,
        typename pqs::meta::binary_operation<
            radians<Extent, Value_typeL>,
            std::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>    
        >::result_type const & eps 
        =typename pqs::meta::binary_operation<
            radians<Extent, Value_typeL>,
            std::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>    
        >::result_type(PQS_COMPARISON_EPSILON)
    )
    {
        typedef typename pqs::meta::binary_operation<
            radians<Extent, Value_typeL>,
            std::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>
        >::result_type comp_type;
        comp_type rhs1(rhs);
        typedef typename comp_type::value_type comp_value_type;
        return ((abs(lhs-rhs1)).numeric_value() <= eps.numeric_value())
        ? 0 
        :(((lhs-rhs1).numeric_value() < static_cast<comp_value_type>(0))
            ? -1
            : 1);
    } 

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline int compare( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        radians<Extent, Value_typeR>const& rhs,
        typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>,
            std::minus,
            radians<Extent, Value_typeR>
        >::result_type const & eps 
        = typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>,
            std::minus,
            radians<Extent, Value_typeR>
        >::result_type(PQS_COMPARISON_EPSILON)
    )     
    {
        typedef typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>,
            std::minus,
            radians<Extent, Value_typeR>
        >::result_type comp_type;
        typedef typename comp_type::value_type comp_value_type;
        comp_type lhs1(lhs);
        return ((abs(lhs1-rhs)).numeric_value() <= eps.numeric_value() )
        ? 0 
        :(((lhs1-rhs).numeric_value() < static_cast<comp_value_type>(0))
            ? -1
            : 1);
    }
// <
 
  template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator <( 
        radians<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) < 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator <( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        radians<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) < 0;
    }

// <=
 
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator <=( 
        radians<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) <= 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator <=( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        radians<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) <= 0;
    }
 
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator ==( 
        radians<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) == 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator ==( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        radians<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) == 0;
    }

//!=
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator !=( 
        radians<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) != 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator !=( 
        fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>const& lhs,
        radians<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) != 0;
    }

//>=
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator >=( 
        radians<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) >= 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator >=( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        radians<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) >= 0;
    }

// >
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator >( 
        radians<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) > 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator >( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        radians<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) > 0;
    }

 // useful container for angles

    template<typename Value_type>
    struct of_angle_{
        
        //typedef rational_c<long,1>       rpf1;
        //typedef rational_c<long,2>       rpf2;
        //typedef rational_c<long,360>     rpf360;
        /*typedef pqs::meta::rational_c<long,21600>   rpf21600;
        typedef pqs::meta::rational_c<long,1296000> rpf1296000;*/
        typedef fraction_of_revolution<
            pqs::meta::rational_c<long,1>,
            pqs::meta::rational_c<long,360>,
            Value_type
        > deg;
        typedef fraction_of_revolution<
            pqs::meta::rational_c<long,1>,
            pqs::meta::rational_c<long,21600>,
            Value_type
        > min;
        typedef fraction_of_revolution<
            pqs::meta::rational_c<long,1>,
            pqs::meta::rational_c<long,1296000>,
            Value_type
        > s;
        typedef fraction_of_revolution<
            pqs::meta::rational_c<long,1>,
            pqs::meta::rational_c<long,1>,
            Value_type
        > rev;
        typedef radians<
            pqs::meta::rational_c<long,1>,
            Value_type
        > rad;
        typedef radians<
            pqs::meta::rational_c<long,2>,
            Value_type
        > sr; 
        static const rad   one;
        static const rad   pi;
        static const rad   two_pi;
        
    };
    struct of_angle : of_angle_<pqs::of_quantity::default_value_type>{};

}}//pqs::math

#endif
