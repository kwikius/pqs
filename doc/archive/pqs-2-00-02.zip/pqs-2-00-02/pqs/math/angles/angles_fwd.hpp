#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_MATH_ANGLES_ANGLES_FWD_HPP
#define PQS_MATH_ANGLES_ANGLES_FWD_HPP
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    forward decl of angles
*/

namespace pqs{namespace math{
    //radians  "just a number with more attributes"
    template <
        typename Extent,    // to power 1 -1, 2 etc
        typename Value_type
    >
    class radians;

    // other angles
    template<
        typename Extent,    // to power 1 -1, 2 etc
        typename Fraction,  // a compile time fraction of a revolution
        typename Value_type
    >
    class fraction_of_revolution;

}}//pqs::math




#endif

