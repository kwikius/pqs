#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_MATH_ANGLES_OUT_HPP_INCLUDED
#define PQS_MATH_ANGLES_OUT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    stream output for angles
*/

#include <string>
#include "pqs/math/angles/angles.hpp"
#include "pqs/math/angles/radians_out.hpp"

namespace pqs{namespace math{

    template<typename Value_type>
    inline
    std::string 
    units_str(fraction_of_revolution<
            pqs::meta::rational_c<long,1>,
            pqs::meta::rational_c<long,360>,
            Value_type
        > const& ang)
    {
        return "deg";
    }

    template<typename Value_type>
    inline
    std::string 
    units_str(fraction_of_revolution<
            pqs::meta::rational_c<long,-1>,
            pqs::meta::rational_c<long,1,360>,
            Value_type
        > const& ang)
    {
        return "deg-1";
    }

    template<typename Value_type>
    inline
    std::string 
    units_str(fraction_of_revolution<
            pqs::meta::rational_c<long,1>,
            pqs::meta::rational_c<long,360 * 60>,
            Value_type
        > const& ang)
    {
        return "min";
    }

    template<typename Value_type>
    inline
    std::string 
    units_str(fraction_of_revolution<
            pqs::meta::rational_c<long,-1>,
            pqs::meta::rational_c<long,1,360 * 60>,
            Value_type
        > const& ang)
    {
        return "min-1";
    }

    template<typename Value_type>
    inline
    std::string 
    units_str(fraction_of_revolution<
            pqs::meta::rational_c<long,1>,
            pqs::meta::rational_c<long,360 * 60 *60>,
            Value_type
        > const& ang)
    {
        return "sec";
    }

    template<typename Value_type>
    inline
    std::string 
    units_str(fraction_of_revolution<
            pqs::meta::rational_c<long,-1>,
            pqs::meta::rational_c<long,1,360 * 60 *60>,
            Value_type
        > const& ang)
    {
        return "sec-1";
    }

    template<
        typename Extent,
        typename ReciprocalFraction,
        typename Value_type>
    inline
    std::ostream & 
    operator << (
        std::ostream& os,
        fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            Value_type
        > const& ang)
    {
        os << ang.numeric_value() << ' ' << units_str(ang) ;
        return os;
    }

}}//pqs::math


namespace pqs{namespace meta{

    template < 
        typename Extent,
        typename ReciprocalFraction,
        typename Value_type
    >
    struct binary_operation< 
        std::ostream,
        pqs::shift_left, 
        pqs::math::fraction_of_revolution<Extent, ReciprocalFraction,Value_type>
    >{
        typedef std::ostream& result_type;
    };

}}//pqs::meta

#endif
