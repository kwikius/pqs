#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_MATH_ANGLES_FRACTION_OF_REVOLUTION_HPP_INCLUDED
#define PQS_MATH_ANGLES_FRACTION_OF_REVOLUTION_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/* 
    fraction of revolution for angles such as degrees etc
*/

#include "pqs/math/angles/angles_fwd.hpp"
#include "pqs/ct_quantity/operations/detail/convert.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include "pqs/math/constant.hpp"
#include "pqs/type_traits/is_angle_value_type.hpp"
#include "pqs/meta/binary_operation_if.hpp"
#include "pqs/meta/is_valid_binary_operation.hpp"
#include "pqs/meta/binary_log_transform.hpp"
#include "boost/mpl/and.hpp"

namespace pqs{namespace math{

    template<
        typename Extent,    // pqs::meta::rational_c<long, N,D>
        typename ReciprocalFraction,  // pqs::meta::rational_c<long, N,D>
        typename Value_type
    >
    class fraction_of_revolution{
        Value_type m_value;
    public:
        typedef typename Extent::type extent_type;
        typedef typename ReciprocalFraction::type fraction_type;
        typedef Value_type value_type;
        typedef fraction_of_revolution type;
        fraction_of_revolution(): m_value(static_cast<Value_type>(0)){}
        explicit fraction_of_revolution(Value_type const& v)
        :m_value(v){}
        template < typename Value_type1>
        explicit fraction_of_revolution(Value_type1 const & v)
        :m_value(pqs::detail::implicit_initialise<Value_type>(v)){}
        fraction_of_revolution(fraction_of_revolution const& fr)
        :m_value(fr.m_value){}
        template<typename ReciprocalFraction1, typename Value_type1>
        fraction_of_revolution(fraction_of_revolution<
                Extent,
                ReciprocalFraction1,
                Value_type1
        > const & fr)
        : m_value( fr.numeric_value() * 
            typename pqs::meta::binary_operation<
                ReciprocalFraction, std::divides,ReciprocalFraction1
            >::result_type::eval()()){}
        template< typename Value_type1>
        fraction_of_revolution(pqs::math::radians<Extent,Value_type1> const & r)
        : m_value( r.numeric_value() * typename ReciprocalFraction::eval()() 
            / (2.0 * constant::pi)){}
        Value_type numeric_value()const{return m_value;}
       // Value_type const& operator()() const {return m_value;}
        // add rad ops
        fraction_of_revolution operator +()const
        {
            return *this;
        }
        fraction_of_revolution operator -()const
        {
            fraction_of_revolution t(-this->numeric_value());
            return t;
        }
        
        fraction_of_revolution& operator +=(fraction_of_revolution const & in)
        {
            m_value += in.m_value;
            return *this;
        }

        fraction_of_revolution& operator -=(fraction_of_revolution const & in)
        {
            m_value -= in.m_value;
             return *this;
        }

        template<typename ReciprocalFraction1, typename Value_type1>
        fraction_of_revolution& operator +=(fraction_of_revolution<
            Extent,
            ReciprocalFraction1,
            Value_type1
        > const & in)
        {
            fraction_of_revolution t(in);
            m_value += t.m_value;
            return *this;
        }

        template<typename ReciprocalFraction1, typename Value_type1>
        fraction_of_revolution& operator -=(fraction_of_revolution<
            Extent,
            ReciprocalFraction1,
            Value_type1
        > const & in)
        {
            fraction_of_revolution t(in);
            m_value -= t.m_value;
            return *this;
        }
       
        template<typename Value_type1>
        fraction_of_revolution& operator *=(Value_type1 const & in)
        {
            m_value *= in;
            return *this;
        }

        template<typename Value_type1>
        fraction_of_revolution& operator /=(Value_type1 const & in)
        {
            m_value /= in;
            return *this;
        }           
    };

    template< long D,typename ReciprocalFraction,typename Value_type>
    class fraction_of_revolution<pqs::meta::rational_c<long,0,D>,ReciprocalFraction, Value_type>{
    public:
       typedef Value_type type;
    };

    template<int D,typename ReciprocalFraction,typename Value_type>
    class fraction_of_revolution<pqs::meta::rational_c<int,0,D>,ReciprocalFraction, Value_type>{
    public:
       typedef Value_type type;
    };

}}//pqs::math

namespace pqs{ namespace type_traits{
    template<
        typename Extent,
        typename ReciprocalFraction,
        typename Value_type
    >
    struct is_ct_quantity_value_type<
        math::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            Value_type
        >
    >{
        enum{value 
        = is_ct_quantity_value_type<Value_type>::value};
        typedef is_ct_quantity_value_type type;
    };
}}// pqs::type_traits

namespace pqs{namespace meta{

//binary operations between fraction_of_revolution's (e.g degrees minutes etc)
//frl + frr
    template<
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
        std::plus,
        pqs::math::fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
    >{
        typedef typename pqs::math::fraction_of_revolution<
            Extent,
            typename boost::mpl::if_c<
               ( pqs::meta::rational_ice_binary_operator<
                    ReciprocalFractionL,
                    std::greater,
                    ReciprocalFractionR
                >::result_value ),
                typename ReciprocalFractionL::type,
                typename ReciprocalFractionR::type
            >::type,
            typename binary_operation<
                Value_typeL,
                std::plus,
                Value_typeR
            >::result_type
        >::type result_type;
    };

// frl - frr
    template<
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
        std::minus,
        pqs::math::fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
    >{
        typedef typename pqs::math::fraction_of_revolution<
            Extent,
            typename boost::mpl::if_c<
               ( pqs::meta::rational_ice_binary_operator<
                    ReciprocalFractionL,
                    std::greater,
                    ReciprocalFractionR
                >::result_value ),
                typename ReciprocalFractionL::type,
                typename ReciprocalFractionR::type
            >::type,
            typename binary_operation<
                Value_typeL,
                std::minus,
                Value_typeR
            >::result_type
        >::type result_type;
    };

// fr * v
    template<
        typename Extent,
        typename ReciprocalFraction, 
        typename Value_type,  
        typename Value_type1
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<Extent,ReciprocalFraction,Value_type>,
        std::multiplies,
        Value_type1,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::type_traits::is_angle_value_type<Value_type1>,
                pqs::meta::is_valid_binary_operation<
                    Value_type,
                    std::multiplies,
                    Value_type1
                >
            >
        >::type
    >{
        typedef typename pqs::math::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            typename binary_operation<
                Value_type,
                std::multiplies,
                Value_type1
            >::result_type
        >::type result_type;
    };

// v * fr
    template<
        typename Value_type1,
        typename Extent,
        typename ReciprocalFraction, 
        typename Value_type
    >
    struct binary_operation<
        Value_type1,
        std::multiplies,
        pqs::math::fraction_of_revolution<Extent,ReciprocalFraction,Value_type>,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::type_traits::is_angle_value_type<Value_type1>,
                pqs::meta::is_valid_binary_operation<
                    Value_type1,
                    std::multiplies,
                    Value_type
                >
            >
        >::type
    >{
        typedef typename pqs::math::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            typename binary_operation<
                Value_type,
                std::multiplies,
                Value_type1
            >::result_type
        >::type result_type;
    };

// fr / v
    template<
        typename Extent,
        typename ReciprocalFraction, 
        typename Value_type,  
        typename Value_type1
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<Extent,ReciprocalFraction,Value_type>,
        std::divides,
        Value_type1,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::type_traits::is_angle_value_type<Value_type1>,
                pqs::meta::is_valid_binary_operation<
                    Value_type,
                    std::divides,
                    Value_type1
                >
            >
        >::type
    >{
        typedef typename pqs::math::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            typename binary_operation<
                Value_type,
                std::divides,
                Value_type1
            >::result_type
        >::type result_type;
        
    };

// v / fr;
    template<
        typename Extent,
        typename ReciprocalFraction, 
        typename Value_type,  
        typename Value_type1
    >
    struct binary_operation<
        Value_type1,
        std::divides,
        pqs::math::fraction_of_revolution<Extent,ReciprocalFraction,Value_type>,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::type_traits::is_angle_value_type<Value_type1>,
                pqs::meta::is_valid_binary_operation<
                    Value_type1,
                    std::divides,
                    Value_type
                >
            >
        >::type
    >{
        typedef typename pqs::math::fraction_of_revolution<
            typename pqs::meta::unary_operation<std::negate,Extent>::result_type,
            typename pqs::meta::unary_operation<pqs::reciprocal,ReciprocalFraction>::result_type,
            typename pqs::meta::binary_operation<
                Value_type,
                std::divides,
                Value_type1
            >::result_type
        >::type result_type;
    };

// fra / frb 
    template < 
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
        std::divides,
        pqs::math::fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>
    >{
        typedef typename pqs::math::fraction_of_revolution<
           typename binary_log_transform<
                ExtentL,
                std::divides,
                ExtentR
            >::result_type,
        // other way up ???
            typename binary_operation<
                ReciprocalFractionL,
                std::divides,
                ReciprocalFractionR
            >::result_type,
            typename binary_operation<
                Value_typeL,
                std::divides,
                Value_typeR
            >::result_type
        >::type  result_type;
    };

// fra * frb
    template < 
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        pqs::math::fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
        std::multiplies,
        pqs::math::fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>
    >{
        typedef typename pqs::math::fraction_of_revolution<
           typename binary_log_transform<
                ExtentL,
                std::multiplies,
                ExtentR
            >::result_type,
            typename binary_operation<
                ReciprocalFractionL,
                std::multiplies,
                ReciprocalFractionR
            >::result_type,
            typename binary_operation<
                Value_typeL,
                std::multiplies,
                Value_typeR
            >::result_type
        >::type  result_type;
    };
}}//pqs::meta
namespace pqs{ namespace math{
// fr + fr
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
        std::plus,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
    >::result_type     
    operator +(fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL> const& lhs,
               fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR> const& rhs)
    {
        typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
            std::plus,
            fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
        >::result_type t(lhs);
        t += rhs;
        return t;    
    }

// fr - fr
     template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
        std::minus,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
    >::result_type     
    operator -(fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL> const& lhs,
               fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR> const& rhs)
    {
        typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>,
            std::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>
        >::result_type t(lhs);
        t -= rhs;
        return t;    
    } 

// fr * fr
    template < 
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
        std::multiplies,
        fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>
    >::result_type
    operator*(fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL> const & lhs,
        fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR> const & rhs)
    {
        typedef typename pqs::meta::binary_log_transform<
            ExtentL,
            std::multiplies,
            ExtentR
        >::result_type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // unlike radians for fraction-of-revolution types
        // only multiplication by fraction_of_revolution;s
        // with resulting Extent of 0 is valid
        pqs::concept_checking::Assert<extent_type::is_zero>();
        //////////////////////CONCEPT CHECK/////////////////////////////

        typedef typename pqs::meta::binary_operation<
            ReciprocalFractionL, std::multiplies,ReciprocalFractionR
        >::result_type eval_type;
 
        return typename pqs::meta::binary_operation<
            fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
            std::multiplies,
            fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>
        >::result_type( lhs.numeric_value() * rhs.numeric_value() /
            typename eval_type::eval()()); 
    }

    template < 
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline
    typename pqs::meta::binary_operation<
        fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
        std::divides,
        fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>
    >::result_type
    operator/(fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL> const & lhs,
        fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR> const & rhs)
    {
        typedef typename pqs::meta::binary_log_transform<
            ExtentL,
            std::divides,
            ExtentR
        >::result_type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only division by fraction_of_revolution;s
        // with resulting extent of 0 is valid
        pqs::concept_checking::Assert<extent_type::is_zero>();
        //////////////////////CONCEPT CHECK/////////////////////////////

        typedef typename pqs::meta::binary_operation<
            ReciprocalFractionR, std::divides,ReciprocalFractionL
        >::result_type eval_type;
 
        return typename pqs::meta::binary_operation<
            fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
            std::divides,
            fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>
        >::result_type( lhs.numeric_value() / rhs.numeric_value() *
            typename eval_type::eval()()); 
    }

// fr * v
    template<
        typename ExtentL,
        typename ReciprocalFractionL, 
        typename Value_typeL,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation_if<
        pqs::type_traits::is_angle_value_type<Value_type>,
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        std::multiplies,
        Value_type
    >::result_type    
    operator *(fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>const& lhs,
            Value_type const& rhs)
    {
        typename pqs::meta::binary_operation<
            fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
            std::multiplies,
            Value_type
        >::result_type t(lhs);
        t *= rhs;
        return t;   
    }
// v * fr
    template<
        typename Value_type,
        typename ExtentR,
        typename ReciprocalFractionR, 
        typename Value_typeR>
    inline
    typename pqs::meta::binary_operation_if<
        pqs::type_traits::is_angle_value_type<Value_type>,
        Value_type,
        std::multiplies,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > 
    >::result_type     
    operator *(Value_type const&  lhs,
             fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>const& rhs)
    {
        return typename pqs::meta::binary_operation<
            Value_type,
            std::multiplies,
            fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR> 
        >::result_type ( lhs * rhs.numeric_value());   
    }

//fr / v 
    template<
        typename ExtentL,
        typename ReciprocalFractionL, 
        typename Value_typeL,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation_if<
        pqs::type_traits::is_angle_value_type<Value_type>,
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        std::divides,
        Value_type
    >::result_type     
    operator /(fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>const& lhs,
            Value_type const& rhs)
    {
        typename pqs::meta::binary_operation<
            fraction_of_revolution<ExtentL,ReciprocalFractionL,Value_typeL>,
            std::divides,
            Value_type
        >::result_type t(lhs);
        t /= rhs;
        return t;   
    }

// v / fr
    template<
        typename Value_type,
        typename ExtentR,
        typename ReciprocalFractionR, 
        typename Value_typeR>
    inline
    typename pqs::meta::binary_operation_if<
        pqs::type_traits::is_angle_value_type<Value_type>,
        Value_type,
        std::divides,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > 
    >::result_type 
    operator /(Value_type const&  lhs,
             fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR>const& rhs)
    {
        return typename pqs::meta::binary_operation<
            Value_type,
            std::divides,
            fraction_of_revolution<ExtentR,ReciprocalFractionR,Value_typeR> 
        >::result_type ( lhs / rhs.numeric_value());   
    }

    // abs
    template<
        typename Extent, 
        typename ReciprocalFraction,
        typename Value_type
    >
    inline 
    fraction_of_revolution<Extent,ReciprocalFraction, Value_type>
    abs(fraction_of_revolution<Extent,ReciprocalFraction, Value_type>const& in)
    {
      return in.numeric_value() < 0 ? -in : in;   
    }

    //comparisons
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline int compare( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs,
        typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>,
            std::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>
        >::result_type const & eps =
        typename pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>,
            std::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>
        >::result_type(PQS_COMPARISON_EPSILON)
     )   
    {
        typedef typename pqs::meta::binary_operation<
            Value_typeL,std::minus,Value_typeR
        >::result_type comp_value_type;
        return ((abs(lhs-rhs)).numeric_value() <= eps.numeric_value()())
        ? 0 
        :(((lhs-rhs).numeric_value() < static_cast<comp_value_type>(0))
            ? -1
            : 1);
    }
// <
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator<( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) < 0;
    }

 // <=
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator<=( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) <= 0;
    }

 //==
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator==( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) == 0;
    }
//!=
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator !=( 
        fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) != 0;
    }
// >=
 template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator>=( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) >= 0;
    }

// >
     template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator >( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) > 0;
    }

}}//pqs::math

#endif
