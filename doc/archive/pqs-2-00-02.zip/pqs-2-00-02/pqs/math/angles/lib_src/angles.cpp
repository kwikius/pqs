//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    pi as an angle, and two_pi;
*/

// note: also requires linking of "pqs/math/constant/lib_src/constant.cpp"

#include "pqs/math/angles/angles.hpp"
// required for this header
#ifndef PQS_MATH_CONSTANT_LIB_SRC_CPP_INCLUDED
#include "pqs/math/lib_src/constant.cpp"
#endif
// static pqs::math::of_angle_<T> member definitions

template<typename Value_type>
typename pqs::math::of_angle_<Value_type>::rad const
pqs::math::of_angle_<Value_type>::one 
= typename pqs::math::of_angle_<Value_type>::rad(1);

template<typename Value_type>
typename pqs::math::of_angle_<Value_type>::rad const
pqs::math::of_angle_<Value_type>::pi 
= typename pqs::math::of_angle_<Value_type>::rad(pqs::math::constant_<Value_type>::pi);

template<typename Value_type>
typename pqs::math::of_angle_<Value_type>::rad const
pqs::math::of_angle_<Value_type>::two_pi 
= typename pqs::math::of_angle_<Value_type>::rad(2 * pqs::math::constant_<Value_type>::pi);


