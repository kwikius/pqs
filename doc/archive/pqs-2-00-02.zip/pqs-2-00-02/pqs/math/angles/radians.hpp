#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_ANGLES_RADIANS_HPP_INCLUDED
#define PQS_ANGLES_RADIANS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    radians implementation.
    radian can be seen as a numeric type with extra attributes
    therefore can be 'decayed' to its value_type.
    The Extent parameter is a rational number so radians  has an extent of 1
    , while steradians has an extent of two
    That said current semantics make radian s * radians = steradians
    ... but maybe not good semantics ultimately
    Other angles ie degrees cannot be 'decayed' in same way,
    but can be converted to from radians 
*/

#include <cmath>
#include "pqs/math/angles/angles_fwd.hpp"
#include "pqs/ct_quantity/ct_quantity_fwd.hpp"
#include "pqs/ct_quantity/operations/detail/convert.hpp"
#include "pqs/meta/rational_c.hpp"
#include "pqs/type_traits/is_angle_value_type.hpp"
#include "pqs/meta/binary_operation_if.hpp"
#include "pqs/meta/is_valid_binary_operation.hpp"
#ifdef  PQS_IMPLICIT_RADIANS_STRAIGHTENING
#include "pqs/type_traits/is_complex_value_type.hpp"
#endif
#include "pqs/type_traits/is_ct_quantity_value_type.hpp"
#include "boost/utility/enable_if.hpp"
#include "boost/mpl/and.hpp"

namespace pqs{namespace math{

    template < 
        typename Extent,   // pqs::meta::rational_c<long, N,D>
        typename Value_type
    >
    class radians{
        Value_type m_value; 
    public:
        typedef Value_type value_type;
        typedef typename Extent::type extent_type;
        typedef radians type;
        radians(): m_value(static_cast<Value_type>(0)){}

#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
        radians(Value_type const & v): m_value(v){}
        template<typename Value_type1>
        radians(Value_type1 const & v)
        : m_value(pqs::detail::implicit_initialise<Value_type>(v)){}
#else
        explicit radians(Value_type const & v): m_value(v){}
        template<typename Value_type1>
        explicit radians(Value_type1 const & v)
        : m_value(pqs::detail::implicit_initialise<Value_type>(v)){}
#endif

        radians(const radians& in)
        :m_value(in.m_value){}
        template< typename Value_type1 >
        radians(radians<Extent,Value_type1> const & r)
        :m_value(pqs::detail::implicit_initialise<Value_type>(r.m_value)){}
        template<typename ReciprocalFraction,typename Value_type1>
        inline radians(fraction_of_revolution<Extent,ReciprocalFraction,Value_type1> const & fr);
        Value_type numeric_value()const {return m_value;}

#ifdef PQS_IMPLICIT_RADIANS_STRAIGHTENING
        operator Value_type()const {return m_value;}
#endif
        radians operator -()const
        {
            return radians(-this->m_value);
        }
        radians operator +()const
        {
            return radians( this->m_value);
        }
        //add fraction_of_rev ops
        template<typename Value_type1>
        radians & operator +=(radians<Extent,Value_type1> const & in)
        {
            this->m_value += in.numeric_value();
            return *this;
        }
        template<typename Value_type1>
        radians & operator -=(radians<Extent,Value_type1> const & in)
        {
            this->m_value -= in.numeric_value();
            return *this;
        }
        template<typename Value_type1>
        radians & operator *=(Value_type1 const & in)
        {
            this->m_value *= in;
            return *this;
        }
        template<typename Value_type1>
        radians & operator /=(Value_type1 const & in)
        {
            this->m_value /= in;
            return *this;
        }
    };

    template <int N,typename Value_type >
    class radians<
        pqs::meta::rational_c<int,0,N>,
        Value_type
    >{
    public:
        typedef Value_type value_type;
        typedef Value_type type;
    };

    template <long N,typename Value_type >
    class radians<
        pqs::meta::rational_c<long,0,N>,
        Value_type
    >{
    public:
        typedef Value_type value_type;
        typedef Value_type type;
    };
    
}}//pqs::math

namespace pqs{namespace type_traits{
    
    template<
        typename Extent,
        typename Value_type
    >
    struct is_ct_quantity_value_type<
        pqs::math::radians<
            Extent,
            Value_type
        >
    >{
        enum{
            value 
            = static_cast<bool>(
                pqs::type_traits::is_ct_quantity_value_type<
                    Value_type
                >::value
            )
        };
        typedef is_ct_quantity_value_type type;
    };
#ifdef  PQS_IMPLICIT_RADIANS_STRAIGHTENING    
    template <
        typename Extent, 
        typename Value_type
    >
    struct is_complex_value_type<
        pqs::math::radians<
            Extent,
            Value_type
        >
    >{
        enum{
            value = 
            static_cast<bool>(
                pqs::type_traits::is_complex_value_type<
                    Value_type
                >::value
            )
        } ;
        typedef is_complex_value_type  type; 
    };
#endif

}}// pqs::type_traits

namespace pqs{namespace meta{

//r + r
    template< 
        typename Value_typeA,
        typename Extent,
        typename Value_typeB
    >
    struct binary_operation<
            pqs::math::radians<Extent,Value_typeA>,
            std::plus,
            pqs::math::radians<Extent,Value_typeB>
    >
    {
        typedef  typename pqs::math::radians<
            Extent,
            typename pqs::meta::binary_operation<
                Value_typeA,
                std::plus,
                Value_typeB
            >::result_type
        >::type  result_type;

    };
// r - r
    template< 
        typename Value_typeA,
        typename Extent,
        typename Value_typeB
    >
    struct binary_operation<
            pqs::math::radians<Extent,Value_typeA>,
            std::minus,
            pqs::math::radians<Extent,Value_typeB>
    >
    {
        typedef  typename pqs::math::radians<
            Extent,
            typename pqs::meta::binary_operation<
                Value_typeA,
                std::minus,
                Value_typeB
            >::result_type
        >::type  result_type;

    };
// ra * rb
    template<
        typename ExtentA,
        typename Value_typeA,
        typename ExtentB,
        typename Value_typeB
    >
    struct binary_operation<
            pqs::math::radians<ExtentA,Value_typeA>,
            std::multiplies,
            pqs::math::radians<ExtentB,Value_typeB>
    >
    {
        typedef  typename pqs::math::radians<
            typename binary_operation<
                ExtentA,
                std::plus,
                ExtentB
            >::result_type,
            typename pqs::meta::binary_operation<
                Value_typeA,
                std::multiplies,
                Value_typeB
            >::result_type
        >::type  result_type;

    };
// r * v
    template<
        typename Extent,
        typename Value_type,
        typename Value_type1
    >
    struct binary_operation<
            pqs::math::radians<Extent,Value_type>,
            std::multiplies,
            Value_type1,
            typename boost::enable_if<
                boost::mpl::and_<
                    pqs::type_traits::is_angle_value_type<Value_type1>,
                    pqs::meta::is_valid_binary_operation<
                        Value_type,
                        std::multiplies,
                        Value_type1
                    >
                >
            >::type
    >
    {
        typedef  typename pqs::math::radians<
            Extent,
            typename pqs::meta::binary_operation<
                Value_type,
                std::multiplies,
                Value_type1
            >::result_type
        >::type  result_type;
    };
// v * r
    template<
        typename Value_type1,
        typename Extent,
        typename Value_type
    >
    struct binary_operation<
            Value_type1,
            std::multiplies,
            pqs::math::radians<Extent,Value_type>,
            typename boost::enable_if<
                boost::mpl::and_<
                    pqs::type_traits::is_angle_value_type<Value_type1>,
                    pqs::meta::is_valid_binary_operation<
                        Value_type1,
                        std::multiplies,
                        Value_type
                    >
                >
            >::type  
    >
    {
        typedef  typename pqs::math::radians<
            Extent,
            typename pqs::meta::binary_operation<
                Value_type1,
                std::multiplies,
                Value_type
            >::result_type
        >::type  result_type;
    };
// ra / rb
    template<
        typename ExtentA,
        typename Value_typeA,
        typename ExtentB,
        typename Value_typeB
    >
    struct binary_operation<
            pqs::math::radians<ExtentA,Value_typeA>,
            std::divides,
            pqs::math::radians<ExtentB,Value_typeB>
    >
    {
        typedef  typename pqs::math::radians<
            typename pqs::meta::binary_operation<
                ExtentA,
                std::minus,
                ExtentB
            >::result_type,
            typename pqs::meta::binary_operation<
                Value_typeA,
                std::divides,
                Value_typeB
            >::result_type
        >::type  result_type;

    };
// r / v
    template< 
        typename Extent,
        typename Value_type,
        typename Value_type1
    >
    struct binary_operation<
            pqs::math::radians<Extent,Value_type>,
            std::divides,
            Value_type1,
            typename boost::enable_if<
                boost::mpl::and_<
                    pqs::type_traits::is_angle_value_type<Value_type1>,
                    pqs::meta::is_valid_binary_operation<
                        Value_type,
                        std::divides,
                        Value_type1
                    >
                >
            >::type
    >
    {
        typedef typename pqs::math::radians<
            Extent,
            typename pqs::meta::binary_operation<
                Value_type,
                std::divides,
                Value_type1
            >::result_type
        >::type  result_type;

    };

// v / r
    template< 
        typename Value_type1,
        typename Extent,
        typename Value_type
    >
    struct binary_operation<
            Value_type1,
            std::divides,
            pqs::math::radians<Extent,Value_type>,
            typename boost::enable_if<
                boost::mpl::and_<
                    pqs::type_traits::is_angle_value_type<Value_type1>,
                    pqs::meta::is_valid_binary_operation<
                        Value_type1,
                        std::divides,
                        Value_type
                    >
                >
            >::type
    >
    {
        typedef typename pqs::math::radians<
            typename unary_operation<
                std::negate,
                Extent
            >::result_type,
            typename pqs::meta::binary_operation<
                Value_type1,
                std::divides,
                Value_type
            >::result_type
        >::type  result_type;

    };
    // r to power rational<int,N,D>
    template <typename Extent,typename Value_type, int N, int D>
    struct binary_operation<
         pqs::math::radians<Extent,Value_type>,
         pqs::to_power,
         pqs::meta::rational_c<int,N,D>
    >
    {
        typedef typename pqs::math::radians<
            typename pqs::meta::binary_operation<
                Extent,
                std::multiplies,
                typename pqs::meta::rational_c<int,N,D>::type
            >::result_type,
            typename pqs::meta::binary_operation<
                Value_type,
                pqs::to_power,
                typename pqs::meta::rational_c<int,N,D>::type
            >::result_type
        >::type result_type;
    };
    
}}//pqs::meta

namespace pqs{namespace math{

    template<
        typename Extent,
        typename Value_typeA,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        pqs::math::radians<Extent,Value_typeA>,
        std::plus,
        pqs::math::radians<Extent,Value_typeB>
    >::result_type
    operator + (
        pqs::math::radians<Extent,Value_typeA> const & ra,
        pqs::math::radians<Extent,Value_typeB> const & rb
    )
    {
        typename pqs::meta::binary_operation<
            pqs::math::radians<Extent,Value_typeA>,
            std::plus,
            pqs::math::radians<Extent,Value_typeB>
        >::result_type t (ra);
        t += rb;
        return t;       
    }

    template<
        typename Extent,
        typename Value_typeA,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        pqs::math::radians<Extent,Value_typeA>,
        std::minus,
        pqs::math::radians<Extent,Value_typeB>
    >::result_type
    operator - (
        pqs::math::radians<Extent,Value_typeA> const & ra,
        pqs::math::radians<Extent,Value_typeB> const & rb
    )
    {
        typename pqs::meta::binary_operation<
            pqs::math::radians<Extent,Value_typeA>,
            std::minus,
            pqs::math::radians<Extent,Value_typeB>
        >::result_type t (ra);
        t -= rb;
        return t;       
    }

    template<
        typename ExtentA,
        typename Value_typeA,
        typename ExtentB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        pqs::math::radians<ExtentA,Value_typeA>,
        std::multiplies,
        pqs::math::radians<ExtentB,Value_typeB>
    >::result_type
    operator * (
        pqs::math::radians<ExtentA,Value_typeA> const & ra,
        pqs::math::radians<ExtentB,Value_typeB> const & rb
    )
    {
        typename pqs::meta::binary_operation<
            pqs::math::radians<ExtentA,Value_typeA>,
            std::multiplies,
            pqs::math::radians<ExtentB,Value_typeB>
        >::result_type t (ra.numeric_value() * rb.numeric_value());
        return t;       
    }

    template<
        typename Extent,
        typename Value_type,
        typename Value_type1
    >
    inline
    typename pqs::meta::binary_operation_if<
        pqs::type_traits::is_angle_value_type<Value_type1>,
        pqs::math::radians<Extent,Value_type>,
        std::multiplies,
        Value_type1
    >::result_type
    operator * (
        pqs::math::radians<Extent,Value_type> const & ra,
        Value_type1 const & b)
    {
        typename pqs::meta::binary_operation<
            pqs::math::radians<Extent,Value_type>,
            std::multiplies,
            Value_type1
        >::result_type t (ra.numeric_value() * b);
        return t;       
    }

    template<
        typename Value_type1,
        typename Extent,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation_if<
        pqs::type_traits::is_angle_value_type<Value_type1>,
        Value_type1,
        std::multiplies,
        pqs::math::radians<Extent,Value_type>  
    >::result_type
    operator * (
        Value_type1 const & b,
        pqs::math::radians<Extent,Value_type> const & ra
    )
    {
        typename pqs::meta::binary_operation<
            Value_type1,
            std::multiplies,
            pqs::math::radians<Extent,Value_type>
        >::result_type t (b * ra.numeric_value());
        return t;       
    }

    template<
        typename ExtentA,
        typename Value_typeA,
        typename ExtentB,
        typename Value_typeB
    >
    inline
    typename pqs::meta::binary_operation<
        pqs::math::radians<ExtentA,Value_typeA>,
        std::divides,
        pqs::math::radians<ExtentB,Value_typeB>
    >::result_type
    operator /(
        pqs::math::radians<ExtentA,Value_typeA> const & ra,
        pqs::math::radians<ExtentB,Value_typeB> const & rb
    )
    {
        typename pqs::meta::binary_operation<
            pqs::math::radians<ExtentA,Value_typeA>,
            std::divides,
            pqs::math::radians<ExtentB,Value_typeB>
        >::result_type t (ra.numeric_value() / rb.numeric_value());
        return t;       
    }

    template<
        typename Extent,
        typename Value_type,
        typename Value_type1
    >
    inline
    typename pqs::meta::binary_operation_if<
        pqs::type_traits::is_angle_value_type<Value_type1>,
        pqs::math::radians<Extent,Value_type>,
        std::divides,
        Value_type1
    >::result_type
    operator / (
        pqs::math::radians<Extent,Value_type> const & ra,
        Value_type1 const & b
    )
    {
        typename pqs::meta::binary_operation<
            pqs::math::radians<Extent,Value_type>,
            std::divides,
            Value_type1
        >::result_type t (ra.numeric_value() / b);
        return t;       
    }

    template<
        typename Value_type1,
        typename Extent,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation_if<
        pqs::type_traits::is_angle_value_type<Value_type1>,
        Value_type1,
        std::divides,
        pqs::math::radians<Extent,Value_type>  
    >::result_type
    operator / (
        Value_type1 const & b,
        pqs::math::radians<Extent,Value_type> const & ra)
    {
        typename pqs::meta::binary_operation<
            Value_type1,
            std::divides,
            pqs::math::radians<Extent,Value_type>
        >::result_type t (b / ra.numeric_value());
        return t;       
    }

    template<typename Value_type>
    inline
    Value_type cos(
        pqs::math::radians<pqs::meta::rational_c<long,1>,Value_type>const& r)
    {
        using std::cos;
        return cos(r.numeric_value());

    }

    template<typename Value_type>
    inline
    Value_type sin(pqs::math::radians<pqs::meta::rational_c<long,1>,Value_type>const& r)
    {
        using std::sin;
        return sin(r.numeric_value());

    }

    template<typename Value_type>
    inline
    Value_type tan(pqs::math::radians<pqs::meta::rational_c<long,1>,Value_type>const& r)
    {
        using std::tan;
        return tan(r.numeric_value());
    }

}}//pqs::math

namespace pqs{

    template <
        int N,
        int D,
        typename Extent,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation<
        typename pqs::math::radians<Extent,Value_type>::type,
        pqs::to_power,
        typename pqs::meta::rational_c<int,N,D>::type
    >::result_type
        
    pow(pqs::math::radians<Extent,Value_type> const& r)
    {
        typedef  typename pqs::meta::binary_operation<
            typename pqs::math::radians<Extent,Value_type>::type,
            pqs::to_power,
            typename pqs::meta::rational_c<int,N,D>::type
        >::result_type result_type;
        return result_type(pqs::pow<N,D>(r.numeric_value()));
       
    }

    template <
        int N,
        typename Extent,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation<
        typename pqs::math::radians<Extent,Value_type>::type,
        pqs::to_power,
        typename pqs::meta::rational_c<int,N,1>::type
    >::result_type
        
    pow(pqs::math::radians<Extent,Value_type> const& r)
    {
        typedef  typename pqs::meta::binary_operation<
            typename pqs::math::radians<Extent,Value_type>::type,
            pqs::to_power,
            typename pqs::meta::rational_c<int,N,1>::type
        >::result_type result_type;
        return result_type(pqs::pow<N,1>(r.numeric_value()));
       
    }
}// pqs

namespace pqs{ namespace math{

    template< typename Extent, typename Value_type>
    inline
    pqs::math::radians<Extent,Value_type>
    abs(pqs::math::radians<Extent,Value_type> const& r)
    {
        pqs::math::radians<Extent,Value_type> ret =
        ( r.numeric_value() < static_cast<Value_type>(0))
        ? -r : r;
        return ret;
    }

    template<
        typename Extent, 
        typename Value_typeL,
        typename Value_typeR
    >
    inline
    int
    compare(radians<Extent,Value_typeL>const & lhs, 
        pqs::math::radians<Extent,Value_typeR> const& rhs ,
        pqs::math::radians<
            Extent,
            typename pqs::meta::binary_operation<
                Value_typeL,
                std::minus,
                Value_typeR
            >::result_type
        > const & epsilon =
         pqs::math::radians<
            Extent,
            typename pqs::meta::binary_operation<
                Value_typeL,
                std::minus,
                Value_typeR
            >::result_type
        >(PQS_COMPARISON_EPSILON)       
    )
    {
        typedef typename pqs::meta::binary_operation<
            pqs::math::radians<Extent, Value_typeL>,
            std::minus,
            pqs::math::radians<Extent, Value_typeR>
        >::result_type comp_type;
        return ((abs(lhs-rhs)).numeric_value() <= epsilon.numeric_value())
        ? 0 
        :(((lhs-rhs).numeric_value() < comp_type(0).numeric_value())
            ? -1
            : 1);
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator <(
        pqs::math::radians<Extent, Value_typeL>const & lhs, 
        pqs::math::radians<Extent,Value_typeR>const& rhs
    )
    {
        return compare(lhs,rhs) < 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator <=(
        pqs::math::radians<Extent,Value_typeL>const & lhs, 
        pqs::math::radians<Extent,Value_typeR>const& rhs
    )
    {
        return pqs::math::compare(lhs,rhs) <= 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator ==(
        pqs::math::radians<Extent, Value_typeL>const & lhs, 
        pqs::math::radians<Extent,Value_typeR>const& rhs
    )
    {
        return pqs::math::compare(lhs,rhs) == 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator !=(
        pqs::math::radians<Extent, Value_typeL>const & lhs, 
        pqs::math::radians<Extent,Value_typeR>const& rhs
    )
    {
        return pqs::math::compare(lhs,rhs) != 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator >=(
        pqs::math::radians<Extent, Value_typeL>const & lhs, 
        pqs::math::radians<Extent,Value_typeR>const& rhs
    )
    {
        return pqs::math::compare(lhs,rhs) >= 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator >(
        pqs::math::radians<Extent, Value_typeL>const & lhs, 
        pqs::math::radians<Extent,Value_typeR>const& rhs
    )
    {
        return pqs::math::compare(lhs,rhs) > 0;
    }

}}//pqs::math

#endif
