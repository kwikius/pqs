#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_ANGLES_RADIANS_OUT_HPP_INCLUDED
#define PQS_ANGLES_RADIANS_OUT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    stream output for radians and sr
*/

#include "pqs/math/angles/radians.hpp"
#include <iostream>

namespace pqs{namespace math{

    template<typename Value_type>
    inline std::string  
    units_str(radians<pqs::meta::rational_c<long,1>,Value_type> const & r)
    {
        return "rad";
    }

    template<typename Value_type>
    inline std::string  
    units_str(radians<pqs::meta::rational_c<long,-1>,Value_type> const & r)
    {
        return "rad-1";
    }

    template<typename Value_type>
    inline std::string  
    units_str(radians<pqs::meta::rational_c<long,2>,Value_type> const & r)
    {
        return "sr";
    }

    template<typename Value_type>
    inline std::string  
    units_str(radians<pqs::meta::rational_c<long,-2>,Value_type> const & r)
    {
        return "sr-1";
    }

    template<
        typename Extent,
        typename Value_type
    >
    inline
    std::ostream& 
    operator <<  (std::ostream& os,
                    radians<Extent,Value_type> const & r)
    {
        os << r.numeric_value() << ' ' << units_str(r);
        return os;
    }

   
}}//pqs::math

namespace pqs{namespace meta{

    template < 
        typename Extent,
        typename Value_type
    >
    struct binary_operation< 
        std::ostream,
        pqs::shift_left, 
        pqs::math::radians<Extent,Value_type>
    >{
        typedef std::ostream& result_type;
    };

}}//pqs::meta

#endif
