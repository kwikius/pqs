#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_MATH_CONSTANT_HPP_INCLUDED
#define PQS_MATH_CONSTANT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

//constants values provided by Paul Bristow
/*
    struct container for math constants
    note requires compilation/link of "pqs/math/constant.cpp"
*/

#include "pqs/ct_quantity/of_quantity.hpp"

namespace pqs{ namespace math {

   template<typename Value_type>
   struct constant_{
        static Value_type const & pi;
        static Value_type const & e;
        static Value_type const & sqrt2;
   };

   struct constant : constant_<of_quantity::default_value_type>{};

 }}//pqs::math
 
#endif

