
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.
#ifndef  PQS_MATH_CONSTANT_LIB_SRC_CPP_INCLUDED
#define  PQS_MATH_CONSTANT_LIB_SRC_CPP_INCLUDED

#include "pqs/math/constant.hpp"

// static members
template<>
long double const &  pqs::math::constant_<long double>::pi 
= 3.141592653589793238462643383279502884197L;

template<>
double const & pqs::math::constant_<double>::pi  
= 3.141592653589793238462643383279502884197;

template<>
float const & pqs::math::constant_<float>::pi  
= 3.141592653589793238462643383279502884197F;

template<>
long double const &  pqs::math::constant_<long double>::e 
= 0.5772156649015328606065120900824024310422L;

template<>
double const & pqs::math::constant_<double>::e  
= 0.5772156649015328606065120900824024310422;

template<>
float const & pqs::math::constant_<float>::e  
= 0.5772156649015328606065120900824024310422F;

template<>
long double const &  pqs::math::constant_<long double>::sqrt2 
= 1.41421356237309504880168872420969807857L;

template<>
double const & pqs::math::constant_<double>::sqrt2  
= 1.41421356237309504880168872420969807857;

template<>
float const & pqs::math::constant_<float>::sqrt2  
= 1.41421356237309504880168872420969807857F;

#endif
  

