#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_BINARY_LOG_TRANSFORM_HPP_INCLUDED
#define PHYSICAL_QUANTITIES_BINARY_LOG_TRANSFORM_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    binary_log_transform is
    used for entities representing powers
    transforms an op to its log equiv 
    so multiplies --> plus etc.
    for with binary_operation<A,Op,B>
*/

#include <functional>
#include "pqs/meta/binary_operation.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include "pqs/meta/is_valid_binary_operation.hpp"

namespace pqs{ namespace meta{

    template <
        typename A,
        template <typename> class Op,
        typename B
    >
    struct binary_log_transform 
    : pqs::concept_checking::Assert<
     pqs::meta::is_valid_binary_operation<A,Op,B>::value
    >{
       // typedef boost::mpl::void_ result_type;
    };
    
    template <
        typename A
    > 
    struct binary_log_transform<A,std::plus,A>{
        typedef A result_type;
    };

    template <
        typename A
    > 
    struct binary_log_transform<A,std::minus,A>{
        typedef A result_type;
    };

    template <
        typename A,
        typename B
    > 
    struct binary_log_transform<A,std::multiplies,B>{
        typedef typename binary_operation<
            A, 
            std::plus,
            B
        >::result_type result_type;
    };

    template <
        typename A,
        typename B
    > 
    struct binary_log_transform<A,std::divides,B>{
        typedef typename binary_operation<
            A, 
            std::minus,
            B
        >::result_type result_type;
    }; 

    template <
        typename A,
        typename B
    > 
    struct binary_log_transform<A,to_power,B>{
        typedef typename binary_operation<
            A, 
            std::multiplies,
            B
        >::result_type result_type;
    };  
    template <
        typename A,
        typename B
    > 
    struct binary_log_transform<A,to_root,B>{
        typedef typename binary_operation<
            A, 
            std::divides,
            B
        >::result_type result_type;
    };        
    
}}//pqs::meta

#endif
