#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_GENERIC_META_BINARY_OPERATION_HPP_INCLUDED
#define PQS_GENERIC_META_BINARY_OPERATION_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    binary_operation struct has one member 'result_type'
    which represents the type of the result of a binary operation.
    such as +, -, *, << ,!= ,== etc.
    The Op template template parameter 'token'
    is represented by the binary-functions in <functional>,
    (some extra Op tokens are provided in
    "pqs/operators/binary_operator_extra_keys.hpp")
    e.g for the result type of addition of 2 ints
    the typedef would look like
    binary_operation<int,std::plus,int>::result_type.
    
    
*/
/*
    modified to use enable_if 23/08/04
    default version has boost::mpl::void_
    as member. specialisation for arithmetic types
    assign, boolean ret types
*/

#include <functional>
//#include "pqs/meta/is_valid_bin_op_fwd.hpp"
#include "boost/type_traits/is_arithmetic.hpp"
#include "pqs/meta/promotion_traits.hpp"
#include "pqs/operators/binary_operator_traits.hpp"
#include "boost/mpl/if.hpp"
#include "boost/mpl/and.hpp"
#include "boost/mpl/not.hpp"
#include "boost/mpl/or.hpp"
#include "boost/utility/enable_if.hpp"

namespace pqs{ namespace meta{
    
    template <
       typename A,
       template <typename> class Op,
       typename B,
       typename Enable = void
    >
    struct binary_operation{
        typedef boost::mpl::void_ result_type;
    };

    template < 
        typename A, 
        template <typename> class Op,
        typename B
    >
    struct binary_operation<
        A,Op,B,
        typename boost::enable_if<
            pqs::is_assignment_operator<Op>
        >::type
    >{
        typedef A& result_type;
    };

    template < 
        typename A, 
        template <typename> class Op,
        typename B
    >
    struct binary_operation<
        A,Op,B,
        typename boost::enable_if<
            boost::mpl::or_<
                pqs::is_equality_operator<Op>,
                pqs::is_relational_operator<Op>,
                pqs::is_logical_or_operator<Op>,
                pqs::is_logical_and_operator<Op>
            >
        >::type
    >{
        typedef bool result_type;
    };

    template <
       typename A,
       template <typename> class Op,
       typename B
    >
    struct binary_operation<
        A,Op,B,
        typename boost::enable_if<
            boost::mpl::and_<
                boost::is_arithmetic<A>,
                boost::is_arithmetic<B>,
                boost::mpl::not_<
                    boost::mpl::or_<
                        boost::mpl::or_<
                            pqs::is_equality_operator<Op>,
                            pqs::is_relational_operator<Op>
                        >,
                        boost::mpl::or_<
                            pqs::is_logical_or_operator<Op>,
                            pqs::is_logical_and_operator<Op>,
                            pqs::is_assignment_operator<Op>
                        >
                    >
                >
            >
        >::type
    > {
           typedef typename arithmetic_promote<
                A,
                B
           >::type result_type;            
    };

}}//pqs::meta

#endif
