#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_BINARY_OPERATION_IF_HPP_INCLUDED
#define PQS_META_BINARY_OPERATION_IF_HPP_INCLUDED
/*
    binary_operation with encapsulated_enable_if
    for use in function return types
*/

#include "pqs/meta/binary_operation.hpp"

namespace pqs{ namespace meta{

    template <
        bool Condition,
        typename Left,
        template <typename> class Op,
        typename Right
    >
    struct binary_operation_if_c;

    template <
        typename Left,
        template <typename> class Op,
        typename Right
    >
    struct binary_operation_if_c<
        true,
        Left,
        Op,
        Right
    > {
        typedef  typename pqs::meta::binary_operation<
            Left,Op,Right
        >::result_type result_type;
    };
    

    template <
        typename Left,
        template <typename> class Op,
        typename Right
    >
    struct binary_operation_if_c<
        false,
        Left,
        Op,
        Right
    >{};

    template <
        typename Condition,
        typename Left,
        template <typename> class Op,
        typename Right
    >
    struct binary_operation_if : binary_operation_if_c<
        (static_cast<bool>(Condition::value)),
        Left, Op, Right
     >{};
            
}}//pqs::meta


#endif
