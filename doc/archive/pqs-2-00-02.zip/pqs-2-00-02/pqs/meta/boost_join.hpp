#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_JOIN_HPP_INCLUDED
#define BOOST_JOIN_HPP_INCLUDED
/*
 taken from boost/config/suffix.hpp which is:
  Boost config.hpp configuration header file  ------------------------------//

  (C) Copyright John Maddock 2001 - 2003. 
  (C) Copyright Darin Adler 2001. 
  (C) Copyright Peter Dimov 2001. 
  (C) Copyright Bill Kempf 2002. 
  (C) Copyright Jens Maurer 2002. 
  (C) Copyright David Abrahams 2002 - 2003. 
  (C) Copyright Gennaro Prota 2003. 
  (C) Copyright Eric Friedman 2003. 
  Use, modification and distribution are subject to the 
  Boost Software License, Version 1.0. (See accompanying file 
  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

  See http://www.boost.org for most recent version.

  Boost config.hpp policy and rationale documentation has been moved to
  http://www.boost.org/libs/config

 text from boost/config/suffix.hpp:
 Helper macro BOOST_JOIN:
 The following piece of macro magic joins the two 
 arguments together, even when one of the arguments is
 itself a macro (see 16.3.1 in C++ standard).  The key
 is that macro expansion of macro arguments does not
 occur in BOOST_DO_JOIN2 but does in BOOST_DO_JOIN.
*/

#define BOOST_JOIN( X, Y ) BOOST_DO_JOIN( X, Y )
#define BOOST_DO_JOIN( X, Y ) BOOST_DO_JOIN2(X,Y)
#define BOOST_DO_JOIN2( X, Y ) X##Y


#endif
