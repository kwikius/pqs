#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_PRIMITIVE_BINARY_OP_IMPL_HPP_INCLUDED
#define PQS_META_PRIMITIVE_BINARY_OP_IMPL_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/max_ice_exponent.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include <functional>

namespace pqs{
namespace meta{ namespace detail{
// definitions of ct_primitive_binary_operations
   
   template <
        typename IntegerTypeA,
        IntegerTypeA A,
        template <typename> class Op,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl;
    
    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::logical_or,
        IntegerTypeB,
        B
    >{  
        typedef typename binary_operation<
            IntegerTypeA,
            std::logical_or,
            IntegerTypeB
        >::result_type result_type;  
        enum{result_value = A || B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::logical_and,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,
            std::logical_and,
            IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A && B};
    };

     template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        bit_or,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,bit_or,IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A | B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        bit_xor,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
        IntegerTypeA,bit_xor,IntegerTypeB
        >::result_type result_type;
        enum{result_value = A ^ B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        bit_and,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,bit_and,IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A & B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::not_equal_to,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::not_equal_to,IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A != B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::equal_to,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::equal_to,IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A == B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::greater_equal,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::greater_equal,IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A >= B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::less_equal,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::less_equal,IntegerTypeB
        >::result_type result_type;
        enum{result_value = A <= B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::less,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::less,IntegerTypeB
        >::result_type result_type;
        enum{result_value = A < B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::greater,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::greater,IntegerTypeB
        >::result_type result_type;
        enum{result_value = A > B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        shift_right,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,shift_right,IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A >> B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        shift_left,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,shift_left,IntegerTypeB
        >::result_type result_type;
        enum{result_value = A << B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::plus,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::plus,IntegerTypeB
        >::result_type result_type;
        enum{result_value = A + B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::minus,
        IntegerTypeB,
        B
    >{
        typedef typename binary_operation<
            IntegerTypeA,std::minus,IntegerTypeB
        >::result_type result_type;
        enum{result_value = A - B};
    };
    
    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::multiplies,
        IntegerTypeB,
        B
    >{
        typedef typename binary_operation<
            IntegerTypeA,std::multiplies,IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A * B};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        std::divides,
        IntegerTypeB,
        B
    >{
        typedef typename binary_operation<
            IntegerTypeA,std::divides,IntegerTypeB
        >::result_type result_type;
        enum{ result_value = A / B};
    };

    template<
        typename BaseIntegerType,
        BaseIntegerType Base,
        unsigned long Exp>
    struct ice_to_power_impl;

    template<typename IntegerType,IntegerType Base>
    struct ice_to_power_impl<IntegerType,Base ,0UL>{
        enum{ value = 1};
    };

    template<typename IntegerType,IntegerType Base, unsigned long Exp>
    struct ice_to_power_impl{
        //////////////////////////////////////////////
        /* YOU GET HERE IF THE BASE EXPONENT COMBO
         IS INVALID FOR CALCULATING an :
        ice_binary_operator<
            typename IntegerBaseType,
            IntegerBaseType Base,
            pqs::to_power, 
            typename IntegerExpType,
            IntegerExpType Exp>

        either would give a value < 0 or would produce overflow
        */
        ////////////////////////////////////////////////////
        BOOST_STATIC_ASSERT( (Exp > 0) && \
        (Exp <= pqs::meta::max_ice_exponent<IntegerType,Base>::value) );
    
        enum{ value = 
        (Base * ice_to_power_impl<IntegerType,Base, Exp - 1 >::value)};
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator_impl<
        IntegerTypeA,
        A,
        to_power,
        IntegerTypeB,
        B
    >{
        typedef typename binary_operation<
            IntegerTypeA,std::multiplies,IntegerTypeB
        >::result_type result_type;

        enum{ result_value =(
                    ice_to_power_impl<
                        IntegerTypeA,
                        A,
                        static_cast<unsigned long>(B)
                    >::value  )};
    };
 
}}}//pqs::meta::detail

#endif

