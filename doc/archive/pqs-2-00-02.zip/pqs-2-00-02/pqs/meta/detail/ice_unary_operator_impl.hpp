#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_META_PRIMITIVE_UNARY_OPERATION_IMPL_HPP_INCLUDED
#define GENERIC_META_PRIMITIVE_UNARY_OPERATION_IMPL_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include <functional>

namespace pqs{
 namespace meta{ namespace detail{

    template <
        template<typename> class op,
        typename IntegerType,
        IntegerType V
    >
    struct ice_unary_operator_impl;

    template<
        typename IntegerType,
        IntegerType V
    >
    struct ice_unary_operator_impl<
        std::negate,
        IntegerType,
        V
    >{
        typedef IntegerType result_type;
        enum{ result_value = -V};
    };
        

}}}//pqs::meta::detail


#endif
