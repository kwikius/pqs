#ifndef PQS_META_PRIMITIVE_BINARY_OP_IMPL_HPP_INCLUDED
#define PQS_META_PRIMITIVE_BINARY_OP_IMPL_HPP_INCLUDED
// pqs pqs-1-00-02 03:50 29/11/2003
// feedback to andy@servocomm.freeserve.co.uk
//primitiv_binary_op_impl.hpp
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/meta/binary_operation.hpp"
#include "to_power.hpp"
#include <functional>

namespace pqs{
namespace meta{ namespace detail{
// definitions of ct_primitive_binary_operations
   
   template <
        typename IntegerTypeA,
        IntegerTypeA A,
        template <typename> class Op,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl;
    
    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::logical_or,
        IntegerTypeB,
        B
    >{  
        typedef typename binary_operation<
            IntegerTypeA,
            std::logical_or,
            IntegerTypeB
        >::result_type result_type;  
        const static result_type    result_value = A || B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::logical_and,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,
            std::logical_and,
            IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A && B;
    };

     template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        bit_or,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,bit_or,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A | B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        bit_xor,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
        IntegerTypeA,bit_xor,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A ^ B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        bit_and,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,bit_and,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A & B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::not_equal_to,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::not_equal_to,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A != B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::equal_to,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::equal_to,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A == B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::greater_equal,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::greater_equal,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A >= B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::less_equal,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::less_equal,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A <= B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::less,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::less,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A < B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::greater,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::greater,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A > B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        shift_right,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,shift_right,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A >> B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        shift_left,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,shift_left,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A << B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::plus,
        IntegerTypeB,
        B
    >{        
        typedef typename binary_operation<
            IntegerTypeA,std::plus,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A + B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::minus,
        IntegerTypeB,
        B
    >{
        typedef typename binary_operation<
            IntegerTypeA,std::minus,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A - B;
    };
    
    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::multiplies,
        IntegerTypeB,
        B
    >{
        typedef typename binary_operation<
            IntegerTypeA,std::multiplies,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A * B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        std::divides,
        IntegerTypeB,
        B
    >{
        typedef typename binary_operation<
            IntegerTypeA,std::divides,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value = A / B;
    };

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_op_impl<
        IntegerTypeA,
        A,
        to_power,
        IntegerTypeB,
        B
    >{
        typedef typename binary_operation<
            IntegerTypeA,std::multiplies,IntegerTypeB
        >::result_type result_type;
        const static result_type result_value 
        = static_cast<result_type>(
                    raise_to_power<
                        IntegerTypeA,
                        A,
                        static_cast<long>(B)
                    >::value  );
    };
 
}}}//pqs::meta::detail

#endif

