#ifndef GENERIC_META_PRIMITIVE_UNARY_OPERATION_IMPL_HPP_INCLUDED
#define GENERIC_META_PRIMITIVE_UNARY_OPERATION_IMPL_HPP_INCLUDED

#include <functional>

namespace pqs{
 namespace meta{ namespace detail{

    template <
        template<typename> class op,
        typename IntegerType,
        IntegerType V
    >
    struct primitive_unary_op_impl;

    template<
        typename IntegerType,
        IntegerType V
    >
    struct primitive_unary_op_impl<
        std::negate,
        IntegerType,
        V
    >{
        typedef IntegerType result_type;
        const static result_type result_value = -V;
    };
        

}}}//pqs::meta::detail


#endif
