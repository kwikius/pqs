#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_RATIONAL_C_ICE_BINARY_OPERATOR_IMPL_HPP_INCLUDED
#define PQS_META_RATIONAL_C_ICE_BINARY_OPERATOR_IMPL_HPP_INCLUDED

/*
    only compile time result available for rationals is
    comparison <, <=, ==, >= , >
*/

#include "pqs/meta/rational_c_fwd.hpp"

namespace pqs{ namespace meta{namespace detail{

    template <
        long NL,
        long DL,
        template <typename> class Op,
        long NR,
        long DR
    >
    struct rat_ice_binary_operator_impl;

    template <
        long NumeL,
        long DenomL,
        long NumeR,
        long DenomR
    >
    struct rat_ice_binary_operator_impl<
        NumeL,DenomL,
        std::greater,
        NumeR,DenomR
    >{  
        // reduce
        typedef typename rational_c<long,NumeL,DenomL>::type left_type;
        typedef typename rational_c<long,NumeR,DenomR>::type right_type; 

        typedef bool result_type;     
        enum{result_value =
        ((left_type::numerator * right_type::denominator) 
            > ( right_type::numerator * left_type::denominator))}; 
    };

    template <
        long NumeL,
        long DenomL,
        long NumeR,
        long DenomR
    >
    struct rat_ice_binary_operator_impl<
        NumeL,DenomL,
        std::less,
        NumeR,DenomR
    >{  
        // reduce
        typedef typename rational_c<long,NumeL,DenomL>::type left_type;
        typedef typename rational_c<long,NumeR,DenomR>::type right_type; 

        typedef bool result_type;     
        enum{result_value =
        ((left_type::numerator * right_type::denominator) 
            < ( right_type::numerator * left_type::denominator))}; 
    };

    template <
        long NumeL,
        long DenomL,
        long NumeR,
        long DenomR
    >
    struct rat_ice_binary_operator_impl<
        NumeL,DenomL,
        std::less_equal,
        NumeR,DenomR
    >{  
        // reduce
        typedef typename rational_c<long,NumeL,DenomL>::type left_type;
        typedef typename rational_c<long,NumeR,DenomR>::type right_type; 

        typedef bool result_type;     
        enum{ result_value =
        ((left_type::numerator * right_type::denominator) 
            <= ( right_type::numerator * left_type::denominator))}; 
    };

    template <
        long NumeL,
        long DenomL,
        long NumeR,
        long DenomR
    >
    struct rat_ice_binary_operator_impl<
        NumeL,DenomL,
        std::greater_equal,
        NumeR,DenomR
    >{  
        // reduce
        typedef typename rational_c<long,NumeL,DenomL>::type left_type;
        typedef typename rational_c<long,NumeR,DenomR>::type right_type; 

        typedef bool result_type;     
        enum{result_value =
        ((left_type::numerator * right_type::denominator) 
            >= ( right_type::numerator * left_type::denominator))}; 
    };

    template <
        long NumeL,
        long DenomL,
        long NumeR,
        long DenomR
    >
    struct rat_ice_binary_operator_impl<
        NumeL,DenomL,
        std::equal_to,
        NumeR,DenomR
    >{  
        // reduce
        typedef typename rational_c<long,NumeL,DenomL>::type left_type;
        typedef typename rational_c<long,NumeR,DenomR>::type right_type; 

        typedef bool result_type;     
        enum{ result_value =
        ((left_type::numerator * right_type::denominator) 
            == ( right_type::numerator * left_type::denominator))}; 
    };

    template <
        long NumeL,
        long DenomL,
        long NumeR,
        long DenomR
    >
    struct rat_ice_binary_operator_impl<
        NumeL,DenomL,
        std::not_equal_to,
        NumeR,DenomR
    >{  
        // reduce
        typedef typename rational_c<long,NumeL,DenomL>::type left_type;
        typedef typename rational_c<long,NumeR,DenomR>::type right_type; 

        typedef bool result_type;     
        enum{result_value =
        ((left_type::numerator * right_type::denominator) 
            != ( right_type::numerator * left_type::denominator))}; 
    };

}}}//pqs::meta


#endif
