#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_META_DETAIL_RATIONAL_C_IMPL_HPP_INCLUDED
#define GENERIC_META_DETAIL_RATIONAL_C_IMPL_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "boost/math/common_factor_ct.hpp"
#include "pqs/meta/min_type.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"

namespace pqs{
 namespace meta{ namespace detail{

  template<
        typename IntegerType,
        IntegerType N,
        IntegerType D 
    >
    struct rational_c_impl {
    private:
        
        enum{pos_nume_in 
        = N >= 0 ? N : -N,
        pos_denom_in 
        = D >= 0 ? D : -D};

        // static_gcd returns unsigned long
        
        typedef typename boost::math::static_gcd<
            static_cast<unsigned long>(pos_nume_in),
            static_cast<unsigned long>(pos_denom_in)
        > gcd_type;
        enum{
        gcd = (gcd_type::value),
        n_sign = (N >= 0)? 1 :-1,
        d_sign = (D >= 0)? 1 :-1,
        nume_in 
        = ( (n_sign * d_sign) > 0)? pos_nume_in : -pos_nume_in }; 
    public:
        enum{numerator = nume_in/gcd,denominator = pos_denom_in/gcd};
       typedef rational_c_impl<IntegerType,numerator,denominator> type; 
    };

    template<
        typename IntegerType,
        IntegerType N,
        IntegerType D
    >
    struct rational_c_impl_eval 
    {
        typedef typename rational_c_impl<IntegerType,N,D>::type rat_type;
        typedef typename pqs::meta::unary_operation<
            pqs::reciprocal,IntegerType
        >::result_type result_type;

        result_type operator()() const 
        {
            return static_cast<result_type>(rat_type::numerator)/rat_type::denominator;
        }
    };

    template<
        int N
    >
    struct rational_c_impl_eval<int,N,1>{
        typedef int result_type;
        result_type operator()() const
        {
            return N;
        }
    };

    template<
        unsigned int N
    >
    struct rational_c_impl_eval<unsigned int,N,1U>{
        typedef unsigned int result_type;
        result_type operator()() const
        {
            return N;
        }
    };

    template<
        long N
    >
    struct rational_c_impl_eval<long,N,1L>{
        typedef long result_type;
        result_type operator()() const
        {
            return N;
        }
    };

    template<
        unsigned long N
    >
    struct rational_c_impl_eval<unsigned long,N,1UL>{
        typedef unsigned long result_type;
        result_type operator()() const
        {
            return N;
        }
    };

}}}//pqs::meta::detail

#endif
