#ifndef GENERIC_META_DETAIL_TO_POWER_HPP_INCLUDED
#define GENERIC_META_DETAIL_TO_POWER_HPP_INCLUDED
// pqs pqs-1-00-02 03:50 29/11/2003
// feedback to andy@servocomm.freeserve.co.uk
//to_power.hpp
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

//#include "pqs/operators//binary_operators.hpp"

/*
    raise to power for 
    primitive_binary_operations
    e.g compile time pow(A,B)for integer types.
*/

namespace pqs{
 namespace meta{namespace detail{

    template<typename Ta, Ta A,long B>
    struct raise_to_power;

    template<typename Ta , Ta A>
    struct raise_to_power<Ta,A,0>{ 
       const static long  value = 1;
    };

    template<typename Ta, Ta A,long B>
    struct raise_to_power{
        static const long value
        = raise_to_power<Ta,A,B-1>::value * A;
    };
}}}//pqs::meta::detail
#endif

