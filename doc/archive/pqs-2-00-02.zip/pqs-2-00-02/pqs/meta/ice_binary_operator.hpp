#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_META_PRIMITIVE_BINARY_OPERATION_HPP_INCLUDED
#define GENERIC_META_PRIMITIVE_BINARY_OPERATION_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
 ice_binary_operator has a result_type (integral)
 and a result_value(type result_type) as public members
 deals with compile time computation on (integral) values
 added check for integers
 concept_checking::AreBothIntegers<A,B>
 
 Only ever useful with integer types.
 As these are the only compile time operations that can have a value
 For result_types use binary_operation.
    
*/

#include "detail/ice_binary_operator_impl.hpp"
#include "pqs/concepts/concept_checking.hpp"

namespace pqs{ namespace meta{


    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        template <typename> class Op,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct ice_binary_operator
    : pqs::concept_checking::AssertAreBothArithmetic<
        IntegerTypeA,IntegerTypeB
    >{
       typedef typename detail::ice_binary_operator_impl<
            IntegerTypeA,
            A,
            Op,
            IntegerTypeB,
            B
        >::result_type result_type;

        enum{result_value 
        = detail::ice_binary_operator_impl<
            IntegerTypeA,
            A,
            Op,
            IntegerTypeB,
            B
        >::result_value};
     };

}}//pqs::meta


#endif


