#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_MIN_TYPE_HPP_INCLUDED
#define PQS_META_MIN_TYPE_HPP_INCLUDED
/*
    promotion convenience
    to a minimum type
*/

#include "pqs/meta/promotion_traits.hpp"

namespace pqs{ namespace meta{
// add to_arithmetic - from arithmetic possibly
    template<typename T>
    struct int_promote{
        typedef typename arithmetic_promote<int,T>::type type;
    };
    template<typename T>
    struct long_promote{
        typedef typename arithmetic_promote<long,T>::type type;
    };

    template<typename T>
    struct float_promote{
        typedef typename arithmetic_promote<float,T>::type type;
    };

    template<typename T>
    struct double_promote{
        typedef typename arithmetic_promote<double,T>::type type;
    };

    template<typename T>
    struct long_double_promote{
        typedef typename arithmetic_promote<long double,T>::type type;
    };
   
    
}}//pqs::meta

#endif
