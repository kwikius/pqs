#ifndef GENERIC_META_PRIMITIVE_BINARY_OPERATION_HPP_INCLUDED
#define GENERIC_META_PRIMITIVE_BINARY_OPERATION_HPP_INCLUDED
// pqs pqs-1-00-02 03:50 29/11/2003
// feedback to andy@servocomm.freeserve.co.uk
//primitive_binary_operation.hpp
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "detail/primitive_binary_op_impl.hpp"

namespace pqs{ namespace meta{

    // primitive_binary_operation has a result_type (integral)
    // and a result_value(type result_type) as public members
    // deals with compile time computation on (integral) values

    template <
        typename IntegerTypeA,
        IntegerTypeA A,
        template <typename> class Op,
        typename IntegerTypeB,
        IntegerTypeB B
    >
    struct primitive_binary_operation{
       typedef typename detail::primitive_binary_op_impl<
            IntegerTypeA,
            A,
            Op,
            IntegerTypeB,
            B
        >::result_type result_type;

        static const result_type result_value 
        = detail::primitive_binary_op_impl<
            IntegerTypeA,
            A,
            Op,
            IntegerTypeB,
            B
        >::result_value;
     };

}}//pqs::meta


#endif


