#ifndef GENERIC_META_PRIMITIVE_UNARY_OPERATION_HPP_INCLUDED
#define GENERIC_META_PRIMITIVE_UNARY_OPERATION_HPP_INCLUDED
// pqs pqs-1-00-02 03:50 29/11/2003
// feedback to andy@servocomm.freeserve.co.uk
//primitive_unary_operation.hpp
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "detail/primitive_unary_op_impl.hpp"

    // primitive_unary_operation has a result_type (integral)
    // and a result_value(type result_type) as public members
    // deals with compile time computation on (integral) values

namespace pqs { namespace meta{

    template <
        template<typename> class Op,
        typename IntegerType,
        IntegerType V
    >
    struct primitive_unary_operation {
        typedef typename detail::primitive_unary_op_impl<
            Op,IntegerType,V
        >::result_type result_type;
        const static result_type result_value
         =  detail::primitive_unary_operation<
                Op,IntegerType,V
            >::result_value; 
    };
    
}}//pqs::meta


#endif
