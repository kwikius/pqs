#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_RATIONAL_C_HPP_INCLUDED
#define PQS_META_RATIONAL_C_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    compile time rational number
    from original impl by Matthias Schabel and ideas from Jan Langer
*/

#include "detail/rational_c_impl.hpp"
#include "pqs/meta/promotion_traits.hpp"
#include "pqs/meta/binary_operation.hpp"
#include "pqs/meta/unary_operation.hpp"
#include "pqs/operators/unary_operators.hpp"
#include "boost/mpl/void.hpp"
#include "boost/mpl/if.hpp"
#include "boost/math/common_factor_ct.hpp"
#include "boost/mpl/integral_c.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include "pqs/meta/detail/rat_ice_binary_operator.hpp"
#include "pqs/meta/rational_c_fwd.hpp"
#include "boost/type_traits/is_same.hpp"
#include "pqs/ct_quantity/of_quantity.hpp"

namespace pqs{namespace concept_checking{

    // for use with pqs::meta::rational_c
    // check for division by zero
    template<bool D>
    struct AssertDenominatorNotZero;
    template<>
    struct AssertDenominatorNotZero<true>{};

}}

namespace pqs{namespace meta{

    template<
        typename IntegerType,
        IntegerType N,
        IntegerType D = 1
    >
    struct rational_c  :
    pqs::concept_checking::AssertIsIntegral<IntegerType>,
    pqs::concept_checking::AssertDenominatorNotZero<(D != 0)> {
        enum{
            numerator 
            = detail::rational_c_impl<IntegerType,N,D>::numerator,
            denominator 
            = detail::rational_c_impl<IntegerType,N,D>::denominator
        };
        typedef IntegerType                             value_type;
        typedef rational_c<IntegerType,numerator,denominator> type;
        enum{
            is_zero = numerator == 0,
            is_integer = denominator == 1,
            is_negative = (numerator < 0),
            is_positive = (numerator >= 0)
        };

        // functor to evaluate the rational
        // invoke as:
        // typename rat::eval()()
        // check the result_type which is int or float
        // dependent on whether denominator == 1 
        // eg compile time result_type by:
        // typename rat::eval::result_type
        struct eval 
        : detail::rational_c_impl_eval<IntegerType,numerator,denominator>{};
     } ;
      
}}//pqs::meta

namespace pqs{namespace meta{
    template<
       typename IntegerType,
        IntegerType N,
        IntegerType D 
    > 
    struct unary_operation<
        std::negate,
        rational_c<IntegerType,N,D>
    >{
        typedef typename rational_c<
            IntegerType,-N,D
        >::type result_type;
    };

    template<
       typename IntegerType,
        IntegerType N,
        IntegerType D 
    > 
    struct unary_operation<
        pqs::reciprocal,
        rational_c<IntegerType,N,D>
    > {
        typedef typename rational_c<
            IntegerType,D,N
        >::type result_type;
    };

    //plus
    template<
        typename IntegerType1,
        IntegerType1 N1,
        IntegerType1 D1,
        typename IntegerType2,
        IntegerType2 N2,
        IntegerType2 D2
    > 
    struct binary_operation< 
       rational_c<IntegerType1,N1,D1>,
       std::plus,
       rational_c<IntegerType2,N2,D2> 
    >{ 
        typedef typename binary_operation<
            IntegerType1,
            std::plus,
            IntegerType2
        >::result_type value_type;
       
        typedef typename rational_c<
            value_type,
            N1 * D2 + N2 * D1,
            D1 * D2
        >::type result_type; 
    };

     template<
        typename IntegerType1,
        IntegerType1 N1,
        IntegerType1 D1,
        typename IntegerType2,
        IntegerType2 N2,
        IntegerType2 D2
    > 
    struct binary_operation<
        rational_c<IntegerType1,N1,D1>,
        std::minus,
        rational_c<IntegerType2,N2,D2> 
    >{ 
        typedef typename binary_operation<
            IntegerType1,
            std::minus,
            IntegerType2
        >::result_type promoted_type;
        typedef typename rational_c<
            promoted_type,
            N1 * D2 - N2 * D1,
            D1 * D2
        >::type result_type; 
    };

    template<
        typename IntegerType1,
        IntegerType1 N1,
        IntegerType1 D1,
        typename IntegerType2,
        IntegerType2 N2,
        IntegerType2 D2
    > 
    struct binary_operation<
        rational_c<IntegerType1,N1,D1>,
        std::multiplies,
        rational_c<IntegerType2,N2,D2> 
    >{ 
        typedef typename binary_operation<
            IntegerType1,   
            std::multiplies,
            IntegerType2
        >::result_type promoted_type;
        typedef typename rational_c<
            promoted_type,
            N1 * N2,
            D1 * D2
        >::type result_type; 
    };

    template<
        typename IntegerType1,
        IntegerType1 N1,
        IntegerType1 D1,
        typename IntegerType2,
        IntegerType2 N2,
        IntegerType2 D2
    > 
    struct binary_operation< 
        rational_c<IntegerType1,N1,D1>,
        std::divides,
        rational_c<IntegerType2,N2,D2>
    >{
        typedef typename binary_operation<
            IntegerType1,
            std::divides,
            IntegerType2
        >::result_type promoted_type;
        typedef typename rational_c<
               promoted_type,
               N1 * D2,
              ( N1 == 0 ) ? 1 : (D1 * N2)   
        >::type result_type; 
    };

// for use with pow
    template <
       typename A,
       typename IntegerType,
       IntegerType N,
       IntegerType D 
    >
    struct binary_operation < A, pqs::to_power, rational_c<IntegerType,N,D> >
    {
        typedef typename arithmetic_promote<
            typename boost::mpl::if_c<
                (boost::is_same<A,float>::value),
                float,
                double
            >::type ,
            typename rational_c<IntegerType,N,D>::type::eval::result_type
        >::type result_type;
    };
// for comparisons ret bool
    template<
        typename RationalA,
        template <typename> class Op,
        typename RationalB
    > 
    struct rational_ice_binary_operator{
    private:
        typedef detail::rat_ice_binary_operator_impl<
            RationalA::numerator,
            RationalA::denominator,
            Op,
            RationalB::numerator,
            RationalB::denominator
        >  rat_ice_impl;
    public:
        typedef typename rat_ice_impl::result_type result_type;
        enum{ result_value = rat_ice_impl::result_value};
    };

    
    
// mpl::integral_c support
    template<
        typename IntegerType1,
        IntegerType1 N1,
        IntegerType1 D1,
        template <typename> class Op,
        typename IntegerType2,
        IntegerType2 N2
    > 
    struct binary_operation< 
        rational_c<IntegerType1,N1,D1>,
        Op,
        boost::mpl::integral_c<IntegerType2,N2>
    >{
        typedef typename binary_operation<
            IntegerType1,
            Op,
            IntegerType2
        >::result_type promoted_type;
        typedef typename binary_operation< 
            rational_c<promoted_type,N1,D1>,
            Op,
            rational_c<promoted_type,N2,1>   
        >::result_type result_type; 
    };

     template<
        typename IntegerType1,
        IntegerType1 N1,
        template <typename> class Op,
        typename IntegerType2,
        IntegerType2 N2,
        IntegerType2 D2
    > 
    struct binary_operation< 
        boost::mpl::integral_c<IntegerType1,N1>,
        Op,
        rational_c<IntegerType2,N2,D2>
    >{
        typedef typename binary_operation<
            IntegerType1,
            Op,
            IntegerType2
        >::result_type promoted_type;
        typedef typename binary_operation< 
               rational_c<promoted_type,N1,1>,
               Op,
               rational_c<promoted_type,N2,D2>  
        >::result_type result_type; 
    };

    

}}//pqs::meta


#endif //PQS_META_RATIONAL_C_HPP_INCLUDED
