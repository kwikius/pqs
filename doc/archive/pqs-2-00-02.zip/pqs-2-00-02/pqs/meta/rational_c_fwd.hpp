#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_RATIONAL_C_FWD_HPP_INCLUDED
#define PQS_META_RATIONAL_C_FWD_HPP_INCLUDED

namespace pqs{ namespace meta{

    template<
        typename IntegerType,
        IntegerType N,
        IntegerType D
    >
    struct rational_c ;
}}//pqs::meta

#endif
