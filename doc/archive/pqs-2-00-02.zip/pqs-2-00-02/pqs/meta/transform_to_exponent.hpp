#ifndef GENERIC_META_TRANSFORM_TO_EXPONENT_HPP_INCLUDED
#define GENERIC_META_TRANSFORM_TO_EXPONENT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

// redundant
namespace pqs{ namespace meta{

    // Float_type is a guide
    template <typename T, typename Float_type>
    struct transform_to_exponent;

}}//pqs::meta


#endif
