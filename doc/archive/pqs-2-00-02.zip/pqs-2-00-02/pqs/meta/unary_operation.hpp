#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_META_UNARY_OPERATION_HPP_INCLUDED
#define GENERIC_META_UNARY_OPERATION_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    not all impl
    negate, reciprocal,square-root,cube-root,square,cube

*/

#include "boost/mpl/void.hpp"
#include "pqs/operators/unary_operators.hpp"
#include "pqs/concepts/concept_checking.hpp"
#include "pqs/meta/min_type.hpp"
#include "pqs/ct_quantity/of_quantity.hpp"

namespace pqs {namespace meta{

    template <
       template <typename> class Op,
       typename T 
    >
    struct unary_operation : pqs::concept_checking::AssertIsArithmetic<T>{
        typedef T result_type;
    };

    template <>
    struct unary_operation<pqs::reciprocal, char>{
        typedef pqs::of_quantity::default_value_type result_type;
    };
    template <>
    struct unary_operation<pqs::reciprocal,unsigned char>{
        typedef pqs::of_quantity::default_value_type result_type;
    };

    template <>
    struct unary_operation<pqs::reciprocal,short>{
        typedef pqs::of_quantity::default_value_type result_type;
    };

    template <>
    struct unary_operation<pqs::reciprocal,unsigned short>{
        typedef pqs::of_quantity::default_value_type result_type;
    };

    template <>
    struct unary_operation<pqs::reciprocal, int>{
        typedef pqs::of_quantity::default_value_type result_type;
    };

    template <>
    struct unary_operation<pqs::reciprocal, unsigned int>{
        typedef pqs::of_quantity::default_value_type result_type;
    };

    template <>
    struct unary_operation<pqs::reciprocal, long>{
        typedef pqs::of_quantity::default_value_type result_type;
    };
   
    template <>
    struct unary_operation<pqs::reciprocal, unsigned long>{
        typedef pqs::of_quantity::default_value_type result_type;
    };

// not implemented
    
    template <
       typename T,
       template <typename> class Op
    >
    struct postfix_operation{
        typedef boost::mpl::void_ result_type;
    };

}}//pqs::meta

#endif
