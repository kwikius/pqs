#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_CONVERTER_HPP_INCLUDED
#define PQS_META_CONVERTER_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    numeric converter with range checking 
    based in part on boost::numeric::converter , but much simplified
    NOTE: boost::numeric converter is much superior
    but this doesnt require full boost library

    fixed 09/04/04 bug causing conversion of negative value throws an exception.
    added 3/06/04 assert T and S are fundamental types

    16/06/04 added safe trivial conversions for integer types
*/

//#include "boost/static_assert.hpp"
#include "pqs/numeric/detail/converter_impl.hpp"
#include "boost/mpl/if.hpp"
//#include "pqs/concepts/concept_checking.hpp"

 namespace pqs{ namespace numeric{
    namespace detail{
        template <
            bool AreArithmetic,
            typename T, 
            typename S
        >
        struct arithmetic_converter;
    }

    template <
        typename T, 
        typename S
    >
    struct converter : detail::arithmetic_converter<
        (std::numeric_limits<T>::is_specialized &&
        std::numeric_limits<S>::is_specialized), T,S>
    {};

    namespace detail{
        template <
            typename T, 
            typename S
        >
        struct arithmetic_converter <true, T,S>{
           
            typedef typename std::numeric_limits<S> source_limits;
            typedef typename std::numeric_limits<T> target_limits;
          
            enum{is_trivial_int
            = ( (boost::is_integral<T>::value && boost::is_integral<S>::value)
                && 
                ( ( (source_limits::is_signed == target_limits::is_signed) && (sizeof(T) >= sizeof(S)))
                    || (target_limits::is_signed && (sizeof(T) > sizeof(S)) ) ) )};

            typedef typename boost::mpl::if_c<
                is_trivial_int,
                detail::trivial_int_converter<T,S>,
                detail::main_converter<T,S>
            >::type actual_converter;
                    
            T operator()(S const& s)const
            {   
                return actual_converter()(s); 
            }
        };
    }// detail

    // for trivial conversions to same type
    template <
        typename T
    >
    struct converter<T,T>{
      const T& operator()(const T& t)const{return t;}
    };

    namespace detail{
        template <
            typename T, 
            typename S
        >
        struct arithmetic_converter<false, T,S>{
            T operator()(const S& s)const{return static_cast<T>(s);}
        };
    }

}}//pqs::numeric

#endif
