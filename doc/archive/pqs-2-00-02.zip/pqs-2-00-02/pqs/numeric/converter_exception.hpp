#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_NUMERIC_CONVERTER_EXCEPTION_HPP_INCLUDED
#define PQS_NUMERIC_CONVERTER_EXCEPTION_HPP_INCLUDED

// extracted from boost/numeric/converter_policies.hpp"
// which is 
// (C) 2003, Fernando Luis Cacciola Carballal.
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.

#include <typeinfo> // for std::bad_cast

namespace boost{namespace numeric{

    class bad_numeric_conversion : public std::bad_cast
    {
    public:

        virtual const char * what() const throw()
        {  return "bad numeric conversion: overflow"; }
    };

    class negative_overflow : public bad_numeric_conversion
    {
    public:

        virtual const char * what() const throw()
        {  return "bad numeric conversion: negative overflow"; }
    };
    class positive_overflow : public bad_numeric_conversion
    {
    public:

        virtual const char * what() const throw()
        { return "bad numeric conversion: positive overflow"; }
    };

}}//boost::numeric

#endif
