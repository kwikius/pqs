#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_CONVERTER_IMPL_HPP_INCLUDED
#define PQS_META_CONVERTER_IMPL_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

// numeric converter with range checking 
// based in part on boost::numeric::converter , but much simplified
// and doesnt requir full boost library

// fixed 09/04/04 bug causing conversion of negative value throws an exception.
// added 3/06/04 assert T and S are fundamental types

// added safe trivial conversions for integer types

//16/09/04
// modified exception to derive from boost::numeric::bad_numeric_conversion

#include <limits>
#include <cmath>
#include "boost/type_traits/is_integral.hpp"
#include "boost/type_traits/is_float.hpp"

#include "pqs/numeric/converter_exception.hpp"

//#include "boost/static_assert.hpp"

 namespace pqs{ namespace numeric{
// exception thrown by pqs::numeric::converter  where the target range
// is not large enough for the source value
    struct conversion_range : public boost::numeric::bad_numeric_conversion{
        const char* what()const throw()
        {return "pqs value-type conversion out of range";}
    };

    template <
        typename T, 
        typename S
    >
    struct converter;

}}//pqs::numeric

 namespace pqs{namespace numeric{namespace detail{

    // converter for float to integer conversions
    template <
        typename T,
        typename S
    >
    struct float_to_integer_converter{
    // nearest neighbour rounding
       T operator()(S const& s)const 
        {  ////////////////////
            /*     
            S int_part;
            S fract_part = std::modf(s,&int_part);
            S result=0;
            if (fract_part > 0.5) result = std::ceil(s);
            else if (fract_part < 0.5) result = std::floor(s);
            else{
                result = ( static_cast<unsigned long>(std::abs(int_part)) & 1) 
                ? std::ceil(s) 
                : std::floor(s);
              return static_cast<T>(result);
            }*/
       
// modified from pqs::numeric::converter algorithm
// in boost/numeric/converter_policies.hpp
// Algorithm contributed by Guillaume Melquiond

// (C) 2003, Fernando Luis Cacciola Carballal.
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
             	 
            using std::floor ;
            using std::ceil  ;
            // only works inside the range not at the boundaries
            S a = floor(s); 
            S b = ceil(s);  
            
            S c = (s - a) - (b - s); // the "good" subtraction
            
            if ( c < static_cast<S>(0.0) ) 
            return static_cast<T>(a);
            else if ( c >  static_cast<S>(0.0) )
            return static_cast<T>(b);
            else 
            return static_cast<T>(2 * floor(b / static_cast<S>(2.0))); // needs to behave sanely          
        }
    };

    template <
        bool IsFloatToIntegral,
        typename T, 
        typename S
    >
    struct positive_value_converter;

// spec for when it is a float to integral conv
    template <
        typename T, 
        typename S
    > 
    struct positive_value_converter<true, T,S>  {
        T operator()(S const& s)const
        {
            // expression promotes either max() or s here
            if (std::numeric_limits<T>::max() >= s){
                return float_to_integer_converter<T,S>()(s);
            }
            throw conversion_range();
        }
    };

// spec for when it isnt a float to integral conv
    template <
        typename T, 
        typename S
    >
    struct positive_value_converter<false, T,S>{
         // used only if s is >=0
        T operator()(S const& s)const
        {
            return static_cast<T>(s);
        }
    };

    template <
        bool IsFloatToInteger,
        bool T_S_valid_if_negative,
        typename T, 
        typename S
    >
    struct negative_value_converter;

// valid negative_value_converter
// for when it is valid and is float-to-int
    template <
        typename T, 
        typename S
    >
    struct negative_value_converter<true,true,T,S>{

        T operator()(S const& s)const
        {
            if ((-std::numeric_limits<T>::max() <= s) ){
               return  float_to_integer_converter<T,S>()(s);
            }
            throw conversion_range();
        }
    };
// valid negative_value_converter
// for when it is valid but is not float-to-int

    template <
        typename T, 
        typename S
    >
    struct negative_value_converter<false,true,T,S>{

        T operator()(S const& s)const
        {
            if ((-std::numeric_limits<T>::max() <= s) ){
               return static_cast<T>(s);
            }
            throw conversion_range();
        }
    };

// invalid negative_value_converter
    template <
        bool X,
        typename T, 
        typename S
    >
    struct negative_value_converter<X,false,T,S>{

        T operator()(S const& s)const
        {
            throw conversion_range();
            
        }
    };

    template <
        typename T, 
        typename S
    >
    struct trivial_int_converter{
        T operator()(S const& s)const
        {
            return static_cast<T>(s);
        }
    };

    template <
        typename T, 
        typename S
    >
    struct main_converter{

        typedef typename std::numeric_limits<S> source_limits;
        typedef typename std::numeric_limits<T> target_limits;

        // the source value may be < 0 for unsigned type
        // valid_negative checks that
        enum{ 
            valid_negative 
            = (source_limits::is_signed && target_limits::is_signed),
            is_float_to_integer
            = (boost::is_float<S>::value && boost::is_integral<T>::value)
        };
        
        T operator()(S const& s)const
        {    
            return (s < 0)
            ? negative_value_converter<is_float_to_integer,valid_negative,T,S>()(s)
            : positive_value_converter<is_float_to_integer,T,S>()(s); 
        }
    };

}}}//pqs::numeric::detail

#endif
