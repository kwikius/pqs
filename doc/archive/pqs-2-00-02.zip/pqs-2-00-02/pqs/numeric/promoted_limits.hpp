#ifndef BOOST_PQS_META_PROMOTED_LIMITS_HPP_INCLUDED
#define BOOST_PQS_META_PROMOTED_LIMITS_HPP_INCLUDED

#include "pqs/meta/promotion_traits.hpp"
#include <limits>

namespace pqs{ 
namespace numeric{namespace detail{

    template <
        typename T, 
        typename S
    >
    struct promoted_max{

        typedef typename pqs::meta::arithmetic_promote<T,S>::type result_type;
        result_type operator()() 
        {
            return static_cast<result_type>(
            std::numeric_limits<T>::max());
        }
    };

    template <
        typename T,
        typename S
    >
    struct promoted_min{
        //only valid if T and S are signed
        static const bool is_valid 
        = (std::numeric_limits<S>::is_signed
        && std::numeric_limits<T>::is_signed);
        typedef typename pqs::meta::arithmetic_promote<T,S>::type result_type;
        result_type operator()() 
        {
            return static_cast<result_type>(
            std::numeric_limits<T>::min());
        }
    };

}}}//pqs::numeric::detail


#endif 
