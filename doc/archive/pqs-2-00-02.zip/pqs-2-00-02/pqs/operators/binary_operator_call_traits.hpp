#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_BINARY_OPERATOR_CALL_TRAITS_HPP_INCLUDED
#define GENERIC_BINARY_OPERATOR_CALL_TRAITS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    no longer used
    binary_operator_call_traits merely combines
    the binary_operation result_type with the
    "best parameter types" of the operator parameters.
    e.g (usually) double is best passed by const reference etc
*/

#include "pqs/meta/binary_operation.hpp"
#include "boost/call_traits.hpp"

namespace pqs{

    template <
        typename A,
        template<typename> class Op,
        typename B
    > 
    struct binary_operator_call_traits {

        typedef typename meta::binary_operation<
            A,Op,B
        >::result_type result_type;
            
        typedef typename boost::call_traits<
            A
        >::param_type first_argument_type;

        typedef typename boost::call_traits<
            B
        >::param_type second_argument_type;
          
    };
   
}//pqs

#endif
