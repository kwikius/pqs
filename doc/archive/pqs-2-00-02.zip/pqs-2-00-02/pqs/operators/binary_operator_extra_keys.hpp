#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_BINARY_OPERATOR_EXTRA_KEYS_HPP_INCLUDED
#define GENERIC_BINARY_OPERATOR_EXTRA_KEYS_HPP_INCLUDED
// pqs pqs-1-00-02 03:50 29/11/2003
// feedback to andy@servocomm.freeserve.co.uk
//binary_operator_extra_keys.hpp
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    extra operator keys to supplemet std::plus etc
    for use with binary_operation 
*/

#include <functional>

namespace pqs{

     // used for 'keys'
    template <typename T>
    struct bit_or;
    template <typename T>
    struct bit_xor;
    template <typename T>
    struct bit_and;
    template <typename T>
    struct shift_left;
    template <typename T> 
    struct shift_right;
    template <typename T>
    struct to_power;
    template <typename T>
    struct to_root;
    template<typename T>
    struct equals;

}//boost:pqs


#endif

