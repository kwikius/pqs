#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BINARY_OPERATOR_FUNCTORS_HPP_INCLUDED
#define BINARY_OPERATOR_FUNCTORS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    functors for replacing original ones in functional
    can be used for udt and combined types e.g
    result_of<operator_plus(int,double) t = operator_plus() (int,double);
*/

#include "pqs/operators/binary_operators.hpp"
#include "pqs/operators/unary_operators.hpp"

namespace pqs{
    // just a common base class
    template<template <typename> class Op>
    struct operator_{

        template<typename> struct result;
        template<typename F, typename L, typename R>
        struct result<F(L,R)> 
        { 
            typedef typename binary_operator<
                L,
                Op,
                R
            >::result_type type;
        };

        
        template<typename L, typename R>
        struct apply
        { 
            typedef typename binary_operator<
                L,
                Op,
                R
            >::result_type type;
        };

       
        template<typename F, typename T>
        struct result<F(T)> 
        { 
            typedef typename unary_operator<
                Op,
                T
            >::result_type type;
        };

        template<typename L, typename R>
        typename result<
            operator_<Op>(L,R)
        >::type 
          operator()(L const&  l, R const & r)    
        { 
            return binary_operator<L,Op,R>()(l,r);
        }
        
        template<typename L, typename R>
        static
        typename result<
            operator_<Op>(L,R)
        >::type eval( L const&  l,R const&   r)
        {
            return binary_operator<L,Op,R>::apply(l, r);
        }

        template<typename T>
        typename result<
            operator_<Op>(T)
        >::type 
        operator()(const T &  t)
        {
            return unary_operator<Op,T>()(t);
        }
        
        template<typename T>
        static
        typename result<
            operator_<Op>(T)
        >::type eval (const T& t)
        {
            return unary_operator<Op,T>::apply(t);
        }
    };
    struct operator_equals : operator_<equals>{};
    struct operator_logical_or : operator_<std::logical_or>{};
    struct operator_logical_and : operator_<std::logical_and>{};
    struct operator_bit_or : operator_<bit_or>{};
    struct operator_bit_xor : operator_<bit_xor>{};
    struct operator_bit_and : operator_<bit_and>{};
    struct operator_equal_to : operator_<std::not_equal_to>{};
    struct operator_not_equal_to : operator_<std::equal_to>{};
    struct operator_greater_equal : operator_<std::greater_equal>{};
    struct operator_less_equal : operator_<std::less_equal>{};
    struct operator_greater : operator_<std::greater>{};
    struct operator_less : operator_<std::less>{};
    struct operator_minus : operator_<std::minus>{};
    struct operator_plus : operator_<std::plus>{};
    struct operator_multiplies : operator_<std::multiplies>{};
    struct operator_divides : operator_<std::divides>{};
    struct operator_shift_left : operator_<shift_left>{};
    struct operator_shift_right : operator_<shift_right>{};

}  //pqs

#endif 
