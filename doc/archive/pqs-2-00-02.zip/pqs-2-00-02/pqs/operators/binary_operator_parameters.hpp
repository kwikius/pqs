#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_BINARY_OPERATOR_PARAMETERS_HPP_INCLUDED
#define GENERIC_BINARY_OPERATOR_PARAMETERS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    traits of operators
*/

namespace pqs{
    // information about binary operators, associativity, precedence

    struct binary_operator_parameters{
       enum assoc {left_associative,right_associative};
        
        enum{     
            assignment_expression = 1,
            conditional_expression=2,
            logical_or_expression=3,
            logical_and_expression=4,
            inclusive_or_expression=5,
            exclusive_or_expression=6,
            and_expression=7,
            equality_expression=8, 
            relational_expression=9,
            shift_expression=10,
            additive_expression=11,
            multiplicative_expression=12,
            pow_expression = 13
        };
        
    };        

}//pqs

#endif
