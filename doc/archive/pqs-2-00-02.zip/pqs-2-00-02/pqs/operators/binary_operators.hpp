#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_BINARY_OPERATORS_HPP_INCLUDED
#define GENERIC_BINARY_OPERATORS_HPP_INCLUDED

// feedback to andy@servocomm.freeserve.co.uk
//  Copyright (C) Andy Little, White Light Device 2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    useage 
    binary_operator<LHS,std::plus,RHS>::result_type t 
    = binary_operator<LHS,std::plus,RHS>()(lhs,rhs)

    std::plus can be std::multiply or others in <functional> etc etc
*/

#include "pqs/meta/binary_operation.hpp"
#include "boost/call_traits.hpp"

namespace pqs{
       
    template <
        typename A, 
        template <typename> class Op,
        typename B
    >
    struct binary_operator;

    namespace meta{
        template <typename T>
        struct as_const_argument{
          // typedef typename boost::call_traits<T>::param_type type;
            typedef  T const & type;  
        };
    }

    template <typename A, typename B>
    struct binary_operator<A,pqs::equals,B> 
    {
        typedef A first_operand_type;
        typedef B second_operand_type;
       typedef typename meta::binary_operation<
            A,pqs::equals,B
        >::result_type result_type;
        //typedef A & result_type;
        result_type operator() (
                A& a,
                typename meta::as_const_argument<B>::type b)const
                {return a = b;}
        static result_type apply (
                A& a,
                typename meta::as_const_argument<B>::type b)
                {return a = b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::logical_or,B> 
    {
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::logical_or,B
        >::result_type result_type;
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a || b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a || b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::logical_and,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::logical_and,B
        >::result_type result_type;
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a && b;}
        static result_type apply(
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a && b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,bit_or,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,bit_or,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a | b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a | b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,bit_xor,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,bit_xor,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a ^ b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a ^ b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,bit_and,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,bit_and,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a & b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a & b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::equal_to,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::equal_to,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a == b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a == b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::not_equal_to,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::not_equal_to,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a != b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a != b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::greater_equal,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::greater_equal,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a >= b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a >= b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::less_equal,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::less_equal,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a <= b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a <= b;}
    };

   template <typename A, typename B>
    struct binary_operator<A,std::greater,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::greater,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a > b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a > b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::less,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::less,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a < b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a < b;}
    };
    
template <typename A, typename B>
    struct binary_operator<A,shift_right,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,shift_right,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a >> b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a >> b;}
    };

  template <typename A, typename B>
    struct binary_operator<A,shift_left,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,shift_left,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a << b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a << b;}
    };

   // add shleq , and shright etc plus eq muleq

    template <typename A, typename B>
    struct binary_operator<A,std::plus,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::plus,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a + b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a + b;}
    };

    
   template <typename A, typename B>
    struct binary_operator<A,std::minus,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::minus,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a - b;}
        static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a - b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::multiplies,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::multiplies,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a * b;}
         static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a * b;}
    };

    template <typename A, typename B>
    struct binary_operator<A,std::divides,B>{
        typedef A first_operand_type;
        typedef B second_operand_type;
        typedef typename meta::binary_operation<
            A,std::divides,B
        >::result_type result_type;       
        result_type operator() (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)const
                {return a / b;}
       static result_type apply (
                typename meta::as_const_argument<A>::type a,
                typename meta::as_const_argument<B>::type b)
                {return a / b;}
    };
    
}//pqs

#endif

