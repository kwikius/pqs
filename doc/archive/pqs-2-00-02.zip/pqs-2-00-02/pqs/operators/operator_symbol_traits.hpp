#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_OPERATOR_SYMBOL_TRAITS_HPP_INCLUDED
#define PQS_OPERATOR_SYMBOL_TRAITS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    output symbols for operators
    useful for debugging binary_operation in ET etc
*/

#include <functional>
#include "pqs/operators/binary_operator_extra_keys.hpp"

namespace pqs{

    template< template<typename> class Op>
    struct   operator_symbol;

    template<>
    struct operator_symbol<std::plus>{

        const char* const operator()()
        {
            return "+";
        }
    };

    template<>
    struct operator_symbol<std::minus>{

       const char* const operator()()
        {
            return "-";
        }
    };

    template<>
    struct operator_symbol<std::multiplies>{

       const char* const operator()()
        {
            return "*";
        }
    };

    template<>
    struct operator_symbol<std::divides>{

       const char* const operator()()
        {
            return "/";
        }
    };

    /*todo
    template <typename T>
    struct bit_or;
    template <typename T>
    struct bit_xor;
    template <typename T>
    struct bit_and;
    template <typename T>
    struct shift_left;
    template <typename T> 
    struct shift_right;
    template <typename T>
    struct to_power;
    template <typename T>
    struct to_root;*/

}

#endif
