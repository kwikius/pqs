#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_UNARY_OPERATORS_HPP_INCLUDED
#define GENERIC_UNARY_OPERATORS_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    unary_operators =- not much used, nor much implemented yet
*/

#include "boost/call_traits.hpp"
#include <functional>

namespace pqs{

    // key for reciprocal
    template <typename T>
    struct reciprocal;

    template <
        template <typename> class Op,
        typename V
    > 
    struct unary_operator_call_traits{
      typedef typename boost::call_traits<
          V
      >::param_type argument_type;
     typedef  V result_type;
    };

    template<template <typename> class Op, typename T>
    struct unary_operator{
        
            typedef T result_type;
    };
    template<typename T>
    struct unary_operator<std::minus,T>{
        
       typedef T result_type;

       result_type operator()( T t)
       {
            return -t;
       }
    };

    template<typename T>
    struct unary_operator<std::plus,T>{
        
       typedef T result_type;

       result_type operator()( T t)
       {
            return t;
       }
    };
 }//pqs

#endif
