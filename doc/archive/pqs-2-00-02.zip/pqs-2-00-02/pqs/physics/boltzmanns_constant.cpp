#include "boltzmanns_constant.hpp"
template<>
pqs::physics::boltzmanns_constant<double>::type const&
pqs::physics::boltzmanns_constant<double>::K 
= pqs::physics::boltzmanns_constant<double>::type(1.3807);

template<>
pqs::physics::boltzmanns_constant<long double>::type const&
pqs::physics::boltzmanns_constant<long double>::K 
= pqs::physics::boltzmanns_constant<long double>::type(1.3807L);

template<>
pqs::physics::boltzmanns_constant<float>::type const&
pqs::physics::boltzmanns_constant<float>::K 
= pqs::physics::boltzmanns_constant<float>::type(1.3807f);


