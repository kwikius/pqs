#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_GAS_CONSTANT_HPP_INCLUDED
#define PQS_GAS_CONSTANT_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    declaration of gas_constant.
    definition in "pqs/physics/lib_src/gas_constant.cpp"
    required to link
*/

#include "pqs/ct_quantity/operations.hpp"

namespace pqs{ namespace physics{

    template<typename Value_type>
    struct gas_constant_{

        typedef ct_quantity<       // gas constant
            named_abstract_quantity<
                anonymous_abstract_quantity<
                    length_pwr<2>,
                    time_pwr<-2>,
                    mass_pwr<1>,
                    temperature_pwr<-1>,
                    current_pwr<0>,
                    substance_pwr<-1>,
                    intensity_pwr<0> 
                >
            >,
            quantity_unit<>,
            Value_type
        > type;
        static type const&  R;
    };

    struct gas_constant : gas_constant_<pqs::of_quantity::default_value_type>{};

}}//pqs::physics

#endif
