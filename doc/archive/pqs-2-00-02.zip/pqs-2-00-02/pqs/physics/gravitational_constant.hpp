#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_GRAVITATIONAL_CONSTANT_HPP_INCLUDED
#define PQS_GRAVITATIONAL_CONSTANT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    gravitational constant declaration
    note:
    requires compilation of "pqs/physics/lib_src/gravitational_constant.cpp"
    for linking
*/

#include "pqs/ct_quantity/operations.hpp"

namespace pqs{namespace physics{

    template <typename Value_type>
    struct gravitational_constant_{
        typedef  ct_quantity<     //pqs-1-00-03 style
            named_abstract_quantity<
                anonymous_abstract_quantity<
                    length_pwr<3>,
                    time_pwr<-2>,
                    mass_pwr<-1>
                >
            >,
            quantity_unit<
                coherent_exponent<-11>
            >,
            Value_type
        > type;
   
        static type const& G;
    };

    struct gravitational_constant : gravitational_constant_<double>{};

}}//pqs::physics

#endif

