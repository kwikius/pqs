/*
    boltzmanns constant definition required to link
*/
#include "pqs/physics/boltzmanns_constant.hpp"

template<>
pqs::physics::boltzmanns_constant_<double>::type const&
pqs::physics::boltzmanns_constant_<double>::K 
= pqs::physics::boltzmanns_constant_<double>::type(1.380658);

template<>
pqs::physics::boltzmanns_constant_<long double>::type const&
pqs::physics::boltzmanns_constant_<long double>::K 
= pqs::physics::boltzmanns_constant_<long double>::type(1.380658L);

template<>
pqs::physics::boltzmanns_constant_<float>::type const&
pqs::physics::boltzmanns_constant_<float>::K 
= pqs::physics::boltzmanns_constant_<float>::type(1.380658f);


