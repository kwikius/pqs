/*
    gas constant definition required to link
*/

#include "pqs/physics/gas_constant.hpp"

template<>
pqs::physics::gas_constant_<double>::type const&
pqs::physics::gas_constant_<double>::R 
= pqs::physics::gas_constant_<double>::type(8.3145);

template<>
pqs::physics::gas_constant_<long double>::type const&
pqs::physics::gas_constant_<long double>::R 
= pqs::physics::gas_constant_<long double>::type(8.3145L);

template<>
pqs::physics::gas_constant_<float>::type const&
pqs::physics::gas_constant_<float>::R
= pqs::physics::gas_constant_<float>::type(8.3145f);
