#include "pqs/physics/gravitational_constant.hpp"
/*
    gravitational_constant definition required to link
*/
template<>
pqs::physics::gravitational_constant_<long double>::type const & 
pqs::physics::gravitational_constant_<long double>::G
= pqs::physics::gravitational_constant_<long double>::type(6.6726L);

template<>
pqs::physics::gravitational_constant_<double>::type const & 
pqs::physics::gravitational_constant_<double>::G
= pqs::physics::gravitational_constant_<double>::type(6.6726);

template<>
pqs::physics::gravitational_constant_<float>::type const & 
pqs::physics::gravitational_constant_<float>::G
= pqs::physics::gravitational_constant_<float>::type(6.6726F);

