#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
     single header giving access to all physical-quantity types
     and stream output
*/

#ifndef PQS_PQS_HPP_INCLUDED2911030401
#define PQS_PQS_HPP_INCLUDED2911030401

#include "pqs/types/all_types_out.hpp"
#include "pqs/util/utility_output.hpp"
#include "pqs/util/utility_input.hpp"

#endif
