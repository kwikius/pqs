#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_RT_QUANTITY_IMPL_ABC_MEMBER_PQ_HPP_INCLUDED
#define PQS_RT_QUANTITY_IMPL_ABC_MEMBER_PQ_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
   abstract base class for the rt_quantity member interface
*/

#include "pqs/rt_quantity/rt_quantity_fwd.hpp"
#include "pqs/ct_quantity/operations.hpp"
#include "pqs/meta/min_type.hpp"
#include <iostream>
namespace pqs{ namespace detail{
               
        // interface to member ct_quantity
        template <
            typename NamedAbstractQuantity,
            typename Value_type
        >
        class abc_member_pq{
            template<
                typename NamedAbstractQuantity1,
                typename QuantityUnit1,
                typename Value_type1
            >
            friend class member_pq;
            friend class rt_quantity<NamedAbstractQuantity,Value_type>;  
            virtual Value_type scale_to(
                Value_type coherent_mux, 
                Value_type incoherent_mux)const=0;
            virtual void set_value_to_pq(
                Value_type quantity_value,
                Value_type coherent_mux, 
                Value_type incoherent_mux)=0;
            virtual std::ostream& put(std::ostream& os)const=0;
            virtual std::ostream& put_units(std::ostream& os)const=0;
            virtual void set_numeric_value(Value_type const & quantity_value)=0;
            virtual abc_member_pq* clone()const =0;
            virtual void clone(abc_member_pq* target)const=0;
            virtual typename pqs::of_quantity::min_real<
                Value_type
            >::type get_coherent_multiplier()const=0;
            virtual typename pqs::of_quantity::min_real<
                    Value_type
            >::type get_incoherent_multiplier()const=0;
            virtual Value_type numeric_value()const =0;
            virtual ~abc_member_pq(){};
        };

}}//pqs::detail

#endif

 