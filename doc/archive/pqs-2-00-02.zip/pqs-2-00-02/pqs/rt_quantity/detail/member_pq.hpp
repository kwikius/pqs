#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_RT_QUANTITY_MEMBER_PQ_HPP_INCLUDED
#define PQS_RT_QUANTITY_MEMBER_PQ_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
   ct_quantity container for rt_quantity
*/

#include "pqs/rt_quantity/detail/abc_member_pq.hpp"

namespace pqs{ namespace detail{

        template <
            typename NamedAbstractQuantity,
            typename QuantityUnit,
            typename Value_type
        >
        class member_pq : private abc_member_pq<
            NamedAbstractQuantity,
            Value_type
        >{
            friend  class pqs::rt_quantity<NamedAbstractQuantity,Value_type>;
            ct_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            > pq;
            
            member_pq(){};
            // for rt_quantity to init from a ct-quantity
            member_pq(ct_quantity<
                        NamedAbstractQuantity,
                        QuantityUnit,
                        Value_type
                    >const& pq_in)
            :pq(pq_in){};
            // used to change to different units at runtime
            Value_type scale_to(
                Value_type coherent_mx_in,
                Value_type incoherent_mx_in)const
            {
                return  this->pq.numeric_value() 
                * (this->get_coherent_multiplier()/coherent_mx_in)
                 * (this->get_incoherent_multiplier()/incoherent_mx_in) ;
            }

            std::ostream& put_units(std::ostream& os)const
            {
                os << units(pq);
                return os;
            }

            member_pq* clone()const
            {
                return new member_pq(this->pq);
            }

            // clone member_pq to other member_pq
            // via placement new
            void clone(abc_member_pq<
                            NamedAbstractQuantity,
                            Value_type
                        >* target)const
            {
                target->abc_member_pq<
                        NamedAbstractQuantity,
                        Value_type
                    >::~abc_member_pq();
                target = new (target) member_pq(this->pq );
            }
                
            void set_value_to_pq(
                Value_type quantity_value,
                Value_type coherent_mx_in, 
                Value_type incoherent_mx_in)
            {
                Value_type new_val = quantity_value * 
                (coherent_mx_in/this->get_coherent_multiplier()) 
                * (incoherent_mx_in/this->get_incoherent_multiplier());
                this->pq 
                =   ct_quantity<
                        NamedAbstractQuantity,
                        QuantityUnit,
                        Value_type
                    >(new_val);
            }

            void set_numeric_value(Value_type const&  quantity_value){
                this->pq 
                = ct_quantity<
                    NamedAbstractQuantity,
                    QuantityUnit,
                    Value_type
                >(quantity_value);
            } 
 
            std::ostream& put(std::ostream& os)const
            {
                os << this->pq ;
                return os;
            }
         
            typename pqs::of_quantity::min_real<
                Value_type
            >::type
            get_coherent_multiplier()const
            {
                return typename QuantityUnit::coherent_exponent_type::template eval<Value_type>()();
            }

            typename pqs::of_quantity::min_real<
                Value_type
            >::type
            get_incoherent_multiplier()const 
            {
                return typename QuantityUnit::incoherent_multiplier_type::template eval<Value_type>()();
            }

            Value_type  numeric_value()const
            {
                return this->pq.numeric_value();
            }
        };//member_pq

}}//pqs::detail


#endif
