#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_RT_QUANTITY_RT_QUANTITY_IMPL_HPP_INCLUDED
#define PQS_RT_QUANTITY_RT_QUANTITY_IMPL_HPP_INCLUDED



#endif
