#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_MAPPED_RT_QUANTITY_HPP_INCLUDED
#define PQS_MAPPED_RT_QUANTITY_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    an rt-quantity incorporating a map of unit conversion functions,
    which are a keyed by the string representing the unit symbol.
    enabling unit conversion via strings
*/

#include "pqs/rt_quantity/rt_units_map.hpp"

namespace pqs{

    template <
        typename NamedAbstractQuantity,
        typename Value_type = of_quantity::default_value_type,
        typename CharType = char
    >
    class mapped_rt_quantity : public rt_quantity<NamedAbstractQuantity,Value_type>{
        typedef rt_units_map<NamedAbstractQuantity,CharType> units_map_type;
        typedef typename units_map_type::const_iterator const_iterator;
    public:   
        static units_map_type units_map;
        // set units of the rt-quantity via string unit-symbol
        bool set_units(std::basic_string<CharType> const& str){
            return units_map.set(*this,str);
        }
        // add unit via type of ct-quantity representing unit
        template <typename CT_pq>
        static void add_unit()
        { 
            concept_checking::function_requires<
                CompatibleQuantityConcept<
                    NamedAbstractQuantity,
                    typename CT_pq::named_abstract_quantity_type
                >
            >();

            units_map.template add_unit<CT_pq>();
        }
        // set units and value
        bool set_quantity(Value_type const& v,std::basic_string<CharType> const& str)
        {
            if (this->set_units(str)){
                this->set_numeric_value(v);
                return true;
            }
            else{
                return false;
            }
        }
        //output the units held in a list
        static void list_units(std::basic_ostream<CharType>& os)
        {
            const_iterator iter = units_map.begin();
            while (iter != units_map.end()){
                os << iter->first;
                if (++iter != units_map.end())
                    os << ", " ; 
            }
        }
    };

}//pqs


#endif
