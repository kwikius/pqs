#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_RUNTIME_QUANTITY_HPP_INCLUDED010104
#define PHYSICAL_QUANTITIES_RUNTIME_QUANTITY_HPP_INCLUDED010104
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    runtime physical-quantity, units modifiable at runtime
    can be initialised with dimensionally-equivalent 
    ct_quantity of any units. Castable back to ct_quantity.
    Assignable from ct_quantity
*/

#include "pqs/rt_quantity/detail/member_pq.hpp"
#include "pqs/ct_quantity/operations.hpp"
#include "pqs/meta/min_type.hpp"

#include <string>
#include <iostream>
#include <sstream>

namespace pqs{

    template <
        typename NamedAbstractQuantity,
        typename Value_type = of_quantity::default_value_type
    >
    class rt_quantity{
        
    protected:
        typename detail::abc_member_pq<NamedAbstractQuantity,Value_type>*  ppq;
    public:
        typedef Value_type value_type;
        typedef NamedAbstractQuantity named_abstract_quantity_type;
        // default ppq is prime-dimension-unit
        rt_quantity()
        :ppq (new typename detail::member_pq<
                        NamedAbstractQuantity,
                        quantity_unit<>,
                        Value_type 
                    >){}

        //alternative can init with  dimensionally-equivalent initialisable type
        template<
            typename NamedAbstractQuantity1,      // used for D.A. checking
            typename QuantityUnit1,
            typename Value_type1
        >
        rt_quantity(
            ct_quantity<
                NamedAbstractQuantity1,
                QuantityUnit1,
                Value_type1
            > const & pq_in)
        {
            pqs::concept_checking::function_requires<
                CompatibleQuantityConcept<
                    NamedAbstractQuantity,
                    NamedAbstractQuantity1  
                >
            >(); 

            this->ppq 
            = new   typename detail::member_pq<
                        NamedAbstractQuantity,
                        QuantityUnit1,
                        Value_type
                    >(pq_in);
        }
//////////////////////////
// template<
//            typename QuantityUnit,
//            typename NamedAbstractQuantity1,      // used for D.A. checking
//            typename QuantityUnit1,
//            typename Value_type1
//        >
//        rt_quantity(
//            ct_quantity<
//                NamedAbstractQuantity1,
//                QuantityUnit1,
//                Value_type1
//            > const & pq_in)
//        {
//            pqs::concept_checking::function_requires<
//                CompatibleQuantityConcept<
//                    NamedAbstractQuantity,
//                    NamedAbstractQuantity1  
//                >
//            >(); 
//            ct_quantity<NamedAbstractQuantity,QuantityUnit,Value_type> tpq(pq_in);
//            this->ppq 
//            = new   typename detail::member_pq<
//                        NamedAbstractQuantity,
//                        QuantityUnit1,
//                        Value_type
//                    >(tpq);
//        }
//
//
//
////////////////////////

        rt_quantity (rt_quantity const & rt_in)
        {
           this->ppq = rt_in.ppq->clone() ;
        }

        // change the current member units and value to that of arg
        template<
            typename NamedAbstractQuantity1,      // used for D.A. checking
            typename QuantityUnit1,
            typename Value_type1
        >
        rt_quantity& install(
            ct_quantity<
                NamedAbstractQuantity1,
                QuantityUnit1,
                Value_type1
            > const & pq_in)
        {
             pqs::concept_checking::function_requires<
                CompatibleQuantityConcept<
                    NamedAbstractQuantity,
                    NamedAbstractQuantity1  
                >
            >(); 

            this->ppq->set_numeric_value(static_cast<Value_type>(0));
            this->set_units<ct_quantity<NamedAbstractQuantity1,QuantityUnit1,Value_type1> >();
            this->ppq->set_numeric_value(pq_in.numeric_value());
            return *this;
        }

        rt_quantity& install(rt_quantity const& rt_in)
        {
            if (&rt_in != this){
              rt_in.ppq->clone(this->ppq);
            }
            return *this;
        }

        rt_quantity& operator =(rt_quantity const& rt_in)
        {
            this->ppq->set_value_to_pq(
                rt_in.numeric_value(),
                rt_in.get_coherent_multiplier(),
                rt_in.get_incoherent_multiplier());
            return *this;
        }
        
        // assign from ct_quantity...but keep current units, so scale input value
        template<
            typename NamedAbstractQuantity1,      // used for D.A. checking
            typename QuantityUnit1,
            typename Value_type1
        > 
        rt_quantity& operator=(
            ct_quantity<
                NamedAbstractQuantity1,
                QuantityUnit1,
                Value_type1
            > const & pq)
        {
            pqs::concept_checking::function_requires<
                CompatibleQuantityConcept<
                    NamedAbstractQuantity,
                    NamedAbstractQuantity1  
                >
            >(); 

            Value_type coherent_mx 
            = typename QuantityUnit1::coherent_exponent_type
            ::template eval<Value_type>()();

            Value_type q_mx 
            = typename QuantityUnit1::incoherent_multiplier_type
            ::template eval<Value_type>()();

            this->ppq->set_value_to_pq(pq.numeric_value(),coherent_mx,q_mx);
            return *this;
        }
       
        ~rt_quantity(){ delete ppq;}

        template<typename PQ>
        void set_units()
        {
             pqs::concept_checking::function_requires<
                CompatibleQuantityConcept<
                    NamedAbstractQuantity,
                    typename PQ::named_abstract_quantity_type
                >
            >(); 

            // get scaled value from ppq for initialiser in new units

            Value_type v 
            =  this->ppq->scale_to(
                typename PQ::units_type::coherent_exponent_type
                ::template eval<Value_type>()(),
                typename PQ::units_type::incoherent_multiplier_type
                ::template eval<Value_type>()()
                );

            // and switch ppq to pq of new units
            
            this->ppq-> detail::abc_member_pq<
                        NamedAbstractQuantity,
                        Value_type
                    >::~abc_member_pq();
            this->ppq 
            = new (ppq)
              detail::member_pq<
                    NamedAbstractQuantity,
                    typename PQ::units_type,
                    Value_type
              >(  ct_quantity<
                        NamedAbstractQuantity,
                        typename PQ::units_type,
                        Value_type
                  >(v) );
        } 

        void set_numeric_value(Value_type const & v)
        {
            this->ppq->set_numeric_value(v);
        }
        // return  a ct_quantity (rt_quantity internal units unchanged)
        template<
            typename PQ
        >
        PQ ct_quantity_cast()const
        { 
            pqs::concept_checking::function_requires<
                CompatibleQuantityConcept<
                    typename PQ::named_abstract_quantity_type,
                    NamedAbstractQuantity
                >
            >(); 
            
            // get scaled value from ppq for initialiser in new units
            Value_type v 
            =  this->ppq->scale_to(
                typename PQ::units_type::coherent_exponent_type::template eval<Value_type>()(),
                typename PQ::units_type::incoherent_multiplier_type::template eval<Value_type>()());

            return ct_quantity<
                        NamedAbstractQuantity,
                        typename PQ::units_type,
                        typename PQ::value_type
                   >(v);
        } 
        template<
            typename NamedAbstractQuantity1,
            typename QuantityUnit ,
            typename Value_type1
        >
        operator ct_quantity<
                NamedAbstractQuantity1,
                QuantityUnit,
                Value_type1
                >()const
        { 
            return this->ct_quantity_cast<
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit,
                    Value_type1
                >
             >();
        }
        
        // stream output 
        template<typename CharType>
        std::basic_ostream<CharType>& put(std::basic_ostream<CharType>& os)const
        {
            return this->ppq->put(os);
        }
        template<typename CharType>
        std::basic_ostream<CharType>& put_units(std::basic_ostream<CharType>& os)const
        {
            return this->ppq->put_units(os);
        }
        template<typename CharType>
        std::basic_string<CharType> units_str()const
        {
            std::basic_ostringstream<CharType> ost;
            this->put_units(ost);
            return ost.str();
        }

        std::string units_str()const
        {
            std::ostringstream ost;
            this->put_units(ost);
            return ost.str();
        }

        Value_type  numeric_value()const
        {
            return this->ppq->numeric_value();
        }

        typename pqs::of_quantity::min_real<
                Value_type
        >::type
        get_coherent_multiplier()const
        {
            return this->ppq->get_coherent_multiplier();
        }

        typename pqs::of_quantity::min_real<
            Value_type
        >::type
        get_incoherent_multiplier()const 
        {
            return this->ppq->get_incoherent_multiplier(); 
        }
        
    }; //rt_quantity

    template<
        typename CharType,
        typename NamedAbstractQuantity, 
        typename QuantityUnit
    >
    std::basic_string<CharType> units_str(
        rt_quantity<
            NamedAbstractQuantity,
            QuantityUnit
        > const & rq_in)
    {
        return rq_in.units_str<CharType>();
    }

    template<
        typename NamedAbstractQuantity, 
        typename QuantityUnit
    >
    std::string units_str(
        rt_quantity<
            NamedAbstractQuantity,
            QuantityUnit
        > const & rq_in)
    {
        return rq_in.units_str();
    }
            
    
    template<
        typename NamedAbstractQuantityL,
        typename Value_typeL,
        typename NamedAbstractQuantityR,
        typename Value_typeR
    >
    int compare (
        rt_quantity<
            NamedAbstractQuantityL,
            Value_typeL
        > const& lhs,
        rt_quantity<
            NamedAbstractQuantityR,
            Value_typeR
        > const& rhs)
    {
        pqs::concept_checking::function_requires<
                CompatibleQuantityConcept<
                    NamedAbstractQuantityL,
                    NamedAbstractQuantityR
                >
        >(); 
        typedef typename pqs::meta::binary_operation<
            Value_typeL,
            std::minus,
            Value_typeR
        >::result_type wkg_type;
        wkg_type tl 
        = lhs.numeric_value() 
        * lhs.get_coherent_multiplier()
        * lhs.get_incoherent_multiplier();

        wkg_type tr
        = rhs.numeric_value() 
        * rhs.get_coherent_multiplier()
        * rhs.get_incoherent_multiplier();
        
        using std::abs;
        if (abs(tl - tr) <= of_quantity::epsilon<wkg_type>()){
            return 0;
        }
        return (tl > tr) ? 1 : -1;
    }

    template<
        typename NamedAbstractQuantityL,
        typename Value_typeL,
        typename NamedAbstractQuantityR,
        typename Value_typeR
    >
    bool operator < (
        rt_quantity<
            NamedAbstractQuantityL,
            Value_typeL
        > const& lhs,
        rt_quantity<
            NamedAbstractQuantityR,
            Value_typeR
        > const& rhs)
    {
        return compare(lhs,rhs) < 0;
    }
    template<
        typename NamedAbstractQuantityL,
        typename Value_typeL,
        typename NamedAbstractQuantityR,
        typename Value_typeR
    >
    bool operator <= (
        rt_quantity<
            NamedAbstractQuantityL,
            Value_typeL
        > const& lhs,
        rt_quantity<
            NamedAbstractQuantityR,
            Value_typeR
        > const& rhs)
    {
        return compare(lhs,rhs) <= 0;
    }

    template<
        typename NamedAbstractQuantityL,
        typename Value_typeL,
        typename NamedAbstractQuantityR,
        typename Value_typeR
    >
    bool operator == (
        rt_quantity<
            NamedAbstractQuantityL,
            Value_typeL
        > const& lhs,
        rt_quantity<
            NamedAbstractQuantityR,
            Value_typeR
        > const& rhs)
    {
        return compare(lhs,rhs) == 0;
    }

     template<
        typename NamedAbstractQuantityL,
        typename Value_typeL,
        typename NamedAbstractQuantityR,
        typename Value_typeR
    >
    bool operator != (
        rt_quantity<
            NamedAbstractQuantityL,
            Value_typeL
        > const& lhs,
        rt_quantity<
            NamedAbstractQuantityR,
            Value_typeR
        > const& rhs)
    {
        return compare(lhs,rhs) != 0;
    }

    template<
        typename NamedAbstractQuantityL,
        typename Value_typeL,
        typename NamedAbstractQuantityR,
        typename Value_typeR
    >
    bool operator >= (
        rt_quantity<
            NamedAbstractQuantityL,
            Value_typeL
        > const& lhs,
        rt_quantity<
            NamedAbstractQuantityR,
            Value_typeR
        > const& rhs)
    {
        return compare(lhs,rhs) >= 0;
    }

    template<
        typename NamedAbstractQuantityL,
        typename Value_typeL,
        typename NamedAbstractQuantityR,
        typename Value_typeR
    >
    bool operator > (
        rt_quantity<
            NamedAbstractQuantityL,
            Value_typeL
        > const& lhs,
        rt_quantity<
            NamedAbstractQuantityR,
            Value_typeR
        > const& rhs)
    {
        return compare(lhs,rhs) > 0;
    }

    // stream output
    template <
        typename NamedAbstractQuantity,
        typename Value_type
    >
    inline 
    std::ostream& 
    operator << (
        std::ostream& os,
        rt_quantity<
            NamedAbstractQuantity,
            Value_type
        > const& rt_pq)
    {
        return rt_pq.put(os);
    }

    // comparisons with compile time quantities
   
    // <
    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator < (
        rt_quantity<
            NamedAbstractQuantity,
            Value_type
        > const& rt ,
        ct_quantity<
            NamedAbstractQuantity1,
            QuantityUnit1,
            Value_type1
        > const& pq)
    {
        return rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >() < pq;
    }

    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator < (
        ct_quantity<
            NamedAbstractQuantity1,
            QuantityUnit1,
            Value_type1
        > const& pq,
        rt_quantity<
            NamedAbstractQuantity,
            Value_type
        > const& rt )
                
    {
        return pq < rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                  >();
    }
    //  <=
    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
       typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator <= (rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt ,
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq)
    {
        return rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >() <= pq;
    }

    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator <= (
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq,
                rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt )
                
    {
        return pq <= rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >();
    }

    //  ==
    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator == (rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt ,
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq)
    {
        return rt. template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >() == pq;
    }

    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator == (
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq,
                rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt )
                
    {
        return pq == rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >();
    }
    // !=
        template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator != (rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt ,
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq)
    {
        return rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >() != pq;
    }

    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator != (
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq,
                rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt )
                
    {
        return pq != rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >();
    }
    // >=
    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator >= (rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt ,
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq)
    {
        return rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >() >= pq;
    }

    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator >= (
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq,
                rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt )
                
    {
        return pq >= rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >();
    }
    // >
    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator > (rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt ,
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq)
    {
        return rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >() > pq;
    }

    template <
        typename NamedAbstractQuantity,
        typename Value_type,
        typename NamedAbstractQuantity1,
        typename QuantityUnit1,
        typename Value_type1
    >
    inline 
    bool 
    operator > (
                ct_quantity<
                    NamedAbstractQuantity1,
                    QuantityUnit1,
                    Value_type1
                > const& pq,
                rt_quantity<
                    NamedAbstractQuantity,
                    Value_type
                > const& rt )
                
    {
        return pq > rt.template ct_quantity_cast<
                    ct_quantity<
                        NamedAbstractQuantity1,
                        QuantityUnit1,
                        Value_type1
                    >
                >();
    }

    /*template<
        typename CT_pq,
        typename RT_abstract_id,
        typename RT_value_type
    >
    inline CT_pq       
    quantity_cast(
        rt_quantity<
            RT_abstract_id,
            RT_value_type
        > const & rt_pq)

    {
        concept_checking::function_requires<
            CompatibleQuantityConcept<
                typename CT_pq::named_abstract_quantity_type,
                RT_abstract_id 
            >
        >();
       
        return rt_pq.template ct_quantity_cast<CT_pq>();
    }*/
   
} //pqs
#endif
