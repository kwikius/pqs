#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PHYSICAL_QUANTITIES_RT_QUANTITY_FWD_HPP_INCLUDED010104
#define PHYSICAL_QUANTITIES_RT_QUANTITY_FWD_HPP_INCLUDED010104

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
     forward decl of a runtime modifiable quantity
*/

namespace pqs{

    template <
        typename NamedAbstractQuantity,
        typename Value_type
    >
    class rt_quantity;

}

#endif
