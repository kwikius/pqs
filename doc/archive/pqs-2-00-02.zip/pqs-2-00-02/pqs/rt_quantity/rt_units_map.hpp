#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_RT_UNITS_MAP_HPP_INCLUDED
#define PQS_RT_UNITS_MAP_HPP_INCLUDED

#include "pqs/rt_quantity/rt_quantity.hpp"
#include <map>

/*
    map for changing units of rt-quantities at run-time
*/

namespace pqs{


    template <
        typename NamedAbstractQuantity,typename CharType = char
    >
    struct rt_units_map : public std::map<
        std::basic_string<CharType>,
        void (rt_quantity<NamedAbstractQuantity>::* )()
    > {
        typedef rt_quantity<NamedAbstractQuantity> rt_quantity_type;
        typedef void (rt_quantity_type::* func_ptr)();
        typedef typename std::map<std::basic_string<CharType>,func_ptr> map_type;
        typedef typename map_type::const_iterator const_iterator;
        template <
            typename CT_quantity
        >
        void add_unit()
        {
            concept_checking::function_requires<
                CompatibleQuantityConcept<
                    NamedAbstractQuantity,
                    typename CT_quantity::named_abstract_quantity_type
                >
            >();
            typename std::basic_string<CharType> str = units_str<CharType>(CT_quantity());
            this->operator[](str) = &rt_quantity_type::template set_units<CT_quantity>;
        }        
      
         bool set(rt_quantity_type & rt, std::basic_string<CharType> const& str)const
        {
            const_iterator iter=this->find(str);
            if(iter == this->end() )
                return false;
            else{
                func_ptr fp = iter->second;
                (&rt->*fp)();
                return true;
            }
        } 
       
        bool
        set(rt_quantity_type & rt,
             typename rt_quantity_type::value_type const & value,
             std::basic_string<CharType> const& str)const
        {
            const_iterator iter=this->find(str);
            if(iter == this->end() )
                return false;
            else{
                func_ptr fp = iter->second;
                (&rt->*fp)();
                rt.set_numeric_value(value);
                return true;
            }
        } 
    };
}//pqs

#endif
