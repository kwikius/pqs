#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TWO_D_BASIC_WORLD_HPP_INCLUDED
#define PQS_TWO_D_BASIC_WORLD_HPP_INCLUDED

#include "pqs/two_d/world_element.hpp"
#include <cassert>

namespace pqs{namespace two_d{
   
    template <typename BasicWorld>
    class basic_world_view;

    template <
        typename WorldPositionType,
        typename AngleType,
        typename ViewportSizeType,
        typename ViewportExtentType
    >
    class basic_world{
    public:
        typedef WorldPositionType       world_position_type;
        typedef AngleType               angle_type;
        typedef ViewportSizeType        viewport_size_type;
        typedef ViewportExtentType      viewport_extent_type;
        typedef world_element<
            world_position_type,
            angle_type
        >                           element_type;
        basic_world(): mp_view(0){}
        world_position_type& min_position()
        {
            return m_min_position;
        }
        world_position_type const & min_position()const
        {
            return m_min_position;
        }
        world_position_type& max_position()
        {
            return m_max_position;
        }
        world_position_type const & max_position()const
        {
            return m_max_position;
        }
        basic_world_view<basic_world>* current_view()
        {
            return mp_view;
        }
        basic_world_view<basic_world>* release_current_view()
        {
            assert(this->mp_view !=0 );
            basic_world_view<basic_world>* t =  mp_view;
            mp_view = 0;
            return t; 
        }
        void delete_current_view()
        {
            delete mp_view;
            mp_view = 0; 
        }
        void set_current_view(basic_world_view<basic_world>* in)
        {
            assert( mp_view == 0 );
            assert(in !=0 );
            mp_view = in;
        }
        
        private:
        world_position_type         m_min_position;
        world_position_type         m_max_position;
        basic_world_view<basic_world>*    mp_view;
    };

}}//pqs::two_d

#endif

 