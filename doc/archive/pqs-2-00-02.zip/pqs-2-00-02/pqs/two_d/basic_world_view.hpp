#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TWO_D_WORLDVIEW_HPP_INCLUDED
#define PQS_TWO_D_WORLDVIEW_HPP_INCLUDED

#include "pqs/two_d/basic_world.hpp"
#include "pqs/meta/associated_arithmetic.hpp"
#include "pqs/gui/graphics_viewport.hpp"
#include "pqs/two_d/vect.hpp"
namespace pqs{namespace two_d{

    template <typename BasicWorld>
     class basic_world_view : public BasicWorld::element_type{
        public:
            typedef BasicWorld          basic_world_type;
            typedef pqs::gui::graphics_viewport<
                typename basic_world_type::viewport_size_type,
                typename basic_world_type::viewport_extent_type
            >                           graphics_viewport_type;
            typedef pqs::two_d::vect<
                typename pqs::meta::to_value_type<
                    typename basic_world_type::world_position_type::x_type
                >::type,
                typename pqs::meta::to_value_type<
                    typename basic_world_type::world_position_type::y_type
                >::type
            >                           scale_type;
            //friend class basic_world_type;
            basic_world_view(
                basic_world_type& bb,
                graphics_viewport_type* gg
            ): mp_parent_world(&bb),mp_graphics_viewport(gg){}
            scale_type scale;
            graphics_viewport_type*     mp_graphics_viewport;
            basic_world_type*           mp_parent_world;
        };
}}// pqs::two_d

#endif

