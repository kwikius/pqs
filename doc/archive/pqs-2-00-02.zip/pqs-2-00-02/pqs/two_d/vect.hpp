#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TWO_D_VECT_HPP_INCLUDED
#define PQS_TWO_D_VECT_HPP_INCLUDED

#include "pqs/meta/binary_operation.hpp"

#include "pqs/meta/binary_operation_if.hpp"
#include "pqs/meta/is_valid_binary_operation.hpp"
#include "boost/mpl/and.hpp"
#include "boost/utility/enable_if.hpp"
#include "pqs/ct_quantity/operations/detail/convert.hpp"

namespace pqs{namespace two_d{

    template <
        typename Tx,
        typename Ty = Tx,
        typename Tag = void
    >
    class vect{
        template<typename Tx1,typename Ty1, typename Tag1> friend class vect;
    public:
        typedef Tx      x_type;
        typedef Ty      y_type;
        typedef Tag     tag_type;
        
        Tx x()const {return element_x;}
        Ty y()const {return element_y;}
        Tx& x() {return element_x;}
        Ty& y() {return element_y;}
        vect(){}
        vect(Tx const& x_in, Ty const & y_in)
        : element_x(x_in), element_y(y_in){}
        vect (const vect& in)
        :element_x(in.element_x),element_y (in.element_y)
        { 
        }
        template<typename Tx1,typename Ty1>
        vect (const vect<Tx1,Ty1,Tag>& in)
        :element_x(pqs::detail::implicit_initialise<Tx>(in.x())),
        element_y(pqs::detail::implicit_initialise<Ty>(in.y()))
        {
        }

        vect& operator =(vect const& in)
        {
            element_x = in.element_x;
            element_y = in.element_y;
            return *this;
        }
        
        template<typename Tx1,typename Ty1>
        vect& operator = (vect<Tx1,Ty1,Tag>const & in)
        {
            element_x = in.x();
            element_y = in.y();
            return *this;
        }

    private:
        Tx element_x;
        Ty element_y;
    };

}}//pqs::two_d

namespace pqs{namespace meta{

    template<
        typename Value_typeX,
        typename Value_typeY,
        typename Tag,
        typename Value_type
    >
    struct binary_operation<
        pqs::two_d::vect<Value_typeX,Value_typeY,Tag>,
        std::multiplies,
        Value_type,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::meta::is_valid_binary_operation<
                    Value_typeX,std::multiplies,Value_type
                >,
                pqs::meta::is_valid_binary_operation<
                    Value_typeY,std::multiplies,Value_type
                >
            >
        >::type
    >{
        typedef pqs::two_d::vect<
            typename binary_operation<
                Value_typeX,
                std::multiplies,
                Value_type
            >::result_type,
            typename binary_operation<
                Value_typeY,
                std::multiplies,
                Value_type
            >::result_type,
            Tag
        > result_type;
    };

    template<
        typename Value_type,
        typename Value_typeX,
        typename Value_typeY,
        typename Tag
    >
    struct binary_operation<
        Value_type,
        std::multiplies,
        pqs::two_d::vect<Value_typeX,Value_typeY, Tag>,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::meta::is_valid_binary_operation<
                    Value_type,std::multiplies,Value_typeX
                >,
                pqs::meta::is_valid_binary_operation<
                    Value_type,std::multiplies,Value_typeY
                >
            >      
        >::type
    >{
        typedef pqs::two_d::vect<
            typename binary_operation<
                Value_type,
                std::multiplies,
                Value_typeX
            >::result_type,
            typename binary_operation<
                Value_type,
                std::multiplies,
                Value_typeY
            >::result_type,
            Tag
        > result_type;
    };


    template<
        typename Value_typeX,
        typename Value_typeY,
        typename Tag,
        typename Value_type
    >
    struct binary_operation<
        pqs::two_d::vect<Value_typeX,Value_typeY, Tag>,
        std::divides,
        Value_type,
        typename boost::enable_if<
            boost::mpl::and_<
                pqs::meta::is_valid_binary_operation<
                    Value_typeX,std::divides,Value_type
                >,
                pqs::meta::is_valid_binary_operation<
                    Value_typeY,std::divides,Value_type
                >
           >     
        >::type
    >{
        typedef pqs::two_d::vect<
            typename binary_operation<
                Value_typeX,
                std::divides,
                Value_type
            >::result_type,
            typename binary_operation<
                Value_typeY,
                std::divides,
                Value_type
            >::result_type,
            Tag
        > result_type;
    };

}}//pqs::meta  

namespace pqs{namespace two_d{

    template <
        typename Value_typeX,
        typename Value_typeY,
        typename Value_type,
        typename Tag
    >
    inline 
    typename pqs::meta::binary_operation_if<
        boost::mpl::and_<
            pqs::meta::is_valid_binary_operation<
                Value_typeX,
                std::multiplies,
                Value_type
            >,
            pqs::meta::is_valid_binary_operation<
                Value_typeY,
                std::multiplies,
                Value_type
            >
        >,
        vect<Value_typeX, Value_typeY, Tag>,
        std::multiplies,
        Value_type
    >::result_type  
    operator *(vect<Value_typeX, Value_typeY, Tag> const & lhs ,Value_type const & rhs)
    {
       typename pqs::meta::binary_operation<
            vect<Value_typeX,Value_typeY, Tag>,
            std::multiplies,
            Value_type
       >::result_type result(lhs.x() * rhs, lhs.y() * rhs);
       return result;
    }

    template <
        typename Value_type, 
        typename Value_typeX, 
        typename Value_typeY,
        typename Tag
    >
    inline 
    typename pqs::meta::binary_operation_if<
        boost::mpl::and_<
            pqs::meta::is_valid_binary_operation<
                Value_type,
                std::multiplies,
                Value_typeX
            >,
            pqs::meta::is_valid_binary_operation<
                Value_type,
                std::multiplies,
                Value_typeY
            >
        >,
        Value_type,
        std::multiplies,
        vect<Value_typeX, Value_typeY, Tag>
    >::result_type  
    operator *(
        Value_type const & lhs ,
        vect<Value_typeX, Value_typeY, Tag> const & rhs)
    {
       typename pqs::meta::binary_operation<
            Value_type,
            std::multiplies,
            vect<Value_typeX, Value_typeY, Tag>
       >::result_type result(lhs * rhs.x(), lhs * rhs.y());
       return result;
    }

    template <
        typename Value_typeX, 
        typename Value_typeY,
        typename Tag, 
        typename Value_type
    >
    inline 
    typename pqs::meta::binary_operation_if<
        boost::mpl::and_<
            pqs::meta::is_valid_binary_operation<
                Value_typeX,
                std::divides,
                Value_type
            >,
            pqs::meta::is_valid_binary_operation<
                Value_typeY,
                std::divides,
                Value_type
            >
        >,
        vect<Value_typeX, Value_typeY, Tag>,
        std::divides,
        Value_type
    >::result_type  
    operator /(vect<Value_typeX,Value_typeY, Tag> const & lhs ,Value_type const & rhs)
    {
       typename pqs::meta::binary_operation<
            vect<Value_typeX, Value_typeY, Tag>,
            std::divides,
            Value_type
       >::result_type result(lhs.x()/ rhs, lhs.y()/ rhs);
       return result;
    }

   
}}//pqs::two_d
#endif
