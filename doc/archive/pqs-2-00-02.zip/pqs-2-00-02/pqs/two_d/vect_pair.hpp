#ifndef PQS_TWO_D_VECT_PAIR_HPP_INCLUDED
#define PQS_TWO_D_VECT_PAIR_HPP_INCLUDED

#include "pqs/ct_quantity/operations/detail/convert.hpp"

namespace pqs{ namespace two_d{

    template< 
      typename PointType
    >
    class vect_pair {
        template<typename PointType1> friend class vect_pair;
    public:
        typedef  typename PointType::x_type x_type;
        typedef  typename PointType::y_type y_type;
        typedef  typename PointType::tag_type tag_type;
        typedef  PointType point_type;
        point_type  from()const {return element_from;}
        point_type  to()const {return element_to;}
        point_type& from() {return element_from;}
        point_type& to() {return element_to;}
        vect_pair(){}
        vect_pair(vect_pair const& in)
        :element_from(in.element_from),element_to(in.element_to){}
        template<typename PointType1>
        vect_pair (vect_pair<PointType1> const& in)
        :element_from(pqs::detail::implicit_initialise<point_type>(in.element_from)),
         element_to(pqs::detail::implicit_initialise<point_type>(in.element_to)){}
        vect_pair(point_type const& point_from,point_type const& point_to)
        :element_from(point_from),element_to(point_to){}
        template<
            typename PointType1,
            typename PointType2
        >
        vect_pair(PointType1 const &point_from,
            PointType2 const & point_to)
        :element_from(pqs::detail::implicit_initialise<point_type>(point_from)),
        element_to(pqs::detail::implicit_initialise<point_type>(point_to)){}

    private: 
        point_type element_from;
        point_type element_to;
    };

}}//pqs::two_d

#endif
