#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

#ifndef PQS_TWO_D_WORLD_HPP_INCLUDED
#define PQS_TWO_D_WORLD_HPP_INCLUDED

#include "pqs/two_d/vect.hpp"

namespace pqs{namespace two_d{

    template<typename PositionType>
    class world{
    public:
        typedef PositionType position_type;
        position_type&
        minimum(){ return m_minimum;}
        position_type const&
        minimum()const{ return m_minimum;}
        position_type&
        maximum(){ return m_maximum;}
        position_type const &
        maximum()const{ return m_maximum;}
    private:
        position_type m_minimum;
        position_type m_maximum;  
    };

}}

#endif
