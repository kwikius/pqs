#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TWO_D_WORLD_ELEMENT_HPP_INCLUDED
#define PQS_TWO_D_WORLD_ELEMENT_HPP_INCLUDED

#include "pqs/types/length.hpp"
#include "pqs/math/angles/angles.hpp"
#include "pqs/two_d/vect.hpp"

namespace pqs{namespace two_d{

    template <
        typename PositionType,
        typename AngleType  = pqs::math::of_angle::rad
    >
    class world_element{
    public:
        typedef typename PositionType::x_type       x_type;
        typedef typename PositionType::y_type       y_type;
        typedef AngleType                           angle_type;
        typedef PositionType                        position_type;

        
        position_type&  position(){return m_position;}
        position_type   position()const{return m_position;}
        angle_type&     angle(){return m_angle;}
        angle_type      angle()const {return m_angle;}  
    private:
        position_type   m_position;
        angle_type      m_angle;
    };
        
}}
#endif
