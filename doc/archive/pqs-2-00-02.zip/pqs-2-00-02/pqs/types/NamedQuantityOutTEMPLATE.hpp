#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_???ABSTRACT-QUANTITY-NAME???_OUT_HPP_INCLUDED2911030401
#define PQS_???ABSTRACT-QUANTITY-NAME???_OUT_HPP_INCLUDED2911030401
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "???ABSTRACT-QUANTITY-NAME???.hpp"
#include "pqs/ct_quantity/io/output.hpp"

namespace pqs{

    // add overloads for incoherent-units here...
    // of_???ABSTRACT-QUANTITY-NAME??? is usually defined 
    //  in a header in
    // "pqs/ct_quantity/types/components/"
    
    //Alternatively coment this out if not required

    inline std::ostream& operator << (
        std::ostream & os,
        physical_quantity_units_out<
            of_???ABSTRACT-QUANTITY-NAME???::type,
            of_???ABSTRACT-QUANTITY-NAME???::incoherent_unit::???
        > )
    {
        os << "???";
        return os;
    }
    /*
        more incoherent-units
    */

}//pqs

#endif
