#ifndef PQS_TYPES_ALL_TYPES_OUT_HPP_INCLUDED
#define PQS_TYPES_ALL_TYPES_OUT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

//all pq-type-out headers
#include "pqs/config.hpp"
#ifdef PQS_USE_Q_PREFIX_ON_CT_QUANTITY_TYPES
#pragma message("Using q_prefix on ct_quantities")
#include "q_acceleration_out.hpp"
#include "q_area_out.hpp"
#include "q_capacitance_out.hpp"
#include "q_charge_out.hpp"
#include "q_conductance_out.hpp"
#include "q_current_out.hpp"
#include "q_density_out.hpp"
#include "q_energy_out.hpp"
#include "q_force_out.hpp"
#include "q_frequency_out.hpp"
#include "q_inductance_out.hpp"
#include "q_intensity_out.hpp"
#include "q_length_out.hpp"
#include "q_magnetic_field_strength_out.hpp"
#include "q_magnetic_flux_out.hpp"
#include "q_magnetic_flux_density_out.hpp"
#include "q_magnetomotive_force_out.hpp"
#include "q_mass_out.hpp"
#include "q_permeability_out.hpp"
#include "q_power_out.hpp"
#include "q_pressure_out.hpp"
#include "q_resistance_out.hpp"
#include "q_substance_out.hpp"
#include "q_temperature_out.hpp"
#include "q_time_out.hpp"
#include "q_torque_out.hpp"
#include "q_velocity_out.hpp"
#include "q_voltage_out.hpp"
#include "q_volume_out.hpp"

#else
#pragma message("Using non prefixed ct_quantities")
#include "acceleration_out.hpp"
#include "area_out.hpp"
#include "capacitance_out.hpp"
#include "charge_out.hpp"
#include "conductance_out.hpp"
#include "current_out.hpp"
#include "density_out.hpp"
#include "energy_out.hpp"
#include "force_out.hpp"
#include "frequency_out.hpp"
#include "inductance_out.hpp"
#include "intensity_out.hpp"
#include "length_out.hpp"
#include "magnetic_field_strength_out.hpp"
#include "magnetic_flux_out.hpp"
#include "magnetic_flux_density_out.hpp"
#include "magnetomotive_force_out.hpp"
#include "mass_out.hpp"
#include "permeability_out.hpp"
#include "power_out.hpp"
#include "pressure_out.hpp"
#include "resistance_out.hpp"
#include "substance_out.hpp"
#include "temperature_out.hpp"
#include "time_out.hpp"
#include "torque_out.hpp"
#include "velocity_out.hpp"
#include "voltage_out.hpp"
#include "volume_out.hpp"
#endif
#endif
