#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TYPES_ANGULAR_VELOCITY_HPP_INCLUDED
#define PQS_TYPES_ANGULAR_VELOCITY_HPP_INCLUDED

#include "pqs/types/frequency.hpp"
#include "pqs/math/angles/angles.hpp"

namespace pqs{

    struct angular_velocity{
        typedef ct_quantity<
            named_abstract_quantity<
                of_frequency::anonymous_abstract_quantity_type,
                named_quantity_tag<1>
            >,
            quantity_unit<>,
            math::of_angle::rad
        > rad_div_s;
    };
}
#endif
