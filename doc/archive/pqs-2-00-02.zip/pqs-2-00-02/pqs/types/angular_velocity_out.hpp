#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TYPES_ANGULAR_VELOCITY_OUT_HPP_INCLUDED
#define PQS_TYPES_ANGULAR_VELOCITY_OUT_HPP_INCLUDED

#include "pqs/types/angular_velocity.hpp"
#include "pqs/math/angles/angles_out.hpp"

namespace pqs{

    inline std::ostream& operator << (
       std::ostream & os,
       pqs::angular_velocity::rad_div_s const & rad)
   {
     std::cout << rad.numeric_value().numeric_value()
     << " rad.s-1";
     return os;
   }


}

#endif
