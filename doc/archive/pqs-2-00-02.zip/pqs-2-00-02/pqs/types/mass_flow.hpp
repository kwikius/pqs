#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
/*
    This header is designed to be modified when defining the 
OfNamedQuantityScope concept for your own types
*/

// physical_quantities pqs-1-01-05Jul 11 2004
// feedback to andy@servocomm.freeserve.co.uk
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_MASS_FLOW_HPP_INCLUDED2911030401
#define PQS_MASS_FLOW_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/operations.hpp"
#include "pqs/ct_quantity/types/components/of_mass_flow.hpp"

namespace pqs{

   template<
      typename Value_type
   >
   struct mass_flow_ : of_mass_flow{

/*
 First the coherent versions of the quantity:

 BIG NOTE if your quantities have a prefix_offset !=0
     and or an extent !=1
 as defined in the mass_flow_mx.hpp header
 you will need to modify these prefixes.
 see mass.hpp for prefix_offset adjustment (off by 3)
    eg kg has a coherent-exponent of 0
     and g has a coherent exponent of -3
 and area.hpp for extent correction ( * 2)
 eg mm^2 has a a coherent exponent of -6 not -3 etc
*/
      //typedef ct_quantity<
      //   type,
      //   typename si_unit::yocto, // coherent-exponent -24
      //   Value_type
      //> y???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::zepto, // coherent-exponent -21
      //   Value_type
      //> z???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::atto, // coherent-exponent -18
      //   Value_type
      //> a???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::femto, // coherent-exponent -15
      //   Value_type
      //> f???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::pico, // coherent-exponent -12
      //   Value_type
      //> p???;

      typedef ct_quantity<
         type,
         typename si_unit::nano, // coherent-exponent -9
         Value_type
      > ug_div_s;

      typedef ct_quantity<
         type,
         typename si_unit::micro, // coherent-exponent -6
         Value_type
      > mg_div_s;

      typedef ct_quantity<
         type,
         typename si_unit::milli, // coherent-exponent -3
         Value_type
      > g_div_s;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::centi, // coherent-exponent -2
      //   Value_type
      //> c???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::deci, // coherent-exponent -1
      //   Value_type
      //> d???;

      typedef ct_quantity<
         type,
         typename si_unit::none, // coherent-exponent 0
         Value_type
      > kg_div_s;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::deka, // coherent-exponent 1
      //   Value_type
      //> da???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::hecto, // coherent-exponent 2
      //   Value_type
      //> h???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::kilo, // coherent-exponent 3
      //   Value_type
      //> k???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::mega, // coherent-exponent 6
      //   Value_type
      //> M???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::giga, // coherent-exponent 9
      //   Value_type
      //> G???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::tera, // coherent-exponent 12
      //   Value_type
      //> T???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::peta, // coherent-exponent 15
      //   Value_type
      //> P???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::exa, // coherent-exponent 18
      //   Value_type
      //> E???;

      //typedef ct_quantity<
      //   type,
      //   typename si_unit::zetta, // coherent-exponent 21
      //   Value_type
      //> Z???;

    // add incoherent versions of the quantity here eg
    // the NAME_FROM_MX_HEADER is the one declared in
    // "mass_flow_mx.hpp"
    // in of_ABSTRACT-QUANTITY-NAME::incoherent_unit member struct
     /* typedef ct_quantity<
         type,
         typename incoherent_unit::???NAME_FROM_MX_HEADER???,
         Value_type
      > ???NAME_FROM_MX_HEADER???;*/

    /*
        more incoherent quantities
    */

   };
// derived version for default quantity value_type
// forwards all the above typedefs
// of_quantity::default_value_type
// is defined in "pqs/ct_quantity/of_quantity.hpp"
   struct mass_flow 
    : mass_flow_<of_quantity::default_value_type>{};

}//pqs

#endif
