#include "q_acceleration.hpp"
using pqs::q_acceleration_;
// gravitational constant S.I units
template<>
q_acceleration_<float>::m_div_s2 const&
q_acceleration_<float>::g 
= q_acceleration_<float>::m_div_s2(9.80665f);

template<>
q_acceleration_<double>::m_div_s2 const&
q_acceleration_<double>::g
= q_acceleration_<double>::m_div_s2(9.80665);

template<>
q_acceleration_<int>::m_div_s2 const&
q_acceleration_<int>::g
= q_acceleration_<int>::m_div_s2(10);

