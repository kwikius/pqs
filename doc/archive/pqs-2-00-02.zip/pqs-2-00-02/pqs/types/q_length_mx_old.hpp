// physical_quantities pqs-1-00-02 03:50 29/11/2003
// feedback to andy@servocomm.freeserve.co.uk
//q_length_mx.hpp
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_TYPES_Q_LENGTH_MX_HPP_INCLUDED2911030401
#define PQS_TYPES_Q_LENGTH_MX_HPP_INCLUDED2911030401

#include "pqs/class_template/of_quantity.hpp"
#include "pqs/class_template/abstract_identity/abstract_identity.hpp"
#include "pqs/class_template/units/quantity_unit.hpp"

namespace pqs{

    struct of_length{
        
        static const char* const abstract_quantity_name()
        {
            return "length";
        }

        typedef abstract_pq<
             length_pwr<1>
        > type_signature;

        typedef abstract_identity<
           type_signature,
           auxiliary_tag<0>
        > type;

        struct incoherent_unit{

            typedef quantity_unit<
                coherent_exponent<11>,
                incoherent_multiplier<1495979>
            > AU;

            typedef quantity_unit<
                coherent_exponent<1>,
                incoherent_multiplier<2011684>
            > ch;
            
            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<1828804>
            > fathom;
            
            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<3048000>
            > ft;

            typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<3048006>
            > ft_us;

            typedef quantity_unit<
                coherent_exponent<-2>,
                incoherent_multiplier<2540000>
            > in;
            
            typedef quantity_unit<
                coherent_exponent<15>,
                incoherent_multiplier<9460730>
            > l_y_;

            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1609344>
            > mi;
            
            typedef quantity_unit<
                coherent_exponent<3>,
                incoherent_multiplier<1852000>
            > naut_mile;
            
            typedef quantity_unit<
                coherent_exponent<16>,
                incoherent_multiplier<3085678>
            > pc;
            
            typedef quantity_unit<
                coherent_exponent<-3>,
                incoherent_multiplier<4233333>
            > pica_comp;
            
            typedef quantity_unit<
                coherent_exponent<-3>,
                incoherent_multiplier<4217518>
            > pica_prn;
            
            typedef quantity_unit<
                coherent_exponent<-4>,
                incoherent_multiplier<3527778>
            > point_comp;
            
            typedef quantity_unit<
                coherent_exponent<-4>,
                incoherent_multiplier<3514598>
            > point_prn;

            typedef quantity_unit<
                coherent_exponent<0>,
                incoherent_multiplier<5029210>
            > rd;

           typedef quantity_unit<
                coherent_exponent<-1>,
                incoherent_multiplier<9144000>
           > yd;
        };
    };
}
#endif

