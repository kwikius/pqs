// physical_quantities pqs-1-00-02 03:50 29/11/2003
// feedback to andy@servocomm.freeserve.co.uk
//q_length.hpp
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#ifndef PQS_TYPES_Q_LENGTH_HPP_INCLUDED2911030401
#define PQS_TYPES_Q_LENGTH_HPP_INCLUDED2911030401

#include "defaults.hpp"
#include "q_length_mx.hpp"

namespace pqs{

    template< 
        typename Value_type
    >
    struct q_length_ : of_length{

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::yotta
       > Ym;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::zetta
       > Zm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::exa
       > Em;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::peta
       > Pm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::tera
       > Tm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::giga
       > Gm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::mega
       > Mm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::kilo
       > km;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::hecto
       > hm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::deka
       > dam;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::none
       > m;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::deci
       > dm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::centi
       > cm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::milli
       > mm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::micro
       > um;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::nano
       > nm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::pico
       > pm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::femto
       > fm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::atto
       > am;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::zepto
       > zm;

       typedef ct_quantity<
          Value_type,
          type,
          si_unit::yocto
       > ym;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::AU
       > AU;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::ch
       > ch;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::fathom
       > fathom;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::ft
       > ft;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::ft_us
       > ft_us;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::in
       > in;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::l_y_
       > l_y_;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::mi
       > mi;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::naut_mile
       > naut_mile;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::pc
       > pc;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::pica_comp
       > pica_comp;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::pica_prn
       > pica_prn;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::point_comp
       > point_comp;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::point_prn
       > point_prn;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::rd
       > rd;

       typedef ct_quantity<
           Value_type,
           type,
           incoherent_unit::yd
       > yd;

     };

     struct q_length : q_length_<of_quantity::default_value_type>{};
}
#endif
