#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif
// pqs-2-00-02,Oct  5 2004
//  Copyright (C) Andy Little, White Light Device 2003-2004.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "pqs/config.hpp"
#ifndef PQS_USE_Q_PREFIX_ON_CT_QUANTITY_TYPES
/*
The q_ prefix is deprecated.
This header is designed for use with q_ prefixed ct_quantities
To enable use of types with the q_prefix,
switch On the macro in "pqs/config.hpp"
If the "q_" prefix not required, use "pqs/types/pressure.hpp"
*/
#error Switch On PQS_USE_Q_PREFIX_ON_CT_QUANTITY_TYPES in "pqs/config.hpp"
#endif
#ifndef PQS_Q_PRESSURE_HPP_INCLUDED2911030401
#define PQS_Q_PRESSURE_HPP_INCLUDED2911030401

#include "pqs/ct_quantity/types_q_prefix/q_pressure.hpp"
#endif
