#ifndef BOOST_MPL_MATH_RATIONAL_INT_HPP_INCLUDED1
#define BOOST_MPL_MATH_RATIONAL_INT_HPP_INCLUDED1
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/mpl/math/rational.hpp>
namespace boost{namespace mpl{namespace math{

    template<int N, int D =1>
    struct rational_int : rational_c<int, N, D>{};
   
}}}

#endif

 