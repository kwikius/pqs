#ifndef BOOST_PQS_CONFIG_HPP_INCLUDED
#define BOOST_PQS_CONFIG_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    Configuration options for boost::pqs
*/
#define PQS_COMPARISON_EPSILON 0.0

//#define BOOST_PQS_REAL_TYPE float
//#define BOOST_PQS_MAX_EXPONENT10 38
//#define BOOST_PQS_MIN_EXPONENT10 -38

#define BOOST_PQS_REAL_TYPE double
#define BOOST_PQS_MAX_EXPONENT10 64
#define BOOST_PQS_MIN_EXPONENT10 -64

// used to test Boost. Typeof in compliant mode
//#define BOOST_TYPEOF_COMPLIANT
// register types with typeof
#include <boost/pqs/typeof_register.hpp>

#endif


