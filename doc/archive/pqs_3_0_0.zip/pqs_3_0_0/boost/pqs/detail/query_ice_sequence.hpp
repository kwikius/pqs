#ifndef BOOST_MPL_QUERY_VALUE_SEQUENCE_HPP_INCLUDED
#define BOOST_MPL_QUERY_VALUE_SEQUENCE_HPP_INCLUDED


#include "boost/config.hpp"
#include "boost/mpl/and.hpp"
#include "boost/mpl/count_if.hpp"

#include "boost/mpl/transform.hpp"
#include "boost/mpl/placeholders.hpp"
#include "boost/mpl/equal.hpp"
#include "boost/mpl/equal_to.hpp"
#include "boost/mpl/not_equal_to.hpp"
#include "boost/mpl/size.hpp"
#include "boost/mpl/assert.hpp"
#include "boost/mpl/contains.hpp"
#include "boost/mpl/fold.hpp"

namespace boost{ namespace mpl{

    template <typename Seq1, typename Seq2, typename Query >
    struct query_ice_sequence;

    template <
        typename Seq1,
        typename Seq2, 
        template<typename,typename> class Query
    >
    struct query_ice_sequence<
            Seq1, Seq2, Query<_1,_2>
    >{
        BOOST_MPL_ASSERT( ( and_<is_sequence<Seq1>,is_sequence<Seq2> > ) );
        BOOST_MPL_ASSERT_RELATION( size<Seq1>::value ,==, size<Seq2>::value );
        typedef typename transform<
            Seq1,Seq2,
            Query<_1,_2> 
        >::type queried_sequence; 
        typedef typename count_if<
            queried_sequence ,
            not_equal_to<_1,true_ > 
        >::type differences_count;  
        typedef typename equal_to<
            differences_count,
            false_
        >::type  type;
    };
}}
#endif
