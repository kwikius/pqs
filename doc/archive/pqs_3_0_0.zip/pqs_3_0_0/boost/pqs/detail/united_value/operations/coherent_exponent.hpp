#ifndef BOOST_PQS_COHERENT_EXPONENT_HPP_INCLUDED
#define BOOST_PQS_COHERENT_EXPONENT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    the coherent exponent represents the exponent 
    of the unit of a coherent quantity.
    e.g kilometers has a coherent exponent of 3.
    Rational exponents are also valid.
    The is_integer and is_positive are used 
    to determine how to best optimise when evaluating.
    IOW where possible an int result_type is returned.
*/
#include <boost/pqs/quantity_traits.hpp>
#include <boost/mpl/math/rational.hpp>
#include <boost/typeof/typeof.hpp>

#include <boost/pqs/detail/united_value/operations/coherent_exponent_eval.hpp>

namespace boost{namespace pqs{namespace concept_checking{
    // used to check that a coherent-exponent is computable
    namespace detail {
         template< int Expnume, int Expdenom>
         struct  CoherentExponentInRangeImpl{
            enum{ value 
            = (( (Expdenom == 1 ) 
            &&(Expnume >= boost::pqs::quantity_traits::min_int_coherent_exponent) 
            && (Expnume <= boost::pqs::quantity_traits::max_int_coherent_exponent)) 
                || ((Expnume <= boost::pqs::quantity_traits::max_rat_coherent_exponent * Expdenom)
                && (Expnume >= boost::pqs::quantity_traits::min_rat_coherent_exponent * Expdenom)) )
            };
         };
    }// detail

     template< int Expnume, int Expdenom>
    ////////////////////////////////////////////////////////
     struct AssertCoherentExponentInRange
    ///////////////////////////////////////////////////////
     // Assertion fails if the coherent-exponent in a quantity_unit 
    // is too big or too small to be evaluated
    : Assert < (detail::CoherentExponentInRangeImpl<Expnume,Expdenom>::value)>
  {};
}}}//boost::pqs::concept_checking

namespace boost{namespace pqs{ namespace detail{

    template <typename N, typename D>
    struct coherent_exponent 
    {
        typedef typename   boost::mpl::math::rational<N,D>::type base_type;
        enum{
            numerator = base_type::numerator::value,
            denominator = base_type::denominator::value,
            is_integer = ( denominator == 1 ),
            is_positive = ( numerator >= 0 ),
            is_zero  = ( numerator == 0)
        };
        template<
            typename ResultType
        >
        struct eval 
        // check in range of eval functions
        : concept_checking::AssertCoherentExponentInRange< numerator , denominator>
        ,  detail::coherent_exponent_eval<
            ResultType,
            numerator,
            denominator,
            (is_positive 
            && is_integer 
            && (((is_positive ) ? numerator : -numerator) 
                            <= boost::pqs::quantity_traits::max_int_exponent))
        >{};
        
        typedef coherent_exponent<
                boost::mpl::int_<numerator>,
                boost::mpl::int_<denominator> 
        >
         type; 
    };
}}}//boost::pqs::detail



 
#endif
