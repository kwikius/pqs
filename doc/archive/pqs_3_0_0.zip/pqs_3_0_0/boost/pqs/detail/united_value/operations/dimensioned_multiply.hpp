#ifndef BOOST_PQS_OPERATIONS_DIMENSIONED_MULTIPLY_HPP_INCLUDED
#define BOOST_PQS_OPERATIONS_DIMENSIONED_MULTIPLY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/detail/united_value/united_value_fwd.hpp>
#include <boost/pqs/detail/united_value/operations/incoherent_mx.hpp>
#include <boost/mpl/times.hpp>
#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/to_arithmetic.hpp>

namespace boost {namespace pqs{namespace detail{

    template<
        typename UnitedValueA, 
        typename UnitedValueB,
        typename Eval_Fx,
        bool Eval_fx_Required
    >
    struct dimensioned_multiply_functor_eval;

    template< 
        typename UnitA,
        typename Value_typeA,
        typename UnitB,
        typename Value_typeB
    > struct dimensioned_multiply_functor{
        typedef united_value<
            UnitA,
            Value_typeA
        > uva_type;
        typedef united_value<
            UnitB,
            Value_typeB
        > uvb_type;
        typedef typename boost::mpl::times<
                UnitA,
                UnitB
        >::type result_unit;
        typedef typename boost::pqs::meta::binary_operation<
            Value_typeA,
            boost::pqs::meta::times,
            Value_typeB
        >::result_type value_type;
        typedef united_value<
            result_unit,
            value_type
        > result_type;
        typedef detail::multiply_incoherent_mx<  
            typename boost::pqs::meta::to_arithmetic<
                value_type
            >::type,
            typename UnitA::multiplier,
            typename UnitB::multiplier
        > incoherent_mx_fx;
        enum{ fx_required = incoherent_mx_fx::required};
        struct eval : dimensioned_multiply_functor_eval<
            uva_type,
            uvb_type, 
            incoherent_mx_fx,
            fx_required
        >
        {};
    };

   // one or both incoherent units so 
   // multiply values and use multiplier constant 
   // in Eval_Fx() functor
    template<
        typename UnitedValueA, 
        typename UnitedValueB,
        typename Eval_Fx
    >
    struct dimensioned_multiply_functor_eval<
        UnitedValueA,UnitedValueB, Eval_Fx, true
    >{
        typedef typename boost::mpl::times<
            typename UnitedValueA::units_type,
            typename UnitedValueB::units_type
        >::type result_unit;
        typedef typename boost::pqs::meta::arithmetic_promote<
            typename UnitedValueA::value_type,
            typename UnitedValueB::value_type
        >::type value_type;
        typedef united_value<
            result_unit,
            value_type
        > result_type;
            
        result_type operator()(UnitedValueA const & lhs, UnitedValueB const & rhs) const
        {
            result_type result( lhs.raw_value() * rhs.raw_value() * Eval_Fx()());
            return result;
        }
    };

// no incoherent units so simply multiply values
    template<
        typename UnitedValueA, 
        typename UnitedValueB,
        typename Eval_Fx
    >
    struct dimensioned_multiply_functor_eval<
        UnitedValueA,UnitedValueB,Eval_Fx, false
    >{
        typedef typename boost::mpl::times<
            typename UnitedValueA::units_type,
            typename UnitedValueB::units_type
        >::type result_unit;
        typedef typename boost::pqs::meta::arithmetic_promote<
            typename UnitedValueA::value_type,
            typename UnitedValueB::value_type
        >::type value_type;
         typedef united_value<
            result_unit,
            value_type
        > result_type;
        result_type operator()(UnitedValueA const & lhs, UnitedValueB const & rhs) const
        {
          result_type result( lhs.raw_value() * rhs.raw_value()) ;
          return result;  
        }
    };
// encapsulate functionality in a function
    template< 
        typename UnitA,
        typename Value_typeA,
        typename UnitB,
        typename Value_typeB
    >
    inline
    typename dimensioned_multiply_functor<
        UnitA,Value_typeA,UnitB,Value_typeB
    >::result_type
    dimensioned_multiply(
        united_value<UnitA,Value_typeA> const & lhs,
        united_value<UnitB,Value_typeB> const & rhs
    )
    {
        typedef  dimensioned_multiply_functor<
            UnitA,Value_typeA,UnitB,Value_typeB
        > func;
        typename func::result_type result = typename func::eval()(lhs,rhs);
        return result;
    }


}}}//boost::pqs::detail


#endif
