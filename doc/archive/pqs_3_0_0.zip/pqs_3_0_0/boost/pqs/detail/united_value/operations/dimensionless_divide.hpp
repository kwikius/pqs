#ifndef BOOST_PQS_DIMENSIONLESS_DIVIDE_TRAITS_HPP_INCLUDED
#define BOOST_PQS_DIMENSIONLESS_DIVIDE_TRAITS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.


#include "boost/pqs/detail/united_value/operations/quantity_conversion_traits.hpp"
#include <boost/pqs/meta/binary_operation.hpp>
 namespace boost {namespace pqs{ namespace detail{
    
    template<
        typename DimensionlessDivideTraits,
        bool Incoh, bool Delog, bool PosAlg
    >
    struct dimensionless_divide_functor_eval;
    
    template <
        typename Value_typeA,
        typename UnitsA,
        typename Value_typeB,
        typename UnitsB
    > 
    struct dimensionless_divide_functor{

        typedef quantity_conversion_traits<
            Value_typeB,                //Target_value_type,
            UnitsB,                     //Target_unit,
            Value_typeA,                //Source_value_type,
            UnitsA                      //Source_unit
        > conversion_traits;

        typedef typename conversion_traits::source_value_type 
            value_typeA;
        typedef typename conversion_traits::target_value_type 
            value_typeB;
        typedef typename conversion_traits::incoherent_divide_fx 
            incoherent_divide_fx;
        typedef typename conversion_traits::abs_difference_delog_fx 
            abs_difference_delog_fx;
        typedef typename conversion_traits::first_difference_exponent 
            first_difference_exponent;

        typedef typename pqs::meta::binary_operation<
            value_typeA,
            boost::pqs::meta::divides,
            value_typeB
        >::result_type result_type;

        struct eval : dimensionless_divide_functor_eval<
            dimensionless_divide_functor,
            incoherent_divide_fx::required,
            abs_difference_delog_fx::required,
            boost::mpl::math::is_positive< 
                first_difference_exponent
            >::type::value   
        >{};
    };
  
    //incoherent_fx_required                    == true
    //abs_difference_delog_fx_required          == true 
    //first_difference_exponent::is_positive    == true 
    template<typename DimensionlessDivideTraits>
    struct dimensionless_divide_functor_eval<
            DimensionlessDivideTraits,
            true,true,true
    >{
        typename DimensionlessDivideTraits::result_type 
        operator()(
            typename DimensionlessDivideTraits::value_typeA const& lhs,
            typename DimensionlessDivideTraits::value_typeB const& rhs
        )const
        {
           typename DimensionlessDivideTraits::result_type result
            = lhs 
            * (typename DimensionlessDivideTraits::incoherent_divide_fx()() 
            * (typename DimensionlessDivideTraits::abs_difference_delog_fx()() / rhs));
            return result;
        }
    };
    
    //incoherent_fx_required                    == true
    //abs_difference_delog_fx_required          == false 
    //first_difference_exponent::is_positive    == X 
    template<typename DimensionlessDivideTraits,bool X>
    struct dimensionless_divide_functor_eval<DimensionlessDivideTraits,true,false,X>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
            typename DimensionlessDivideTraits::value_typeA const& lhs,
            typename DimensionlessDivideTraits::value_typeB const& rhs
        )const
        {
            typename DimensionlessDivideTraits::result_type result
            = lhs * typename DimensionlessDivideTraits::incoherent_divide_fx()() / rhs ;
            return result;
        }
    };
    
    //incoherent_fx_required                    == false
    //abs_difference_delog_fx_required          == true 
    //first_difference_exponent::is_positive    == true 
    template<typename DimensionlessDivideTraits>
    struct dimensionless_divide_functor_eval<DimensionlessDivideTraits,false,true,true>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
            typename DimensionlessDivideTraits::value_typeA const& lhs,
            typename DimensionlessDivideTraits::value_typeB const& rhs
        )const
        {
            typename DimensionlessDivideTraits::result_type result
            = lhs * typename DimensionlessDivideTraits::abs_difference_delog_fx()() 
            / rhs;
            return result;
        }
    };
    
    //incoherent_fx_required                    == true
    //abs_difference_delog_fx_required          == true 
    //first_difference_exponent::is_positive    == false 
    template<typename DimensionlessDivideTraits>
    struct dimensionless_divide_functor_eval<DimensionlessDivideTraits,true,true,false>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
            typename DimensionlessDivideTraits::value_typeA const& lhs,
            typename DimensionlessDivideTraits::value_typeB const& rhs
        )const
        {
            typename DimensionlessDivideTraits::result_type result
            = lhs 
            / ( rhs * typename DimensionlessDivideTraits::abs_difference_delog_fx()() 
                / typename DimensionlessDivideTraits::incoherent_divide_fx()());
            return result;
        }
    };

    //incoherent_fx_required                    == false
    //abs_difference_delog_fx_required          == true 
    //first_difference_exponent::is_positive    == false 
    template<typename DimensionlessDivideTraits>
    struct dimensionless_divide_functor_eval<DimensionlessDivideTraits,false,true,false>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
            typename DimensionlessDivideTraits::value_typeA const& lhs,
            typename DimensionlessDivideTraits::value_typeB const& rhs
        )const
        {
            typename DimensionlessDivideTraits::result_type result
            = lhs 
            / ( rhs * typename DimensionlessDivideTraits::abs_difference_delog_fx()());
            return result;
        }
    };

    //incoherent_fx_required                    == false
    //abs_difference_delog_fx_required          == false 
    //first_difference_exponent::is_positive    == X 
    template<typename DimensionlessDivideTraits,bool X>
    struct dimensionless_divide_functor_eval<DimensionlessDivideTraits,false,false,X>{
        typename DimensionlessDivideTraits::result_type 
        operator()(
            typename DimensionlessDivideTraits::value_typeA const& lhs,
            typename DimensionlessDivideTraits::value_typeB const& rhs
        )const
        {
            typename DimensionlessDivideTraits::result_type result
            = lhs / rhs;
            return result;
        }
    };
    template <
        typename Value_typeA,
        typename UnitA,
        typename Value_typeB,
        typename UnitB
    >
    inline
    typename dimensionless_divide_functor<
        typename Value_typeA,
        typename UnitA,
        typename Value_typeB,
        typename UnitB
    >::result_type
    dimensionless_divide(
        united_value<UnitA,Value_typeA> const & lhs,
        united_value<UnitB,Value_typeB> const & rhs
    )
    {
        typedef dimensionless_divide_functor<
            typename Value_typeA,
            typename UnitA,
            typename Value_typeB,
            typename UnitB
        > func;
        typename func::result_type result 
        = typename func::eval()(lhs.raw_value(),rhs.raw_value());
        return result;
     };   
   
}}}//boost::pqs::detail

#endif
