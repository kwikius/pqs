#ifndef BOOST_PQS_DIMENSIONLESS_MULTIPLY_TRAITS_HPP_INCLUDED
#define BOOST_PQS_DIMENSIONLESS_MULTIPLY_TRAITS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
   united value multipy low level calcs
*/

#include "boost/pqs/detail/united_value/operations/quantity_conversion_traits.hpp"

 namespace boost{ namespace pqs{ namespace detail{

    template<
        typename DimlessMulTraits,
        bool Incoh, 
        bool Delog,
        bool PosAlg
    >
    struct dimensionless_multiply_functor_eval;

    template <
        typename Value_typeA,
        typename UnitsA,
        typename Value_typeB,
        typename UnitsB
    > 
    struct dimensionless_multiply_functor{

        typedef quantity_conversion_traits<
            Value_typeB,                //Target_value_type,
            UnitsB,                     //Target_unit,
            Value_typeA,                //Source_value_type,
            UnitsA                      //Source_unit
        > conversion_traits;
        typedef typename conversion_traits::source_value_type value_typeA;
        typedef typename conversion_traits::target_value_type value_typeB;
        typedef typename conversion_traits::incoherent_multiply_fx incoherent_multiply_fx;
        typedef typename conversion_traits::abs_sum_delog_fx abs_sum_delog_fx;
        typedef typename conversion_traits::first_sum_exponent first_sum_exponent;
        typedef typename pqs::meta::binary_operation<
            value_typeA,
            boost::pqs::meta::times,
            value_typeB
        >::result_type result_type;

        struct eval : dimensionless_multiply_functor_eval<
                    dimensionless_multiply_functor,
                    incoherent_multiply_fx::required,
                    abs_sum_delog_fx::required,
                    boost::mpl::math::is_positive<
                        first_sum_exponent
                    >::type::value
        >{};
    };

    //incoherent_fx_required             == true
    //abs_sum_delog_fx_required          == true 
    //first_sum_exponent::is_positive    == true 
    template<typename DimlessMulTraits>
    struct dimensionless_multiply_functor_eval<DimlessMulTraits,true,true,true>{
        typename DimlessMulTraits::result_type 
        operator()(
            typename DimlessMulTraits::value_typeA const& lhs,
            typename DimlessMulTraits::value_typeB const& rhs)const
        {
            typename DimlessMulTraits::result_type result
            = lhs * rhs
            * typename DimlessMulTraits::incoherent_multiply_fx()() 
            * typename DimlessMulTraits::abs_sum_delog_fx()();
            return result;
        }
    };
    
    //incoherent_fx_required             == true
    //abs_sum_delog_fx_required          == false 
    //first_sum_exponent::is_positive    == X 
    template<typename DimlessMulTraits,bool X>
    struct dimensionless_multiply_functor_eval<DimlessMulTraits,true,false,X>{
        typename DimlessMulTraits::result_type
        operator()(
            typename DimlessMulTraits::value_typeA const& lhs,
            typename DimlessMulTraits::value_typeB const& rhs)const
        {
            typename DimlessMulTraits::result_type result
            = lhs * rhs 
            * typename DimlessMulTraits::incoherent_multiply_fx()();
            return result;
        }
    };
    
    //incoherent_fx_required             == false
    //abs_sum_delog_fx_required          == true 
    //first_sum_exponent::is_positive    == true 
    template<typename DimlessMulTraits>
    struct dimensionless_multiply_functor_eval<DimlessMulTraits,false,true,true>{
        typename DimlessMulTraits::result_type
        operator()(
            typename DimlessMulTraits::value_typeA const& lhs,
            typename DimlessMulTraits::value_typeB const& rhs)const
        {
            typename DimlessMulTraits::result_type result
            = lhs * rhs * typename DimlessMulTraits::abs_sum_delog_fx()();
            return result;
        }
    };
    
    //incoherent_fx_required             == true
    //abs_sum_delog_fx_required          == true 
    //first_sum_exponent::is_positive    == false 
    template<typename DimlessMulTraits>
    struct dimensionless_multiply_functor_eval<DimlessMulTraits,true,true,false>{
        typename DimlessMulTraits::result_type
        operator()(
            typename DimlessMulTraits::value_typeA const& lhs,
            typename DimlessMulTraits::value_typeB const& rhs)const
        {
            typename DimlessMulTraits::result_type result
            = lhs * rhs * typename DimlessMulTraits::incoherent_multiply_fx()()
            /  typename DimlessMulTraits::abs_sum_delog_fx()() ;
            return result;
        }
    };

    //incoherent_fx_required             == false
    //abs_sum_delog_fx_required          == true 
    //first_sum_exponent::is_positive    == false 
    template<typename DimlessMulTraits>
    struct dimensionless_multiply_functor_eval<DimlessMulTraits,false,true,false>{
        typename DimlessMulTraits::result_type
        operator()(
            typename DimlessMulTraits::value_typeA const& lhs,
            typename DimlessMulTraits::value_typeB const& rhs)const
        {
            typename DimlessMulTraits::result_type result 
            = lhs * rhs
            /  typename DimlessMulTraits::abs_sum_delog_fx()() ;
            return result;
        }
    };

    //incoherent_fx_required             == false
    //abs_sum_delog_fx_required          == false 
    //first_sum_exponent::is_positive    == X 
    template<typename DimlessMulTraits,bool X>
    struct dimensionless_multiply_functor_eval<DimlessMulTraits,false,false,X>{
        typename DimlessMulTraits::result_type 
        operator()(
            typename DimlessMulTraits::value_typeA const& lhs,
            typename DimlessMulTraits::value_typeB const& rhs)const
        {
            typename DimlessMulTraits::result_type  result
            = lhs * rhs;
            return  result;
        }
    };

     template< 
        typename UnitA,
        typename Value_typeA,
        typename UnitB,
        typename Value_typeB
    >
    inline
    typename dimensionless_multiply_functor<
        Value_typeA,UnitA,Value_typeB,UnitB
    >::result_type
    dimensionless_multiply(
        united_value<UnitA,Value_typeA> const & lhs,
        united_value<UnitB,Value_typeB> const & rhs
    )
    {
        typedef  dimensionless_multiply_functor<
            Value_typeA,UnitA,Value_typeB,UnitB
        > func;
        typename func::result_type result 
        = typename func::eval()(lhs.raw_value(),rhs.raw_value());
        return result;
    }
    
}}}//boost::pqs::detail

#endif
