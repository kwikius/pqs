#ifndef BOOST_PQS_DETAIL_INCOHERENT_MX_HPP_INCLUDED
#define BOOST_PQS_DETAIL_INCOHERENT_MX_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    get incoherent multiplier /divide value
*/

#include <boost/pqs/quantity_traits.hpp>
#include <boost/pqs/meta/min_type.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/denominator.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/or.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/utility/enable_if.hpp>

namespace boost{namespace pqs{ namespace detail{
 // restricted to arithmetic types only

    template <
        typename Value_type,
        typename Nume,
        typename Denom,
        typename Enable = void
    >
    struct divide_incoherent_mx ;

    template <
        typename Value_type,
        typename Nume,
        typename Denom
    >
    struct divide_incoherent_mx <
        Value_type,
        Nume,
        Denom,
        typename boost::enable_if<
            boost::mpl::and_<
                boost::mpl::equal_to<
                    typename boost::mpl::math::denominator<Nume>::type,
                    typename boost::mpl::math::denominator<Denom>::type
                >,
                boost::mpl::not_equal_to<
                    typename boost::mpl::math::numerator<Nume>::type,
                    typename boost::mpl::math::numerator<Denom>::type
                >
            >
        >::type
    > : boost::pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required = true};
        typedef typename boost::pqs::quantity_traits::min_real<
            Value_type
        >::type result_type;
        result_type  operator()()const throw()
        {   
            result_type result
            = static_cast<result_type>(boost::mpl::math::numerator<Nume>::type::value)
                    /boost::mpl::math::numerator<Denom>::type::value;
            return result;
        } 
    };

    template<
        typename Value_type,
        typename Nume,
        typename Denom
    >
    struct divide_incoherent_mx <
        Value_type,
        Nume, 
        Denom,
        typename boost::enable_if<
            boost::mpl::equal_to<Nume,Denom>
        >::type
    > : boost::pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required = false};
        typedef typename boost::pqs::meta::int_promote<
            Value_type
        >::type result_type;
       
        result_type operator ()()const throw()
        {   
            return  1;// static_cast<result_type>(1);
        } 
    };

    template <
        typename Value_type,
        typename Nume,
        typename Denom
    >
    struct divide_incoherent_mx <
        Value_type,
        Nume,
        Denom,
        typename boost::enable_if<
            boost::mpl::and_<
                boost::mpl::not_equal_to<
                    typename boost::mpl::math::denominator<Nume>::type,
                    typename boost::mpl::math::denominator<Denom>::type
                >,
                boost::mpl::not_equal_to<
                    typename boost::mpl::math::numerator<Nume>::type,
                    typename boost::mpl::math::numerator<Denom>::type
                >
            >
        >::type
    > : boost::pqs::concept_checking::AssertIsArithmetic<Value_type>
    {
        enum{required = true};
        typedef typename boost::pqs::quantity_traits::min_real<
            Value_type
        >::type result_type;
        result_type  operator()()const throw()
        {   
            result_type result
            = (static_cast<result_type>(boost::mpl::math::numerator<Nume>::type::value)
                        / boost::mpl::math::denominator<Nume>::type::value)
                    * (static_cast<result_type>( boost::mpl::math::denominator<Denom>::type::value)
                        / boost::mpl::math::numerator<Denom>::type::value);
            return result;
        } 
    };


     template<
        typename Value_type,
        typename MxL,
        typename MxR,
        typename Enable = void
     >
     struct multiply_incoherent_mx ;
  
     template<
        typename Value_type,
        typename MxL,
        typename MxR
     >
     struct multiply_incoherent_mx <
        Value_type,MxL,MxR,
        typename boost::enable_if<
            boost::mpl::and_<
                boost::mpl::equal_to<
                    MxL,
                    boost::mpl::int_<1>
                >,
                boost::mpl::equal_to<
                    MxR,
                    boost::mpl::int_<1>
                >
            >
        >::type
    >
     : boost::pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required =false};
        typedef typename boost::pqs::meta::int_promote<
                Value_type
        >::type  result_type;
  
        result_type  operator()() throw()
        {  
            return 1;
        } 
    };

    template<
        typename Value_type,
        typename MxL,
        typename MxR
     >
     struct multiply_incoherent_mx <
        Value_type,MxL,MxR,
        typename boost::enable_if<
            boost::mpl::or_<
                boost::mpl::not_equal_to<
                    MxL,
                    boost::mpl::int_<1>
                >,
                boost::mpl::not_equal_to<
                    MxR,
                    boost::mpl::int_<1>
                >
            >
        >::type
    >
     : boost::pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required =true};
        typedef typename boost::pqs::quantity_traits::min_real<
            Value_type
        >::type result_type;
  
        result_type  operator()() throw()
        {  
            result_type result 
            = (static_cast<result_type>(
                    typename boost::mpl::math::numerator<MxL>::type::value)
                    / typename boost::mpl::math::denominator<MxL>::type::value)
                * (static_cast<result_type>(
                        typename boost::mpl::math::numerator<MxR>::type::value)
                    / typename boost::mpl::math::denominator<MxR>::type::value)
            ;
            return result;
        } 
    };

}}}//boost::pqs::detail

#endif



