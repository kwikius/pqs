#ifndef BOOST_PQS_UNITED_VALUE_HPP_INCLUDED
#define BOOST_PQS_UNITED_VALUE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/config.hpp>
#include <boost/pqs/quantity_traits.hpp>
#include <boost/implicit_cast.hpp>
#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/pqs/detail/united_value/united_value_fwd.hpp>
#include <boost/pqs/detail/united_value/operations/value_cast.hpp>
#include <boost/mpl/is_negative.hpp>
#include <boost/pqs/pow_identities.hpp>
#include <boost/pqs/meta/evaluate_mpl_ice.hpp>
#include <boost/mpl/math/rational.hpp>
#include <boost/mpl/math/rational_int.hpp>

/*
    united_value is a quantity without dimensional analysis
*/
#include <boost/utility/enable_if.hpp>
#include <boost/pqs/meta/binary_operation.hpp>

#include <boost/typeof/typeof.hpp>
#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP() 
BOOST_TYPEOF_REGISTER_TEMPLATE(boost::pqs::detail::united_value, 2);

namespace boost{ namespace pqs{ namespace meta{

#define BOOST_PQS_UNITED_VALUE_BINOP(Op) \
    template < \
        typename UnitsL BOOST_PP_COMMA() \
        typename ValueTypeL BOOST_PP_COMMA() \
        typename UnitsR BOOST_PP_COMMA() \
        typename ValueTypeR \
    > \
    struct binary_operation< \
        boost::pqs::detail::united_value<UnitsL BOOST_PP_COMMA() ValueTypeL \
        > BOOST_PP_COMMA() \
        boost::pqs::meta:: ## Op BOOST_PP_COMMA() \
        boost::pqs::detail::united_value<UnitsR BOOST_PP_COMMA() ValueTypeR> \
    >{ \
        typedef boost::pqs::detail::united_value< \
            typename boost::mpl::## Op < \
                UnitsL BOOST_PP_COMMA() UnitsR \
            >::type BOOST_PP_COMMA() \
            typename pqs::meta::binary_operation< \
                ValueTypeL BOOST_PP_COMMA() \
                boost::pqs::meta:: ## Op BOOST_PP_COMMA() \
                ValueTypeR \
            >::result_type \
        > result_type; \
    };
    BOOST_PQS_UNITED_VALUE_BINOP(plus)
    BOOST_PQS_UNITED_VALUE_BINOP(minus)

#undef BOOST_PQS_UNITED_VALUE_BINOP

    //template
    //// need reciprocal, pow
    template<
        typename Unit, 
        typename ValueType, 
        typename PowType
    >
    struct binary_operation<
        boost::pqs::detail::united_value<Unit,ValueType>,
        pqs::meta::pow,
        PowType,
        typename boost::enable_if<
            boost::mpl::or_<
                boost::mpl::greater<
                    PowType,
                    boost::mpl::int_<1>
                >,
                boost::mpl::is_negative<
                    PowType
                >
            >
        >::type
    >{
        typedef boost::pqs::detail::united_value<
            typename boost::mpl::pow<
                Unit,
                PowType
            >::type,
            typename binary_operation<
                typename ValueType,
                boost::pqs::meta::pow,
                PowType
            >::result_type
        > result_type;
    };
         
}}}//boost::pqs::meta

namespace boost{namespace pqs{namespace detail{

    template <
        typename Units, 
        typename ValueType
    >
    class united_value{
    public:
        typedef Units units_type;
        typedef ValueType value_type;

        inline united_value() ;
        inline explicit united_value(value_type const & in) ;
      
        template<typename Value_typeIn>
        inline explicit united_value(Value_typeIn const & in) ;
        inline united_value(united_value const & in);

        template <typename UnitsIn, typename Value_typeIn>
        inline united_value(united_value<UnitsIn,Value_typeIn> const & in);

#define BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP(Op)\
        inline united_value & operator Op (united_value const & in);\
        template <typename UnitsIn, typename ValueTypeIn>\
        inline united_value & operator Op (\
            united_value<UnitsIn,ValueTypeIn> const & in\
        );
        BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP(=)
        BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP(+=)
        BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP(-=)

        template <typename Arithmetic>
        typename boost::enable_if<
           boost::pqs::meta::is_value_type<Arithmetic>,
            united_value &
        >::type
        operator *= ( Arithmetic const & in){
            this->value *= in;
            return *this;
        }
        template <typename Arithmetic>
        typename boost::enable_if<
            boost::pqs::meta::is_value_type<Arithmetic>,
            united_value &
        >::type
        operator /= ( Arithmetic const & in){
            this->value /= in;
            return *this;
        }

#undef BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP

// cast to eg double from united_value
        template<typename T>
        typename boost::pqs::meta::binary_operation<
            T,
            boost::pqs::meta::divides,
            ValueType,
            typename boost::enable_if<
                boost::pqs::meta::is_value_type<T>
            >::type
         >::result_type
        arithmetic_cast()const
        {
            typedef typename boost::pqs::meta::binary_operation<
                united_value,
                boost::pqs::meta::divides,  
                united_value
            >::result_type this_res_type; // coherent unitless type
            this_res_type t(*this) ; // scale
            typename this_res_type::value_type v
            = boost::pqs::quantity_traits::value_type_converter<
                T,typename this_res_type::value_type
            >()(t.raw_value());
            return v;   
        }
        value_type raw_value() const {return m_value;} 
        value_type & raw_value_ref()
        {
           return  m_value;
        }
    private:
        value_type m_value; 
    };

///////////////united_value definitions/////////////////

// default ctor init default ValueType
    template <
        typename Units, 
        typename ValueType
    >
    inline
    united_value<Units,ValueType>::united_value() 
    : m_value(ValueType())
    {}
// value ctor where in.type == ValueType
    template <
        typename Units, 
        typename ValueType
    >
    inline
    united_value<Units,ValueType>::united_value(
        ValueType const& in 
    ) 
    : m_value(in)
    {}
    // value ctor where in.type implicit convertible to ValueType
    template <
        typename Units, 
        typename ValueType
    >
    template<
        typename ValueTypeIn
    >
    inline
    united_value<Units,ValueType>::united_value(
        ValueTypeIn const & in
    ) 
    : m_value( boost::implicit_cast<ValueType>(in))
    {}
   // copy ctor where in is of same type
    template <
        typename Units,
        typename ValueType
    >
    inline
    united_value<Units,ValueType>::united_value(
        united_value const & in
    )
    : m_value(in.m_value)
    {}

// copy ctor where in has different value_type and units
    template <
        typename Units,
        typename ValueType
    >
    template <
        typename UnitsIn,
        typename ValueTypeIn
    >
    inline  
    united_value<Units,ValueType>::united_value(
        united_value<UnitsIn,ValueTypeIn> const & in
    )
    : m_value(detail::united_value_cast<united_value>(in))
    {}

#define BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP(Op) \
    template <typename Units,typename ValueType>\
    inline united_value<Units, ValueType> & \
    united_value<Units, ValueType>::operator Op (united_value const & in)\
    { this->m_value Op in.m_value; return *this;}\
    template <typename Units,typename ValueType>\
    template <typename UnitsIn,typename ValueTypeIn>\
    inline united_value<Units,ValueType>&\
    united_value<Units, ValueType>:: operator Op (\
        united_value<UnitsIn,ValueTypeIn> const & in\
    ) \
    { \
        united_value c = in; \
        this->m_value Op c.m_value; \
        return *this; \
    }
BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP(=)
BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP(+=)
BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP(-=)

#undef BOOST_PQS_UNITED_VALUE_ASSIGNMENT_OP

#define BOOST_PQS_UNITED_VALUE_BINOP(MetaOp,Op) \
    template < \
        typename UnitsL BOOST_PP_COMMA() \
        typename ValueTypeL BOOST_PP_COMMA() \
        typename UnitsR BOOST_PP_COMMA() \
        typename ValueTypeR \
    > \
    typename pqs::meta::binary_operation< \
        united_value<UnitsL BOOST_PP_COMMA() ValueTypeL> BOOST_PP_COMMA() \
        meta:: ## MetaOp BOOST_PP_COMMA() \
        united_value<UnitsR BOOST_PP_COMMA() ValueTypeR> \
    >::result_type \
    operator  Op ( \
        united_value<UnitsL BOOST_PP_COMMA() ValueTypeL> const & lhs \
        BOOST_PP_COMMA() \
        united_value<UnitsR BOOST_PP_COMMA() ValueTypeR> const & rhs ) \
    {   typename pqs::meta::binary_operation< \
        united_value<UnitsL BOOST_PP_COMMA() ValueTypeL> BOOST_PP_COMMA() \
            meta:: ## MetaOp BOOST_PP_COMMA() \
            united_value<UnitsR BOOST_PP_COMMA() ValueTypeR> \
        >::result_type result(lhs); \
        result  Op ## = rhs; \
        return result; \
    }

/////////////////
////////////////
//#undef BOOST_PQS_UNITED_VALUE_BINOP
//#define BOOST_PQS_UNITED_VALUE_BINOP(MetaOp,Op) \
//    template < \
//        typename UnitsL BOOST_PP_COMMA() \
//        typename ValueTypeL BOOST_PP_COMMA() \
//        typename UnitsR BOOST_PP_COMMA() \
//        typename ValueTypeR \
//    > \
//    typename pqs::meta::binary_operation< \
//        united_value<UnitsL BOOST_PP_COMMA() ValueTypeL> BOOST_PP_COMMA() \
//        meta:: ## MetaOp BOOST_PP_COMMA() \
//        united_value<UnitsR BOOST_PP_COMMA() ValueTypeR> \
//    >::result_type \
//    operator  Op ( \
//        united_value<UnitsL BOOST_PP_COMMA() ValueTypeL> const & lhs \
//        BOOST_PP_COMMA() \
//        united_value<UnitsR BOOST_PP_COMMA() ValueTypeR> const & rhs ) \
//    { 
//        //typedef
//        typename pqs::meta::binary_operation< \
//        united_value<UnitsL BOOST_PP_COMMA() ValueTypeL> BOOST_PP_COMMA() \
//            meta:: ## MetaOp BOOST_PP_COMMA() \
//            united_value<UnitsR BOOST_PP_COMMA() ValueTypeR> \
//        >::result_type result(lhs.value * rhs.value); \
//       // result  Op ## = rhs; \
//        return result; \
//    }

    BOOST_PQS_UNITED_VALUE_BINOP(plus,+)
    BOOST_PQS_UNITED_VALUE_BINOP(minus,-)
// 
//    BOOST_PQS_UNITED_VALUE_BINOP(times,*)
//    BOOST_PQS_UNITED_VALUE_BINOP(divides,/) 

    template<int N, int D , typename Units, typename ValueType>
    inline
    typename boost::enable_if<
        boost::mpl::or_<
            boost::mpl::greater<
                boost::mpl::math::rational_int<N,D>,
                boost::mpl::int_<1>
            >,
            boost::mpl::is_negative<
                boost::mpl::math::rational_int<N,D>
            >
        >,
        typename  boost::pqs::meta::binary_operation<
            united_value<Units,ValueType>,
            boost::pqs::meta::pow,
            boost::mpl::math::rational_int<N,D>
        >::result_type   
    >::type
    pow( united_value<Units,ValueType> const & v)
    {
        typedef united_value<
            typename  boost::pqs::meta::
                    detail::transform_coherent<
                Units
            >::type,
            ValueType
        >  coherent_type; 
       
        typedef typename  boost::pqs::meta::binary_operation<
            united_value<Units,ValueType>,
            boost::pqs::meta::pow,
            boost::mpl::math::rational_int<N,D>
        >::result_type  result_type;

        typedef typename boost::pqs::meta::evaluate< 
            boost::mpl::rational_int<N,D>
        > pow_type;

        coherent_type t(v); // convert to a coherent type
        result_type result( std::pow(t.raw_value(),pow_type()()));
        return result;
    }

}}}//boost::pqs::detail

#endif

                                                                     