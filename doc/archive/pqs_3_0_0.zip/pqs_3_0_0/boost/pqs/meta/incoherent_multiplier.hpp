#ifndef BOOST_PQS_META_INCOHERENT_MULTIPLIER_INCLUDED
#define BOOST_PQS_META_INCOHERENT_MULTIPLIER_INCLUDED

#include <boost/mpl/math/rational_long.hpp>
namespace boost{namespace pqs{namespace meta{

    template<long N>
    struct incoherent_multiplier 
    : boost::mpl::math::rational_long<N,1000000>{};

}}}//boost::pqs::meta

#endif
