#ifndef BOOST_PQS_META_POW10_HPP_INCLUDED
#define BOOST_PQS_META_POW10_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/config.hpp>
#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/rational_tag.hpp>
#include <boost/pqs/preboost/is_integral.hpp>
#include <boost/pqs/preboost/is_rational.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/comparison.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/math/rational_int.hpp>
#include <boost/mpl/math/rational_long.hpp>
#include <boost/mpl/math/simplify_rational_or_numeric.hpp>
#include <boost/pqs/meta/arithmetic_promote.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/denominator.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/pqs/meta/detail/get_value_type_of.hpp>
#include <boost/pqs/meta/digitsN.hpp>

#include <limits>
#include <cmath>
/*
    static constants representing powers of N.
    Base is an int, Exp is a integral constant or a rational constant
    Where possible they are represented as integers
    otherwise as reals. The type of the real is
    according to BOOST_PQS_REAL_TYPE
    defined in <boost/pqs/config.hpp>
    Currently Only base 10 is defined.
    To use other bases specialize for them
    <boost/pqs/meta/digitsN.hpp>
*/

namespace boost{namespace pqs{namespace meta{

    namespace detail{
          
            template<
                int Base, 
                typename Exp, 
                typename Enable = void
            >
            struct powN_impl;

            // specialisation for  pow 0
            template<
                int Base,
                typename Exp        
            > struct powN_impl<
                    Base,
                    Exp,
                    typename  boost::enable_if<
                        boost::mpl::equal_to<
                            Exp,
                            boost::mpl::int_<0>
                        >
                    >::type
            > : boost::mpl::int_<1>{};

            // if Exp is an integer, is positive and result can fit into the int type
            template<
                int Base,
                typename Exp        
            > struct powN_impl<
                    Base,
                    Exp,
                    typename  boost::enable_if<
                        boost::mpl::and_<
                            boost::mpl::greater< Exp,boost::mpl::int_<0> >,
                            boost::mpl::math::is_integral<
                                typename boost::mpl::math::simplify_rational_or_numeric<
                                    Exp
                                >::type
                            >,
                            boost::mpl::less_equal<
                                Exp,
                                boost::mpl::int_<
                                    boost::pqs::meta::digits<
                                       Base,
                                       typename get_value_type_of<Exp>::type 
                                    >::value
                                >
                            >
                        >
                    >::type
            > : boost::mpl::times<
                    boost::mpl::integral_c<
                        typename get_value_type_of<Exp>::type ,
                        Base
                    >,
                    typename powN_impl<
                        Base,
                        typename  boost::mpl::minus<
                            Exp, 
                            boost::mpl::int_<1>
                        >::type
                    >::type
                >::type  {};

            // if after reduction Exp is a rational
            
            template<
                int Base,
                typename Exp        
            > struct powN_impl<
                Base,
                Exp,
                typename  boost::enable_if<
                    boost::mpl::math::is_rational<
                        typename boost::mpl::math::simplify_rational_or_numeric<
                            Exp
                        >::type
                    >
                >::type
            > { 
                typedef BOOST_PQS_REAL_TYPE value_type;
                struct type{
                    operator value_type () 
                    {
                        return std::pow(static_cast<value_type>(Base),Exp::get<value_type>());
                    }
                };
            };
          
        template <int Base,long N>
        struct powN_c;

        #define BOOST_PQS_POW10_C(Number) \
            template <> \
            struct powN_c< 10, Number > \
            { \
                BOOST_PQS_REAL_TYPE operator()() \
                { \
                    return static_cast<BOOST_PQS_REAL_TYPE>( 1.e ## Number); \
                } \
            };
        #if (BOOST_PQS_MIN_EXPONENT10  <= -64)

            BOOST_PQS_POW10_C(-64);
            BOOST_PQS_POW10_C(-63);
            BOOST_PQS_POW10_C(-62);
            BOOST_PQS_POW10_C(-61); 
            BOOST_PQS_POW10_C(-60);
            BOOST_PQS_POW10_C(-59);
            BOOST_PQS_POW10_C(-58);
            BOOST_PQS_POW10_C(-57);
            BOOST_PQS_POW10_C(-56);
            BOOST_PQS_POW10_C(-55);
            BOOST_PQS_POW10_C(-54);
            BOOST_PQS_POW10_C(-53);
            BOOST_PQS_POW10_C(-52);
            BOOST_PQS_POW10_C(-51);
            BOOST_PQS_POW10_C(-50);
            BOOST_PQS_POW10_C(-49);
            BOOST_PQS_POW10_C(-48);
            BOOST_PQS_POW10_C(-47);
            BOOST_PQS_POW10_C(-46);
            BOOST_PQS_POW10_C(-45);
            BOOST_PQS_POW10_C(-44);
            BOOST_PQS_POW10_C(-43);
            BOOST_PQS_POW10_C(-42);
            BOOST_PQS_POW10_C(-41);
            BOOST_PQS_POW10_C(-40);
            BOOST_PQS_POW10_C(-39);
        #endif
            BOOST_PQS_POW10_C(-38);
            BOOST_PQS_POW10_C(-37);
            BOOST_PQS_POW10_C(-36);
            BOOST_PQS_POW10_C(-35);
            BOOST_PQS_POW10_C(-34);
            BOOST_PQS_POW10_C(-33);
            BOOST_PQS_POW10_C(-32);
            BOOST_PQS_POW10_C(-31);
            BOOST_PQS_POW10_C(-30);
            BOOST_PQS_POW10_C(-29);
            BOOST_PQS_POW10_C(-28);
            BOOST_PQS_POW10_C(-27);
            BOOST_PQS_POW10_C(-26);
            BOOST_PQS_POW10_C(-25);
            BOOST_PQS_POW10_C(-24);
            BOOST_PQS_POW10_C(-23);
            BOOST_PQS_POW10_C(-22);
            BOOST_PQS_POW10_C(-21);
            BOOST_PQS_POW10_C(-20);
            BOOST_PQS_POW10_C(-19);
            BOOST_PQS_POW10_C(-18);
            BOOST_PQS_POW10_C(-17);
            BOOST_PQS_POW10_C(-15);
            BOOST_PQS_POW10_C(-14);
            BOOST_PQS_POW10_C(-13);
            BOOST_PQS_POW10_C(-12);
            BOOST_PQS_POW10_C(-11);
            BOOST_PQS_POW10_C(-10);
            BOOST_PQS_POW10_C(-9);
            BOOST_PQS_POW10_C(-8);
            BOOST_PQS_POW10_C(-7);
            BOOST_PQS_POW10_C(-6);
            BOOST_PQS_POW10_C(-5);
            BOOST_PQS_POW10_C(-4);
            BOOST_PQS_POW10_C(-3);
            BOOST_PQS_POW10_C(-2);
            BOOST_PQS_POW10_C(-1);
            BOOST_PQS_POW10_C(0);
            BOOST_PQS_POW10_C(1);
            BOOST_PQS_POW10_C(2);
            BOOST_PQS_POW10_C(3);
            BOOST_PQS_POW10_C(4);
        //    BOOST_PQS_POW10_C(5);
            BOOST_PQS_POW10_C(6);
            BOOST_PQS_POW10_C(7);
            BOOST_PQS_POW10_C(8);
            BOOST_PQS_POW10_C(9);
            BOOST_PQS_POW10_C(10);
            BOOST_PQS_POW10_C(11);
            BOOST_PQS_POW10_C(12);
            BOOST_PQS_POW10_C(13);
            BOOST_PQS_POW10_C(14);
            BOOST_PQS_POW10_C(15);
            BOOST_PQS_POW10_C(16);
            BOOST_PQS_POW10_C(17);
            BOOST_PQS_POW10_C(18);
            BOOST_PQS_POW10_C(19);
            BOOST_PQS_POW10_C(20);
            BOOST_PQS_POW10_C(21);
            BOOST_PQS_POW10_C(22);
            BOOST_PQS_POW10_C(23);
            BOOST_PQS_POW10_C(24);
            BOOST_PQS_POW10_C(25);
            BOOST_PQS_POW10_C(26);
            BOOST_PQS_POW10_C(27);
            BOOST_PQS_POW10_C(28);
            BOOST_PQS_POW10_C(29);
            BOOST_PQS_POW10_C(30);
            BOOST_PQS_POW10_C(31);
            BOOST_PQS_POW10_C(32);
            BOOST_PQS_POW10_C(33);
            BOOST_PQS_POW10_C(34);
            BOOST_PQS_POW10_C(35);
            BOOST_PQS_POW10_C(36);
            BOOST_PQS_POW10_C(37);
            BOOST_PQS_POW10_C(38);
        #if (BOOST_PQS_MAX_EXPONENT10 == 64)
            BOOST_PQS_POW10_C(39);
            BOOST_PQS_POW10_C(40);
            BOOST_PQS_POW10_C(41);
            BOOST_PQS_POW10_C(42);
            BOOST_PQS_POW10_C(43);
            BOOST_PQS_POW10_C(44);
            BOOST_PQS_POW10_C(45);
            BOOST_PQS_POW10_C(46);
            BOOST_PQS_POW10_C(47);
            BOOST_PQS_POW10_C(48);
            BOOST_PQS_POW10_C(49);
            BOOST_PQS_POW10_C(50);
            BOOST_PQS_POW10_C(51);
            BOOST_PQS_POW10_C(52);
            BOOST_PQS_POW10_C(53);
            BOOST_PQS_POW10_C(54);
            BOOST_PQS_POW10_C(55);
            BOOST_PQS_POW10_C(56);
            BOOST_PQS_POW10_C(57);
            BOOST_PQS_POW10_C(58);
            BOOST_PQS_POW10_C(59);
            BOOST_PQS_POW10_C(60);
            BOOST_PQS_POW10_C(61);
            BOOST_PQS_POW10_C(62);
            BOOST_PQS_POW10_C(63);
            BOOST_PQS_POW10_C(64);
        #endif
         
            // if exp is an int with result too big for int or less than 1
        template<
                int Base,
                typename Exp        
            > struct powN_impl<
                Base,
                Exp,
                typename  boost::enable_if<
                    boost::mpl::and_<
                        boost::mpl::math::is_integral<
                            typename boost::mpl::math::simplify_rational_or_numeric<
                                Exp
                            >::type
                        >,
                        boost::mpl::or_<
                            boost::mpl::greater<
                                Exp,
                                boost::mpl::int_<
                                    boost::pqs::meta::digits<
                                        Base,
                                       typename get_value_type_of<Exp>::type 
                                    >::value
                                >
                            >,
                            boost::mpl::less<
                                Exp,
                                boost::mpl::int_<0 >
                            >
                        >
                    >
                >::type
            > {
                typedef BOOST_PQS_REAL_TYPE value_type; 
                struct type{
                    typedef powN_c<
                            Base, 
                            boost::mpl::math::numerator<Exp>::value
                    > pow_type;
                      
        //            BOOST_MPL_ASSERT_RELATION( pow_type::value, == ,1);  
                    operator value_type() 
                    {
                        return pow_type()();
                    }
                };
            };

        }//detail    
   
    template<int Base, typename T>
    struct powN : detail::powN_impl<Base,T>{};
  
}}}// boost::pqs::meta
#endif

