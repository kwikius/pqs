#ifndef BOOST_PQS_QUANTITY_UNIT_HPP_INCLUDED
#define BOOST_PQS_QUANTITY_UNIT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/pqs/config.hpp>
#include <boost/pqs/meta/quantity_unit_fwd.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/or.hpp>
#include <boost/mpl/less.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/pqs/detail/mpl_pow.hpp>
#include <boost/pqs/detail/mpl_reciprocal.hpp>
#include <boost/mpl/math/simplify_rational_or_numeric.hpp>
#include <boost/typeof/typeof.hpp>
#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP()

 BOOST_TYPEOF_REGISTER_TEMPLATE(boost::pqs::meta::quantity_unit, 3);
   
   /* BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::integral_c,2);
    BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::math::rational,2);
    BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::math::rational_c,3);
    BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::int_,(int) );
    BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::long_,(long) );*/


namespace boost{namespace pqs{namespace meta{

    template <
        typename Exponent,
        typename Multiplier,
        typename Id
    >
    struct quantity_unit{
        typedef Exponent        exponent;
       /* typedef typename boost::mpl::math::simplify_rational_or_numeric<
            Exponent
        >::type                 exponent;*/
        typedef Multiplier      multiplier;
        typedef Id              id;
        typedef quantity_unit   type;
    };

    namespace detail{

        template <typename T>
        struct transform_coherent;

        template <
            typename Exponent,
            typename Multiplier,
            typename Id
        >
        struct transform_coherent<
            quantity_unit<
                Exponent,
                Multiplier,
                Id
            >
        > 
        : quantity_unit<
            Exponent,
            typename default_quantity_unit_multiplier::type,
            typename default_quantity_unit_id::type
        > {};

        template <
            typename Lhs, 
            typename Rhs
        >
        struct finest_grained_quantity_unit 
        : boost::mpl::if_<
            boost::mpl::less<
                typename Lhs::exponent ,
                typename Rhs::exponent
            >,
            Lhs,
            Rhs
        >{};

        template <typename Lhs , typename Rhs>
        struct plus_minus_quantity_unit{
           
            typedef typename finest_grained_quantity_unit< 
                    Lhs, Rhs
            >::type finest_grained_type;

            typedef typename transform_coherent<
                finest_grained_type
            >::type  coherent_type;

            typedef typename boost::mpl::eval_if<
                boost::mpl::or_<
                    boost::mpl::and_<
                        boost::mpl::equal_to<
                            typename Lhs::multiplier,
                            typename default_quantity_unit_multiplier::type
                        >,
                        boost::mpl::equal_to<
                            typename Lhs::id,
                            typename default_quantity_unit_id::type
                        >
                    >,
                    boost::mpl::and_<
                        boost::mpl::equal_to<
                            typename Rhs::multiplier,
                            typename default_quantity_unit_multiplier::type
                        >,
                        boost::mpl::equal_to<
                            typename Rhs::id,
                            typename default_quantity_unit_id::type
                        >
                    >
                >,
                coherent_type,
                typename boost::mpl::if_<  
                        boost::mpl::and_<   
                            boost::mpl::equal_to<
                                typename Lhs::exponent,
                                typename Rhs::exponent
                            >,
                            boost::mpl::equal_to<
                                typename Lhs::multiplier,
                                typename Rhs::multiplier
                            >
                        >,
                        Lhs, 
                        finest_grained_type
                >::type       
            >::type type;
        };

    // specialise for power of 1
        template< 
            typename QuantityUnit,
            typename PowType,
            bool Equals1 = boost::mpl::equal_to<
                PowType, 
                boost::mpl::int_<1> 
            >::value
        >
        struct pow_quantity_unit;

        template< 
            typename QuantityUnit,
            typename PowType
        >
        struct pow_quantity_unit<QuantityUnit,PowType, true>
        : QuantityUnit{};

        template< 
            typename QuantityUnit,
            typename PowType
        >
        struct pow_quantity_unit<QuantityUnit,PowType, false>
        : boost::pqs::meta::quantity_unit<
                typename boost::mpl::times<
                    typename QuantityUnit::exponent,
                    PowType
                >::type,
                typename default_quantity_unit_multiplier::type,
                typename default_quantity_unit_id::type
         >{};
        
    }//detail

}}}//boost::pqs::meta
namespace boost{namespace mpl{
//+
        template<
            typename LhsExponent,
            typename LhsMultiplier, 
            typename LhsId,
            typename RhsExponent,
            typename RhsMultiplier, 
            typename RhsId
        >
        struct plus<
            boost::pqs::meta::quantity_unit<
                 LhsExponent,
                 LhsMultiplier, 
                 LhsId
            >,
            boost::pqs::meta::quantity_unit<
                 RhsExponent,
                 RhsMultiplier, 
                 RhsId
            >
        > 
        : boost::pqs::meta::detail::plus_minus_quantity_unit<
            boost::pqs::meta::quantity_unit<
                    LhsExponent,
                    LhsMultiplier, 
                    LhsId
            >,
            boost::pqs::meta::quantity_unit<
                RhsExponent,
                RhsMultiplier, 
                RhsId
            >
        >{};
//-
        template<
            typename LhsExponent,
            typename LhsMultiplier, 
            typename LhsId,
            typename RhsExponent,
            typename RhsMultiplier, 
            typename RhsId
        >
        struct minus<
            boost::pqs::meta::quantity_unit<
                 LhsExponent,
                 LhsMultiplier, 
                 LhsId
            >,
            boost::pqs::meta::quantity_unit<
                 RhsExponent,
                 RhsMultiplier, 
                 RhsId
            >
        > 
        : boost::pqs::meta::detail::plus_minus_quantity_unit<
            boost::pqs::meta::quantity_unit<
                    LhsExponent,
                    LhsMultiplier, 
                    LhsId
            >,
            boost::pqs::meta::quantity_unit<
                RhsExponent,
                RhsMultiplier, 
                RhsId
            >
        >{};
//*
        template<
            typename LhsExponent,
            typename LhsMultiplier, 
            typename LhsId,
            typename RhsExponent,
            typename RhsMultiplier, 
            typename RhsId
        >
        struct times<
            boost::pqs::meta::quantity_unit<
                 LhsExponent,
                 LhsMultiplier, 
                 LhsId
            >,
            boost::pqs::meta::quantity_unit<
                 RhsExponent,
                 RhsMultiplier, 
                 RhsId
            >
        >  
        : boost::pqs::meta::quantity_unit<
            typename plus<
                LhsExponent,
                RhsExponent
            >::type,
            typename boost::pqs::meta::
                default_quantity_unit_multiplier::type,
            typename boost::pqs::meta::
                default_quantity_unit_id::type
         >{};
// /
        template<
            typename LhsExponent,
            typename LhsMultiplier, 
            typename LhsId,
            typename RhsExponent,
            typename RhsMultiplier, 
            typename RhsId
        >
        struct divides<
            boost::pqs::meta::quantity_unit<
                 LhsExponent,
                 LhsMultiplier, 
                 LhsId
            >,
            boost::pqs::meta::quantity_unit<
                 RhsExponent,
                 RhsMultiplier, 
                 RhsId
            >
        > 
        : boost::pqs::meta::quantity_unit<
            typename minus<
                LhsExponent,
                RhsExponent
            >::type,
            typename boost::pqs::meta::
                default_quantity_unit_multiplier::type,
            typename boost::pqs::meta::
                default_quantity_unit_id::type
        > {};
//^
        template<
            typename Exponent,
            typename Multiplier, 
            typename Id,
            typename PowType
        >
        struct pow<
            boost::pqs::meta::quantity_unit<
                 Exponent,
                 Multiplier, 
                 Id
            >,
            PowType
        > 
        : boost::pqs::meta::detail::pow_quantity_unit<
            boost::pqs::meta::quantity_unit<
                 Exponent,
                 Multiplier, 
                 Id
            >,
            PowType
        >{};
// 1/
        template<
            typename Exponent,
            typename Multiplier, 
            typename Id
        >
        struct reciprocal<
            boost::pqs::meta::quantity_unit<
                 Exponent,
                 Multiplier, 
                 Id
            >
        > 
        : boost::pqs::meta::quantity_unit<
                typename negate<
                    Exponent
                >::type,
                typename boost::pqs::meta::
                    default_quantity_unit_multiplier::type,
                typename boost::pqs::meta::
                    default_quantity_unit_id::type
         >{};
           
}}//boost::mpl

#endif
