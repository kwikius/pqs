#ifndef BOOST_PQS_POW_IDENTITIES_HPP_INCLUDED
#define BOOST_PQS_POW_IDENTITIES_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
    avalue to power 0 =1
    a value to power 1 = t
    provide these specialisations
*/

#include <boost/pqs/detail/mpl_pow.hpp>
#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/int.hpp>


namespace boost{namespace pqs{namespace meta{

// returns 1;
    template<typename T, typename PowType>
    struct binary_operation<
        T,
        pqs::meta::pow,
        PowType,
        typename boost::enable_if<
            boost::mpl::equal_to<
                PowType,
                boost::mpl::int_<0>
            >
        >::type
    >{
        typedef int result_type;
    };


 //return T
    template<typename T, typename PowType>
    struct binary_operation<
        T,
        pqs::meta::pow,
        PowType,
        typename boost::enable_if<
            boost::mpl::equal_to<
                PowType,
                boost::mpl::int_<1>
            >
        >::type
    >{
        typedef T result_type;
    };


}}}///boost::pqs::meta


#endif
