#ifndef BOOST_MPL_MATH_ABS_HPP_INCLUDED
#define BOOST_MPL_MATH_ABS_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/negate.hpp>
#include <boost/mpl/is_negative.hpp>

namespace boost{namespace mpl{namespace math{

    template <typename T>
    struct abs 
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
    : if_<
            is_negative<T>,
            negate<T> ,
            T
     > {
#else 
      {
        typedef  BOOST_DEDUCED_TYPENAME if_<
            is_negative<T>,
            negate<T> ,
            T
         >::type type;
#endif
    BOOST_MPL_AUX_LAMBDA_SUPPORT(
            1
          , abs
          , (T)
        )
    };
  
}}}//boost::mpl::math


#endif

