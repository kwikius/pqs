#ifndef BOOST_PQS_T1_QUANTITY_COHERENT_QUANTITY_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_COHERENT_QUANTITY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
      transforms the type of a ct-quantity
      a physical_quantity to a coherent type
*/
#include <boost/pqs/t1_quantity/t1_quantity.hpp>

namespace boost{namespace pqs {namespace detail{
  
    template<
        typename T
    >
    struct transform_coherent;

    template<
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    struct transform_coherent<
        boost::pqs::t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >
    >{
        typedef t1_quantity<
            AbstractQuantity,
            typename boost::pqs::meta::detail::transform_coherent<
                Units
            >::type,
            Value_type
        > type;
    };

}}}//boost::pqs::detail

#endif
