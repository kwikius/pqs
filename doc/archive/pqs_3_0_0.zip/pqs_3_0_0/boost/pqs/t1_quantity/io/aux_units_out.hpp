#ifndef BOOST_PQS_AUX_UNITS_OUT_HPP_INCLUDED
#define BOOST_PQS_AUX_UNITS_OUT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
   overloaded stream output of the units of a ct_quantity
   via the units(pq) function.
*/

#include <iostream>
#include <boost/utility/enable_if.hpp>
#include <boost/pqs/t1_quantity/t1_quantity_fwd.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/t1_quantity/io/units_out.hpp>
#include <boost/pqs/t1_quantity/components/adjusted_coherent_prefix.hpp>
#include <boost/pqs/meta/si_units.hpp>
#include <boost/pqs/t1_quantity/io/detail/units_out_impl.hpp>
#include <boost/pqs/t1_quantity/io/units_ostream.hpp>

namespace boost{namespace pqs{
    
    // units(pq) simply returns a t1_quantity_units_out <..> object
    // which is what the ostream operator actually picks up.
    // The function is limited to types
    // with a named_quantity_tag less than
    // of_quantity::max_default_named_quantity_tag
    // to allow for expansion on custom types
    template<
        typename AbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline
    typename boost::enable_if_c<
        (
            AbstractQuantity::id::value <
                static_cast<int>(quantity_traits::max_default_named_quantity_tag)
        ),
            t1_quantity_units_out < 
            AbstractQuantity,
            QuantityUnit
        >
    >::type  
    units(
        t1_quantity<
            AbstractQuantity,
            QuantityUnit,
            Value_type
        > const & 
    )
    {
        return t1_quantity_units_out< 
            AbstractQuantity,
            QuantityUnit
        >();
    }

    // the ostream << operator for the 
    // t1_quantity_units_out<..> object returned by the above function
    //
    template<
        typename AbstractQuantity,
        typename QuantityUnit,
        typename CharType
    >
    inline std::basic_ostream<CharType>& 
    operator << (  
        std::basic_ostream<CharType>& os,
        t1_quantity_units_out< 
            AbstractQuantity,
            QuantityUnit
        > const&  
    )
    {
        typedef  typename meta::si_unit::prefix<
            typename adjusted_coherent_prefix< 
                AbstractQuantity,
                QuantityUnit
            >::type 
        > adjusted_prefix_type;
              
        return  pqs::detail::t1_quantity_units_output_impl<
            AbstractQuantity,
            QuantityUnit,
             ( meta::is_named_abstract_quantity<AbstractQuantity>::value
            && adjusted_prefix_type::value )
        >::put(os);
    }
}}//boost::pqs

#endif
