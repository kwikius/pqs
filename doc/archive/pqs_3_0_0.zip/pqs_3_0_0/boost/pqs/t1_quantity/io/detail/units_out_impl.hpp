#ifndef BOOST_PQS_DETAIL_UNITS_OUT_IMPL_HPP_INCLUDED
#define BOOST_PQS_DETAIL_UNITS_OUT_IMPL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    implementation called by the 
    ostream& operator << (ostream&,t1_quantity_units_out< ..>);
    defined in <boost/pqs/t1_quantity/io/aux_units_out.hpp>
*/

#include <iosfwd>
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/si_units.hpp>
#include <boost/pqs/t1_quantity/components/of_named_quantity_for.hpp>
#include <boost/pqs/t1_quantity/components/adjusted_coherent_prefix.hpp>

namespace boost{namespace pqs{ namespace detail{

    // specialised differently for
    //1) named And coherent types
    //2) anonymous Or incoherent types
    // via NamedCoherent condition
    template < 
        typename AbstractQuantity, 
        typename QuantityUnit,
        bool IsNamed
    > struct t1_quantity_units_output_impl;

    // This version is for use with
    // named-quantities that are also coherent-quantities
    template <
        typename AbstractQuantity, 
        typename QuantityUnit
    > struct t1_quantity_units_output_impl<
        AbstractQuantity,
        QuantityUnit,
        true
    >{
        typedef typename meta::si_unit::prefix<
            typename adjusted_coherent_prefix< 
                AbstractQuantity,
                QuantityUnit
            >::type 
        > adjusted_prefix_type;

        typedef of_named_quantity_for<
            AbstractQuantity
        > of_type;
        
        template<typename CharType>
        static std::basic_ostream<CharType>&  put(std::basic_ostream<CharType>& os)
        {
                os << adjusted_prefix_type::template symbol<CharType>()
                << of_type::template unprefixed_symbol<CharType>();
                return os;
        }

    };

    // this version simply uses the pq.units() function
    // It is usually used for anonymous ct_quanties
    // though will also be invoked for incoherent named quantities
    // which have not had an overload of 
    // ostream operator << (ostream&, t1_quantity_units_out<..>)
    template < 
        typename AbstractQuantity, 
        typename QuantityUnit
    > 
    struct t1_quantity_units_output_impl<
        AbstractQuantity,
        QuantityUnit,
        false
    >{
        template<typename CharType>
        static std::basic_ostream<CharType>&  
        put(std::basic_ostream<CharType>& os)
        {
            os << t1_quantity<
                AbstractQuantity,
                QuantityUnit,
                typename quantity_traits::default_value_type
            >::units(); 
            return os;
        }
    };
}}}//boost::pqs::detail

#endif
