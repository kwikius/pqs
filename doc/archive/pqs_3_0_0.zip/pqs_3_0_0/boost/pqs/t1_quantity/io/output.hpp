#ifndef BOOST_PQS_T1_QUANTITY_OUTPUT_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_OUTPUT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    basic utility output 
    of a physical_quantity for demo purposes
    useage
    pq is physical_quantity
    os << pq ;
    outputs value of pq and units
*/

#include <iostream>
#include <sstream>
#include <boost/pqs/t1_quantity/io/aux_units_out.hpp>

namespace boost{namespace pqs{
    // This function provides output of ct_quantities
    // Note that the units implementation is much more complex
    // than would appear from this definition.
    // See the documentation for more details
    // OTOH look at the implementation of
    // units(pq) in "boost/pqs/t1_quantity/io/aux_units_out.hpp"
    template <
        typename AbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename CharType
    >
    inline 
    std::basic_ostream<CharType>& 
    operator << (
        std::basic_ostream<CharType>& os,
        t1_quantity<
            AbstractQuantity,
            QuantityUnit,
            Value_type
        > const& pq 
    )
    {
        os << pq.numeric_value() << ' ' << units(pq);
        return os;
    }

    // This function simply returns the stream output of a t1_quantity
    // as in os << pq above, as a std::string
    template <
        typename CharType,
        typename AbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    std::basic_string<CharType>
    units_str( 
        t1_quantity<
            AbstractQuantity,
            QuantityUnit,
            Value_type
        > const& pq 
    )
    {
        std::basic_ostringstream<CharType> ost;
        ost << units(pq);
        return ost.str();
    }

    template <
        typename AbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    std::string
    units_str( 
        t1_quantity<
            AbstractQuantity,
            QuantityUnit,
            Value_type
        > const& pq 
    )
    {
        std::ostringstream ost;
        ost << units(pq);
        return ost.str();
    }
 
}}//boost:pqs

//useful specialisation of binary_operation stream output
// eg  for boost::lambda with ct_quantities
namespace boost{namespace pqs{namespace meta{

    template < 
        typename AbstractQuantity,
        typename QuantityUnit,
        typename Value_type,    
        typename CharType
    >
    struct binary_operation< 
        std::basic_ostream<CharType>,
        shift_left, 
        t1_quantity<AbstractQuantity,QuantityUnit,Value_type>
    >{
        typedef std::basic_ostream<CharType>& result_type;
    };

}}}//boost::pqs::meta

#endif


    

