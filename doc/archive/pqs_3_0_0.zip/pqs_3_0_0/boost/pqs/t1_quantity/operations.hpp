#ifndef PQS_CT_QUANTITY_OPERATIONS_HPP__INCLUDED
#define PQS_CT_QUANTITY_OPERATIONS_HPP__INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

// ct_quantity components
#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/pqs/meta/si_units.hpp>
// operations
#include <boost/pqs/t1_quantity/operations/add_subtract.hpp>
#include <boost/pqs/t1_quantity/operations/multiply.hpp>
#include <boost/pqs/t1_quantity/operations/scalar_multiply.hpp>
#include <boost/pqs/t1_quantity/operations/divide.hpp>
#include <boost/pqs/t1_quantity/operations/scalar_divide.hpp>
#include <boost/pqs/t1_quantity/operations/power_root.hpp>
//#include <boost/pqs/quantity/t1/operations/compare.hpp"
//#include <boost/pqs/quantity/t1/operations/anonymous_cast.hpp"

#endif
