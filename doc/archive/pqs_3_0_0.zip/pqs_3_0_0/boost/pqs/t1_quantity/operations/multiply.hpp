#ifndef BOOST_PQS_T1_QUANTITY_MULTIPLY_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_MULTIPLY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    multiply two t1-quantities
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>
//#include <boost/pqs/meta/quantity_unit.hpp>

#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/pqs/detail/united_value/operations/dimensioned_multiply.hpp>
#include <boost/pqs/detail/united_value/operations/dimensionless_multiply.hpp>
#include <boost/pqs/t1_quantity/operations/t1_quantity_bin_op_macros.hpp>

namespace boost{namespace pqs{
    namespace meta{
     // binary operation for multiplication of two quantities
        BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_BIN_OP(times)  
    }
    // dimensionless
    template< 
        typename AbstractQuantityA,
        typename UnitsA,
        typename Value_typeA,
        typename AbstractQuantityB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation_if<
        boost::pqs::meta::dimensionally_equivalent<
            AbstractQuantityA,
            typename boost::mpl::reciprocal<
                AbstractQuantityB
            >::type
        >,
        Value_typeA,
        meta::times,
        Value_typeB
    >::result_type
    operator *( 
        t1_quantity<
            AbstractQuantityA,
            UnitsA,
            Value_typeA
        > const & pqa,
        t1_quantity<
            AbstractQuantityB,
            UnitsB,
            Value_typeB
        > const & pqb )
    {
        
        typename pqs::meta::binary_operation<
            Value_typeA,
            meta::times,
            Value_typeB
        >::result_type result 
        = detail::dimensionless_multiply(
                pqa.get_united_value(), pqb.get_united_value()
        );
        return result;      
    }
    
////////////non dimensionless//////////////////////////
    template< 
        typename AbstractQuantityA,
        typename UnitsA,
        typename Value_typeA,
        typename AbstractQuantityB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation_if<
        boost::mpl::not_<
            meta::dimensionally_equivalent<
                typename boost::mpl::reciprocal<
                    AbstractQuantityA
                >::type,
                AbstractQuantityB
            >
        >,
        t1_quantity<
            AbstractQuantityA,
            UnitsA,
            Value_typeA
        >,
        meta::times,
        t1_quantity<
            AbstractQuantityB,
            UnitsB,
            Value_typeB
        >
    >::result_type
    operator * ( 
        t1_quantity<
            AbstractQuantityA,
            UnitsA,
            Value_typeA
        > const & pqa ,
        t1_quantity<
            AbstractQuantityB,
            UnitsB,
            Value_typeB
        > const & pqb )
        {
            typedef t1_quantity<
                AbstractQuantityA,
                UnitsA,
                Value_typeA
            > pqA_type;
            typedef t1_quantity<
                AbstractQuantityB,
                UnitsB,
                Value_typeB
            > pqB_type;
            typename meta::binary_operation<
                pqA_type,
                meta::times,
                pqB_type
            >::result_type result (
                (   
                    detail::dimensioned_multiply( 
                        pqa.get_united_value(),
                        pqb.get_united_value() 
                    )
                ).raw_value()
            );
            return result;
        }
}}//boost::pqs

#endif
