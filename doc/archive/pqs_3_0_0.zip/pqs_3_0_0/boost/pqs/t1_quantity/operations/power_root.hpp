#ifndef BOOST_PQS_T1_QUANTITY_POWER_ROOT_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_POWER_ROOT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    power and root functions for inbuilts and ct-quantities
    for inbuilts pow<N>(v) to bring in to line with
*/

#include <cmath>
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/mpl/math/rational.hpp>
#include <boost/pqs/t1_quantity/coherent_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
#include <boost/pqs/t1_quantity/is_t1_quantity_value_type.hpp>
#include <boost/pqs/meta/to_arithmetic.hpp>
#include <boost/mpl/and.hpp>

namespace boost{namespace pqs{

    namespace meta{
 
        template <
            typename Exponent,
            typename AbstractQuantity,
            typename Units,
            typename Value_type
        >
        struct binary_operation<
            t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            pow, 
            Exponent
        >{
           
            typedef typename t1_quantity <
                typename boost::mpl::pow<
                    AbstractQuantity,
                    Exponent
                >::type,
                typename boost::mpl::pow<
                    Units,
                    Exponent
                >::type,
                typename binary_operation<
                    Value_type,
                    pow,
                    Exponent
                >::result_type
            >::type result_type;
        };
    }// meta

    template<int N> struct deduced_int{};
    template<int N, int D> struct deduced_fraction{};

    template <
        int N,
        int D,
        typename T
    >
    inline
    typename meta::binary_operation_if<
        boost::is_arithmetic<T>,
        T,
        meta::pow,
        boost::mpl::math::rational_c<int,N,D>        
    >::result_type
    pow(T const& v)
    {
        typedef  boost::mpl::math::rational_c<int,N,D>  rational;
        typedef typename meta::binary_operation<
            T,
            meta::pow,
            rational        
        >::result_type result_type;
        result_type result 
        = std::pow(
            static_cast<result_type>( v ),
            static_cast<result_type>( N ) / D
        );         
        return result;
    }

    template <
        int N,
        int D,
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    inline 
    typename meta::binary_operation<
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >,
        meta::pow,
        boost::mpl::math::rational_c<int,N,D>
    >::result_type
    pow(
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        > const & pq )
    {   //scale to coherent temporary version
        typedef typename boost::pqs::detail::transform_coherent<
            t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >
        >::type coherent_pq;
        coherent_pq t(pq);
        typedef typename boost::mpl::math::rational_c<
            int,N,D
        >::type exponent_type;
        typedef typename meta::binary_operation<
            coherent_pq,
            meta::pow,
            exponent_type
        >::result_type result_type;
        result_type result(pqs::pow<N,D>(t.numeric_value()));
        return result;
    }

    template <
        int N,
        typename T
    >
    inline 
    typename meta::binary_operation<
        T,
        meta::pow,
        boost::mpl::math::rational_c<int,N,1>
    >::result_type
    pow(T const & in)
    {   
        typename meta::binary_operation<
            T,
            meta::pow,
            boost::mpl::math::rational_c<int,N,1>
        >::result_type result = pqs::pow<N,1>(in);
        return result;
    }

//root
    template <
        int N,
        int D,
       typename T
    >
    inline 
    typename meta::binary_operation<
        T,
        meta::pow,
        boost::mpl::math::rational_c<int,D,N>
    >::result_type
    root(T const & in)
    {   
        typename meta::binary_operation<
            T,
            meta::pow,
            boost::mpl::math::rational_c<int,D,N>
        >::result_type result 
        = pqs::pow<D,N>(in);
        return result;
    }

//root

    template <
        int N,
        typename T
    >
    inline 
    typename meta::binary_operation<
       T,
       meta::pow,
       boost::mpl::math::rational_c<int,1,N>
    >::result_type
    root(T const & in )
    {   
        typename meta::binary_operation<
            T,
            meta::pow,
            boost::mpl::math::rational_c<int,1,N>
        >::result_type result = boost::pqs::pow<1,N>(in);
        return result ;
    }

// modify to more generic type?
    template <
       typename T
    >
    inline 
    typename meta::binary_operation<
        T,
        meta::pow,
        boost::mpl::math::rational_c<int,1,2>
    >::result_type
    sqrt(T  const & in )
    {   
        typename meta::binary_operation<
            T,
            meta::pow,
            boost::mpl::math::rational_c<int,1,2>
        >::result_type result = boost::pqs::pow<1,2>(in);
        return result;
    }

    //template<
    //    typename AbstractQuantity,
    //    typename Units,
    //    typename Value_type
    //>
    //template<
    //    int N, int D
    //>
    //inline
    //typename pqs::meta::binary_operation<
    //    t1_quantity<
    //        AbstractQuantity,
    //        Units,
    //        Value_type
    //    >,
    //    pqs::to_power,
    //    boost::mpl::math::rational_c<int,N,D>
    //>::result_type
    //t1_quantity<
    //    AbstractQuantity,
    //    Units,
    //    Value_type
    //>::pow()const
    //{
    //    return pqs::pow<
    //        N,D,
    //        AbstractQuantity,
    //        Units,
    //        Value_type
    //    >(*this);
    //}

    //template<
    //    typename AbstractQuantity,
    //    typename Units,
    //    typename Value_type
    //>
    //template<
    //    int N
    //>
    //inline
    //typename pqs::meta::binary_operation_if_c<
    //    (N !=0),
    //    t1_quantity<
    //        AbstractQuantity,
    //        Units,
    //        Value_type
    //    >,
    //    pqs::to_power,
    //    boost::mpl::math::rational_c<int,N,1>
    //>::result_type
    //t1_quantity<
    //    AbstractQuantity,
    //    Units,
    //    Value_type
    //>::pow()const
    //{
    //    return pqs::pow<
    //        N,1,
    //        AbstractQuantity,
    //        Units,
    //        Value_type
    //    >(*this);
    //}

    template<
        int N, 
        int D, 
        typename T, 
        template<int,int> class Exponent
    >
    inline 
    typename meta::binary_operation<
            T,
            meta::pow,
            boost::mpl::math::rational_c<int,N,D>
    >::result_type
    pow(T const & t, Exponent<N,D>)
    {
        typename meta::binary_operation<
            T,
            meta::pow,
            boost::mpl::math::rational_c<int,N,D>
        >::result_type result 
        = boost::pqs::pow<N,D>(t);
        return result;
    }

    template<
        int N,
        typename T, 
        template<int> class Exponent
    >
    inline 
    typename meta::binary_operation<
            T,
            meta::pow,
            boost::mpl::math::rational_c<int,N,1>
    >::result_type
    pow(T const & t, Exponent<N>)
    {
        typename meta::binary_operation<
            T,
            meta::pow,
            boost::mpl::math::rational_c<int,N,1>
        >::result_type result
        = boost::pqs::pow<N,1>(t);
        return result;
    }
    
}}//boost::pqs

#endif

