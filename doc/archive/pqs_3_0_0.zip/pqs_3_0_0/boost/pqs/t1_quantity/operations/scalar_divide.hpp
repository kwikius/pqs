#ifndef BOOST_PQS_T1_QUANTITY_SCALAR_DIVIDE_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_SCALAR_DIVIDE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    division of ct-quantity by numeric
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
#include <boost/pqs/t1_quantity/is_t1_quantity_value_type.hpp>
#include <boost/mpl/and.hpp>

namespace boost{namespace pqs{
    namespace meta{
        //value_type / pq
        template<
            typename ArithmeticType,
            typename AbstractQuantity,
            typename Units,
            typename Value_type
        >
        struct binary_operation<
            ArithmeticType,
            divides,
            boost::pqs::t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            typename boost::enable_if<
                boost::mpl::and_<
                    is_t1_quantity_value_type<ArithmeticType>,
                    is_valid_binary_operation<
                        ArithmeticType,
                        divides,
                        Value_type
                    >
                >
            >::type
            
        >{
            typedef boost::pqs::t1_quantity<
                typename boost::mpl::reciprocal<
                    AbstractQuantity
                >::type,
                typename boost::mpl::reciprocal<
                    Units
                >::type,
                typename binary_operation<
                    ArithmeticType,
                    divides,
                    Value_type
                >::result_type
            > result_type;
        };   

        //pq / value_type
        template<
            typename AbstractQuantity,
            typename Units,
            typename Value_type,
            typename ArithmeticType
        >
        struct binary_operation<
            typename boost::pqs::t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            divides,
            ArithmeticType,
            typename boost::enable_if<
                boost::mpl::and_<
                    is_t1_quantity_value_type<ArithmeticType>,
                    is_valid_binary_operation<
                        Value_type,
                        divides,
                        ArithmeticType
                    >
                >
            >::type
        >{
            typedef boost::pqs::t1_quantity<
                AbstractQuantity,
                Units,
                typename binary_operation<
                    Value_type,
                    divides,
                    ArithmeticType
                >::result_type
            > result_type;
        };
             
    }//meta

    //scalar / PQ 
    template<
        typename ArithmeticType,
        typename AbstractQuantity,
        typename Units,
        typename Value_type 
    >
    inline 
    typename meta::binary_operation_if<
        meta::is_t1_quantity_value_type<ArithmeticType>,
        ArithmeticType,
        meta::divides,
        t1_quantity<
            AbstractQuantity,
            typename meta::detail::transform_coherent<
                Units
            >::type,
            Value_type
        >
    >::result_type
    operator / (
        ArithmeticType const & v,
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >const & pq)
    {   
        typedef t1_quantity<
            AbstractQuantity,
            typename meta::detail::transform_coherent<
                Units
            >::type,
            Value_type
        > coherent_type;
        coherent_type coh(pq);
            
        typename meta::binary_operation<
            ArithmeticType,
            meta::divides,
            coherent_type
        >::result_type result( v/coh.numeric_value() );
        return result;
    }

    // PQ / scalar
    template<
        typename AbstractQuantity,
        typename Units,
        typename Value_type,
        typename ArithmeticType
    >
    inline 
    typename meta::binary_operation_if<
        meta::is_t1_quantity_value_type<ArithmeticType>,
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >,
        meta::divides,
        ArithmeticType
    >::result_type
    operator / (
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >const & pq,
        ArithmeticType const& v)
    {
        typename meta::binary_operation<
            t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            meta::divides,
            ArithmeticType
        >::result_type result(pq.numeric_value() / v);
        return result;
    }

}}//boost::pqs
#endif
