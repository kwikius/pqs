#ifndef BOOST_PQS_T1_QUANTITY_SCALAR_MUL_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_SCALAR_MUL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    multiply ct-quantity by numeric
*/
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
#include <boost/pqs/t1_quantity/is_t1_quantity_value_type.hpp>
#include <boost/mpl/and.hpp>

namespace boost{namespace pqs{namespace meta{

    //pq * value_type
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename ArithmeticType
    >
    struct binary_operation<
        boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        times,
        ArithmeticType,
        typename boost::enable_if<
            boost::mpl::and_<
                is_t1_quantity_value_type<ArithmeticType>,
                is_valid_binary_operation<
                    Value_type,
                    times,
                    ArithmeticType
                >
            >
        >::type
    >{
        typedef typename boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            typename binary_operation<
                Value_type,
                times,
                ArithmeticType
            >::result_type
        > result_type;
     };

    //value_type * pq
    template<
            typename ArithmeticType,
            typename NamedAbstractQuantity,
            typename QuantityUnit,
            typename Value_type
    >
    struct binary_operation<
        ArithmeticType,
        times,
        boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        typename boost::enable_if<
            boost::mpl::and_<
                is_t1_quantity_value_type<ArithmeticType>,
                is_valid_binary_operation<
                    ArithmeticType,
                    times,
                    Value_type
                >
            >
        >::type
    >{
        typedef typename boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            typename binary_operation<
                ArithmeticType,
                times,
                Value_type
            >::result_type
        > result_type;
     };            

}}}//boost::pqs::meta

namespace boost{namespace pqs{
    // PQ * scalar generic
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename ArithmeticType
    >
    inline 
    typename meta::binary_operation_if<
        meta::is_t1_quantity_value_type<ArithmeticType>,
        t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        meta::times,
        ArithmeticType
    >::result_type   
    operator *( 
        t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & pq,
        ArithmeticType const& v)
    {
       typename meta::binary_operation<
            t1_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >,
            meta::times,
            ArithmeticType
        >::result_type result( pq.numeric_value() * v );
        return result;
    }

    //scalar * PQ 
    template<
        typename ArithmeticType,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename meta::binary_operation_if< 
        meta::is_t1_quantity_value_type<ArithmeticType>,
        ArithmeticType,
        meta::times,
        t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    >::result_type   
    operator * ( 
        ArithmeticType const & v,
        t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & pq
    )
    {
        typename meta::binary_operation<
            ArithmeticType,
            meta::times,
            t1_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >::result_type result( v * pq.numeric_value());
        return result;
    }

}}//boost::pqs

#endif
