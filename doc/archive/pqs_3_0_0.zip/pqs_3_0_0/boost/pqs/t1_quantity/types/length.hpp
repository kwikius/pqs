#ifndef BOOST_PQS_T1_QUANTITY_TYPES_LENGTH_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_TYPES_LENGTH_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/t1_quantity/operations.hpp>
#include <boost/pqs/t1_quantity/types/of_length.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct length_ : of_length{
    private:
      //  friend void detail::dummy_friend_function();
        length_();
        length_(length_ const&);
        length_ operator =(length_ const &);
    public:
        typedef t1_quantity<
            type,
            typename meta::si_unit::yocto, // coherent-exponent -24
            Value_type
        > ym;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > zm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > am;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > fm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > pm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > nm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > um;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > mm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > cm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > dm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > m;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > dam;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > hm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > km;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > Mm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > Gm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > Tm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > Pm;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > Em;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > Zm;

        typedef t1_quantity<
            type,
            typename incoherent_unit::fathom_us,
            Value_type
        > fathom_us;

        typedef t1_quantity<
            type,
            typename incoherent_unit::AU,
            Value_type
        > AU;

        typedef t1_quantity<
            type,
            typename incoherent_unit::ch,
            Value_type
        > ch;

        typedef t1_quantity<
            type,
            typename incoherent_unit::fathom,
            Value_type
        > fathom;

        typedef t1_quantity<
            type,
            typename incoherent_unit::ft,
            Value_type
        > ft;

        typedef t1_quantity<
            type,
            typename incoherent_unit::ft_us,
            Value_type
        > ft_us;

        typedef t1_quantity<
            type,
            typename incoherent_unit::in,
            Value_type
        > in;

        typedef t1_quantity<
            type,
            typename incoherent_unit::l_y_,
            Value_type
        > l_y_;

        typedef t1_quantity<
            type,
            typename incoherent_unit::mi,
            Value_type
        > mi;

        typedef t1_quantity<
            type,
            typename incoherent_unit::naut_mile,
            Value_type
        > naut_mile;

        typedef t1_quantity<
            type,
            typename incoherent_unit::pc,
            Value_type
        > pc;

        typedef t1_quantity<
            type,
            typename incoherent_unit::pica_comp,
            Value_type
        > pica_comp;

        typedef t1_quantity<
            type,
            typename incoherent_unit::pica_prn,
            Value_type
        > pica_prn;

        typedef t1_quantity<
            type,
            typename incoherent_unit::point_comp,
            Value_type
        > point_comp;

        typedef t1_quantity<
            type,
            typename incoherent_unit::point_prn,
            Value_type
        > point_prn;

        typedef t1_quantity<
            type,
            typename incoherent_unit::rd,
            Value_type
        > rd;

        typedef t1_quantity<
            type,
            typename incoherent_unit::yd,
            Value_type
        > yd;

    };

    struct length : length_<
            typename quantity_traits::default_value_type
    >{};

}}//boost::pqs

#endif
