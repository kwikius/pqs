
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include "boost/pqs/meta/abstract_quantity.hpp"
#include "boost/mpl/math/rational.hpp"
#include "boost/mpl/math/numerator.hpp"
#include "boost/mpl/math/denominator.hpp"
#include "boost/mpl/math/rational_int.hpp"
#include "boost/mpl/math/rational_long.hpp"
#include "boost/mpl/int.hpp"
#include "boost/pqs/preboost/to_rational.hpp"

#include "boost/mpl/vector.hpp"
#include "boost/mpl/vector_c.hpp"
#include "boost/mpl/at.hpp"
#include "boost/type_traits/is_same.hpp"
#include <boost/mpl/assert.hpp>
#include <iostream>
#include <fstream>

#include "check_rational.hpp"
#include <boost/utility/enable_if.hpp>
#include <boost/mpl/bool.hpp>

namespace boost{namespace pqs{
 
    namespace aux{

        typedef ::boost::mpl::math::rational_c<long,0> zero;
      //  typedef ::boost::mpl::integral_c<int,0> zero;
        typedef ::boost::mpl::math::rational_c<int,1,4> one_quarter;
        typedef ::boost::mpl::math::rational_c<int,1,3> one_third;
        typedef ::boost::mpl::math::rational_c<int,1,2> one_half;
        typedef ::boost::mpl::math::rational_c<int,2,3> two_thirds;
        typedef ::boost::mpl::math::rational_c<int,3,4> three_quarters;
        typedef boost::mpl::math::rational_c<int,1>  one;
       // typedef ::boost::mpl::int_<1> one;       
    }
   
    typedef ::boost::pqs::meta::abstract_quantity <
            boost::mpl::vector< 
                aux::one_quarter,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::three_quarters
            >,
            boost::mpl::int_<1>
    > type;

    typedef ::boost::pqs::meta::abstract_quantity <
            boost::mpl::vector< 
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero
            >,
            boost::mpl::int_<0>
    > dimless_type;
     typedef ::boost::pqs::meta::abstract_quantity <
            boost::mpl::vector< 
                aux::one,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero
            >,
            boost::mpl::int_<1>
    > length_type0;
    typedef ::boost::pqs::meta::abstract_quantity <
            boost::mpl::vector_c< int,
                1,0,0,0,0,0,0
            >,
            boost::mpl::int_<1>
    > length_type1;
}}

void test_abstract_quantity()
{
    typedef boost::mpl::math::to_rational<boost::mpl::int_<2> >::type int_to_rat_type;
    CHECK_RAT( int_to_rat_type,int ,2,1);

    BOOST_CHECK (( boost::pqs::meta::is_anonymous_quantity<
            boost::pqs::length_type1
    >::value == false));
    BOOST_CHECK (( boost::pqs::meta::is_anonymous_quantity<
            boost::pqs::dimless_type
    >::value == true));
    typedef ::boost::mpl::plus<
        ::boost::pqs::type,
        ::boost::pqs::type
    >::type plus_type;
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type,plus_type
    >::value));
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type::dimension,plus_type::dimension
    >::value));
    typedef ::boost::mpl::plus<
        ::boost::pqs::length_type1,
        ::boost::pqs::length_type1
    >::type plus_type_l;

    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::length_type1,boost::pqs::length_type0
    >::value));
    typedef boost::mpl::minus<
        boost::pqs::type,
        boost::pqs::type
    >::type minus_type;
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type,minus_type
    >::value));
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type::dimension,minus_type::dimension
    >::value));
    BOOST_CHECK((boost::pqs::meta::is_dimensionless<
        minus_type
    >::value == false) );
    BOOST_CHECK( (boost::pqs::meta::is_dimensionless<
        minus_type::dimension
    >::value ==false));
    
    typedef boost::mpl::multiplies<
        boost::pqs::type,
        boost::pqs::type
    >::type multiplies_type;
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type,multiplies_type
    >::value == false));
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type::dimension,multiplies_type::dimension
    >::value == false));
    BOOST_CHECK((boost::pqs::meta::is_dimensionless<
        multiplies_type
    >::value == false) );
    BOOST_CHECK( (boost::pqs::meta::is_dimensionless<
        multiplies_type::dimension
    >::value ==false));
    
   
    typedef boost::mpl::at_c<multiplies_type::dimension,0>::type mux0;
    CHECK_RAT( mux0,int ,1,2);
    typedef boost::mpl::at_c<multiplies_type::dimension,1>::type mux1;
   // std::cout << typeid(mux1).name() << '\n';
   // std::cout << boost::mpl::math::is_rational<mux1>::value <<'\n';
   
    CHECK_INT( mux1,int ,0);
    typedef boost::mpl::at_c<multiplies_type::dimension,2>::type mux2;
    CHECK_INT( mux2,int ,0);
    typedef boost::mpl::at_c<multiplies_type::dimension,3>::type mux3;
    CHECK_INT( mux3,int ,0);
    typedef boost::mpl::at_c<multiplies_type::dimension,4>::type mux4;
    CHECK_INT( mux4,int ,0);
    typedef boost::mpl::at_c<multiplies_type::dimension,5>::type mux5;
    CHECK_INT( mux5,int ,0);
    typedef boost::mpl::at_c<multiplies_type::dimension,6>::type mux6;
    CHECK_RAT( mux6,int ,3,2);

    typedef boost::mpl::divides<
        boost::pqs::type,
        boost::pqs::type
    >::type divides_type;
     BOOST_CHECK(boost::pqs::meta::is_dimensionless<divides_type>::value == true );
    BOOST_CHECK(boost::pqs::meta::is_dimensionless<divides_type::dimension>::value == true);
    typedef boost::mpl::at_c<divides_type::dimension,0>::type div0;
    CHECK_INT( div0,int ,0);
    typedef boost::mpl::at_c<divides_type::dimension,1>::type div1;
    CHECK_INT( div1,int ,0);
    typedef boost::mpl::at_c<divides_type::dimension,2>::type div2;
    CHECK_INT( div2,int ,0);
    typedef boost::mpl::at_c<divides_type::dimension,3>::type div3;
    CHECK_INT( div3,int ,0);
    typedef boost::mpl::at_c<divides_type::dimension,4>::type div4;
    CHECK_INT( div4,int ,0);
    typedef boost::mpl::at_c<divides_type::dimension,5>::type div5;
    CHECK_INT( div5,int ,0);
    typedef boost::mpl::at_c<divides_type::dimension,6>::type div6;
    CHECK_INT( div6,int ,0);
    
    typedef boost::mpl::pow<
            boost::pqs::type,
            boost::mpl::int_<3>  
    >::type pow_type;

    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::meta::abstract_quantity <
            boost::mpl::vector< 
                boost::mpl::int_<1>,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::mpl::math::rational_c<int,1,2>
            >,
            boost::mpl::int_<1>
        >,
         boost::pqs::meta::abstract_quantity <
            boost::mpl::vector< 
                boost::mpl::math::rational_int<1>,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::mpl::math::rational<
                    boost::mpl::int_<1>,
                    boost::mpl::integral_c<int,2> 
                >
            >,
            boost::mpl::int_<0>
        >
    >::value ));

    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::meta::abstract_quantity <
            boost::mpl::vector< 
                boost::mpl::int_<2>,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::mpl::math::rational_c<int,1,2>
            >,
            boost::mpl::int_<1>
        >,
        boost::pqs::meta::abstract_quantity <
            boost::mpl::vector< 
                boost::mpl::math::rational_int<1>,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::mpl::math::rational<
                    boost::mpl::int_<1>,
                    boost::mpl::integral_c<int,2> 
                >
            >,
            boost::mpl::int_<0>
        >
    >::type::value == 0));
    typedef boost::mpl::at_c<pow_type::dimension,0>::type pow_t0;
    CHECK_RAT( pow_t0,int ,3,4);
    typedef boost::mpl::at_c<pow_type::dimension,1>::type pow_t1;
    CHECK_INT( pow_t1,int ,0);
    typedef boost::mpl::at_c<pow_type::dimension,2>::type pow_t2;
    CHECK_INT( pow_t2, int ,0);
    typedef boost::mpl::at_c<pow_type::dimension,3>::type pow_t3;
    CHECK_INT( pow_t3,int ,0);
    typedef boost::mpl::at_c<pow_type::dimension,4>::type pow_t4;
    CHECK_INT( pow_t4,int ,0);
    typedef boost::mpl::at_c<pow_type::dimension,5>::type pow_t5;
    CHECK_INT( pow_t5,int ,0);
    typedef boost::mpl::at_c<pow_type::dimension,6>::type pow_t6;
    CHECK_RAT( pow_t6,int ,9,4);
 
    BOOST_CHECK( ( boost::pqs::meta::is_dimensionless<
            boost::pqs::dimless_type
    >::value ) == true);
    BOOST_CHECK( (boost::pqs::meta::is_dimensionless<
            boost::pqs::type
    >::value ) == false );
   
  }


    
   