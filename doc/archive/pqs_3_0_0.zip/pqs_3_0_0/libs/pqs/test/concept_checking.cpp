
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.
#include <boost/mpl/assert.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>

void concept_check_test()
{

//template< templaetypename boost::enable_if<
//void concept_check_test()
//{
//    
//    boost::pqs::concept_checking::AssertIsArithmetic<int>();
//
// //boost::pqs::concept_checking::AssertIsArithmetic<test>();
//    boost::function_requires<
//        boost::pqs::concept_checking::DimensionallyEquivalentQuantityConcept<int,double> 
//    >();
//
}
