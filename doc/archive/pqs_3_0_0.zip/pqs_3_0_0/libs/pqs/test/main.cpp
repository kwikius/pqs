
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.
#include <boost/test/test_tools.hpp>
#include <boost/test/floating_point_comparison.hpp>
#include <boost/test/unit_test.hpp>
#include <boost/test/included/unit_test_framework.hpp>
void test_arithmetic_promote( );
void test_abstract_quantity();
void test_si_unit();
void test_quantity_unit();
void test_pow10();
void united_value_test();
void rational_test();
void t1_quantity_test();
void t1_quantity_test1();
void named_func();
using boost::unit_test_framework::test_suite;

test_suite*
init_unit_test_suite( int, char* [] ) {
    test_suite* test = BOOST_TEST_SUITE( "Unit test boost/pqs" );

    test->add(BOOST_TEST_CASE( test_abstract_quantity ));
    test->add(BOOST_TEST_CASE( test_si_unit ));
    test->add(BOOST_TEST_CASE( test_quantity_unit ));
    test->add(BOOST_TEST_CASE( t1_quantity_test ));
    test->add(BOOST_TEST_CASE( named_func ));
    test->add(BOOST_TEST_CASE( united_value_test ));
  //  test->add(BOOST_TEST_CASE( rational_test ));*/
    return test;
}
