
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.
#include <boost/pqs/config.hpp>
#include <boost/test/test_tools.hpp>
#include <boost/mpl/math/rational.hpp>
#include <boost/pqs/meta/powN.hpp>
#include <boost/mpl/math/rational_int.hpp>
#include <boost/mpl/math/rational_long.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/preprocessor/comma.hpp>
#include <boost/preprocessor/punctuation.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>

void test_pow10()
{
    typedef boost::mpl::math::rational_c<int,3,1> rational1;
    
    BOOST_STATIC_ASSERT((boost::mpl::math::is_rational<
        rational1  
    >::value));
    BOOST_STATIC_ASSERT(
        (boost::mpl::math::is_integral<
            boost::mpl::math::simplify_rational_or_numeric<
                rational1
            >::type
        >::value));
    BOOST_STATIC_ASSERT((
            boost::mpl::less_equal<
            rational1,
            boost::mpl::int_<
               boost::pqs::meta::digits<
                    10,
                    typename boost::pqs::meta::detail::get_value_type_of<rational1>::type
                >::value
            >
          >::value));
   
   BOOST_STATIC_ASSERT((
        boost::mpl::less_equal<
            boost::mpl::math::rational_long<7,1>,
            boost::mpl::int_<
                boost::pqs::meta::digits<
                    10,
                    long 
                >::value
            >
        >::value));
        int t3 = boost::pqs::meta::powN<10,rational1>::type();
        
    BOOST_CHECK_EQUAL(t3, 1000);
    BOOST_CHECK( (boost::is_same<
        boost::pqs::meta::detail::get_value_type_of<
            boost::mpl::math::rational_long<7,1>
        >::type,
        long
    >::value));
    BOOST_CHECK( (boost::is_same<
        boost::pqs::meta::detail::get_value_type_of<
            boost::mpl::math::rational_int<7,1>
        >::type,
        int
    >::value));
   ///* BOOST_CHECK_EQUAL( (boost::pqs::meta::powN<
   //     10,
   //     boost::mpl::math::rational_long<6,1>
   // >::type() ), 1000000);*/
   //  BOOST_CHECK_EQUAL( (boost::pqs::meta::powN<
   //     10,
   //     boost::mpl::int_<1>
   // >::type() ), 1000000);
    
////    std::cout << typeid(rational1::value_type).name() <<'\n';
//    BOOST_PQS_REAL_TYPE t2ret = std::pow(
//        static_cast<BOOST_PQS_REAL_TYPE>(10), 
//        static_cast<BOOST_PQS_REAL_TYPE>(7)/2);
//    typedef boost::pqs::meta::pow10<boost::mpl::math::rational_long<7,2> > t2;
//    CHECKPOW(t2, BOOST_PQS_REAL_TYPE , t2ret );
//
//    typedef boost::pqs::meta::pow10<boost::mpl::int_<1> > t3;
//    CHECKPOW(t3, int , 10);
//
//    BOOST_PQS_REAL_TYPE t4ret = std::pow(static_cast<BOOST_PQS_REAL_TYPE>(10),-1);
//    typedef boost::pqs::meta::pow10<boost::mpl::int_<-1> > t4;
//    CHECKPOW(t4,BOOST_PQS_REAL_TYPE , t4ret);
//    CHECKPOW(t4,BOOST_PQS_REAL_TYPE , BOOST_PQS_REAL_TYPE(.1) );
//    typedef boost::pqs::meta::pow10<boost::mpl::integral_c<short, 4> > t5;
//   // value_type modified to int
//   // std::cout << typeid(t5::value_type).name() << '\n';
//   //CHECKPOW(t5, short ,10000);
//    BOOST_CHECK( t5::type() == 10000  );
//  
//    typedef boost::pqs::meta::pow10<boost::mpl::integral_c<short, 5> > t6;
//    CHECKPOW(t6,BOOST_PQS_REAL_TYPE  ,100000);
//    typedef boost::pqs::meta::pow10<boost::mpl::integral_c<int, 10> > t7;
//    CHECKPOW(t7,BOOST_PQS_REAL_TYPE  , static_cast<BOOST_PQS_REAL_TYPE>( 1e10));
//    typedef boost::pqs::meta::pow10<boost::mpl::integral_c<int,BOOST_PQS_MAX_EXPONENT10 > > t8;
//
//    CHECKPOW(t8,BOOST_PQS_REAL_TYPE  , static_cast<BOOST_PQS_REAL_TYPE>( 
//            BOOST_PP_CAT(1e,BOOST_PQS_MAX_EXPONENT10))
//    );
//    
//   // std::cout <<  t7::type() <<'\n';
}