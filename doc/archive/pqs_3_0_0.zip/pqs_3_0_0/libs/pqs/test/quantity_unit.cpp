
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/pqs/meta/si_units.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/test/test_tools.hpp>
// same si
// different si
// same inco
// different inco
// si inco
// same unit but diff tag
using boost::pqs::meta::quantity_unit;
using boost::pqs::meta::si_unit;
#define CHECK_QUANTITY_UNIT(name,E,M,I) \
 BOOST_CHECK( (boost::mpl::equal_to< \
        name ## ::exponent,\
        boost::mpl::int_< E >\
    >::value));\
\
    BOOST_CHECK( (boost::mpl::equal_to<\
        name ## ::multiplier,\
        boost::mpl::long_< M >\
    >::value));  \
\
    BOOST_CHECK( (boost::mpl::equal_to<\
        name ## ::id, \
        boost::mpl::int_< I >\
    >::value)); 

#define CHECK_SI_QUANTITY_UNIT( prefix, E ) \
    CHECK_QUANTITY_UNIT( prefix, E, 1, 0)

void test_quantity_unit()
{
//same si unit
    typedef quantity_unit<> default_type;
    CHECK_SI_QUANTITY_UNIT(default_type, 0);

    typedef boost::mpl::plus<
            si_unit::micro,
            si_unit::micro 
    >::type plus_unit0;
    CHECK_SI_QUANTITY_UNIT(plus_unit0,-6);
    typedef boost::mpl::minus<
            si_unit::kilo,
            si_unit::kilo 
    >::type minus_unit0;
    CHECK_SI_QUANTITY_UNIT(minus_unit0,3);
    typedef boost::mpl::times<
            si_unit::nano,
            si_unit::nano 
    >::type times_unit0;
    CHECK_SI_QUANTITY_UNIT(times_unit0,-18);
      typedef boost::mpl::divides<
            si_unit::mega,
            si_unit::mega 
    >::type divides_unit0;
    CHECK_SI_QUANTITY_UNIT(divides_unit0,0);
////////// different si unit
    typedef boost::mpl::plus<
            si_unit::nano,
            si_unit::milli 
    >::type plus_unit1;
    CHECK_SI_QUANTITY_UNIT(plus_unit1,-9);
    typedef boost::mpl::minus<
            si_unit::nano,
            si_unit::milli 
    >::type minus_unit1;
    CHECK_SI_QUANTITY_UNIT(minus_unit1,-9);
    typedef boost::mpl::times<
            si_unit::nano,
            si_unit::milli 
    >::type times_unit1;
    CHECK_SI_QUANTITY_UNIT(times_unit1,-12);
      typedef boost::mpl::divides<
            si_unit::nano,
            si_unit::milli 
    >::type divides_unit1;
    CHECK_SI_QUANTITY_UNIT(divides_unit1,-6);

// same non si unit
    typedef quantity_unit<
            boost::mpl::int_<3>,
            boost::mpl::long_<1020000>,
            boost::mpl::int_<1>
    > non_si_type0;
    typedef boost::mpl::plus<
        non_si_type0,
        non_si_type0
    >::type plus_non_si_type0;
    BOOST_CHECK( (boost::is_same<
          plus_non_si_type0,
          non_si_type0
    >::value)); 
    typedef boost::mpl::minus<
        non_si_type0,
        non_si_type0
    >::type minus_non_si_type0;
    BOOST_CHECK( (boost::is_same<
          non_si_type0,
          minus_non_si_type0
    >::value));
    typedef boost::mpl::times<
        non_si_type0,
        non_si_type0
    >::type times_non_si_type0;
    CHECK_SI_QUANTITY_UNIT(times_non_si_type0,6);
    typedef boost::mpl::divides<
        non_si_type0,
        non_si_type0
    >::type divides_non_si_type0;
    CHECK_SI_QUANTITY_UNIT(divides_non_si_type0,0);
// different non si
    typedef quantity_unit<
            boost::mpl::int_<2>,
            boost::mpl::long_<1020000>,
            boost::mpl::int_<1>
    > non_si_type1;
////////
typedef boost::mpl::plus< // finest grained
        non_si_type0,
        non_si_type1
    >::type plus_non_si_type1;
    BOOST_CHECK( (boost::is_same<
          plus_non_si_type1,
          non_si_type1
    >::value)); 
typedef boost::mpl::minus<
        non_si_type0,
        non_si_type1
    >::type minus_non_si_type1;
    BOOST_CHECK( (boost::is_same<
          minus_non_si_type1,
          non_si_type1
    >::value)); 
 
    typedef boost::mpl::times<
        non_si_type1,
        non_si_type0
    >::type times_non_si_type1;
    CHECK_SI_QUANTITY_UNIT(times_non_si_type1,5);
    typedef boost::mpl::divides<
        non_si_type0,
        non_si_type1
    >::type divides_non_si_type1;
    CHECK_SI_QUANTITY_UNIT(divides_non_si_type1,1);
/// special case same unit different id
typedef quantity_unit<
            boost::mpl::int_<2>,
            boost::mpl::long_<1020000>,
            boost::mpl::int_<2>
    > non_si_type2;

    typedef boost::mpl::plus< 
        non_si_type1,
        non_si_type2
    >::type plus_non_si_type2;
    BOOST_CHECK( (boost::is_same<
          plus_non_si_type2,
          non_si_type1
    >::value)); 

    typedef boost::mpl::plus< 
        non_si_type2,
        non_si_type1
    >::type plus_non_si_type3;
    BOOST_CHECK( (boost::is_same<
          plus_non_si_type3,
          non_si_type2
    >::value)); 

    typedef boost::mpl::minus< 
        non_si_type1,
        non_si_type2
    >::type minus_non_si_type2;
    BOOST_CHECK( (boost::is_same<
          minus_non_si_type2,
          non_si_type1
    >::value)); 

    typedef boost::mpl::minus< 
        non_si_type2,
        non_si_type1
    >::type minus_non_si_type3;
    BOOST_CHECK( (boost::is_same<
          minus_non_si_type3,
          non_si_type2
    >::value)); 

//si v non si
    typedef boost::mpl::plus<
            si_unit::milli,
            non_si_type0
    >::type plus_si_non_si0;
    CHECK_SI_QUANTITY_UNIT(plus_si_non_si0,-3);
    typedef boost::mpl::minus<
            si_unit::milli,
            non_si_type0
    >::type minus_si_non_si0;
    CHECK_SI_QUANTITY_UNIT(minus_si_non_si0,-3);
    typedef boost::mpl::times<
            si_unit::milli,
            non_si_type0
    >::type times_si_non_si0;
    CHECK_SI_QUANTITY_UNIT(times_si_non_si0,0);

    typedef boost::mpl::divides<
            si_unit::milli,
            non_si_type0
    >::type divides_si_non_si0;
    CHECK_SI_QUANTITY_UNIT(divides_si_non_si0,-6);
    
    
 
}

