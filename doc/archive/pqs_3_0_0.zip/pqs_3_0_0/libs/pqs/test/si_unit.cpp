
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include "libs/pqs/test/test.hpp"
using boost::pqs::meta::quantity_unit;
using boost::pqs::meta::si_unit;

void test_si_unit()
{

    CHECK_SI_QUANTITY_UNIT(si_unit::yotta,24);
    CHECK_SI_QUANTITY_UNIT(si_unit::zetta,21);
    CHECK_SI_QUANTITY_UNIT(si_unit::exa,18);
    CHECK_SI_QUANTITY_UNIT(si_unit::peta,15);
    CHECK_SI_QUANTITY_UNIT(si_unit::tera,12);
    CHECK_SI_QUANTITY_UNIT(si_unit::giga,9);
    CHECK_SI_QUANTITY_UNIT(si_unit::mega,6);
    CHECK_SI_QUANTITY_UNIT(si_unit::kilo,3);
    CHECK_SI_QUANTITY_UNIT(si_unit::hecto,2);
    CHECK_SI_QUANTITY_UNIT(si_unit::deka,1);
    CHECK_SI_QUANTITY_UNIT(si_unit::none,0);
    CHECK_SI_QUANTITY_UNIT(si_unit::deci,-1);
    CHECK_SI_QUANTITY_UNIT(si_unit::centi,-2);
    CHECK_SI_QUANTITY_UNIT(si_unit::milli,-3);
    CHECK_SI_QUANTITY_UNIT(si_unit::micro,-6);
    CHECK_SI_QUANTITY_UNIT(si_unit::nano,-9);
    CHECK_SI_QUANTITY_UNIT(si_unit::pico,-12);
    CHECK_SI_QUANTITY_UNIT(si_unit::femto,-15);
    CHECK_SI_QUANTITY_UNIT(si_unit::atto,-18);
    CHECK_SI_QUANTITY_UNIT(si_unit::zepto,-21);
    CHECK_SI_QUANTITY_UNIT(si_unit::yocto,-24);
       
}