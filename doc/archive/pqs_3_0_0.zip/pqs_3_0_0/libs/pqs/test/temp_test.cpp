
#include <boost/pqs/meta/abstract_quantity.hpp>
//#include < boost/mpl/vector.hpp>
//#include <boost/mpl/math/rational.hpp>
//#include <boost/mpl/vector_c.hpp>
//#include "boost/mpl/at.hpp"
//#include "boost/type_traits/is_same.hpp"
//#include "boost/test/minimal.hpp"
//#include <iostream>
//
//
//#define CHECK_RAT(Rational, T, n, d) \
//    BOOST_CHECK( Rational ## ::numerator::value == n );\
//    BOOST_CHECK( Rational ## ::denominator::value == d );\
//  //  BOOST_CHECK(  (boost::is_same< Rational ## ::value_type , T >::value) ) ;
//#define CHECK_INT(Integral,T, v)\
//    BOOST_CHECK(  (Integral ## ::type::value) == v);\
//    BOOST_CHECK( (boost::is_same< Integral ## ::value_type, T >::value) );
//
//    namespace aux{
//
//        typedef boost::mpl::math::rational_c<int,0> zero;
//       // typedef ::boost::mpl::integral_c<int,0> zero;
//        typedef ::boost::mpl::math::rational_c<int,1,4> one_quarter;
//        typedef ::boost::mpl::math::rational_c<long,1,3> one_third;
//        typedef ::boost::mpl::math::rational_c<int,1,2> one_half;
//        typedef ::boost::mpl::math::rational_c<int,2,3> two_thirds;
//        typedef ::boost::mpl::math::rational_c<int,3,4> three_quarters;
//        typedef boost::mpl::math::rational_c<int,1>  one;
//       // typedef ::boost::mpl::int_<1> one;       
//    }
//   namespace my{
//    typedef ::boost::pqs::meta::abstract_quantity <
//            boost::mpl::vector< 
//                aux::one_quarter,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::three_quarters
//            >,
//            boost::mpl::int_<1>
//    > type;
//
//    typedef ::boost::pqs::meta::abstract_quantity <
//            boost::mpl::vector< 
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero
//            >,
//            boost::mpl::int_<1>
//    > dimless_type;
//     typedef ::boost::pqs::meta::abstract_quantity <
//            boost::mpl::vector< 
//                aux::one,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero,
//                aux::zero
//            >,
//            boost::mpl::int_<1>
//    > length_type0;
//    typedef ::boost::pqs::meta::abstract_quantity <
//            boost::mpl::vector_c< int,
//                1,0,0,0,0,0,0
//            >,
//            boost::mpl::int_<1>
//    > length_type1;
//}
//int test_main(int argc, char* argv[])
//{
//    typedef boost::mpl::math::rational_c<int,1 ,1> var;
//    typedef boost::mpl::equal_to<var,var>::type res;
//    std::cout << res::value <<'\n';
//
//    typedef ::boost::mpl::plus<
//        my::type,
//        my::type
//    >::type plus_type;
//    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
//        my::type,plus_type
//    >::value));
//    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
//        my::type::dimension,plus_type::dimension
//    >::value));
//    typedef ::boost::mpl::plus<
//        my::length_type1,
//        my::length_type1
//    >::type plus_type_l;
//
//    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
//        my::length_type1,my::length_type0
//    >::value));
//    typedef boost::mpl::minus<
//        my::type,
//        my::type
//    >::type minus_type;
//    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
//        my::type,minus_type
//    >::value));
//    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
//        my::type::dimension,minus_type::dimension
//    >::value));
//    BOOST_CHECK(boost::pqs::meta::is_dimensionless<minus_type>::value == false );
//    BOOST_CHECK(boost::pqs::meta::is_dimensionless<minus_type::dimension>::value ==false);
//    
//    typedef boost::mpl::multiplies<
//        my::type,
//        my::type
//    >::type multiplies_type;
//
//    typedef boost::mpl::at_c<multiplies_type::dimension,0>::type mux0;
//    CHECK_RAT( mux0,int ,1,2);
//    typedef boost::mpl::at_c<multiplies_type::dimension,1>::type mux1;
//    CHECK_INT( mux1,int ,0);
//    typedef boost::mpl::at_c<multiplies_type::dimension,2>::type mux2;
//    CHECK_INT( mux2,int ,0);
//    typedef boost::mpl::at_c<multiplies_type::dimension,3>::type mux3;
//    CHECK_INT( mux3,int ,0);
//    typedef boost::mpl::at_c<multiplies_type::dimension,4>::type mux4;
//    CHECK_INT( mux4,int ,0);
//    typedef boost::mpl::at_c<multiplies_type::dimension,5>::type mux5;
//    CHECK_INT( mux5,int ,0);
//    typedef boost::mpl::at_c<multiplies_type::dimension,6>::type mux6;
//    CHECK_RAT( mux6,int ,3,2);
//
//
//    typedef boost::mpl::divides<
//        my::type,
//        my::type
//    >::type divides_type;
//    BOOST_CHECK( boost::pqs::meta::is_dimensionless<divides_type>::value == true );
//    BOOST_CHECK( boost::pqs::meta::is_dimensionless<divides_type::dimension>::value == true);
//    typedef boost::mpl::at_c<divides_type::dimension,0>::type div0;
//    CHECK_INT( div0,int ,0);
//    typedef boost::mpl::at_c<divides_type::dimension,1>::type div1;
//    CHECK_INT( div1,int ,0);
//    typedef boost::mpl::at_c<divides_type::dimension,2>::type div2;
//    CHECK_INT( div2,int ,0);
//    typedef boost::mpl::at_c<divides_type::dimension,3>::type div3;
//    CHECK_INT( div3,int ,0);
//    typedef boost::mpl::at_c<divides_type::dimension,4>::type div4;
//    CHECK_INT( div4,int ,0);
//    typedef boost::mpl::at_c<divides_type::dimension,5>::type div5;
//    CHECK_INT( div5,int ,0);
//    typedef boost::mpl::at_c<divides_type::dimension,6>::type div6;
//    CHECK_INT( div6,int ,0);
//    
//   /* typedef boost::mpl::pow<
//            boost::pqs::type,
//            boost::mpl::int_<3>  
//    >::type pow_type;*/
///*
//    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
//        boost::pqs::meta::abstract_quantity <
//            boost::mpl::vector< 
//                boost::mpl::int_<1>,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::mpl::math::rational_c<int,1,2>
//            >,
//            boost::mpl::int_<1>
//        >,
//         boost::pqs::meta::abstract_quantity <
//            boost::mpl::vector< 
//                boost::mpl::math::rational_long<1>,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::mpl::math::rational<boost::mpl::long_<1>,boost::mpl::integral_c<long,2> >
//            >,
//            boost::mpl::int_<0>
//        >
//    >::value ));
//
//    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
//        boost::pqs::meta::abstract_quantity <
//            boost::mpl::vector< 
//                boost::mpl::int_<2>,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::mpl::math::rational_c<int,1,2>
//            >,
//            boost::mpl::int_<1>
//        >,
//        boost::pqs::meta::abstract_quantity <
//            boost::mpl::vector< 
//                boost::mpl::math::rational_long<1>,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::pqs::aux::zero,
//                boost::mpl::math::rational<boost::mpl::long_<1>,boost::mpl::integral_c<long,2> >
//            >,
//            boost::mpl::int_<0>
//        >
//    >::value == 0));
//
//    typedef boost::mpl::at_c<pow_type::dimension,0>::type pow_t0;
//    CHECK_RAT( pow_t0,int ,3,4);
//    typedef boost::mpl::at_c<pow_type::dimension,1>::type pow_t1;
//    CHECK_INT( pow_t1,int ,0);
//    typedef boost::mpl::at_c<pow_type::dimension,2>::type pow_t2;
//    CHECK_INT( pow_t2,int ,0);
//    typedef boost::mpl::at_c<pow_type::dimension,3>::type pow_t3;
//    CHECK_INT( pow_t3,int ,0);
//    typedef boost::mpl::at_c<pow_type::dimension,4>::type pow_t4;
//    CHECK_INT( pow_t4,int ,0);
//    typedef boost::mpl::at_c<pow_type::dimension,5>::type pow_t5;
//    CHECK_INT( pow_t5,int ,0);
//    typedef boost::mpl::at_c<pow_type::dimension,6>::type pow_t6;
//    CHECK_RAT( pow_t6,int ,9,4);
// 
//    BOOST_CHECK( ( boost::pqs::meta::is_dimensionless<
//            boost::pqs::dimless_type
//    >::value ) == true);
//    BOOST_CHECK( (boost::pqs::meta::is_dimensionless<
//            boost::pqs::type
//    >::value ) == false );
//   
//   */
//    return EXIT_SUCCESS;
//}
