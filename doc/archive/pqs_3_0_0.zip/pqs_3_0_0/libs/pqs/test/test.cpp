#include <boost/pqs/t1_quantity/types/out/length.hpp>
//#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <iostream>
#include <boost/pqs/t1_quantity/io/output.hpp>
void named_func() 
{ 
    boost::pqs::length::ft L1(1.f);
    boost::pqs::length::in L2 = L1;
    //std::cout << L1 << '\n';
    //std::cout << L2 << '\n';
    //std::cout << L1 * L2 << '\n';
    boost::pqs::length::mm L3 = L2 /12;
    //std::cout << L3 << '\n';

    typedef boost::mpl::math::is_rational<
        boost::mpl::math::simplified_rational<
            boost::mpl::int_<0>,
            boost::mpl::int_<1>
        >
    >::type reduc_type;
   // std::cout <<"is reduced " << reduc_type::value;

    typedef boost::mpl::math::simplify_rational_or_numeric<
        boost::mpl::math::simplified_rational<
            boost::mpl::int_<0>,
            boost::mpl::int_<1>
        >
    >::type int_type;
   // std::cout << typeid(int_type).name() <<'\n';
            
}

