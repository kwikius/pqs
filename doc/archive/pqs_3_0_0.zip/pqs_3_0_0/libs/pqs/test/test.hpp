#ifndef BOOST_PQS_TEST_HPP_INCLUDED
#define  BOOST_PQS_TEST_HPP_INCLUDED
#include <boost/test/test_tools.hpp>
#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/pqs/meta/si_units.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/equal_to.hpp>

#define CHECK_QUANTITY_UNIT(Name,E,M,I) \
  BOOST_CHECK( (boost::mpl::equal_to< \
        Name ## ::exponent,\
        boost::mpl::int_< E > \
    >::type::value));\
\
    BOOST_CHECK( (boost::mpl::equal_to< \
        Name ## ::multiplier, \
        boost::mpl::long_< M > \
    >::type::value)); \
\
    BOOST_CHECK( (boost::mpl::equal_to<\
        Name ## ::id, \
        boost::mpl::int_< I >\
    >::type::value)); 


#define CHECK_SI_QUANTITY_UNIT( Prefix , E ) \
 CHECK_QUANTITY_UNIT( Prefix, E , 1, 0)


#endif
