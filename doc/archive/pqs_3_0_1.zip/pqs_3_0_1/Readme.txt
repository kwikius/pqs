Readme for Boost.Pqs library

pqs_3_0_1 is dependent on the proposed mpl_math library for boost::mpl::rational and asociated operations, available in the boost vault.


I found it necessary to modify boost/mpl/aux_/has_type.hpp to get the tests to compile in boost_1_33-0. Not tried in later versions of boost
The modified version of has_type.hpp, is in the boost/ mpl.aux_ directory in this package.

pqs_3_0_1 has only been tested in VC7.1

regards
Andy Little

