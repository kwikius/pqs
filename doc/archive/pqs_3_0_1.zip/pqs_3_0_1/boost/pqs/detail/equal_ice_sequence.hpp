#ifndef BOOST_MPL_EQUAL_VALUES_HPP_INCLUDED
#define BOOST_MPL_EQUAL_VALUES_HPP_INCLUDED

#include "boost/pqs/detail/query_ice_sequence.hpp"

namespace boost{ namespace mpl{
       
    template< typename Seq1, typename Seq2>
    struct equal_ice_sequence : query_ice_sequence<Seq1,Seq2,equal_to<_1,_2> >{};

}}//boost::mpl

#endif



