#ifndef BOOST_PQS_DETAIL_COHERENT_EXPONENT_EVAL_INCLUDED
#define BOOST_PQS_DETAIL_COHERENT_EXPONENT_EVAL_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    functors to evaluate the value of a coherent-exponent
    // could provide larger range of int values via limits
    // should use long not int
*/

#include <boost/pqs/meta/pow.hpp>
#include <boost/pqs/quantity_traits.hpp>
#include <boost/pqs/meta/min_type.hpp>
#include <cmath>
#include <limits>
#include <boost/preprocessor/comma.hpp>
namespace boost{namespace pqs{ namespace detail{

        // default  instantiated for any non-integer exponent
        // wants Arithmetic Type ??
        template <typename ResultType,int N, int D, bool WantInt>
        struct coherent_exponent_eval{

            enum{ required = true};
            typedef float min_result_type;
            typedef typename boost::pqs::quantity_traits::min_real<
                min_result_type
            >::type result_type;
            result_type operator()()const 
            {
                result_type result 
                = std::pow(
                    static_cast<result_type>(boost::pqs::quantity_traits::exponent_base),
                    static_cast<result_type>(N)/D
                );
                return result;
            }

        };

        // instantiated for very large/small integer powers but not used
        // really requires a mod
        template <typename ResultType,int N, bool WantInt>
        struct coherent_exponent_eval<
            ResultType,N,1, WantInt
        >{
            enum{ required = true};
            typedef ResultType min_result_type;
            typedef ResultType result_type;
            result_type operator()()const ;
        };

        //isntantiated for small positive exponents
        //
        template<typename ResultType,int N>
        struct coherent_exponent_eval<ResultType,N,1,true>{
            enum{ required = ( N !=0 ) };
            typedef int min_result_type;
            typedef typename meta::long_promote<ResultType>::type result_type;
 
            result_type operator()()const 
            {
                result_type result
                = static_cast<result_type>(
                    boost::pqs::meta::pow_c<
                        int,
                        boost::pqs::quantity_traits::exponent_base,N
                    >::value
                );
                return result;
            }
        };

 #define BOOST_PQS_COHERENT_EXPONENT_EVAL(Num, FLOAT)\
       template <>\
       struct coherent_exponent_eval< \
            FLOAT BOOST_PP_COMMA() Num  BOOST_PP_COMMA()\
             1 BOOST_PP_COMMA() false\
             >{\
           enum{ required = true};\
           typedef FLOAT min_result_type;\
           typedef FLOAT result_type;\
           result_type operator()()const\
           {    result_type result\
                = static_cast< FLOAT > (1e ## Num);\
                return result;\
            }\
       };

BOOST_PQS_COHERENT_EXPONENT_EVAL(-60, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-59, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-58, double)    
BOOST_PQS_COHERENT_EXPONENT_EVAL(-57, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-56, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-55, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-54, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-53, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-52, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-51, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-50, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-49, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-48, double)    
BOOST_PQS_COHERENT_EXPONENT_EVAL(-47, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-46, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-45, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-44, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-43, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-42, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-41, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-40, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-39, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-38, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-37, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-37, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-36, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-36, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-35, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-35, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-34, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-34, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-33, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-33, float)  
BOOST_PQS_COHERENT_EXPONENT_EVAL(-32, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-31, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-30, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-30, float)  
BOOST_PQS_COHERENT_EXPONENT_EVAL(-29, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-29, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-28, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-28, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-27, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-27, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-26, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-26, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-25, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-25, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-24, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-23, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-22, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-22, float)  
BOOST_PQS_COHERENT_EXPONENT_EVAL(-21, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-21, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-20, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-20, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-19, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-19, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-18, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-18, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-17, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-17, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-16, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-16, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-15, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-15, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-14, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-14, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-13, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-13, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-12, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-12, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-11, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-11, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(-10, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-10, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-9, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-9, float)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-8, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-8, float)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-7, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-7, float)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-6, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-6, float)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-5, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-5, float)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-4, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-3, float) 
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-2, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-1, float)  
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-1, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-1, float) 
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-10, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-10, float)      
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-9, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-9, float)       
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-8, double)
//BOOST_PQS_COHERENT_EXPONENT_EVAL(-8, float)
#define BOOST_PQS_COHERENT_EXPONENT_EVAL_I(Num)\
      template <>\
       struct coherent_exponent_eval<int BOOST_PP_COMMA() Num BOOST_PP_COMMA() 1 BOOST_PP_COMMA() false>{\
           enum{required = true};\
           typedef float min_result_type;\
           typedef boost::pqs::quantity_traits::min_real<\
                min_result_type\
           >::type result_type;\
           result_type operator()()const\
           {return coherent_exponent_eval<result_type  BOOST_PP_COMMA()  Num BOOST_PP_COMMA() 1 BOOST_PP_COMMA() false>()();}\
       };
BOOST_PQS_COHERENT_EXPONENT_EVAL(-8, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-8, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL_I(-8)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-7, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-7, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL_I(-7)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-6, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-6, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL_I(-6)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-5, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-5, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL_I(-5)     
BOOST_PQS_COHERENT_EXPONENT_EVAL(-4, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-4, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL_I(-4)     
BOOST_PQS_COHERENT_EXPONENT_EVAL(-3, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-3, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL_I(-3)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-2, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-2, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL_I(-2)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-1, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(-1, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL_I(-1)      
#undef BOOST_PQS_COHERENT_EXPONENT_EVAL_I
BOOST_PQS_COHERENT_EXPONENT_EVAL(0, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(0, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(1, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(1, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(2, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(2, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(3, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(3, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(4, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(4, float)       
BOOST_PQS_COHERENT_EXPONENT_EVAL(5, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(5, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(6, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(6, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(7, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(7, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(8, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(8, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(9, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(9, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(10, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(10, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(11, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(11, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(12, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(12, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(13, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(13, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(14, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(14, float)       
BOOST_PQS_COHERENT_EXPONENT_EVAL(15, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(15, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(16, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(16, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(17, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(17, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(18, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(18, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(19, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(19, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(20, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(20, float)   
BOOST_PQS_COHERENT_EXPONENT_EVAL(21, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(21, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(22, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(22, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(23, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(23, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(24, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(24, float)       
BOOST_PQS_COHERENT_EXPONENT_EVAL(25, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(25, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(26, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(26, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(27, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(27, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(28, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(28, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(29, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(29, float)   
BOOST_PQS_COHERENT_EXPONENT_EVAL(30, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(30, float)   
BOOST_PQS_COHERENT_EXPONENT_EVAL(31, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(31, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(32, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(32, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(33, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(33, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(34, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(34, float)       
BOOST_PQS_COHERENT_EXPONENT_EVAL(35, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(35, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(36, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(36, float) 
BOOST_PQS_COHERENT_EXPONENT_EVAL(37, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(37, float)
BOOST_PQS_COHERENT_EXPONENT_EVAL(38, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(39, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(40, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(41, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(42, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(43, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(44, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(45, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(46, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(47, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(48, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(49, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(50, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(51, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(52, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(53, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(54, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(55, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(56, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(57, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(58, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(59, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(60, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(61, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(62, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(63, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(64, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(65, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(66, double)
BOOST_PQS_COHERENT_EXPONENT_EVAL(67, double)
#undef BOOST_PQS_COHERENT_EXPONENT_EVAL
}}}//boost::pqs::detail

#endif

