#ifndef BOOST_PQS_QUANTITY_CONVERSION_TRAITS_HPP_INCLUDED
#define BOOST_PQS_QUANTITY_CONVERSION_TRAITS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    get incoherent-multiplier /divide value
*/

#include <boost/pqs/meta/arithmetic_promote.hpp>
#include <boost/pqs/meta/to_arithmetic.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/pqs/detail/united_value/operations/incoherent_mx.hpp>
#include <boost/pqs/preboost/is_positive.hpp>
#include <boost/pqs/detail/united_value/operations/coherent_exponent.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/denominator.hpp>

/*
    in division and multiplication using units
    use calc that doesnt involve converting ftom int to float if possible
    ie  x / 0.001 == x * 1000 therefore use 2nd form
*/
 namespace boost{namespace pqs{namespace detail {
        
    template <
        typename Target_value_type,
        typename Target_unit,
        typename Source_value_type,
        typename Source_unit
    > struct quantity_conversion_traits{

        typedef Source_value_type  source_value_type;
        typedef Target_value_type  target_value_type;
        typedef typename boost::pqs::meta::arithmetic_promote<
            typename boost::pqs::meta::to_arithmetic<
                source_value_type
            >::type,
            typename boost::pqs::meta::to_arithmetic<
                target_value_type
            >::type
        >::type                 min_in_arith_value_type;
        
        typedef typename boost::mpl::plus<
            typename Source_unit::exponent,
            typename Target_unit::exponent
        >::type first_sum_exponent;  
        // also get negated version, use if first < 0

        typedef typename boost::mpl::negate<
            first_sum_exponent
        >::type second_sum_exponent;

        // always positive version
        typedef typename boost::mpl::if_<
            boost::mpl::math::is_positive<
                first_sum_exponent
            >,
            first_sum_exponent,
            second_sum_exponent
        >::type abs_sum_exponent;

        typedef typename boost::mpl::minus<
            typename Source_unit::exponent,
            typename Target_unit::exponent
        >::type first_difference_exponent;

        typedef typename boost::mpl::negate<
              first_difference_exponent
        >::type  second_difference_exponent;  

        typedef typename boost::mpl::if_<
            boost::mpl::math::is_positive<
                first_difference_exponent
            >,
            first_difference_exponent,
            second_difference_exponent
        >::type abs_difference_exponent;   


         typedef divide_incoherent_mx<
            min_in_arith_value_type,
            typename Source_unit::multiplier,
            typename Target_unit::multiplier
        > incoherent_divide_fx;
//
//         typedef divide_incoherent_mx<
//            min_in_arith_value_type,
//            Source_unit::multiplier::value,
//            Target_unit::multiplier::value
//        > incoherent_divide_fx;
//

        typedef typename boost::mpl::if_c<
            incoherent_divide_fx::required,
            typename incoherent_divide_fx::result_type,
            min_in_arith_value_type
        >::type min_incoherent_divide_value_type;


        typedef multiply_incoherent_mx<
            min_in_arith_value_type,
            typename Source_unit::multiplier,
            typename Target_unit::multiplier
        > incoherent_multiply_fx;

       /* typedef multiply_incoherent_mx<
            min_in_arith_value_type,
            Source_unit::multiplier::value,
            Target_unit::multiplier::value
        > incoherent_multiply_fx;*/
      
         typedef typename boost::mpl::if_c<
            incoherent_multiply_fx::required,
            typename incoherent_multiply_fx::result_type,
            min_in_arith_value_type
        >::type min_incoherent_multiply_value_type;

        typedef boost::pqs::detail::coherent_exponent<
                typename boost::mpl::math::numerator<abs_difference_exponent>::type,
                typename boost::mpl::math::denominator<abs_difference_exponent>::type
        > abs_difference_exponent_ce;
        typedef typename abs_difference_exponent_ce::eval<
            typename  boost::pqs::meta::arithmetic_promote<
                min_in_arith_value_type,
                min_incoherent_divide_value_type
            >::type
        > abs_difference_delog_fx;
        typedef   boost::pqs::detail::coherent_exponent<
                typename boost::mpl::math::numerator<abs_sum_exponent>::type,
                typename boost::mpl::math::denominator<abs_sum_exponent>::type
        > abs_sum_exponent_ce;               
        typedef typename abs_sum_exponent_ce::eval<
            typename  boost::pqs::meta::arithmetic_promote<
                min_in_arith_value_type,
                min_incoherent_multiply_value_type
            >::type
        > abs_sum_delog_fx;

        typedef typename boost::pqs::meta::arithmetic_promote<
            typename abs_difference_delog_fx::result_type,
            typename incoherent_divide_fx::result_type 
        >::type promoted_difference_divide_working_type;

         typedef typename boost::pqs::meta::arithmetic_promote<
            typename abs_sum_delog_fx::result_type,
            typename incoherent_multiply_fx::result_type 
        >::type promoted_sum_multiply_working_type;
        
     };

}}}//boost::pqs::detail

#endif
