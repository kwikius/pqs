#ifndef BOOST_PQS_ABSTRACT_QUANTITY_HPP_INCLUDED
#define BOOST_PQS_ABSTRACT_QUANTITY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
  An abstract Quantity has dimension and a tag to distinguish it
   if the tag is  equal to the anonymous_quantity_id
  then it is regarded as an anonymous-abstract-quantity
   otherwise it is a named-abstract-quantity
*/

#include <boost/pqs/config.hpp>
#include <boost/mpl/arithmetic.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/equal.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/transform.hpp>
#include <boost/mpl/placeholders.hpp>
#include <boost/mpl/find_if.hpp>
#include <boost/pqs/detail/mpl_pow.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/pqs/preboost/simplify_rational_or_numeric.hpp>
#include <boost/pqs/preboost/reciprocal.hpp>
#include <boost/pqs/meta/abstract_quantity_fwd.hpp>
#include <boost/typeof/typeof.hpp>

#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP() 

BOOST_TYPEOF_REGISTER_TEMPLATE(boost::pqs::meta::abstract_quantity, 2);

namespace boost{namespace pqs{ namespace meta{

    template< 
        typename Dimension, 
        typename QuantityId
    >
    struct abstract_quantity{
        typedef Dimension               dimension;
        typedef QuantityId              id;
        typedef abstract_quantity       type;
    };

    template <
        typename DimensionL,
        typename DimensionR
    > 
    struct dimensionally_equivalent
    : boost::mpl::equal< 
        DimensionL,
        DimensionR,
        boost::mpl::equal_to<
            boost::mpl::_1,
            boost::mpl::_2
        >
    >{};

    template <
        typename DimensionL,
        typename QuantityIdL,
        typename DimensionR,
        typename QuantityIdR
    >
    struct dimensionally_equivalent<
        abstract_quantity<
            DimensionL,
            QuantityIdL
        >,
        abstract_quantity<
            DimensionR,
            QuantityIdR
        >
    > 
    : dimensionally_equivalent<
        DimensionL,
        DimensionR
    >{};

    template <typename Dimension>
    struct is_dimensionless : ::boost::is_same <
        typename ::boost::mpl::find_if<
            Dimension,
            boost::mpl::not_equal_to<
                boost::mpl::_1,
                boost::mpl::int_<0>
            >
        >::type ,
        typename boost::mpl::end<Dimension>::type
    >{};
    
    template< 
        typename Dimension,
        typename QuantityId
    > struct is_dimensionless<
        abstract_quantity<
            Dimension,
            QuantityId
        >
    > : is_dimensionless<Dimension>{};


    namespace detail{

        // given two Quantity_ids get their anonymous id
        template <typename L_id, typename R_id>
        struct anonymous_id_from{
            //normalise
            typedef typename boost::mpl::plus<
                    L_id, R_id
            >::type dummy_id;
            // zeroise
            typedef typename boost::mpl::minus<
                    dummy_id,dummy_id
            >::type type;
        };

        // result for addition
        // if L and R are equal -->  L (==R)
        // if L is anon and R not anon --> R
        // if R is anon and L not anon --> L
        // otherwise must be neither L or R anon, but not same --> anon
        template <typename L_id, typename R_id>
        struct plus_minus_quantity_id{
            typedef typename anonymous_id_from<
                    L_id,R_id
            >::type  anonymous_id ;
            struct l_is_anonymous : boost::mpl::equal_to<
                L_id,anonymous_id
            >::type {};
            struct r_is_anonymous : boost::mpl::equal_to<
                R_id,anonymous_id
            >::type {} ;

            typedef typename boost::mpl::if_<
                boost::mpl::equal_to<
                    L_id,R_id
                >,
                L_id ,
                typename boost::mpl::if_<
                    r_is_anonymous,
                    L_id,
                    typename boost::mpl::if_<
                        l_is_anonymous,
                        R_id,
                        anonymous_id
                    >::type
                >::type
            >::type  type;
        };

        template <
            typename AbstractQuantityL,
            typename AbstractQuantityR
        >
        struct plus_minus_abstract_quantity {

            typedef typename plus_minus_quantity_id<
                typename AbstractQuantityL::id,
                typename AbstractQuantityR::id
            >::type quantity_id ;
                              
            typedef typename boost::mpl::transform<
                typename AbstractQuantityL::dimension,
                boost::mpl::math::simplify_rational_or_numeric<
                    boost::mpl::_1
                >
            >::type  reduced_dimension;
            typedef typename boost::mpl::eval_if<
                dimensionally_equivalent<
                    AbstractQuantityL,
                    AbstractQuantityR
                >,
                boost::pqs::meta::abstract_quantity< 
                    reduced_dimension,
                    quantity_id
                >,
                boost::mpl::void_
            >::type type;    
        }; 
        

        template <typename A, typename B>
        struct add_reduce : boost::mpl::math::simplify_rational_or_numeric <
            typename boost::mpl::plus<A,B>::type
        >{};
        template <typename A, typename B>
        struct subtract_reduce : boost::mpl::math::simplify_rational_or_numeric <
            typename boost::mpl::minus<A,B>::type
        >{};
        template <typename A, typename B>
        struct times_reduce : boost::mpl::math::simplify_rational_or_numeric <
            typename boost::mpl::times<A,B>::type
        >{};
        template <typename A>
        struct negate_reduce : boost::mpl::math::simplify_rational_or_numeric <
            typename boost::mpl::negate<A>::type
        >{};

        template <
            typename AbstractQuantityL,
            typename AbstractQuantityR
        >
        struct multiply_abstract_quantity{
  
            typedef typename boost::mpl::transform<
                typename AbstractQuantityL::dimension,
                typename AbstractQuantityR::dimension,
                boost::pqs::meta::detail::add_reduce<
                    boost::mpl::_1,boost::mpl::_2 
                >
            >::type dims_type;
            typedef typename anonymous_id_from<
               typename AbstractQuantityL::id,
               typename AbstractQuantityR::id
            >::type  anonymous_id ;
            typedef typename boost::pqs::meta::abstract_quantity<
                dims_type,
                anonymous_id
            >::type  type;
        };
        
        template <
            typename AbstractQuantityL,
            typename AbstractQuantityR
        >
        struct divides_abstract_quantity{
            typedef typename boost::mpl::transform<
                typename AbstractQuantityL::dimension,
                typename AbstractQuantityR::dimension,
                boost::pqs::meta::detail::subtract_reduce<
                    boost::mpl::_1,boost::mpl::_2
                > 
            >::type dims_type;          
            typedef typename anonymous_id_from<
               typename AbstractQuantityL::id,
               typename AbstractQuantityR::id
            >::type  anonymous_id ;
            typedef typename  boost::pqs::meta::abstract_quantity<
                dims_type,
                anonymous_id
            >::type  type;
        };
         
        template <
                typename AbstractQuantity,
                typename Exp
        >
        struct abstract_quantity_to_power{
            typedef typename boost::mpl::transform<
                typename AbstractQuantity::dimension,
                detail::times_reduce<boost::mpl::_,Exp>
            >::type  dims_type;
            typedef typename anonymous_id_from<
               typename AbstractQuantity::id,
               typename AbstractQuantity::id
            >::type  anonymous_id ;
            typedef typename  boost::pqs::meta::abstract_quantity<
                dims_type,
                anonymous_id
            >::type  type; 
        };
        template <
            typename AbstractQuantity
        > struct reciprocal_abstract_quantity{
            typedef typename anonymous_id_from<
               typename AbstractQuantity::id,
               typename AbstractQuantity::id
            >::type  anonymous_id ;
            typedef typename boost::mpl::transform<
                typename AbstractQuantity::dimension,
                detail::negate_reduce<boost::mpl::_>
            >::type  dims_type;
            typedef  typename boost::pqs::meta::abstract_quantity<
                dims_type,
                anonymous_id
            >::type  type; 
        };
        
    }//detail
    struct anonymous_quantity_id : mpl::int_<0> {};

    template<typename T> 
    struct is_anonymous_quantity;

    template<typename Dimension,typename ID>
    struct is_anonymous_quantity<abstract_quantity<Dimension,ID> >
    :  boost::mpl::equal_to<ID, anonymous_quantity_id>{};

}}}//boost::pqs::meta

namespace boost{namespace mpl{

    template<
        typename DimensionL, typename IDl, 
        typename DimensionR, typename IDr
    >
    struct plus<
        boost::pqs::meta::abstract_quantity<DimensionL,IDl>,
        boost::pqs::meta::abstract_quantity<DimensionR,IDr>
    > :  boost::pqs::meta::detail::plus_minus_abstract_quantity<
            boost::pqs::meta::abstract_quantity<DimensionL,IDl>,
            boost::pqs::meta::abstract_quantity<DimensionR,IDr>
    >::type {};

    template<
        typename DimensionL, typename IDl, 
        typename DimensionR, typename IDr
    >
    struct minus<
        boost::pqs::meta::abstract_quantity<DimensionL,IDl>,
        boost::pqs::meta::abstract_quantity<DimensionR,IDr>
    > :  boost::pqs::meta::detail::plus_minus_abstract_quantity<
            boost::pqs::meta::abstract_quantity<DimensionL,IDl>,
            boost::pqs::meta::abstract_quantity<DimensionR,IDr>
    >::type{};

    template<
        typename DimensionL, typename IDl, 
        typename DimensionR, typename IDr
    >
    struct times<
        boost::pqs::meta::abstract_quantity<DimensionL,IDl>,
        boost::pqs::meta::abstract_quantity<DimensionR,IDr>
    > :  boost::pqs::meta::detail::multiply_abstract_quantity<
            boost::pqs::meta::abstract_quantity<DimensionL,IDl>,
            boost::pqs::meta::abstract_quantity<DimensionR,IDr>
    >::type{};

    template<
        typename DimensionL, typename IDl, 
        typename DimensionR, typename IDr
    >
    struct divides<
        boost::pqs::meta::abstract_quantity<DimensionL,IDl>,
        boost::pqs::meta::abstract_quantity<DimensionR,IDr>
    > :  boost::pqs::meta::detail::divides_abstract_quantity<
            boost::pqs::meta::abstract_quantity<DimensionL,IDl>,
            boost::pqs::meta::abstract_quantity<DimensionR,IDr>
    >::type{};

    template <
            typename Dimension, 
            typename ID,
            typename Exp
    >
    struct pow<
        boost::pqs::meta::abstract_quantity<Dimension,ID>,
        Exp
    > : boost::pqs::meta::detail::abstract_quantity_to_power<
          boost::pqs::meta::abstract_quantity<Dimension,ID>,
          Exp
    >::type {};  
               
    template<typename Dimension, typename ID>
    struct reciprocal<
        boost::pqs::meta::abstract_quantity<Dimension,ID>
    > : boost::pqs::meta::detail::reciprocal_abstract_quantity<
            boost::pqs::meta::abstract_quantity<Dimension,ID>
    >::type{};
}}//boost::mpl

#endif
