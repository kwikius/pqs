#ifndef BOOST_PQS_META_ARITHMETIC_PROMOTE_HPP_INCLUDED
#define BOOST_PQS_META_ARITHMETIC_PROMOTE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.


/*
    from Boost promotion_traits.hpp header file  -------------

    (C) Copyright Aleksey Gurtovoy 2000. Permission to copy, use,
    modify, sell and distribute this software is granted provided this
    copyright notice appears in all copies. This software is provided
    "as is" without express or implied warranty, and with no claim as
    to its suitability for any purpose.

    Acknowledgments:
    Blitz++ and the Lambda Library provided some starting ideas for this 
    implementation of types' promotion traits; however, the implementation
    below pretends to be more accurate in modelling the letter of the standard 
    than its predecessors ;)

    Andy little 2 feb 04 ,
    1) added some 'typename's
    2) (in case of name clash) replaced boost::detail::type_rank<T> with
    boost::detail::types_promotion_traits_rank<T>
    3) replaced boost::detail::rank_step with 
    boost::detail::types_promotion_traits_rank_step
    4) changed boost::promote_to_signed_or_unsigned member name
    from result to type
    compile and build tested on VC7.1
    5) changed enums to static int const (to elim warnings on gcc3.2)
    6) changed namespace to boost::pqs::meta (as not official boost)
*/

#include <boost/mpl/if.hpp>
#include <boost/type_traits/is_arithmetic.hpp>

 namespace boost{namespace pqs{ namespace meta { 

    template<
        typename T1,
        typename T2
    >
    struct arithmetic_promote;

}}}//pqs::meta
namespace boost{ namespace pqs{
namespace meta { namespace detail{

    // integral_promotion_traits ------------------
    // the following implementation is based on std
    // section 4.5 [conv.prom]. 

    // by default integer promotion for unknown type
    // does nothing.
    template<
        class T
    > 
    struct integral_promotion_traits{
        typedef T type; 
    };

    // 4.5 [conv.prom], para 4.
    template<> 
    struct integral_promotion_traits<
        bool
    >{ 
        typedef int type; 
    };

    // for signed types it is guarateed that 'int'
    // can represent all the values of the source 
    // type being promoted (because they are all 
    // signed and sizeof(int) >= sizeof(T) where T
    // is 'signed char' or 'short').

    template<> 
    struct integral_promotion_traits<
        signed char
    >{
        typedef int type; 
    };

    template<>
    struct integral_promotion_traits<
        short
    >{
        typedef int type;
    };

    // promotion for unsigned types,
    // 4.5 [conv.prom], para 1
    template<
        class T
    >
    struct promote_to_signed_or_unsigned { 
        typedef typename boost::mpl::if_c<
            (sizeof(int) > sizeof(T)),
            int,
            unsigned int
        >::type type;
    };

    // 3.9.1 [basic.fundamental], para 1: 
    // In any particular implementation, a 
    // plain 'char' object can take on either
    // the same values as a 'signed char' or 
    // an 'unsigned char'; which one is 
    // implementation-defined
    template<> 
    struct integral_promotion_traits<
        char
    >{

#ifdef BOOST_UNSIGNED_CHAR_IMPLEMENTATION
        typedef typename promote_to_signed_or_unsigned<
            char
        >::type type;
#else
        typedef int type;
#endif
    };

    template<>
    struct integral_promotion_traits<
        unsigned char
    >{ 
        typedef promote_to_signed_or_unsigned<
            unsigned char
        >::type  type;
    };

    template<> 
    struct integral_promotion_traits<
        unsigned short
    >{
        typedef promote_to_signed_or_unsigned<
            unsigned short
        >::type type;
    };
#ifdef _MSVC_VER
#ifdef  _WCHAR_T_DEFINED 
  //  #ifndef BOOST_NO_WCHAR_T_SUPPORT
    // promotion for wchar_t, 4.5 [conv.prom], para 2;
    // also 3.9.1 [basic.fundamental], para 5: Type 
    // 'wchar_t' shall have the same size, signednes,
    // and alignment requirements (3.9) as one of the
    // other integral types, called its 
    // _underlying-type_.
    template<> 
    struct integral_promotion_traits<
        wchar_t
    >{ 
       // #ifdef BOOST_UNSIGNED_WCHAR_T_IMPLEMENTATION
        typedef boost::mpl::if_c<
            (sizeof(int) > sizeof(wchar_t)),
            int, 
            boost::mpl::if_c<
                (sizeof(int)  ==  sizeof(wchar_t)),
                unsigned int, 
                boost::mpl::if_c<
                    (sizeof(long) > sizeof(wchar_t)),
                    long,
                    unsigned long
                >::type
            >::type
        >::type type;
      //  #else
      //  typedef boost::mpl::if_c<
      //      (sizeof(int) >= sizeof(wchar_t)),
      //      int,
      //      long
      //  >::type type;
      //#endif // BOOST_UNSIGNED_WCHAR_T_IMPLEMENTATION
    };
#endif 
#endif
    // TODO: enums??

        // types_promotion_traits_rank -----------------------------------
        // won't work for other than built-in types
        template<
            class T
        > 
        struct types_promotion_traits_rank; 
        static int const types_promotion_traits_rank_step = 10 ;

        template<> 
        struct types_promotion_traits_rank<
            bool
        >{ 
            static int const value = 0;
        };

        template<>
        struct types_promotion_traits_rank<
            signed char
        >{ 
            static int const value = types_promotion_traits_rank<bool>::value 
            + types_promotion_traits_rank_step ; 
        };

        template<> 
        struct types_promotion_traits_rank<
            unsigned char
        >{
            static int const value = types_promotion_traits_rank<signed char>::value
            + types_promotion_traits_rank_step ;
        };

        template<>
        struct types_promotion_traits_rank<
            char
        >{ 
            static int const value = types_promotion_traits_rank<unsigned char>::value
            + types_promotion_traits_rank_step;
        };
#ifdef _MSVC_VER
#ifdef _WCHAR_T_DEFINED 
        template<> 
        struct types_promotion_traits_rank<
            wchar_t
        >
        {
            static int const value = types_promotion_traits_rank<char>::value
            + types_promotion_traits_rank_step;
        };
#endif
#endif
        template<>
        struct types_promotion_traits_rank<
            short
        >{
            static int const value = types_promotion_traits_rank_step * 10 ;
        };

        template<>
        struct types_promotion_traits_rank<
            unsigned short
        >{
            static int const value = types_promotion_traits_rank<short>::value
            + types_promotion_traits_rank_step ;
        };

        template<>
        struct types_promotion_traits_rank<
            int
        >{
            static int const value = types_promotion_traits_rank<unsigned short>::value
            + types_promotion_traits_rank_step;
        };

        template<>
        struct types_promotion_traits_rank<
            unsigned int
        >{
            static int const value = types_promotion_traits_rank<int>::value
            + types_promotion_traits_rank_step;
        };
    
        template<> 
        struct types_promotion_traits_rank<
            long
        >{
            static int const value = types_promotion_traits_rank<unsigned int>::value
            + types_promotion_traits_rank_step;
        };

        template<>
        struct types_promotion_traits_rank<
            unsigned long
        >{
            static int const value = types_promotion_traits_rank<long>::value
            + types_promotion_traits_rank_step;
        };

        template<>
        struct types_promotion_traits_rank<float>
        {
            static int const value = types_promotion_traits_rank_step * 100;
        };

        template<>
        struct types_promotion_traits_rank<double>
        { 
            static int const value 
            = types_promotion_traits_rank<float>::value
            + types_promotion_traits_rank_step;
        };

        template<> 
        struct types_promotion_traits_rank<
            long double
        >{
            static int const value 
            = types_promotion_traits_rank<
                double
            >::value
            + types_promotion_traits_rank_step;
        };

   
    // arithmetic_conversions_traits ------------------

    // 5 [expr], para 9: 
    // Many binary operators that expect operands of
    // arithmetic or enumeration type cause conversions
    // and yield result types in a similar way. The 
    // purpose is to yield a common type, which is also
    // the type of the result. This pattern is called 
    // the _usual arithmetic conversions_, which are
    // defined as follows:

    template<
        typename T1,
        typename T2
    >
    struct arithmetic_conversions_traits {
    private: 
    // workaround for MSVC bugs, will be re-written someday
        template<
            class T
        >
        struct type_rank { 
            typedef types_promotion_traits_rank<T> type; 
        };

        enum  {  floating_point_promotion 
                = type_rank<T1>::type::value
                    >= type_rank<float>::type::value 
                || type_rank<T2>::type::value
                    >= type_rank<float>::type::value };

        typedef typename integral_promotion_traits<
            T1
        >::type promoted_t1;
    
        typedef typename integral_promotion_traits<
            T2
        >::type promoted_t2;

        enum  { long_int_unsigned_int_combination
                = type_rank<
                    promoted_t1
                >::type::value 
                    == type_rank<
                        unsigned int
                    >::type::value 
                && type_rank<
                        promoted_t2
                    >::type::value
                        == type_rank<
                            long
                        >::type::value 
                || type_rank<
                    promoted_t2
                >::type::value 
                    == type_rank<
                        unsigned int
                    >::type::value 
                    && type_rank<
                        promoted_t1
                    >::type::value
                    == type_rank<
                        long
                    >::type::value };

        // results of some temporary computations 
        // were placed here because of the compilers'
        // parsing problems; in theory they could be 
        // (??) a part of the typedef below
        enum  { type1_rank_gt_type2_rank 
                = type_rank<T1>::type::value 
                    > type_rank<T2>::type::value,
                sizeof_long_gt_sizeof_unsigned
                = sizeof(long) > sizeof(unsigned int),
                promoted_t1_rank_gt_promoted_t2_rank  
                = type_rank<promoted_t1>::type::value 
                    > type_rank<promoted_t2>::type::value
        };
    public:
        typedef typename boost::mpl::if_c<
            floating_point_promotion,
            typename boost::mpl::if_c<
                type1_rank_gt_type2_rank,
                T1,
                T2
            >::type,
            typename boost::mpl::if_c<
                long_int_unsigned_int_combination,
                typename boost::mpl::if_c<
                    sizeof_long_gt_sizeof_unsigned,
                    long,
                    unsigned long
                >::type,
                typename boost::mpl::if_c<
                    promoted_t1_rank_gt_promoted_t2_rank,
                    promoted_t1, 
                    promoted_t2
                >::type 
            >::type 
        >::type type;
    };
}}}}//boost::pqs::meta::detail

 namespace boost{namespace pqs{namespace meta{

    template<
        typename T1,
        typename T2
    >
    struct arithmetic_promote
    // arithmetic_promote must be specialised for user-defined types
  // : pqs::concept_checking::AssertAreBothArithmetic<T1,T2>  
    {
         typedef typename detail::arithmetic_conversions_traits<
                T1, 
                T2
            >::type type;
    };

}}} //boost::pqs::meta

#endif // PQS_META_TYPES_PROMOTION_TRAITS_HPP
