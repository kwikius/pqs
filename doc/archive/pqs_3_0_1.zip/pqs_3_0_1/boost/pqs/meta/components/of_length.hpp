#ifndef BOOST_PQS_OF_LENGTH_HPP_INCLUDED
#define BOOST_PQS_OF_LENGTH_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_length : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "length";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::mpl::vector<
            boost::mpl::int_<1>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<1828804>,
                boost::mpl::int_<0>
            > fathom_us;
            typedef meta::quantity_unit<
                boost::mpl::int_<11>,
                meta::incoherent_multiplier<1495979>,
                boost::mpl::int_<0>
            > AU;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<2011684>,
                boost::mpl::int_<0>
            > ch;
            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<1828800>,
                boost::mpl::int_<0>
            > fathom;
            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<3048000>,
                boost::mpl::int_<0>
            > ft;
            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<3048006>,
                boost::mpl::int_<0>
            > ft_us;
            typedef meta::quantity_unit<
                boost::mpl::int_<-2>,
                meta::incoherent_multiplier<2540000>,
                boost::mpl::int_<0>
            > in;
            typedef meta::quantity_unit<
                boost::mpl::int_<15>,
                meta::incoherent_multiplier<9460730>,
                boost::mpl::int_<0>
            > l_y_;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1609344>,
                boost::mpl::int_<0>
            > mi;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1852000>,
                boost::mpl::int_<0>
            > naut_mile;
            typedef meta::quantity_unit<
                boost::mpl::int_<16>,
                meta::incoherent_multiplier<3085678>,
                boost::mpl::int_<0>
            > pc;
            typedef meta::quantity_unit<
                boost::mpl::int_<-3>,
                meta::incoherent_multiplier<4233333>,
                boost::mpl::int_<0>
            > pica_comp;
            typedef meta::quantity_unit<
                boost::mpl::int_<-3>,
                meta::incoherent_multiplier<4217518>,
                boost::mpl::int_<0>
            > pica_prn;
            typedef meta::quantity_unit<
                boost::mpl::int_<-4>,
                meta::incoherent_multiplier<3527778>,
                boost::mpl::int_<0>
            > point_comp;
            typedef meta::quantity_unit<
                boost::mpl::int_<-4>,
                meta::incoherent_multiplier<3514598>,
                boost::mpl::int_<0>
            > point_prn;
            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<5029210>,
                boost::mpl::int_<0>
            > rd;
            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<9144000>,
                boost::mpl::int_<0>
            > yd;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<4046873>,
                boost::mpl::int_<0>
            > acre;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1233489>,
                boost::mpl::int_<0>
            > acre_foot;
            typedef meta::quantity_unit<
                boost::mpl::int_<-10>,
                meta::incoherent_multiplier<1000000>,
                boost::mpl::int_<1>
            > angstrom;
        };
        typedef  of_length of_type;
    };
    template<>
    inline
    const char*
    of_length::unprefixed_symbol<char>()
    {
        return "m";
    }
    template <>
    struct of_named_quantity_for<
        of_length::type
    > : of_length{};
}}}}//boost::pqs::meta::components
#endif
