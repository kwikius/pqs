#ifndef BOOST_PQS_OF_MASS_HPP_INCLUDED
#define BOOST_PQS_OF_MASS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_mass : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "mass";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 3
        };

        typedef boost::mpl::vector<
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<1>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::quantity_unit<
                boost::mpl::int_<-2>,
                meta::incoherent_multiplier<2916667>,
                boost::mpl::int_<0>
            > AT;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1016047>,
                boost::mpl::int_<0>
            > ton_long;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1000000>,
                boost::mpl::int_<1>
            > t;
            typedef meta::quantity_unit<
                boost::mpl::int_<-4>,
                meta::incoherent_multiplier<2000000>,
                boost::mpl::int_<0>
            > carat;
            typedef meta::quantity_unit<
                boost::mpl::int_<-5>,
                meta::incoherent_multiplier<6479891>,
                boost::mpl::int_<0>
            > grain;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<5080235>,
                boost::mpl::int_<0>
            > hundredwgt_short;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<4535924>,
                boost::mpl::int_<0>
            > hundredwgt_long;
            typedef meta::quantity_unit<
                boost::mpl::int_<-2>,
                meta::incoherent_multiplier<2834952>,
                boost::mpl::int_<0>
            > oz;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<3110348>,
                boost::mpl::int_<0>
            > troy_oz;
            typedef meta::quantity_unit<
                boost::mpl::int_<-3>,
                meta::incoherent_multiplier<1555174>,
                boost::mpl::int_<0>
            > dwt;
            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<4535924>,
                boost::mpl::int_<0>
            > lb;
            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<3732417>,
                boost::mpl::int_<0>
            > troy_lb;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<1459390>,
                boost::mpl::int_<0>
            > slug;
        };
        typedef  of_mass of_type;
    };
    template<>
    inline
    const char*
    of_mass::unprefixed_symbol<char>()
    {
        return "g";
    }
    template <>
    struct of_named_quantity_for<
        of_mass::type
    > : of_mass{};
}}}}//boost::pqs::meta::components
#endif
