#ifndef BOOST_PQS_OF_PRESSURE_HPP_INCLUDED
#define BOOST_PQS_OF_PRESSURE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_pressure : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "pressure";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::mpl::vector<
            boost::mpl::int_<-1>,
            boost::mpl::int_<-2>,
            boost::mpl::int_<1>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::quantity_unit<
                boost::mpl::int_<5>,
                meta::incoherent_multiplier<1013250>,
                boost::mpl::int_<0>
            > atm;
            typedef meta::quantity_unit<
                boost::mpl::int_<4>,
                meta::incoherent_multiplier<9806650>,
                boost::mpl::int_<0>
            > at;
            typedef meta::quantity_unit<
                boost::mpl::int_<5>,
                meta::incoherent_multiplier<1000000>,
                boost::mpl::int_<1>
            > bar;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1333220>,
                boost::mpl::int_<0>
            > cm_mercury0C;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1333224>,
                boost::mpl::int_<0>
            > cmHg;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<9806380>,
                boost::mpl::int_<0>
            > cm_water4C;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<9806650>,
                boost::mpl::int_<0>
            > cmH20;
            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<1000000>,
                boost::mpl::int_<1>
            > dyn_div_cm2;
            typedef meta::quantity_unit<
                boost::mpl::int_<4>,
                meta::incoherent_multiplier<4063666>,
                boost::mpl::int_<0>
            > ftHg;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<2988980>,
                boost::mpl::int_<0>
            > ft_water39_2F;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<2989067>,
                boost::mpl::int_<0>
            > ftH20;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<9806650>,
                boost::mpl::int_<1>
            > gf_div_cm2;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<3386380>,
                boost::mpl::int_<0>
            > in_mercury32F;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<3376850>,
                boost::mpl::int_<0>
            > in_mercury60F;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<3386389>,
                boost::mpl::int_<0>
            > inHg;
            typedef meta::quantity_unit<
                boost::mpl::int_<2>,
                meta::incoherent_multiplier<2490820>,
                boost::mpl::int_<0>
            > in_water39_2F;
            typedef meta::quantity_unit<
                boost::mpl::int_<2>,
                meta::incoherent_multiplier<2490889>,
                boost::mpl::int_<0>
            > inH20;
            typedef meta::quantity_unit<
                boost::mpl::int_<4>,
                meta::incoherent_multiplier<9806650>,
                boost::mpl::int_<1>
            > kgf_div_cm2;
            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<9806650>,
                boost::mpl::int_<0>
            > kgf_div_m2;
            typedef meta::quantity_unit<
                boost::mpl::int_<6>,
                meta::incoherent_multiplier<9806650>,
                boost::mpl::int_<0>
            > kgf_div_mm2;
            typedef meta::quantity_unit<
                boost::mpl::int_<6>,
                meta::incoherent_multiplier<6894757>,
                boost::mpl::int_<0>
            > ksi;
            typedef meta::quantity_unit<
                boost::mpl::int_<2>,
                meta::incoherent_multiplier<1000000>,
                boost::mpl::int_<2>
            > mbar;
            typedef meta::quantity_unit<
                boost::mpl::int_<2>,
                meta::incoherent_multiplier<1333224>,
                boost::mpl::int_<0>
            > mmHg;
            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<9806650>,
                boost::mpl::int_<1>
            > mmH20;
            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<4788026>,
                boost::mpl::int_<0>
            > lbf_div_ft2;
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<6894757>,
                boost::mpl::int_<0>
            > psi;
            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<1488164>,
                boost::mpl::int_<0>
            > poundal_div_ft2;
            typedef meta::quantity_unit<
                boost::mpl::int_<2>,
                meta::incoherent_multiplier<1333224>,
                boost::mpl::int_<1>
            > torr;
        };
        typedef  of_pressure of_type;
    };
    template<>
    inline
    const char*
    of_pressure::unprefixed_symbol<char>()
    {
        return "Pa";
    }
    template <>
    struct of_named_quantity_for<
        of_pressure::type
    > : of_pressure{};
}}}}//boost::pqs::meta::components
#endif
