#ifndef BOOST_PQS_OF_TEMPERATURE_HPP_INCLUDED
#define BOOST_PQS_OF_TEMPERATURE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_temperature : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "temperature";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::mpl::vector<
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<1>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
        };
        typedef  of_temperature of_type;
    };
    template<>
    inline
    const char*
    of_temperature::unprefixed_symbol<char>()
    {
        return "K";
    }
    template <>
    struct of_named_quantity_for<
        of_temperature::type
    > : of_temperature{};
}}}}//boost::pqs::meta::components
#endif
