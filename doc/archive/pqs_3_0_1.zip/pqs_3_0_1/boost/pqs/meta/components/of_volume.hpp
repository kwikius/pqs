#ifndef BOOST_PQS_OF_VOLUME_HPP_INCLUDED
#define BOOST_PQS_OF_VOLUME_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_volume : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "volume";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 3,
            prefix_offset = 0
        };

        typedef boost::mpl::vector<
            boost::mpl::int_<3>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1233489>,
                boost::mpl::int_<0>
            > acre_foot;
            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<1589873>,
                boost::mpl::int_<0>
            > bbl;
            typedef meta::quantity_unit<
                boost::mpl::int_<2>,
                meta::incoherent_multiplier<3523907>,
                boost::mpl::int_<0>
            > bu;
            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<3624556>,
                boost::mpl::int_<0>
            > cord;
            typedef meta::quantity_unit<
                boost::mpl::int_<-2>,
                meta::incoherent_multiplier<2831685>,
                boost::mpl::int_<0>
            > ft3;
            typedef meta::quantity_unit<
                boost::mpl::int_<-5>,
                meta::incoherent_multiplier<1638706>,
                boost::mpl::int_<0>
            > in3;
            typedef meta::quantity_unit<
                boost::mpl::int_<9>,
                meta::incoherent_multiplier<4168182>,
                boost::mpl::int_<0>
            > mi3;
            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<7645549>,
                boost::mpl::int_<0>
            > yd3;
            typedef meta::quantity_unit<
                boost::mpl::int_<-4>,
                meta::incoherent_multiplier<2365882>,
                boost::mpl::int_<0>
            > cup;
            typedef meta::quantity_unit<
                boost::mpl::int_<-5>,
                meta::incoherent_multiplier<2957353>,
                boost::mpl::int_<0>
            > fl_oz_US;
            typedef meta::quantity_unit<
                boost::mpl::int_<-3>,
                meta::incoherent_multiplier<4546090>,
                boost::mpl::int_<0>
            > gal;
            typedef meta::quantity_unit<
                boost::mpl::int_<-3>,
                meta::incoherent_multiplier<3785412>,
                boost::mpl::int_<0>
            > gal_US;
        };
        typedef  of_volume of_type;
    };
    template<>
    inline
    const char*
    of_volume::unprefixed_symbol<char>()
    {
        return "m3";
    }
    template <>
    struct of_named_quantity_for<
        of_volume::type
    > : of_volume{};
}}}}//boost::pqs::meta::components
#endif
