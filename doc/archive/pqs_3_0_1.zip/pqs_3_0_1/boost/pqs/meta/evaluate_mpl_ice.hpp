#ifndef BOOST_PQS_META_EVALUATE_MPL_ICE_HPP_INCLUDED
#define BOOST_PQS_META_EVALUATE_MPL_ICE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/pqs/quantity_traits.hpp>
#include <boost/mpl/math/rational.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/pqs/meta/arithmetic_promote.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/denominator.hpp>
namespace boost{namespace pqs{namespace meta{

    template<typename ICE>
    struct evaluate_impl;
    template<typename ICE>
    struct evaluate{
        typedef typename evaluate_impl<
            typename ICE::tag
        >:: template apply<
            ICE
        >::result_type result_type;
        result_type operator()()const
        {
            return evaluate_impl<
                typename ICE::tag
            >::
            template apply<
                ICE
            >()();
        }
    };
    
    template<>
    struct evaluate_impl<boost::mpl::integral_c_tag>
    {
        template <typename N> struct apply{
            typedef typename N::value_type result_type;
            result_type operator()() const
            {
                return N::value;
            }
        };
    };

    template<>
    struct evaluate_impl<boost::mpl::math::rational_tag>
    {
        template <typename R> struct apply{
            typedef typename boost::pqs::meta::arithmetic_promote<
                typename boost::mpl::math::denominator<R>::value_type,
                typename boost::mpl::math::numerator<R>::value_type
            >::type promoted_value_type;
            typedef typename boost::mpl::if_<
                typename R::is_integer,
                promoted_value_type,
                typename boost::pqs::quantity_traits::default_value_type
            >::type result_type;
            result_type operator()() const
            {
                result_type result = boost::mpl::math::numerator<R>::type::value;
                result /= boost::mpl::math::denominator<R>::type::value;
                return result;
            }
        };
    };

}}}//boost::pqs::meta
#endif

