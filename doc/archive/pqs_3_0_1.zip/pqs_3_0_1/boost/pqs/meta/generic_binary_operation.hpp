#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_META_GENERIC_BINARY_OPERATION_HPP_INCLUDED
#define BOOST_PQS_META_GENERIC_BINARY_OPERATION_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2005.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
   generic binary_operations on ct_quantities
   Note other specialisations are used per op
*/

#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/pqs/quantity/t1/t1_quantity_fwd.hpp>

namespace boost {namespace pqs{ namespace meta{

    template <
        typename Op,
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    struct unary_operation<
        Op,
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >
    >{
        typedef t1_quantity<
            typename unary_operation<
                Op,
                AbstractQuantity
            >::result_type,
            typename unary_operation<
                Op,
                Units
            >::result_type,
            typename unary_operation<
                Op,
                Value_type
            >::result_type
        > result_type;
    };

    template < 
        typename AbstractQuantityL,
        typename UnitsL,
        typename Value_typeL,
        typename Op,
        typename AbstractQuantityR,
        typename UnitsR,
        typename Value_typeR
    >
    struct binary_operation<
        t1_quantity<
            AbstractQuantityL,
            UnitsL,
            Value_typeL
        >,
        Op,
        t1_quantity<
            AbstractQuantityR, 
            UnitsR,
            Value_typeR
        >,
        typename boost::disable_if<
            boost::mpl::or_<
                boost::mpl::or_<
                    is_conditional_operator<Op>,
                    is_equality_operator<Op>,
                    is_relational_operator<Op>
                >,
                boost::mpl::or_<
                    is_logical_or_operator<Op>,
                    is_logical_and_operator<Op>,
                    is_assignment_operator<Op>
                >/*,
                boost::mpl::or_<
                    boost::is_same<
                        AbstractQuantityL,boost::mpl::void_
                    >,
                    boost::is_same<
                        AbstractQuantityR,boost::mpl::void_
                    >
                >*/
            >
        >::type
    >{
        typedef typename t1_quantity<
            typename binary_operation<
                AbstractQuantityL,
                Op,
                AbstractQuantityR
            >::result_type,
            typename binary_operation<
                UnitsL,Op,UnitsR
            >::result_type,
            typename binary_operation<
                Value_typeL,
                Op,
                Value_typeR
            >::result_type
        >::type result_type;
    };
            
}}}//boost::pqs::meta

#endif
