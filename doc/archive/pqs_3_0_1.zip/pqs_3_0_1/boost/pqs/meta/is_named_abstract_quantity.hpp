#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_IS_NAMED_ABSTRACT_QUANTITY_HPP_INCLUDED
#define BOOST_PQS_IS_NAMED_ABSTRACT_QUANTITY_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/t1_quantity/t1_quantity_fwd.hpp>
#include <boost/pqs/meta/components/of_named_quantity_for_fwd.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/not.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/void.hpp>

namespace boost{namespace pqs{namespace meta{
   
    //Is this AbstractQuantity a NamedAbstractQuantity
    // with a specialisation of the OfNamedQuantityComponents concept
    template <
        typename AbstractQuantity
    >
    struct is_named_abstract_quantity
    : boost::mpl::and_<
        boost::mpl::not_equal_to<
            typename AbstractQuantity::id,
            anonymous_quantity_id
        >, 
        boost::mpl::not_<
            boost::is_same<
                typename components::of_named_quantity_for<
                    AbstractQuantity
                >::type,
                boost::mpl::void_
            >
        >
    >{};  
}}}//boost::pqs::meta
#endif
