#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_META_ASSOCIATED_ARITHMETIC_TYPES_HP_INCLUDED
#define PQS_META_ASSOCIATED_ARITHMETIC_TYPES_HP_INCLUDED
/*
    to get at value_type and arithmetic type of a type
*/

#include "boost/mpl/if.hpp"
#include "boost/type_traits/is_arithmetic.hpp"

namespace boost{namespace pqs{namespace meta{

    template <typename T>
    struct to_arithmetic;

    namespace detail{

        template<bool Condition,typename T>
        struct recursive_apply_value_type_if;

        // if  T is not arithmetic
        // recursively apply to get to arithmetic type
        template<typename T>
        struct recursive_apply_value_type_if<true,T>{
            typedef typename T::value_type t_value_type;
            typedef typename pqs::meta::to_arithmetic<
                t_value_type
            >::type type;
        };

        //if T is arithmetic
        template<typename T>
        struct recursive_apply_value_type_if<false,T>{
            typedef T type;
        };

        template<bool Condition,typename T>
        struct apply_value_type_if;

        // if  T is not arithmetic
        // apply to get to value_type
        template<typename T>
        struct apply_value_type_if<true,T>{
            typedef typename T::value_type type;
        };

        //if T is arithmetic
        template<typename T>
        struct apply_value_type_if<false,T>{
            typedef T type;
        };
    }

    template <typename T>
    struct to_arithmetic : detail::recursive_apply_value_type_if<
            (boost::is_arithmetic<T>::value == false),
            T   
    >{};
    
    template <typename T>
    struct to_value_type : detail::apply_value_type_if<
            (boost::is_arithmetic<T>::value == false),
            T   
    >{};

    template <typename T, int N>
    struct to_value_type< T[N]>{
        typedef T type;
    };
    template <typename T, int N>
    struct to_value_type< T const [N]>{
        typedef T type;
    };
    template <typename T>
    struct to_value_type< T*>{
        typedef T type;
    };
    template <typename T>
    struct to_value_type< T const *>{
        typedef T type;
    };
    template <>
    struct to_value_type<char>{
        typedef char type;
    };
    template <>
    struct to_value_type<const char>{
        typedef const char type;
    };
}}}//boost::pqs::meta

#endif
