#ifndef BOOST_PQS_MPL_CHECK_ZERO_HPP_INCLUDED
#define BOOST_PQS_MPL_CHECK_ZERO_HPP_INCLUDED

#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/mpl/int.hpp>
namespace boost{namespace mpl{ namespace math{

    //template <typename T>
    //struct is_zero : :equal_to<T,int_<0> >{};
    template <typename T>
    struct not_zero : not_equal_to<T,int_<0> >{};
}}}//boost::mpl::math

#endif
