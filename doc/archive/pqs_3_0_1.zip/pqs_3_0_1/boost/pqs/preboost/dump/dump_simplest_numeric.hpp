#ifndef BOOST_MPL_REDUCE_NUMERIC_CONSTANT_HPP_INCLUDED
#define BOOST_MPL_REDUCE_NUMERIC_CONSTANT_HPP_INCLUDED

#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/math/is_rational.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/or.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/assert.hpp>


namespace boost{namespace mpl{namespace math{

    namespace detail{

        
        // get from integral_c<int,,> to better type eg int_
        
        template <typename IntegerType>
        struct best_integral_c_type{
            template <IntegerType N> struct apply 
            : integral_c<IntegerType, N>{};
        };

        template <>
        struct best_integral_c_type<int>{
            typedef best_integral_c_type type;
            template <int N>
            struct apply : int_<N>{};
        };

        template <>
        struct best_integral_c_type<long>{
            typedef best_integral_c_type type;
            template <long N>
            struct apply : long_<N>{};
        };
       
        template<typename Rational>
        struct can_be_integral : or_<    
            is_zero<typename Rational::numerator>,
            equal_to< typename Rational::denominator,int_<1> >
        > {};
        template <typename Rational>
        struct reduce_rational{
            typedef rational<typename Rational::numerator, typename Rational::denominator>
            type;
        }
        //Some rationals are representable as integers
        // Try to educe to integral if possible
        template <typename Rational>
        struct to_integral_if_possible_impl{
        private:
            BOOST_MPL_ASSERT( (boost::mpl::math::is_rational<Rational>));
        public:
            typedef typename Rational::denominator::value_type value_type;
            typedef typename boost::mpl::eval_if<
               can_be_integral<Rational>,
               typename best_integral_c_type<value_type>
               ::template apply<Rational::type::numerator::value> ,
               typename reduce_rational<Rational>::type
            >::type  type;
        };

        template< typename T>
        struct to_integral_if_possible 
        : boost::mpl::eval_if<
            boost::mpl::math::is_rational<T>,
            to_integral_if_possible_impl<T>,
            typename T
        >{};

       }//detail

        template<typename T>
        struct simplify_rational_or_numeric : detail::to_integral_if_possible<T>{};

        
    
}}}//boost::mpl::math


#endif
 