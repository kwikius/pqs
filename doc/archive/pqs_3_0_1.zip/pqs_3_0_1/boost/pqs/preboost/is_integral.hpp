#ifndef BOOST_MPL_IS_INTEGRAL_HPP_INCLUDED
#define BOOST_MPL_IS_INTEGRAL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/mpl/integral_c_tag.hpp>
#include <boost/pqs/meta/detail/is_family_of_ice_impl.hpp>

namespace boost{namespace mpl{namespace math{

    template <typename T>
    struct is_integral 
    : boost::pqs::meta::detail::is_family_of_ice_impl<
        integral_c_tag,T
    >{};

}}}//boost::mpl::math


#endif
 