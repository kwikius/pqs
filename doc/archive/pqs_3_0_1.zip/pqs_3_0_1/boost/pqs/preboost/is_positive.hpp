#ifndef BOOST_MPL_IS_POSITIVE_HPP_INCLUDED
#define BOOST_MPL_IS_POSITIVE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.


#include <boost/mpl/aux_/config/forwarding.hpp>
#include <boost/mpl/aux_/lambda_support.hpp>
#include <boost/mpl/negate.hpp>
#include <boost/mpl/greater_equal.hpp>

namespace boost{namespace mpl{ namespace math{

    template <typename T>
    struct is_positive 
#if !defined BOOST_MPL_CFG_NO_NESTED_FORWARDING
    : greater_equal<
            T,
            negate<T> 
    >{
#else  
    {
        typedef BOOST_DEDUCED_TYPENAME  greater_equal<
            T,negate<T> 
        >::type type;
#endif
        BOOST_MPL_AUX_LAMBDA_SUPPORT(
            1
            , is_positive
            , (T)
        )
    };

}}}// boost::mpl::math


#endif
