#ifndef BOOST_MPL_REDUCE_NUMERIC_CONSTANT_HPP_INCLUDED
#define BOOST_MPL_REDUCE_NUMERIC_CONSTANT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>
#include <boost/pqs/preboost/is_rational.hpp>
//#include <boost/mpl/is_integral_constant.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/or.hpp>
#include <boost/mpl/math/is_zero.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/mpl/if.hpp>
#include <limits>

namespace boost{namespace mpl{namespace math{

    namespace detail{

        // get from integral_c<int,,> to better type eg int_
        
        template <typename IntegerType>
        struct best_integral_c_type{
            template <IntegerType N> struct apply 
            : integral_c<IntegerType, N>{};
        };

        template <>
        struct best_integral_c_type<int>{
            typedef best_integral_c_type type;
            template <int N>
            struct apply : int_<N>{};
        };

        template <>
        struct best_integral_c_type<long>{
            typedef best_integral_c_type type;
            template <long N>
            struct apply {
                typedef typename if_c<
                    ( ( N <= INT_MAX) && (N >= INT_MIN) ),
                    int_<N>,
                    long_<N> 
                >::type type;
            };
        };
       
        template<typename Rational>
        struct can_be_integral : or_<    
            is_zero<typename Rational::numerator>,
            equal_to< typename Rational::denominator,int_<1> >
        > {
             BOOST_MPL_ASSERT((boost::mpl::math::is_rational<Rational>));
        };

        template <typename Rational>
        struct reduce_rational{
            BOOST_MPL_ASSERT((boost::mpl::math::is_rational<Rational>));
            typedef typename boost::mpl::eval_if<
                can_be_integral<Rational>,
                typename best_integral_c_type<
                    typename Rational::denominator::value_type
                >::template apply<
                        Rational::type::numerator::value
                    >::type ,
                typename Rational::type
            >::type  type; 
        };

        //Some rationals are representable as integers
        // Try to reduce to integral if possible
        template <typename Rational>
        struct to_integral_if_possible_impl{
        private:
            BOOST_MPL_ASSERT( (boost::mpl::math::is_rational<Rational>));
        public:
            typedef typename Rational::denominator::value_type value_type;
            typedef typename boost::mpl::eval_if<
               can_be_integral<Rational>,
               typename best_integral_c_type<value_type>
               ::template apply<Rational::type::numerator::value>::type ,
               typename reduce_rational<Rational>::type
            >::type  type;
        };

        template< typename T>
        struct to_integral_if_possible 
        : boost::mpl::eval_if<
            boost::mpl::math::is_rational<T>,
            to_integral_if_possible_impl<T>,
            typename T::type
        >{};

       }//detail

        template<typename T>
        struct simplify_rational_or_numeric : detail::to_integral_if_possible<T>{};

}}}//boost::mpl::math


#endif
 