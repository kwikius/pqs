#ifndef BOOST_MPL_TO_RATIONAL_C_HPP_INCLUDED
#define BOOST_MPL_TO_RATIONAL_C_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/utility/enable_if.hpp>
#include <boost/pqs/preboost/is_rational.hpp>
#include <boost/mpl/identity.hpp>

#include <boost/mpl/identity.hpp>
#include <boost/mpl/is_integral_constant.hpp>

namespace boost{namespace mpl{namespace math{

    namespace detail{

        template <typename T, typename Enable = void>
        struct to_rational_impl;

        template  <typename T>
        struct to_rational_impl<
            T,
            typename enable_if<is_rational<T> >::type
        > : identity<T>{};

        template  <typename T>
        struct to_rational_impl<
            T,
            typename enable_if<is_integral_constant<T> >::type
        > : rational< 
            T , 
            boost::mpl::int_<1> 
        >{};

    }//detail
    template <typename T>
    struct to_rational : detail::to_rational_impl<T>{};
        
}}}//boost::mpl::math

#endif
