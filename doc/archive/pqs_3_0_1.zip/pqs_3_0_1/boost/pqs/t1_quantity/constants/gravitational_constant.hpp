#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_GRAVITATIONAL_CONSTANT_HPP_INCLUDED
#define BOOST_PQS_GRAVITATIONAL_CONSTANT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    gravitational constant declaration
    note:
    requires compilation of "pqs/physics/lib_src/gravitational_constant.cpp"
    for linking
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/mpl/vector.hpp>
#include <boost/mpl/int.hpp>
namespace boost{namespace pqs{namespace physics{

    template <typename Value_type>
    struct gravitational_constant_{
        typedef  boost::pqs::t1_quantity<     //pqs-1-00-03 style
            boost::pqs::meta::abstract_quantity<
                boost::mpl::vector<
                    boost::mpl::int_<3>,
                    boost::mpl::int_<-2>,
                    boost::mpl::int_<-1>,
                    boost::mpl::int_<0>,
                    boost::mpl::int_<0>,
                    boost::mpl::int_<0>,
                    boost::mpl::int_<0> 
                >,
                boost::mpl::int_<0>
            >,
            boost::pqs::meta::quantity_unit<
                boost::mpl::int_<-11>
            >,
            Value_type
        > type;
   
        static type const& G;
    };

    struct gravitational_constant : gravitational_constant_<double>{};

}}}//boost::pqs::physics

#endif

