#ifndef BOOST_PQS_T1_QUANTITY_UNITS_OSTREAM_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_UNITS_OSTREAM_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    default stream output of ct-quantity.
    defines std::ostream& operator << (std::ostream& ,
         physical_quantity_basic_units_out<...> );
    where physical_quantity_basic_units_out<...>
    is the dummy object returned by invoking pq.units()
*/
#include <iostream>
#include <sstream>
#include <cstring>
#include <string>
#include <boost/pqs/quantity_traits.hpp>
#include <boost/pqs/t1_quantity/io/detail/put_rational.hpp>
#include <boost/pqs/t1_quantity/io/units_out.hpp>
#include <boost/mpl/at.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/pqs/t1_quantity/operations/power_root.hpp>
#include <boost/mpl/or.hpp>
#include <boost/pqs/preboost/check_zero.hpp>

namespace boost{namespace pqs{

// This ostream operator << picks up the physical_quantity_basic_units_out class
// returned by pq.units(). The general idea is to use the p.units() form for
// output of the basic units (and any scaling). The units(pq) form is meant
// for overloading on  eg for a pqs::force::kgf pq;
// pq.units() gives  "[kg.m.s-2 * 9.8XX]"
// units(pq) gives   "kgf"
// this is the pq.units() format definition

    template<
        typename CharType,
        typename AbstractQuantity,
        typename QuantityUnit
    >
    inline std::basic_ostream<CharType>& 
    operator << 
        (std::basic_ostream<CharType>& os,
            t1_quantity_basic_units_out< 
                AbstractQuantity,
                QuantityUnit
            > const&  )
    {
        typedef typename AbstractQuantity::dimension dimension;
        typedef typename boost::mpl::at_c<dimension,0>::type p_length;
        typedef typename boost::mpl::at_c<dimension,1>::type p_time;
        typedef typename boost::mpl::at_c<dimension,2>::type p_mass;
        typedef typename boost::mpl::at_c<dimension,3>::type p_temperature;
        typedef typename boost::mpl::at_c<dimension,4>::type p_current;
        typedef typename boost::mpl::at_c<dimension,5>::type p_substance;
        typedef typename boost::mpl::at_c<dimension,6>::type p_intensity;
        typedef typename AbstractQuantity::dimension dimension;
        typedef boost::mpl::math::not_zero<p_length> has_length;
        typedef boost::mpl::math::not_zero<p_time> has_time;
        typedef boost::mpl::math::not_zero<p_mass> has_mass;
        typedef boost::mpl::math::not_zero<p_temperature> has_temperature;
        typedef boost::mpl::math::not_zero<p_current> has_current;
        typedef boost::mpl::math::not_zero<p_substance> has_substance;
        typedef boost::mpl::math::not_zero<p_intensity> has_intensity;

        
        // fractional exponent or non 1 incoherent multiplier 
        typedef typename boost::mpl::or_<
            boost::mpl::not_equal_to<
                typename QuantityUnit::multiplier,
                boost::mpl::int_<1>
            >,
            boost::mpl::not_equal_to<
                typename boost::mpl::math::denominator<
                    typename QuantityUnit::exponent
                >::type,
                boost::mpl::int_<1>
            >
        >::type has_brackets;
        std::ostringstream ost;
        if( has_brackets::value){
            ost << '[';
        }
        if ( has_mass::value){
            ost << "kg";
            detail::put_rational<p_mass>(ost);
            if (
                has_length::value ||has_time::value 
                || has_temperature::value ||has_current::value 
                ||has_substance::value 
                || has_intensity::value
            ){
                ost << '.';
            }
        }
        
        if (has_length::value) {
            ost << 'm';
            detail::put_rational<p_length>(ost);
            if (
                has_time::value || has_temperature::value 
                || has_current::value ||has_substance::value 
                || has_intensity::value
            ){
                ost << '.';
            }
        }
        if (has_time::value){
            ost << 's';
            detail::put_rational<p_time>(ost);
            if ( 
                has_temperature::value ||has_current::value 
                ||has_substance::value || has_intensity::value
            ){
                ost << '.';
            }
        }
        if (has_temperature::value){
            ost << 'K';
            detail::put_rational<p_temperature>(ost);
            if ( has_current::value ||has_substance::value || has_intensity::value){
                ost << '.';
            }
        }
        if (has_current::value){
            ost << 'A';
             detail::put_rational<p_current>(ost);
            if ( has_substance::value || has_intensity::value){
                ost << '.';
            }
        }
        if (has_substance::value){
            ost << "mol";
            detail::put_rational<has_substance>(ost);
            if (has_intensity::value){
                ost << '.';
            }
        }
        if (has_intensity::value){
            ost << "cd";
            detail::put_rational<has_intensity>(ost);
        }
        if( boost::mpl::not_equal_to<
                typename QuantityUnit::multiplier,
                boost::mpl::int_<1>
            >::value
        ){
            double mux =
                (static_cast<double>(boost::mpl::math::numerator<
                    typename QuantityUnit::multiplier
                >::type::value) 
                / (boost::mpl::math::denominator<
                    typename QuantityUnit::multiplier
                >::type::value))
            *
               pqs::pow<
                    boost::mpl::math::numerator<
                        typename QuantityUnit::exponent
                    >::type::value,
                    boost::mpl::math::denominator<
                        typename QuantityUnit::exponent
                    >::type::value
                >(10.);
            ost << " * " << mux ;
        } 
        else if(boost::mpl::math::numerator<typename QuantityUnit::exponent>::type::value !=0 ){
            if (boost::mpl::math::denominator<typename QuantityUnit::exponent>::type::value == 1){
                // neat exponent
                ost << " * 1e" 
                << boost::mpl::math::numerator<typename QuantityUnit::exponent>::type::value; 
            }
            else {
                // messy exponent
                ost << " * " 
                <<   pqs::pow<
                    boost::mpl::math::numerator<
                        typename QuantityUnit::exponent
                    >::type::value,
                    boost::mpl::math::denominator<
                        typename QuantityUnit::exponent
                    >::type::value
                >(10.) ;
            } 
        }
        if( has_brackets::value){
            ost << ']';
        }
        os << ost.str();
        return os;
    }
    
}}//boost::pqs

#endif

