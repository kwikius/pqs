#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_T1_QUANTITY_COMPARE_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_COMPARE_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    compare(pqa,pqb) works like strcmp and string::compare:
    if( a == b ) return 0;
    if( a > b ) return 1;
    if( a < b ) return -1;

    compare is basis of all other comp functions
    added 23/09/04 optional 'epsilon' arg to compare
    modified config so default param is type(0)
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <cmath>
#include <cstdlib>

namespace boost{namespace pqs{

    // for compatibiliyt of built_in types;
    template<typename T>
    int compare( T const & a, T const & b, T const & ep)
    {
        return ( std::abs(a-b) <= std::abs(ep))
        ? 0 
        :( ((a-b) < 0)? -1: 1 );
    }
    // abs(pq)
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    t1_quantity<
        NamedAbstractQuantity,
        QuantityUnit,
        Value_type
    >
    abs(
        t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & in)
    {
        return (in.numeric_value() >=0 )
        ? in
        : -in;
    }  

    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    int 
    compare(
        t1_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        t1_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b,
        //ouch :-)
        typename meta::binary_operation<
            t1_quantity< 
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >,
            meta::minus,
            t1_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        >::result_type const &  ep
        = typename pqs::meta::binary_operation<
            t1_quantity< 
                NamedAbstractQuantityA,
                QuantityUnitA,
                Value_typeA
            >,
            meta::minus,
            t1_quantity<
                NamedAbstractQuantityB,
                QuantityUnitB,
                Value_typeB
            >
        >::result_type(
            static_cast<
                typename meta::binary_operation<
                    Value_typeA,
                    meta::minus,
                    Value_typeB
                >::result_type
            >(PQS_COMPARISON_EPSILON))   
        )
    {
        typedef typename meta::binary_operation<
                Value_typeA,meta::minus,Value_typeB
        >::result_type comp_type;
        return ((abs(a-b)).numeric_value() <= abs(ep).numeric_value()) // should be  ep/2 ??
        ? 0 
        :(((a-b).numeric_value() < static_cast<comp_type>(0))
            ? -1
            : 1 );
    }

    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator == (  
        t1_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        t1_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {
        return (compare(a,b) == 0); 
    }
    
    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator != (
        t1_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        t1_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b)
    {
        return (compare(a,b)!= 0);
    }

 // PQa < PQb
    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator<(
        t1_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        t1_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b) 
    {
        return (compare(a,b) < 0);
    }

    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator >(
        t1_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        t1_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {
        return (compare(a,b) > 0);
    }

    template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator <=(
        t1_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        t1_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {
        return (compare(a,b) <= 0);
    }

   template<
        typename NamedAbstractQuantityA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename NamedAbstractQuantityB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    bool
    operator >=(
        t1_quantity< 
            NamedAbstractQuantityA,
            QuantityUnitA,
            Value_typeA
        >const & a,
        t1_quantity<
            NamedAbstractQuantityB,
            QuantityUnitB,
            Value_typeB
        >const& b )
    {
        return (compare(a,b) >= 0);
    }

}}//boost::pqs

#endif
