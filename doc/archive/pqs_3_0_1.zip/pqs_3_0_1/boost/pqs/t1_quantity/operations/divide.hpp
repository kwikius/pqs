#ifndef BOOST_PQS_T1_QUANTITY_DIVIDE_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_DIVIDE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    division of ct-quantities
*/
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/pqs/detail/united_value/operations/dimensioned_divide.hpp>
#include <boost/pqs/detail/united_value/operations/dimensionless_divide.hpp>
#include <boost/pqs/t1_quantity/operations/t1_quantity_bin_op_macros.hpp>

namespace boost {namespace pqs{
    namespace meta{
         BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_BIN_OP(divides)  
    }
    //dimensionless result
    template<
        typename AbstractQuantityA,
        typename UnitsA,
        typename Value_typeA,
        typename AbstractQuantityB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation_if<
        meta::dimensionally_equivalent<
            AbstractQuantityA,
            AbstractQuantityB
        >,
        Value_typeA,
        meta::divides,
        Value_typeB
    >::result_type
    operator / ( 
        t1_quantity<
            AbstractQuantityA,
            UnitsA,
            Value_typeA
        > const & pqa,
        t1_quantity<
            AbstractQuantityB,
            UnitsB,
            Value_typeB
        > const & pqb )
    {
        typename meta::binary_operation< 
            Value_typeA,
            meta::divides,
            Value_typeB
        >::result_type result 
        =   detail::dimensionless_divide(
                pqa.get_united_value(),
                pqb.get_united_value()
            ); 
        return result;
    }
    
    //dimensioned result
    template< 
        typename AbstractQuantityA,
        typename UnitsA,
        typename Value_typeA,
        typename AbstractQuantityB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation_if<
        boost::mpl::not_<
            meta::dimensionally_equivalent<
                AbstractQuantityA,
                AbstractQuantityB
            >
        >,
        t1_quantity<
            AbstractQuantityA,
            UnitsA,
            Value_typeA
        >,
        meta::divides,
        t1_quantity<
            AbstractQuantityB,
            UnitsB,
            Value_typeB
        >
    >::result_type
    operator / ( 
        t1_quantity<
            AbstractQuantityA,
            UnitsA,
            Value_typeA
        > const & pqa,
        t1_quantity<
            AbstractQuantityB,
            UnitsB,
            Value_typeB
        > const & pqb )
    {
        typename meta::binary_operation<
            t1_quantity<
                AbstractQuantityA,
                UnitsA,
                Value_typeA
            >,
            meta::divides,
            t1_quantity<
                AbstractQuantityB,
                UnitsB,
                Value_typeB
            >
        >::result_type result(
            (
                detail::dimensioned_divide(
                    pqa.get_united_value(),
                    pqb.get_united_value()
                )
             ).raw_value() 
        );
        return result;
    }
        
}}//boost::pqs

#endif
