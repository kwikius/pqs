#ifndef BOOST_PQS_T1_QUANTITY_POWER_ROOT_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_POWER_ROOT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    power and root functions for inbuilts and ct-quantities
    for inbuilts pow<N>(v) to bring in to line with
*/

#include <cmath>
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/is_t1_quantity.hpp>
#include <boost/mpl/math/rational.hpp>
#include <boost/pqs/meta/coherent_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
#include <boost/pqs/meta/is_t1_quantity_value_type.hpp>
#include <boost/pqs/meta/to_arithmetic.hpp>
#include <boost/pqs/pow_identities.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/not_equal_to.hpp>

namespace boost{namespace pqs{

    namespace meta{
 
        template <
            typename Exponent,
            typename AbstractQuantity,
            typename Units,
            typename Value_type
        >
        struct binary_operation<
            t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            pow, 
            Exponent ,
            typename boost::enable_if<
                boost::mpl::and_<
                    boost::mpl::not_equal_to<
                        Exponent,
                        boost::mpl::int_<0>
                    >,
                    boost::mpl::not_equal_to<
                        Exponent,
                        boost::mpl::int_<1>
                    >
                >
            >::type
        >{
            typedef typename t1_quantity <
                typename boost::mpl::pow<
                    AbstractQuantity,
                    Exponent
                >::type,
                typename boost::mpl::pow<
                    Units,
                    Exponent
                >::type,
                typename binary_operation<
                    Value_type,
                    pow,
                    Exponent
                >::result_type
            >::type result_type;
        };

    }// meta

   /* template<int N> struct deduced_int{};
    template<int N, int D> struct deduced_fraction{};*/


    template <
        int N,
        int D
    >
    inline
    double
    pow( double const& v)
    {
        double  result 
        = std::pow(
             v ,
            static_cast<double>( N ) / D
        );         
        return result;
    }
    template <
        int N,
        int D
    >
    inline
    double
    pow( int const& v)
    {
        double  result 
        = std::pow(
            static_cast<double>( v ),
            static_cast<double>( N ) / D
        );         
        return result;
    }

    template <
        int N,
        int D,
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    inline 
    typename boost::enable_if<
        boost::mpl::and_<
            boost::mpl::not_equal_to<
                boost::mpl::math::rational_c<int,N,D>,
                boost::mpl::int_<0>
            >,
            boost::mpl::not_equal_to<
                boost::mpl::math::rational_c<int,N,D>,
                boost::mpl::int_<1>
            >
        >,    
        t1_quantity<
            typename boost::mpl::pow<
                AbstractQuantity,
                boost::mpl::math::rational_c<int,N,D>
            >::type,
            typename boost::mpl::pow<
                Units,
                boost::mpl::math::rational_c<int,N,D>
            >::type,
           typename meta::binary_operation<
                Value_type,
                meta::pow,
                typename boost::mpl::math::rational_c<int,N,D>::type
           >::result_type 
        >
    >::type
    pow(
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        > const & pq 
    )
    {   //scale to coherent temporary version
        typedef typename meta::transform_coherent<
            t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >
        >::type coherent_pq;
        coherent_pq t(pq);
        typedef typename boost::mpl::math::rational_c<
            int,N,D
        >::type exponent_type;
        typedef typename meta::binary_operation<
            coherent_pq,
            meta::pow,
            exponent_type
        >::result_type result_type;
        result_type result(pqs::pow<N,D>(t.numeric_value()));
        return result;
    }
    template <
        int N,
        int D,
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    inline 
    typename boost::enable_if<
        typename boost::mpl::equal_to<
           boost::mpl::math::rational_c<int,N,D>,
           boost::mpl::int_<1>
        >::type,    
       t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
       >
    >::type
    pow(
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        > const & pq 
    )
    {   //scale to coherent temporary version
       
        return pq;
    }

     template <
        int N,
        int D,
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    inline 
    typename boost::enable_if<
        typename boost::mpl::equal_to<
           boost::mpl::math::rational_c<int,N,D>,
           boost::mpl::int_<0>
        >::type,    
      int
    >::type
    pow(
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        > const & pq 
    )
    {   //scale to coherent temporary version
       
        return 1;
    }

    template <
        int N,
        typename T
    >
    inline
    typename meta::binary_operation<
        T, meta::pow,
        boost::mpl::math::rational_c<int,N,1>
    >::result_type
    pow( T const & t)
    {
        meta::binary_operation<
            T, 
            meta::pow,
            boost::mpl::math::rational_c<int,N,1>
        >::result_type result = boost::pqs::pow<N,1>(t);
        return result;
    }

  
}}//boost::pqs

#endif

