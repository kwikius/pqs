#ifndef BOOST_PQS_T1_QUANTITY_FWD_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_FWD_HPP_INCLUDED

//  Copyright (C) Andy Little, White Light Device 2005.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

//    forward declaration of boost::pqs::t1_quantity

namespace boost{namespace pqs{

    template<
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    class t1_quantity;
  
}}//boost::pqs

#endif
