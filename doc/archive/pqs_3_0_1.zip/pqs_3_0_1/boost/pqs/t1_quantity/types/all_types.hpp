
#ifndef BOOST_PQS_T1_QUANTITY_ALL_TYPES_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_ALL_TYPES_HPP_INCLUDED

#include <boost/pqs/t1_quantity/types/circulation.hpp>
#include <boost/pqs/t1_quantity/types/conductance.hpp>
#include <boost/pqs/t1_quantity/types/density.hpp>
#include <boost/pqs/t1_quantity/types/energy.hpp>
#include <boost/pqs/t1_quantity/types/frequency.hpp>
#include <boost/pqs/t1_quantity/types/reciprocal_time.hpp>
#include <boost/pqs/t1_quantity/types/inductance.hpp>
#include <boost/pqs/t1_quantity/types/magnetic_field_strength.hpp>
#include <boost/pqs/t1_quantity/types/magnetic_flux.hpp>
#include <boost/pqs/t1_quantity/types/magnetic_flux_density.hpp>
#include <boost/pqs/t1_quantity/types/magnetomotive_force.hpp>
#include <boost/pqs/t1_quantity/types/mass_flow.hpp>
#include <boost/pqs/t1_quantity/types/power.hpp>
#include <boost/pqs/t1_quantity/types/reciprocal_mass.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/magnetic_permeability.hpp>
#include <boost/pqs/t1_quantity/types/torque.hpp>
#include <boost/pqs/t1_quantity/types/voltage.hpp>
#include <boost/pqs/t1_quantity/types/potential_difference.hpp>
#include <boost/pqs/t1_quantity/types/pressure.hpp>
#include <boost/pqs/t1_quantity/types/velocity.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/mass.hpp>
#include <boost/pqs/t1_quantity/types/temperature.hpp>
#include <boost/pqs/t1_quantity/types/current.hpp>
#include <boost/pqs/t1_quantity/types/substance.hpp>
#include <boost/pqs/t1_quantity/types/intensity.hpp>
#include <boost/pqs/t1_quantity/types/area.hpp>
#include <boost/pqs/t1_quantity/types/volume.hpp>
#include <boost/pqs/t1_quantity/types/acceleration.hpp>
#include <boost/pqs/t1_quantity/types/force.hpp>
#include <boost/pqs/t1_quantity/types/capacitance.hpp>
#include <boost/pqs/t1_quantity/types/charge.hpp>

#endif
