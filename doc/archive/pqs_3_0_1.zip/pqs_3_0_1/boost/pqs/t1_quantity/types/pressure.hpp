#ifndef BOOST_PQS_PRESSURE_HPP_INCLUDED
#define BOOST_PQS_PRESSURE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_pressure.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct pressure_ : meta::components::of_pressure{
        typedef t1_quantity<
            type,
            typename meta::si_unit::yocto, // coherent-exponent -24
            Value_type
        > yPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > zPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > aPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > fPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > pPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > nPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > uPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > mPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > cPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > dPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > Pa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > daPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > hPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > kPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > MPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > GPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > TPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > PPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > EPa;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZPa;

        typedef t1_quantity<
            type,
            typename incoherent_unit::atm,
            Value_type
        > atm;

        typedef t1_quantity<
            type,
            typename incoherent_unit::at,
            Value_type
        > at;

        typedef t1_quantity<
            type,
            typename incoherent_unit::bar,
            Value_type
        > bar;

        typedef t1_quantity<
            type,
            typename incoherent_unit::cm_mercury0C,
            Value_type
        > cm_mercury0C;

        typedef t1_quantity<
            type,
            typename incoherent_unit::cmHg,
            Value_type
        > cmHg;

        typedef t1_quantity<
            type,
            typename incoherent_unit::cm_water4C,
            Value_type
        > cm_water4C;

        typedef t1_quantity<
            type,
            typename incoherent_unit::cmH20,
            Value_type
        > cmH20;

        typedef t1_quantity<
            type,
            typename incoherent_unit::dyn_div_cm2,
            Value_type
        > dyn_div_cm2;

        typedef t1_quantity<
            type,
            typename incoherent_unit::ftHg,
            Value_type
        > ftHg;

        typedef t1_quantity<
            type,
            typename incoherent_unit::ft_water39_2F,
            Value_type
        > ft_water39_2F;

        typedef t1_quantity<
            type,
            typename incoherent_unit::ftH20,
            Value_type
        > ftH20;

        typedef t1_quantity<
            type,
            typename incoherent_unit::gf_div_cm2,
            Value_type
        > gf_div_cm2;

        typedef t1_quantity<
            type,
            typename incoherent_unit::in_mercury32F,
            Value_type
        > in_mercury32F;

        typedef t1_quantity<
            type,
            typename incoherent_unit::in_mercury60F,
            Value_type
        > in_mercury60F;

        typedef t1_quantity<
            type,
            typename incoherent_unit::inHg,
            Value_type
        > inHg;

        typedef t1_quantity<
            type,
            typename incoherent_unit::in_water39_2F,
            Value_type
        > in_water39_2F;

        typedef t1_quantity<
            type,
            typename incoherent_unit::inH20,
            Value_type
        > inH20;

        typedef t1_quantity<
            type,
            typename incoherent_unit::kgf_div_cm2,
            Value_type
        > kgf_div_cm2;

        typedef t1_quantity<
            type,
            typename incoherent_unit::kgf_div_m2,
            Value_type
        > kgf_div_m2;

        typedef t1_quantity<
            type,
            typename incoherent_unit::kgf_div_mm2,
            Value_type
        > kgf_div_mm2;

        typedef t1_quantity<
            type,
            typename incoherent_unit::ksi,
            Value_type
        > ksi;

        typedef t1_quantity<
            type,
            typename incoherent_unit::mbar,
            Value_type
        > mbar;

        typedef t1_quantity<
            type,
            typename incoherent_unit::mmHg,
            Value_type
        > mmHg;

        typedef t1_quantity<
            type,
            typename incoherent_unit::mmH20,
            Value_type
        > mmH20;

        typedef t1_quantity<
            type,
            typename incoherent_unit::lbf_div_ft2,
            Value_type
        > lbf_div_ft2;

        typedef t1_quantity<
            type,
            typename incoherent_unit::psi,
            Value_type
        > psi;

        typedef t1_quantity<
            type,
            typename incoherent_unit::poundal_div_ft2,
            Value_type
        > poundal_div_ft2;

        typedef t1_quantity<
            type,
            typename incoherent_unit::torr,
            Value_type
        > torr;

    };

    struct pressure : pressure_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
