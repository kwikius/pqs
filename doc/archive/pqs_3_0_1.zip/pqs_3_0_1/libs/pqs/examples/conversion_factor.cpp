#include <boost/pqs/t1_quantity/types/out/all_types.hpp>
    // get conversion factor from one dimensionally-equivalent type to another
namespace boost{namespace pqs{

    template <
        typename Target,
        typename Source
    >
    typename pqs::meta::arithmetic_promote<
        typename Target::value_type,
        typename Source::value_type
    >::type
    conversion_factor()
    {
        Source s(1);
        Target t = s;
        return t.numeric_value();
    }

    
}}//boost::pqs

int main()
{
    boost::pqs::length::m plankA(2);
    boost::pqs::length::mm plankB(1000);
    std::cout << "ratio  plankA / plankB = " << plankA / plankB << '\n'; 

    std::cout << "conversion-factor\n";
    std::cout << boost::pqs::conversion_factor<
        boost::pqs::length::mm,boost::pqs::length::m
    >() << '\n';
}