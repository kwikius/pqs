#ifndef BOOST_PQS_OPERATIONS_DIMENSIONED_DIVIDE_HPP_INCLUDED
#define BOOST_PQS_OPERATIONS_DIMENSIONED_DIVIDE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    divide low level calcs
*/

#include <boost/pqs/detail/united_value/united_value_fwd.hpp>
#include <boost/pqs/detail/united_value/operations/incoherent_mx.hpp>
#include <boost/pqs/meta/arithmetic_promote.hpp>
#include <boost/pqs/meta/to_arithmetic.hpp>

namespace boost{namespace pqs{namespace detail{

    template<
        typename UnitedValueL, 
        typename UnitedValueR,
        typename Result_type,
        typename Eval_Fx,
        bool Eval_fx_Required
    >
    struct dimensioned_divide_functor_eval;

    template< 
        typename UnitsL,
        typename Value_typeL,
        typename UnitsR,
        typename Value_typeR
    > struct dimensioned_divide_functor{
        typedef boost::pqs::detail::united_value<
            UnitsL,
            Value_typeL
        > uv_typeL;
        typedef boost::pqs::detail::united_value<
            UnitsR,
            Value_typeR
        > uv_typeR;
        typedef typename boost::pqs::meta::binary_operation<
            UnitsL,
            boost::pqs::meta::divides,
            UnitsR
        >::type result_unit;
        typedef typename boost::pqs::meta::binary_operation<
            Value_typeL,
            boost::pqs::meta::divides,
            Value_typeR
        >::type value_type;
        typedef united_value<result_unit,value_type> result_type;
        typedef typename detail::divide_incoherent_mx<  
            typename boost::pqs::meta::to_arithmetic<value_type>::type,
            typename UnitsL::multiplier,
            typename UnitsR::multiplier
        > incoherent_div_fx;
        enum{ fx_required = incoherent_div_fx::required};
        struct eval : dimensioned_divide_functor_eval<
            uv_typeL,
            uv_typeR,
            result_type,
            incoherent_div_fx,
            fx_required
        >{};
    };

    template<
        typename UnitedValueL, 
        typename UnitedValueR,
        typename Result_type,
        typename Eval_Fx
    >
    struct dimensioned_divide_functor_eval<
        UnitedValueL,UnitedValueR,Result_type,Eval_Fx, true
    >{
        Result_type operator()(
            UnitedValueL const & lhs, 
            UnitedValueR const & rhs
        )const
        {
            Result_type result(
                lhs.raw_value() 
                * Eval_Fx()() 
                / rhs.raw_value()
            );
            return result;
        }
    };

    template<
        typename UnitedValueL, 
        typename UnitedValueR,
        typename Result_type,
        typename Eval_Fx
    >
    struct dimensioned_divide_functor_eval<
    UnitedValueL,UnitedValueR,Result_type,Eval_Fx, false
    >{
        Result_type operator()(
            UnitedValueL const & a,
            UnitedValueR const & b
        )const
        {
            Result_type result( 
                a.raw_value() 
                / b.raw_value()
            );
            return result;
        }
    };

    template <
        typename UnitsL,
        typename Value_typeL,
        typename UnitsR,
        typename Value_typeR
    >
    inline
    typename dimensioned_divide_functor<
        UnitsL,Value_typeL,
        UnitsR, Value_typeR
    >::result_type
    dimensioned_divide(
        united_value<UnitsL,Value_typeL> const & lhs,
        united_value<UnitsR,Value_typeR> const & rhs
    ){
        typedef dimensioned_divide_functor<
            UnitsL, Value_typeL,
            UnitsR, Value_typeR
        > func;
        typename func::result_type result 
        = typename func::eval()(lhs,rhs);
        return result;
    }
    
}}}//boost::pqs::detail

#endif
