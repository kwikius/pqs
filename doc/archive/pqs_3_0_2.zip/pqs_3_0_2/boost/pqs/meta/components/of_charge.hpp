#ifndef BOOST_PQS_OF_CHARGE_HPP_INCLUDED
#define BOOST_PQS_OF_CHARGE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_charge : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "charge";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::pqs::meta::dimension<
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 typename meta::rational<3600000, 10000000>::type,
                boost::mpl::int_<0>
            > A_h;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<1>,
                 typename meta::rational<1000000, 10000000>::type,
                boost::mpl::int_<1>
            > abcoulomb;
        };
        typedef  of_charge of_type;
    };
    template<>
    inline
    const char*
    of_charge::unprefixed_symbol<char>()
    {
        return "C";
    }
    template <>
    struct of_named_quantity_for<
        of_charge::type
    > : of_charge{};
}}}}//boost::pqs::meta::components
#endif
