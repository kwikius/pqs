#ifndef BOOST_PQS_OF_LENGTH_HPP_INCLUDED
#define BOOST_PQS_OF_LENGTH_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_length : boost::noncopyable{
        static const char* abstract_quantity_name()
        {
            return "length";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::mpl::vector<
            boost::mpl::int_<1>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>,
            boost::mpl::int_<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;

        struct incoherent_unit{

            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<1828804>
            > fathom_us;

            typedef meta::quantity_unit<
                boost::mpl::int_<11>,
                meta::incoherent_multiplier<1495979>
            > AU;

            typedef meta::quantity_unit<
                boost::mpl::int_<1>,
                meta::incoherent_multiplier<2011684>
            > ch;

            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<1828800>
            > fathom;

            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<3048000>
            > ft;

            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<3048006>
            > ft_us;

            typedef meta::quantity_unit<
                boost::mpl::int_<-2>,
                meta::incoherent_multiplier<2540000>
            > in;

            typedef meta::quantity_unit<
                boost::mpl::int_<15>,
                meta::incoherent_multiplier<9460730>
            > l_y_;

            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1609344>
            > mi;

            typedef meta::quantity_unit<
                boost::mpl::int_<3>,
                meta::incoherent_multiplier<1852000>
            > naut_mile;

            typedef meta::quantity_unit<
                boost::mpl::int_<16>,
                meta::incoherent_multiplier<3085678>
            > pc;

            typedef meta::quantity_unit<
                boost::mpl::int_<-3>,
                meta::incoherent_multiplier<4233333>
            > pica_comp;

            typedef meta::quantity_unit<
                boost::mpl::int_<-3>,
                meta::incoherent_multiplier<4217518>
            > pica_prn;

            typedef meta::quantity_unit<
                boost::mpl::int_<-4>,
                meta::incoherent_multiplier<3527778>
            > point_comp;

            typedef meta::quantity_unit<
                boost::mpl::int_<-4>,
                meta::incoherent_multiplier<3514598>
            > point_prn;

            typedef meta::quantity_unit<
                boost::mpl::int_<0>,
                meta::incoherent_multiplier<5029210>
            > rd;

            typedef meta::quantity_unit<
                boost::mpl::int_<-1>,
                meta::incoherent_multiplier<9144000>
            > yd;

        };
        typedef  of_length of_type;

    };

    //explicit for char
    template<>
    inline
    const char*
    of_length::unprefixed_symbol<char>()
    {
        return "m";
    }

    //The following enables use of of_length data
    //as a traits class for abstract quantity length
    template <>
    struct of_named_quantity_for<
        of_length::type
    > : of_length{};


}}}}//boost::pqs::meta::components

#endif

