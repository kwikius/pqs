#ifndef BOOST_PQS_META_RATIONAL_FWD_HPP_INCLUDED
#define BOOST_PQS_META_RATIONAL_FWD_HPP_INCLUDED

namespace boost{namespace pqs{namespace meta{

    template <int N, int D=1>
    struct rational;

}}}//boost::pqs::meta

#endif
