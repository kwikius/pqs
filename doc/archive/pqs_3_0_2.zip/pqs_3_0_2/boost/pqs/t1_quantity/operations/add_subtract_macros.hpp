#ifndef BOOST_PQS_T1_QUANTITY_ADD_SUB_MACROS_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_ADD_SUB_MACROS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#define BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_ADDSUB_DEFINE(Operator, Op)\
    template < \
        typename AbstractQuantityL BOOST_PP_COMMA()\
        typename UnitsL BOOST_PP_COMMA()\
        typename Value_typeL BOOST_PP_COMMA()\
        typename AbstractQuantityR BOOST_PP_COMMA()\
        typename UnitsR BOOST_PP_COMMA()\
        typename Value_typeR\
    >\
    inline\
    typename boost::pqs::meta::binary_operation_if<\
        boost::pqs::meta::dimensionally_equivalent<\
           AbstractQuantityL BOOST_PP_COMMA()\
           AbstractQuantityR\
        > BOOST_PP_COMMA()\
        t1_quantity<\
            AbstractQuantityL BOOST_PP_COMMA() \
            UnitsL BOOST_PP_COMMA()\
            Value_typeL\
        > BOOST_PP_COMMA()\
        boost::pqs::meta:: ## Operator BOOST_PP_COMMA()\
        t1_quantity<\
            AbstractQuantityR BOOST_PP_COMMA()\
            UnitsR BOOST_PP_COMMA()\
            Value_typeR\
        >\
    >::type\
    operator Op (\
        t1_quantity<\
            AbstractQuantityL BOOST_PP_COMMA()\
            UnitsL BOOST_PP_COMMA()\
            Value_typeL\
        >const& lhs BOOST_PP_COMMA()\
        t1_quantity<\
            AbstractQuantityR BOOST_PP_COMMA()\
            UnitsR BOOST_PP_COMMA()\
            Value_typeR\
        >const& rhs)\
        {\
        typename boost::pqs::meta::binary_operation<\
            t1_quantity<\
                AbstractQuantityL BOOST_PP_COMMA()\
                UnitsL BOOST_PP_COMMA()\
                Value_typeL\
            > BOOST_PP_COMMA()\
            boost::pqs::meta:: ## Operator BOOST_PP_COMMA()\
            t1_quantity<\
                AbstractQuantityR BOOST_PP_COMMA()\
                UnitsR BOOST_PP_COMMA()\
                Value_typeR\
            >\
        >::type result = lhs;\
        result Op ## = rhs;\
        return result;\
    }
#endif
