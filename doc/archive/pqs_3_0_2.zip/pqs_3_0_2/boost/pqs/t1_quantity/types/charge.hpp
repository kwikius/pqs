#ifndef BOOST_PQS_CHARGE_HPP_INCLUDED
#define BOOST_PQS_CHARGE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_charge.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct charge_ : meta::components::of_charge{
        typedef t1_quantity<
            type,
            typename meta::si_unit::yocto, // coherent-exponent -24
            Value_type
        > yC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > zC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > aC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > fC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > pC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > nC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > uC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > mC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > cC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > dC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > C;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > daC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > hC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > kC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > MC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > GC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > TC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > PC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > EC;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZC;

        typedef t1_quantity<
            type,
            typename incoherent_unit::A_h,
            Value_type
        > A_h;

        typedef t1_quantity<
            type,
            typename incoherent_unit::abcoulomb,
            Value_type
        > abcoulomb;

    };

    struct charge : charge_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
