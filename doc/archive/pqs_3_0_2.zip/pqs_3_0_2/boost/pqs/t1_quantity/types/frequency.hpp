#ifndef BOOST_PQS_FREQUENCY_HPP_INCLUDED
#define BOOST_PQS_FREQUENCY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_frequency.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct frequency_ : meta::components::of_frequency{
        typedef t1_quantity<
            type,
            typename meta::si_unit::yocto, // coherent-exponent -24
            Value_type
        > yHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > zHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > aHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > fHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > pHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > nHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > uHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > mHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > cHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > dHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > Hz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > daHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > hHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > kHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > MHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > GHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > THz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > PHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > EHz;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZHz;

    };

    struct frequency : frequency_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
