
#ifndef BOOST_PQS_T1_QUANTITY_ACCELERATION_G_CPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_ACCELERATION_G_CPP_INCLUDED

#include <boost/pqs/t1_quantity/types/acceleration.hpp>

using boost::pqs::acceleration_;
// gravitational constant S.I units
template<>
acceleration_<float>::m_div_s2 const&
acceleration_<float>::g 
= acceleration_<float>::m_div_s2(9.80665f);

template<>
acceleration_<double>::m_div_s2 const&
acceleration_<double>::g
= acceleration_<double>::m_div_s2(9.80665);

template<>
acceleration_<int>::m_div_s2 const&
acceleration_<int>::g
= acceleration_<int>::m_div_s2(10);

#endif

