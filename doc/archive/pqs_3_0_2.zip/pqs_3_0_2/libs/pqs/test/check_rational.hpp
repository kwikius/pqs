#ifndef CHECK_RATIONAL_HPP_INCLUDED
#define CHECK_RATIONAL_HPP_INCLUDED

//#include "boost/math/rational.hpp"
//#include "boost/test/minimal.hpp"
//#include "libs/pqs/test/simple_test.hpp"

#include <boost/test/test_tools.hpp>
#include "boost/type_traits/is_same.hpp"

#define CHECK_RAT(Rational, n, d) \
    BOOST_CHECK( Rational ## ::numerator == n );\
    BOOST_CHECK( Rational ## ::denominator == d );

#define CHECK_INT(Integral,T, v)\
    BOOST_CHECK(  (Integral ## ::type::value) == v);\
    BOOST_CHECK( (boost::is_same< Integral ## ::value_type, T >::value) );

//void divide_test();
//void plus_test();

#endif
