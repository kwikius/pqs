#ifndef BOOST_PQS_TEST_HPP_INCLUDED
#define  BOOST_PQS_TEST_HPP_INCLUDED
#include <boost/test/test_tools.hpp>
#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/pqs/meta/si_units.hpp>
#include <boost/pqs/meta/rational.hpp>
//#include <boost/type_traits/is_same.hpp>
//#include <boost/mpl/int.hpp>
//#include <boost/mpl/long.hpp>
#include <boost/mpl/equal_to.hpp>

#define CHECK_QUANTITY_UNIT(Name,E,M,I) \
  BOOST_CHECK( (boost::mpl::equal_to< \
        Name ## ::exponent,\
        boost::pqs::meta::rational< E > \
    >::type::value));\
\
    BOOST_CHECK( (boost::mpl::equal_to< \
        Name ## ::multiplier, \
        boost::pqs::meta::rational< M > \
    >::type::value)); \
\
    BOOST_CHECK( (boost::mpl::equal_to<\
        Name ## ::id, \
        boooost::pqs::meta::rational< I >\
    >::type::value)); 


#define CHECK_SI_QUANTITY_UNIT( Prefix , E ) \
 CHECK_QUANTITY_UNIT( Prefix, E , 1, 0)


#endif
