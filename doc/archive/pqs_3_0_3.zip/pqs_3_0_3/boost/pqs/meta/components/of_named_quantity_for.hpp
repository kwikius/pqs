#ifndef BOOST_PQS_T1_QUANTITY_OF_NAMED_QUANTITY_COMPONENTS_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_OF_NAMED_QUANTITY_COMPONENTS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/meta/components/of_named_quantity_for_fwd.hpp>
#include <boost/pqs/t1_quantity/t1_quantity_fwd.hpp>
#include <boost/mpl/void.hpp>

/*
    required to be specialised for 
    each OFAbstractQuantity Concept
*/
namespace boost{namespace pqs{namespace meta{namespace components{

    template <
        typename AbstractQuantity   
    >
    struct of_named_quantity_for{
        typedef boost::mpl::void_ type;
    };

    // to get at the OfNamedQuantity via ct_quantity
    // will fail on anonymous type
    template<
        typename AbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    struct of_named_quantity_for<
       t1_quantity<
            AbstractQuantity,
            QuantityUnit,
            Value_type
        >
    > : of_named_quantity_for<
          AbstractQuantity 
    >::of_type{};
        
}}}}//boost::pqs::meta::components

#endif
