#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_META_DETAIL_RATIONAL_C_IMPL_HPP_INCLUDED
#define GENERIC_META_DETAIL_RATIONAL_C_IMPL_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

#include "boost/math/common_factor_ct.hpp"

namespace boost{namespace pqs{namespace meta{namespace detail{

    template<
        int N,
        int D 
    >
    struct rational_impl {
  
        enum{
            pos_nume_in = N >= 0 ? N : -N,
            pos_denom_in = D >= 0 ? D : -D
        };        
        typedef typename boost::math::static_gcd<
            static_cast<unsigned long>(pos_nume_in),
            static_cast<unsigned long>(pos_denom_in)
        > gcd_type;
        enum{
            gcd = (gcd_type::value),
            n_sign = (N >= 0)? 1 :-1,
            d_sign = (D >= 0)? 1 :-1,
            nume_in 
            = ( (n_sign * d_sign) > 0)? pos_nume_in : -pos_nume_in,  
            numerator = nume_in / gcd,
            denominator = pos_denom_in / gcd
        };
    };

    template<
        int N,
        int D
    >
    struct rational_impl_eval 
    {
        typedef typename rational_impl<N,D>::type rat_type;
        typedef double result_type;

        result_type operator()() const 
        {
            return static_cast<result_type>(rat_type::numerator)/rat_type::denominator;
        }
    };

    template<
        int N
    >
    struct rational_impl_eval<N,1>{
        typedef int result_type;
        result_type operator()() const
        {
            return N;
        }
    };
}}}}//boost::mpl::math::detail

#endif
