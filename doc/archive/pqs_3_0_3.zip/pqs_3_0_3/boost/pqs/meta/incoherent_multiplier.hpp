#ifndef BOOST_PQS_META_INCOHERENT_MULTIPLIER_INCLUDED
#define BOOST_PQS_META_INCOHERENT_MULTIPLIER_INCLUDED

#include <boost/pqs/meta/rational.hpp>
namespace boost{namespace pqs{namespace meta{

  /*  template<int N>
    struct incoherent_multiplier 
    : boost::pqs::meta::rational<N,1000000>{};*/

}}}//boost::pqs::meta

#endif
