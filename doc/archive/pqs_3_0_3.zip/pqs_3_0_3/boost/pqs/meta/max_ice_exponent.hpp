#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_META_MAX_ICE_EXPONENT_HPP_INCLUDED
#define BOOST_PQS_META_MAX_ICE_EXPONENT_HPP_INCLUDED
/*
    largest exponents for pow
    ideally not hard coded .... todo
*/

#include <limits>

namespace boost{namespace pqs{namespace meta{

        template< typename IntegerType, int Base>
        struct max_ice_exponent;

        template<typename IntegerType>
        struct max_ice_exponent<IntegerType, 10>{
              enum{value 
            = std::numeric_limits<IntegerType>::digits10};
        };

        /*template<>
        struct max_ice_exponent<int, 10>{
            enum{value = 8};
        };

        template<>
        struct max_ice_exponent<unsigned int, 10>{
            enum{value = 8};
        };

        template<>
        struct max_ice_exponent<long, 10L>{
            enum{value = 8};
        };

        template<>
        struct max_ice_exponent<unsigned long, 10UL>{
            enum{value = 8};
        };*/

}}}//boost::pqs::meta

#endif
