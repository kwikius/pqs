#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_META_RATIONAL_HPP_INCLUDED
#define BOOST_PQS_META_RATIONAL_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    compile time rational number
    from original impl by Matthias Schabel and ideas from Jan Langer
*/
#include <boost/pqs/meta/rational_fwd.hpp>
#include <boost/pqs/meta/detail/rational_impl.hpp>
#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/comparison.hpp>

namespace boost {namespace pqs{namespace meta{

    template<
        int N,
        int D 
    >
    struct rational {
        enum{
            numerator 
            = detail::rational_impl<N,D>::numerator,
            denominator 
            = detail::rational_impl<N,D>::denominator
        };
        typedef rational<numerator,denominator> type;
    };
   
    template<
        int N,
        int D 
    > 
    struct unary_operation<
         negate, 
         rational<N,D>
    >{
        typedef typename rational<-N,D>::type type;
    };

    template<
        int N,
        int D 
    > 
    struct unary_operation<
         reciprocal, 
         rational<N,D>
    >{
        typedef typename rational<D,N>::type type;
    };
 
 
    template <
        int Nlhs,int Dlhs,
        int Nrhs, int Drhs
    > struct binary_operation<
        rational<Nlhs,Dlhs>,
        plus,
        rational<Nrhs,Drhs>
    >{
        typedef rational<Nlhs,Dlhs> lhs;
        typedef rational<Nrhs,Drhs> rhs;
        enum{
            lhsn = lhs::numerator,
            lhsd = lhs::denominator,
            rhsn = rhs::numerator,
            rhsd = rhs::denominator
        };
        typedef typename rational<
            static_cast<int>(lhsn) * rhsd + static_cast<int>(rhsn) * lhsd, 
            static_cast<int>(lhsd) * rhsd
        >::type type;
    };

    template <
        int Nlhs,int Dlhs,
        int Nrhs, int Drhs
    > struct binary_operation<
        rational<Nlhs,Dlhs>,
        minus,
        rational<Nrhs,Drhs>
    >{
        typedef rational<Nlhs,Dlhs> lhs;
        typedef rational<Nrhs,Drhs> rhs;
        enum{
            lhsn = lhs::numerator,
            lhsd = lhs::denominator,
            rhsn = rhs::numerator,
            rhsd = rhs::denominator
        };
        typedef typename rational<
            static_cast<int>(lhsn) * rhsd - static_cast<int>(rhsn) * lhsd, 
            static_cast<int>(lhsd) * rhsd
        >::type type;
    };

    template <
        int Nlhs,int Dlhs,
        int Nrhs, int Drhs
    > struct binary_operation<
        rational<Nlhs,Dlhs>,
        times,
        rational<Nrhs,Drhs>
    >{
        typedef rational<Nlhs,Dlhs> lhs;
        typedef rational<Nrhs,Drhs> rhs;
        enum{
            lhsn = lhs::numerator,
            lhsd = lhs::denominator,
            rhsn = rhs::numerator,
            rhsd = rhs::denominator
        };
        typedef typename rational<
            static_cast<int>(lhsn) * rhsn, 
            static_cast<int>(lhsd) * rhsd
        >::type type;
    };

    template <
        int Nlhs,int Dlhs,
        int Nrhs, int Drhs
    > struct binary_operation<
        rational<Nlhs,Dlhs>,
        divides,
        rational<Nrhs,Drhs>
    >{
        typedef rational<Nlhs,Dlhs> lhs;
        typedef rational<Nrhs,Drhs> rhs;
        enum{
            lhsn = lhs::numerator,
            lhsd = lhs::denominator,
            rhsn = rhs::numerator,
            rhsd = rhs::denominator
        };
        typedef typename rational<
            static_cast<int>(lhsn) * rhsd , 
            (static_cast<int>(lhsn) == 0) ? 1 : static_cast<int>(lhsd) * rhsn
        >::type type;
    };
    template <typename T>
    struct is_rational : boost::mpl::false_{};   
    template <int N, int D>
    struct is_rational<rational<N,D> > : boost::mpl::true_{};

}}}//boost::pqs::meta

namespace boost{namespace mpl{

    #define BOOST_PQS_META_RATIONAL_COMPARISON_OP( Operator,OpSymbol)\
    template <\
            int Nlhs BOOST_PP_COMMA()\
            int Dlhs BOOST_PP_COMMA()\
            int Nrhs BOOST_PP_COMMA()\
            int Drhs\
    >\
    struct  Operator <\
        boost::pqs::meta::rational<Nlhs BOOST_PP_COMMA() Dlhs > BOOST_PP_COMMA()\
        boost::pqs::meta::rational<Nrhs BOOST_PP_COMMA() Drhs >\
    >{\
        typedef boost::pqs::meta::rational<Nlhs BOOST_PP_COMMA() Dlhs> lhs;\
        typedef boost::pqs::meta::rational<Nrhs BOOST_PP_COMMA() Drhs> rhs;\
        enum{\
            lhsn = lhs::numerator BOOST_PP_COMMA()\
            lhsd = lhs::denominator BOOST_PP_COMMA()\
            rhsn = rhs::numerator BOOST_PP_COMMA()\
            rhsd = rhs::denominator BOOST_PP_COMMA()\
            value = (static_cast<int>(lhsn) * rhsd OpSymbol static_cast<int>(rhsn) * lhsd )\
        };\
        typedef bool_<value> type;\
    };
   
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( less , < )
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( less_equal, <= )
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( equal_to, == )
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( not_equal_to, != )
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( greater_equal, >= )
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( greater, > )
    #undef BOOST_PQS_META_RATIONAL_COMPARISON_OP


}}//boost:mpl


#endif //PQS_META_RATIONAL_C_HPP_INCLUDED
