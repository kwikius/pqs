#ifndef BOOST_PQS_META_TRANSFORM_COHERENT_HPP_INCLUDED
#define BOOST_PQS_META_TRANSFORM_COHERENT_HPP_INCLUDED

namespace boost{namespace pqs {namespace meta{
  
    template<
        typename T
    >
    struct transform_coherent;
}}}//boost::pqs::meta

#endif
