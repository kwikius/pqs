#ifndef BOOST_PQS_UTILITY_INTPUT_HPP_INCLUDED2911030401
#define BOOST_PQS_UTILITY_INTPUT_HPP_INCLUDED2911030401
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    simple input routine for ct-quantity.
    sets badbit on invalid input
     
*/

#include <sstream>
#include <boost/pqs/t1_quantity/io/output.hpp>

 namespace boost{namespace pqs{
// after C++ 3rd ed p 621
// input of a ct-quantity
// basically compares the format of the units in operator <<

    template<
        typename AbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename CharType
    >
    inline std::basic_istream<CharType>& 
    operator >> (
        std::basic_istream<CharType>& is,
        t1_quantity<
            AbstractQuantity,
            QuantityUnit,
            Value_type
        >& pq 
    )
    {
        // use output for type to compare units
        std::basic_ostringstream<CharType> ost;
        ost << units(t1_quantity<
            AbstractQuantity,
            QuantityUnit,
            Value_type
        >());
        std::basic_string<CharType> str = ost.str();
        Value_type v;
        is >> v;
        CharType ch=0;
        int space_count = 0;
        while (is.get(ch)){
            if (ch  == is.widen(' ')){
                space_count++;
                continue;
            }
            else {
                is.putback(ch);
                break;
            }
        }
        if (!space_count){
            is.clear(std::ios_base::badbit);
            return is;
        }
        
        typename std::basic_string<CharType>::const_iterator iter = str.begin();
        while (iter != str.end()){
            is.get(ch);
            if (ch != *iter){
                is.clear(std::ios_base::badbit);
                break;
            }
            ++iter;
        }
        if (is){
            pq 
            = t1_quantity<
                AbstractQuantity,
                QuantityUnit,
                Value_type
            >(v);
        }
        return is; 
    } 
}}//boost::pqs
#endif
