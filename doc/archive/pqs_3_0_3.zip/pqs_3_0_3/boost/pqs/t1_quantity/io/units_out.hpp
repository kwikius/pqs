#ifndef BOOST_PQS_T1_QUANTITY_UNITS_OUT_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_UNITS_OUT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    utility "dummy" classes used for output of units of a physical quantity
    which can be overloaded for special units
    e.g "N" (newtons),"kgf" (kilograms force )
*/

namespace boost{namespace pqs{

    template<   
        typename AbstractQuantity,
        typename QuantityUnit
    >
    class t1_quantity_units_out{};

/*
    utility class used for output of units of a physical quantity  as
    QuantityUnit::si_exponent * QuantityUnit::incoherent_mx  version
    e.g "kg.m.s-2" (newtons), "kg.m.s-2 * 9.8" (kilograms force )
*/
    template<
        typename AbstractQuantity,
        typename QuantityUnit
    > 
    class t1_quantity_basic_units_out{};

}}//boost::pqs

#endif

