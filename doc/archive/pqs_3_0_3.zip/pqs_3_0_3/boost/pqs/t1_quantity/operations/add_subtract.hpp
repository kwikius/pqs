#ifndef BOOST_PQS_T1_QUANTITY_ADD_SUBTRACT_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_ADD_SUBTRACT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    addition and subtraction of t1-quantities
*/

#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/t1_quantity/operations/t1_quantity_bin_op_macros.hpp>
#include <boost/pqs/t1_quantity/operations/add_subtract_macros.hpp>

namespace boost {namespace pqs{ 
    namespace meta{
    // binary_operation defs for t1_quantity add /subtract
        BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_BIN_OP(plus)
        BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_BIN_OP(minus) 
    }//meta
    // function definitions for t1_quantity add /subtract
   BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_ADDSUB_DEFINE(plus,+)
   BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_ADDSUB_DEFINE(minus,-)
     
}}//boost::pqs

#endif

