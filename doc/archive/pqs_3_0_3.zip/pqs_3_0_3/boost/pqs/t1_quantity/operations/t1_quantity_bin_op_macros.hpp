#ifndef BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/mpl/arithmetic.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
// declare Macro in boost::pqs::meta namespace 

#define BOOST_PQS_T1_QUANTITY_OP_T1_QUANTITY_BIN_OP(Operator)\
    template <\
        typename AbstractQuantityL BOOST_PP_COMMA()\
        typename UnitsL BOOST_PP_COMMA()\
        typename Value_typeL BOOST_PP_COMMA()\
        typename AbstractQuantityR BOOST_PP_COMMA()\
        typename UnitsR BOOST_PP_COMMA()\
        typename Value_typeR\
    > struct binary_operation<\
        t1_quantity<\
            AbstractQuantityL BOOST_PP_COMMA()\
            UnitsL BOOST_PP_COMMA()\
            Value_typeL\
        > BOOST_PP_COMMA()\
        Operator BOOST_PP_COMMA()\
        t1_quantity<\
            AbstractQuantityR BOOST_PP_COMMA()\
            UnitsR BOOST_PP_COMMA()\
            Value_typeR\
        >\
    >{\
        typedef typename binary_operation <\
            AbstractQuantityL BOOST_PP_COMMA()\
            Operator BOOST_PP_COMMA()\
            AbstractQuantityR\
        >::type abstract_quantity;\
        typedef typename binary_operation <\
            UnitsL BOOST_PP_COMMA()\
            Operator BOOST_PP_COMMA()\
            UnitsR \
        >::type units;\
        typedef typename binary_operation<\
            Value_typeL BOOST_PP_COMMA()\
             Operator\
             BOOST_PP_COMMA() Value_typeR\
        >::type value_type;\
        typedef typename t1_quantity<\
            abstract_quantity BOOST_PP_COMMA()\
            units BOOST_PP_COMMA()\
            value_type\
        >::type type;\
    };

#endif
    