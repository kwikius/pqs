#ifndef BOOST_PQS_MAGNETIC_FLUX_HPP_INCLUDED
#define BOOST_PQS_MAGNETIC_FLUX_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_magnetic_flux.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct magnetic_flux_ : meta::components::of_magnetic_flux{
        typedef t1_quantity<
            type,
            typename meta::si_unit::yocto, // coherent-exponent -24
            Value_type
        > yWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > zWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > aWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > fWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > pWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > nWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > uWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > mWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > cWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > dWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > Wb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > daWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > hWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > kWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > MWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > GWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > TWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > PWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > EWb;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZWb;

    };

    struct magnetic_flux : magnetic_flux_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
