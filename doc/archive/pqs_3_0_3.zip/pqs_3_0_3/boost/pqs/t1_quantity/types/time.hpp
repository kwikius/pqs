#ifndef BOOST_PQS_TIME_HPP_INCLUDED
#define BOOST_PQS_TIME_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_time.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct time_ : meta::components::of_time{
        typedef t1_quantity<
            type,
            typename meta::si_unit::yocto, // coherent-exponent -24
            Value_type
        > ys;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > zs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > as;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > fs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > ps;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > ns;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > us;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > ms;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > cs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > ds;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > s;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > das;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > hs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > ks;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > Ms;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > Gs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > Ts;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > Ps;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > Es;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > Zs;

        typedef t1_quantity<
            type,
            typename incoherent_unit::d,
            Value_type
        > d;

        typedef t1_quantity<
            type,
            typename incoherent_unit::d_sid,
            Value_type
        > d_sid;

        typedef t1_quantity<
            type,
            typename incoherent_unit::h,
            Value_type
        > h;

        typedef t1_quantity<
            type,
            typename incoherent_unit::h_sid,
            Value_type
        > h_sid;

        typedef t1_quantity<
            type,
            typename incoherent_unit::min,
            Value_type
        > min;

        typedef t1_quantity<
            type,
            typename incoherent_unit::min_sid,
            Value_type
        > min_sid;

        typedef t1_quantity<
            type,
            typename incoherent_unit::s_sid,
            Value_type
        > s_sid;

        typedef t1_quantity<
            type,
            typename incoherent_unit::wk,
            Value_type
        > wk;

        typedef t1_quantity<
            type,
            typename incoherent_unit::yr,
            Value_type
        > yr;

        typedef t1_quantity<
            type,
            typename incoherent_unit::yr_sid,
            Value_type
        > yr_sid;

        typedef t1_quantity<
            type,
            typename incoherent_unit::yr_trop,
            Value_type
        > yr_trop;

    };

    struct time : time_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
