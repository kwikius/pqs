#ifndef BOOST_PQS_TYPEOF_REGISTER_HPP_INCLUDED
#define BOOST_PQS_TYPEOF_REGISTER_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    register internal types with Boost.Typeof
*/
//#include <boost/typeof/typeof.hpp>
//#include <boost/mpl/math/rational.hpp>
//#include <boost/mpl/integral_c.hpp>
//#include <boost/mpl/int.hpp>
//#include <boost/mpl/long.hpp>
//#include <boost/pqs/preboost/rational_int.hpp>
//#include <boost/pqs/preboost/rational_long.hpp>
//#include <boost/mpl/vector.hpp>
//#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP()
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::vector1,1);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::vector2,2);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::vector3,3);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::vector4,4);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::vector5,5);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::vector6,6);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::vector7,7);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::vector,BOOST_MPL_LIMIT_VECTOR_SIZE);
//BOOST_TYPEOF_REGISTER_TYPE(boost::mpl::na);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::math::rational, 2);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::math::simplified_rational, 2);
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::math::rational_c, (class) (int) (int) );
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::math::rational_int,  (int) (int) );
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::math::rational_long,  (long) (long) );
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::integral_c, (class) (int));
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::int_, (int) );
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::mpl::long_, (long) );

// BOOST_TYPEOF_REGISTER_TEMPLATE(boost::pqs::meta::quantity_unit, 3);

#endif

