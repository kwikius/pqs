/*
    boltzmanns constant definition required to link
*/
#include <boost/pqs/t1_quantity/constants/boltzmanns_constant.hpp>

template<>
boost::pqs::physics::boltzmanns_constant_<double>::type const&
boost::pqs::physics::boltzmanns_constant_<double>::K 
= boost::pqs::physics::boltzmanns_constant_<double>::type(1.380658);

template<>
boost::pqs::physics::boltzmanns_constant_<long double>::type const&
boost::pqs::physics::boltzmanns_constant_<long double>::K 
= boost::pqs::physics::boltzmanns_constant_<long double>::type(1.380658L);

template<>
boost::pqs::physics::boltzmanns_constant_<float>::type const&
boost::pqs::physics::boltzmanns_constant_<float>::K 
= boost::pqs::physics::boltzmanns_constant_<float>::type(1.380658f);


