#ifndef BOOST_PQS_OPERATIONS_VALUE_CAST_HPP_INCLUDED
#define BOOST_PQS_OPERATIONS_VALUE_CAST_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    compute result value in scaling two ct-quantities
*/
#include <boost/pqs/quantity_traits.hpp>
#include <boost/implicit_cast.hpp>
#include <boost/pqs/detail/united_value/operations/value_cast_traits.hpp>
#include <boost/pqs/detail/united_value/united_value_fwd.hpp>

namespace boost{namespace pqs {namespace detail{

    template <
        typename TargetUV,
        typename Source_unit,
        typename Source_value_type
    > 
    inline 
    typename TargetUV::value_type     
    united_value_cast(
        united_value<
            Source_unit,
            Source_value_type
        >const & source_uv
    )
    {   
        typedef value_cast_traits<
                typename TargetUV::value_type,
                typename TargetUV::units_type,
                Source_value_type,
                Source_unit
        > traits;
       // typename TargetUV::value_type result
        typename traits::result_type result
        = typename traits::eval()( source_uv.raw_value() ) ;
        typename TargetUV::value_type vv 
        = typename quantity_traits::value_type_converter<
            typename TargetUV::value_type,
            typename traits::result_type
        >()(result);
        return vv;
    }

}}}//boost::pqs::detail

#endif
