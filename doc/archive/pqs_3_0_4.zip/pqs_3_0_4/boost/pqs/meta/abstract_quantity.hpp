#ifndef BOOST_PQS_ABSTRACT_QUANTITY_HPP_INCLUDED
#define BOOST_PQS_ABSTRACT_QUANTITY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
  An abstract Quantity has dimension and a tag to distinguish it
   if the tag is  equal to the anonymous_quantity_id
  then it is regarded as an anonymous-abstract-quantity
   otherwise it is a named-abstract-quantity
*/

#include <boost/pqs/config.hpp>
#include <boost/pqs/meta/abstract_quantity_fwd.hpp>
#include <boost/pqs/meta/dimension.hpp>
#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/pqs/meta/pow.hpp>
#include <boost/mpl/if.hpp>

namespace boost{namespace pqs{ namespace meta{

    typedef boost::mpl::int_<0> default_abstract_quantity_id ;
    typedef boost::mpl::int_<0> anonymous_abstract_quantity_id ;

    template< 
        typename Dimension, 
        typename QuantityId
    >
    struct abstract_quantity{
        typedef Dimension               dimension;
        typedef QuantityId              id;
        typedef abstract_quantity       type;
    };

    template <
        typename DimensionL,
        typename QuantityIdL,
        typename DimensionR,
        typename QuantityIdR
    >
    struct dimensionally_equivalent<
        abstract_quantity<
            DimensionL,
            QuantityIdL
        >,
        abstract_quantity<
            DimensionR,
            QuantityIdR
        >
    > 
    : dimensionally_equivalent<
        DimensionL,
        DimensionR
    >{};

   
    
    template< 
        typename Dimension,
        typename QuantityId
    > struct is_dimensionless<
        abstract_quantity<
            Dimension,
            QuantityId
        >
    > : is_dimensionless<Dimension>{};

    namespace detail{
        
        // given two Quantity_ids get their anonymous id
        template <typename L_id, typename R_id>
        struct anonymous_id_from{
            //normalise
            typedef typename boost::mpl::plus<
                    L_id, R_id
            >::type dummy_id;
            // zeroise
            typedef typename boost::mpl::minus<
                    dummy_id,dummy_id
            >::type type;
        };

        // result for addition
        // if L and R are equal -->  L (==R)
        // if L is anon and R not anon --> R
        // if R is anon and L not anon --> L
        // otherwise must be neither L or R anon, but not same --> anon
        template <typename L_id, typename R_id>
        struct plus_minus_quantity_id{
            typedef typename anonymous_id_from<
                    L_id,R_id
            >::type  anonymous_id ;
            struct l_is_anonymous : boost::mpl::equal_to<
                L_id,anonymous_id
            >::type {};
            struct r_is_anonymous : boost::mpl::equal_to<
                R_id,anonymous_id
            >::type {} ;

            typedef typename boost::mpl::if_<
                boost::mpl::equal_to<
                    L_id,R_id
                >,
                L_id ,
                typename boost::mpl::if_<
                    r_is_anonymous,
                    L_id,
                    typename boost::mpl::if_<
                        l_is_anonymous,
                        R_id,
                        anonymous_id
                    >::type
                >::type
            >::type  type;
        };

        template <typename Lhs,typename Op, typename Rhs>
        struct transform_abstract_quantity_id2{
            typedef default_abstract_quantity_id type;
        };

        template <typename Lhs, typename Rhs>
        struct transform_abstract_quantity_id2<Lhs,plus,Rhs>
        {
            typedef typename plus_minus_quantity_id<Lhs,Rhs>::type type;
        };
        template <typename Lhs, typename Rhs>
        struct transform_abstract_quantity_id2<Lhs,minus,Rhs>
        {
            typedef typename plus_minus_quantity_id<Lhs,Rhs>::type type;
        };

        template <typename Op, typename Id>
        struct transform_abstract_quantity_id1{
            typedef boost::pqs::meta::default_abstract_quantity_id type;
        };
        
            
    }//detail
    template <
        typename DL, typename IDL,
        typename Op,
        typename DR, typename IDR
    >
    struct binary_operation<
        abstract_quantity<
            DL, IDL
        >,
        Op,
        abstract_quantity<
            DR, IDR
        >
    > : abstract_quantity<
           typename binary_operation<DL,Op,DR>::type,
           typename detail::transform_abstract_quantity_id2<IDL,Op,IDR>::type
    >{};

    template <typename D, typename ID, typename Op>
    struct unary_operation<
        Op,
        abstract_quantity<D,ID>
    >{
        typedef abstract_quantity<
           typename unary_operation<Op,D>::type,
           typename detail::transform_abstract_quantity_id1<Op,ID>::type
        > type;
    };

    template <
        typename D, typename ID,
        typename Exp
    >
    struct binary_operation<
        abstract_quantity<
            D, ID
        >,
        pow,
        Exp,
        typename boost::enable_if<
            not_0_or_1<Exp>
        >::type
    > : abstract_quantity<
            typename binary_operation<D,pow,Exp>::type,
            default_abstract_quantity_id
    >{};
    
}}}//boost::pqs::meta

#endif
