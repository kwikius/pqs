#ifndef BOOST_PQS_META_BINARY_OPERATION_HPP_INCLUDED1
#define BOOST_PQS_META_BINARY_OPERATION_HPP_INCLUDED1
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
    binary_operation struct has one member 'type'
    which represents the type of the result of a binary operation.
    such as +, -, *, << ,!= ,== etc.
    The Op  parameter 'token'
    is represented by  Op tokens provided in
    "boost/pqs/meta/binary_operator_extra_keys.hpp")
    e.g for the result type of addition of 2 ints
    the typedef would look like
    binary_operation<int,plus,int>::type.

    modified to use enable_if 23/08/04
    default version has boost::mpl::void_
    as member. specialisation for arithmetic types
    assign, boolean ret types

    modified for boost version to use own keys instead of keys in functional
*/

#include <boost/pqs/meta/is_value_type.hpp>
#include <boost/pqs/quantity_traits.hpp>
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
#include <boost/typeof/typeof.hpp>
#else
#include <boost/pqs/meta/arithmetic_promote.hpp>
#endif

#include <boost/pqs/meta/binary_operator_traits.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/not.hpp>
#include <boost/mpl/or.hpp>
#include <boost/mpl/comparison.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/pqs/meta/rational_fwd.hpp>

namespace boost{namespace pqs{ namespace meta{
    
    template <
       typename A,
       typename Op,
       typename B,
       typename Enable = void
    >
    struct binary_operation{
        typedef boost::mpl::void_ type;
    };

    template <
       typename A,
       typename B
    >
    struct binary_operation<
        A , plus, B , 
        typename boost::enable_if<
            are_value_type2<A,B>
        >::type
    > {
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
      typedef BOOST_TYPEOF_TPL( A() + B() ) type;
#else
    typedef typename arithmetic_promote<A,B>::type type;
#endif
    };
    template <
       typename A,
       typename B
    >
    struct binary_operation<
        A , minus, B , 
        typename boost::enable_if<
            are_value_type2<A,B>
        >::type
    > {
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
        typedef BOOST_TYPEOF_TPL( A() - B() ) type;
#else
        typedef typename arithmetic_promote<A,B>::type type;
#endif

    };

    template <
       typename A,
       typename B
    >
    struct binary_operation<
        A , times, B , 
        typename boost::enable_if<
            are_value_type2<A,B>
        >::type
    > {
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
        typedef BOOST_TYPEOF_TPL( A() * B() ) type;
#else
        typedef typename arithmetic_promote<A,B>::type type;
#endif
    };

    template <
       typename A,
       typename B
    >
    struct binary_operation<
        A , divides, B , 
        typename boost::enable_if<
            are_value_type2<A,B>
        >::type
    > {
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION

    typedef BOOST_TYPEOF_TPL( A() / B(1) ) type;
#else
        typedef typename arithmetic_promote<A,B>::type type;
#endif
    };

    template <
       typename A,
       typename B
    >
    struct binary_operation<
        A , pow, B , 
        typename boost::enable_if<
            boost::mpl::and_<
                is_value_type<A>,
                boost::mpl::and_<
                    boost::mpl::not_equal_to<
                        B,
                        rational<1>
                    >,
                    boost::mpl::not_equal_to<
                        B,
                        rational<0>
                    >
                >
            >
        >::type
    > {
      typedef typename quantity_traits::default_value_type type;
    };
   
}}}//boost::pqs::meta

#endif
