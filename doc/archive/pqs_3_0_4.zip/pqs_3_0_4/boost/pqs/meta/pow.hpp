#ifndef BOOST_PQS_POW_IDENTITIES_HPP_INCLUDED
#define BOOST_PQS_POW_IDENTITIES_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
    independent of type
    a value to power 0 == 1
    a value to power 1 == t
    provide these specialisations
*/

#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/pqs/meta/rational_fwd.hpp>
#include <boost/mpl/not.hpp>
#include <boost/mpl/or.hpp>

namespace boost{namespace pqs{namespace meta{

// returns 1;
    template<typename T, typename PowType>
    struct binary_operation<
        T,
        pow,
        PowType,
        typename boost::enable_if<
            boost::is_same<
                PowType,
                rational<0>
            >
        >::type
    >{
        typedef int result_type;
    };


 //return T
    template<typename T, typename PowType>
    struct binary_operation<
        T,
        pow,
        PowType,
        typename boost::enable_if<
            boost::is_same<
                PowType,
                rational<1>
            >
        >::type
    >{
        typedef T result_type;
    };

    template <typename Rational>
    struct not_0_or_1 
    : boost::mpl::not_<
            boost::mpl::or_<
                boost::is_same<
                    Rational,
                    rational<0>
                >,
                boost::is_same<
                    Rational,
                    rational<1>
                >
            >
      >{};
        
}}}///boost::pqs::meta


#endif
