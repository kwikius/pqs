#ifndef BOOST_PQS_QUANTITY_UNIT_HPP_INCLUDED
#define BOOST_PQS_QUANTITY_UNIT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/pqs/config.hpp>
#include <boost/pqs/meta/quantity_unit_fwd.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/or.hpp>
#include <boost/mpl/less.hpp>
#include <boost/pqs/meta/pow.hpp>
#include <boost/pqs/meta/transform_coherent.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/pqs/meta/rational.hpp>
//#include <boost/static_assert.hpp>

namespace boost{namespace pqs{namespace meta{

    template <
        typename Exponent, //pqs::meta::rational
        typename Multiplier, //pqs::meta::rational
        typename Id // boost::mpl::int_
    >
    struct quantity_unit{
        typedef Exponent        exponent;
        typedef Multiplier      multiplier;
        typedef Id              id;
        typedef quantity_unit   type;
   //     BOOST_STATIC_ASSERT((is_rational<exponent>::value));
    //    BOOST_STATIC_ASSERT((is_rational<multiplier>::value));
    };

    template <
        typename Exponent,
        typename Multiplier,
        typename Id
    >
    struct transform_coherent<
        quantity_unit<
            Exponent,
            Multiplier,
            Id
        >
    > 
    : quantity_unit<
        Exponent,
        typename default_quantity_unit_multiplier::type,
        typename default_quantity_unit_id::type
    > {};

    namespace detail{
        
        template <typename QuantityUnit>
        struct is_coherent_quantity_unit 
        :   boost::mpl::and_<
                boost::is_same<
                    typename QuantityUnit::multiplier,
                    typename default_quantity_unit_multiplier::type
                >,
                boost::is_same<
                    typename QuantityUnit::id,
                    typename default_quantity_unit_id::type
                >
        >{};

        template <
            typename Lhs,  //quantity_unit
            typename Rhs
        >
        struct finest_grained_quantity_unit 
        : boost::mpl::if_<
            boost::mpl::less<
                typename Lhs::exponent,
                typename Rhs::exponent
            >,
            Lhs,
            Rhs
        >{};
        // impl for binary_operation plus/minus
        template <typename Lhs , typename Rhs>
        struct plus_minus_quantity_unit{
           
            typedef typename finest_grained_quantity_unit< 
                    Lhs, Rhs
            >::type finest_grained_type;

            typedef typename transform_coherent<
                finest_grained_type
            >::type  coherent_type;

            typedef typename boost::mpl::eval_if<
            // if one or both coherent use coherent type as result
                boost::mpl::or_<
                    is_coherent_quantity_unit<Lhs>,
                    is_coherent_quantity_unit<Rhs>
                >,
                coherent_type,
                //if here both incoherent
                typename boost::mpl::if_<  
                    // if exponent and multiplier are same
                    // select Lhs 
                    // otherwise finest grained
                        boost::mpl::and_<   
                            boost::is_same<
                                typename Lhs::exponent,
                                typename Rhs::exponent
                            >,
                            boost::is_same<
                                typename Lhs::multiplier,
                                typename Rhs::multiplier
                            >
                        >,
                        Lhs, 
                        finest_grained_type
                >::type       
            >::type type;
        };
    
        template< 
            typename QuantityUnit,
            typename PowType
        >
        struct pow_quantity_unit{ 
            typedef  quantity_unit<
                typename binary_operation<
                    typename QuantityUnit::exponent,
                    times,
                    PowType
                >::type,
                typename default_quantity_unit_multiplier::type,
                typename default_quantity_unit_id::type
            > type;
        };
        
    }//detail

//+
        template<
            typename LhsExponent,
            typename LhsMultiplier, 
            typename LhsId,
            typename RhsExponent,
            typename RhsMultiplier, 
            typename RhsId
        >
        struct  binary_operation<
            quantity_unit<
                 LhsExponent,
                 LhsMultiplier, 
                 LhsId
            >,
            plus,
            quantity_unit<
                 RhsExponent,
                 RhsMultiplier, 
                 RhsId
            >
        > 
        : detail::plus_minus_quantity_unit<
            quantity_unit<
                    LhsExponent,
                    LhsMultiplier, 
                    LhsId
            >,
            quantity_unit<
                RhsExponent,
                RhsMultiplier, 
                RhsId
            >
        >{};
//-
        template<
            typename LhsExponent,
            typename LhsMultiplier, 
            typename LhsId,
            typename RhsExponent,
            typename RhsMultiplier, 
            typename RhsId
        >
        struct binary_operation<
            quantity_unit<
                 LhsExponent,
                 LhsMultiplier, 
                 LhsId
            >,
            minus,
            quantity_unit<
                 RhsExponent,
                 RhsMultiplier, 
                 RhsId
            >
        > : detail::plus_minus_quantity_unit<
            quantity_unit<
                    LhsExponent,
                    LhsMultiplier, 
                    LhsId
            >,
            quantity_unit<
                RhsExponent,
                RhsMultiplier, 
                RhsId
            >
        >{};
//*
        template<
            typename LhsExponent,
            typename LhsMultiplier, 
            typename LhsId,
            typename RhsExponent,
            typename RhsMultiplier, 
            typename RhsId
        >
        struct binary_operation<
            quantity_unit<
                 LhsExponent,
                 LhsMultiplier, 
                 LhsId
            >,
            times,
            quantity_unit<
                 RhsExponent,
                 RhsMultiplier, 
                 RhsId
            >
        >{ 
        // in multiplication
        // add exponents
        // transform multiplier and id to default

            typedef quantity_unit<
                typename binary_operation<
                    LhsExponent,
                    plus,
                    RhsExponent
                >::type,
                typename default_quantity_unit_multiplier::type,
                typename default_quantity_unit_id::type
            >  type;
        };
// /
       
        template<
            typename LhsExponent,
            typename LhsMultiplier, 
            typename LhsId,
            typename RhsExponent,
            typename RhsMultiplier, 
            typename RhsId
        >
        struct binary_operation<
            quantity_unit<
                 LhsExponent,
                 LhsMultiplier, 
                 LhsId
            >,
            divides,
            quantity_unit<
                 RhsExponent,
                 RhsMultiplier, 
                 RhsId
            >
        >{ 
        // in division
        // subtract exponents
        // transform multiplier and id to default
        // type is always a coherent quantity
            typedef  quantity_unit<
                typename binary_operation<
                    LhsExponent,
                    minus,
                    RhsExponent
                >::type,
                typename default_quantity_unit_multiplier::type,
                typename default_quantity_unit_id::type
            > type;
        };
//^
        template<
            typename Exponent,
            typename Multiplier, 
            typename Id,
            typename PowType
        >
        struct binary_operation<
            boost::pqs::meta::quantity_unit<
                 Exponent,
                 Multiplier, 
                 Id
            >,
            pow,
            PowType,
            typename boost::enable_if<
                not_0_or_1<PowType>
            >::type
        > : detail::pow_quantity_unit<
            quantity_unit<
                 Exponent,
                 Multiplier, 
                 Id
            >,
            PowType
        >{};
// 1/
        template<
            typename Exponent,
            typename Multiplier, 
            typename Id
        >
        struct unary_operation<
            reciprocal,
            quantity_unit<
                 Exponent,
                 Multiplier, 
                 Id
            >
        >{ 
            typedef quantity_unit<
                typename unary_operation<
                    negate,
                    Exponent
                >::type,
                typename default_quantity_unit_multiplier::type,
                typename default_quantity_unit_id::type
            > type;
        };
           
}}}//boost::pqs::meta

#endif
