#ifndef BOOST_PQS_META_UNARY_OPERATORS_HPP_INCLUDED
#define BOOST_PQS_META_UNARY_OPERATORS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

namespace boost{namespace pqs{ namespace meta{

    struct reciprocal;
    struct negate;

}}}//boost::pqs::meta

#endif
