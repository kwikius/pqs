#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_BOLTZMANNS_CONSTANT_HPP_INCLUDED
#define PQS_BOLTZMANNS_CONSTANT_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    declaration of boltzmanns constant.
    definition in "pqs/physics/lib_src/boltzmanns_constant.cpp"
    required to link
*/

#include <boost/pqs/t1_quantity/operations.hpp>

namespace boost{namespace pqs{ namespace physics{

    template<typename Value_type=double>
    struct boltzmanns_constant_{
       typedef  t1_quantity< // boltzmanns constant
            meta::abstract_quantity<
                meta::dimension<
                    meta::rational<2>,
                    meta::rational<-2>,
                    meta::rational<1>,
                    meta::rational<-1>,
                    meta::rational<0>,
                    meta::rational<0>,
                    meta::rational<0>
                >,
                boost::mpl::int_<0>
            >,
            meta::quantity_unit<
                meta::rational<-23>
            >,
            Value_type
        > type;
        static type const & K;
    };
    struct boltzmanns_constant 
    : boltzmanns_constant_<boost::pqs::quantity_traits::default_value_type>{};

}}}//boost::pqs::physics

#endif
