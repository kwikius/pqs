#ifndef BOOST_PQS_T1_QUANTITY_SCALAR_MUL_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_SCALAR_MUL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    multiply ct-quantity by numeric
*/
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
#include <boost/pqs/meta/is_t1_quantity_value_type.hpp>
#include <boost/mpl/and.hpp>

namespace boost{namespace pqs{namespace meta{

    //pq * value_type
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename ArithmeticType
    >
    struct binary_operation<
        boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        times,
        ArithmeticType,
        typename boost::enable_if<
            boost::mpl::and_<
                is_t1_quantity_value_type<ArithmeticType>,
                is_valid_binary_operation<
                    Value_type,
                    times,
                    ArithmeticType
                >
            >
        >::type
    >{
        typedef typename boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            typename binary_operation<
                Value_type,
                times,
                ArithmeticType
            >::type
        > type;
     };

    //value_type * pq
    template<
            typename ArithmeticType,
            typename NamedAbstractQuantity,
            typename QuantityUnit,
            typename Value_type
    >
    struct binary_operation<
        ArithmeticType,
        times,
        boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        typename boost::enable_if<
            boost::mpl::and_<
                is_t1_quantity_value_type<ArithmeticType>,
                is_valid_binary_operation<
                    ArithmeticType,
                    times,
                    Value_type
                >
            >
        >::type
    >{
        typedef typename boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            typename binary_operation<
                ArithmeticType,
                times,
                Value_type
            >::type
        > type;
     };            

}}}//boost::pqs::meta

#if !(defined _MSC_VER && _MSC_VER ==1400)
namespace boost{namespace pqs{
#endif
    // PQ * scalar generic
    template<
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type,
        typename ArithmeticType
    >
    inline 
    typename boost::pqs::meta::binary_operation_if<
        boost::pqs::meta::is_t1_quantity_value_type<ArithmeticType>,
        boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >,
        boost::pqs::meta::times,
        ArithmeticType
    >::type   
    operator *( 
        boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & pq,
        ArithmeticType const& v)
    {
       typename boost::pqs::meta::binary_operation<
            boost::pqs::t1_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >,
            boost::pqs::meta::times,
            ArithmeticType
        >::type result( pq.numeric_value() * v );
        return result;
    }

    //scalar * PQ 
    template<
        typename ArithmeticType,
        typename NamedAbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    typename boost::pqs::meta::binary_operation_if< 
        boost::pqs::meta::is_t1_quantity_value_type<ArithmeticType>,
        ArithmeticType,
        boost::pqs::meta::times,
        boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >
    >::type   
    operator * ( 
        ArithmeticType const & v,
        boost::pqs::t1_quantity<
            NamedAbstractQuantity,
            QuantityUnit,
            Value_type
        >const & pq
    )
    {
        typename boost::pqs::meta::binary_operation<
            ArithmeticType,
            boost::pqs::meta::times,
            boost::pqs::t1_quantity<
                NamedAbstractQuantity,
                QuantityUnit,
                Value_type
            >
        >::type result( v * pq.numeric_value());
        return result;
    }

#if !(defined _MSC_VER && _MSC_VER ==1400)
}} //boost::pqs
#endif

#endif
