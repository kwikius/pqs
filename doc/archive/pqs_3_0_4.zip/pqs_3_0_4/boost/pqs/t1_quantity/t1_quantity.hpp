#ifndef BOOST_PQS_T1_QUANTITY_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/detail/united_value/united_value.hpp>
#include <boost/pqs/t1_quantity/t1_quantity_fwd.hpp>
#include <boost/pqs/t1_quantity/io/units_out.hpp>
#include <boost/mpl/if.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/pqs/meta/is_value_type.hpp>
//#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP() 
//
//BOOST_TYPEOF_REGISTER_TEMPLATE(boost::pqs::t1_quantity, 3);

namespace boost{namespace pqs{
   
    template<
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    class t1_quantity 
    {
        template <
            typename A1, 
            typename U1, 
            typename V1
        >
        friend class t1_quantity;

        typedef detail::united_value<
            Units, 
            Value_type
        > united_value;
        united_value m_united_value;
        
     public:
        typedef AbstractQuantity abstract_quantity;
        typedef Units units_type;
        typedef Value_type value_type;
       
        // A dimensionless type is replaced by
        // its value_type;
        typedef typename boost::mpl::if_<
            boost::pqs::meta::is_dimensionless<
                abstract_quantity
            >,
            value_type,
            t1_quantity
        >::type type;

// default ctor
        t1_quantity(){}
// value initialisation ctor
        template<typename Value_type1>
        explicit t1_quantity(
            Value_type1 const& value_in,
             typename boost::enable_if< 
                boost::is_convertible<
                    Value_type1,
                    Value_type
                >,
                void*
            >::type = 0
        )
        : m_united_value(
            boost::implicit_cast<Value_type>(value_in)      
        ){}

// converting copy ctor
        template< 
            typename AbstractQuantity1,
            typename Units1,
            typename Value_type1
        >
        t1_quantity( 
            t1_quantity<
                AbstractQuantity1,
                Units1,
                Value_type1
            > const & in,
            typename boost::enable_if< 
                boost::pqs::meta::dimensionally_equivalent<
                    AbstractQuantity,
                    AbstractQuantity1
                >,
                void*
            >::type = 0
        ) : m_united_value(in.m_united_value){}

		t1_quantity(t1_quantity const & in)
		: m_united_value(in.m_united_value){}

		t1_quantity &
		operator =(t1_quantity const & in)
		{
			this->m_united_value = in.m_united_value;
			return *this;
		}

// assign
		
        template< 
            typename AbstractQuantity1,
            typename Units1,
            typename Value_type1
        >
        typename boost::enable_if<
           boost::pqs::meta::dimensionally_equivalent<
                    AbstractQuantity,
                    AbstractQuantity1
           >,
           t1_quantity&  
        >::type
        operator = (
            t1_quantity<
                AbstractQuantity1,
                Units1,
                Value_type1
            > const  & in
        )
        {
            this->m_united_value = in.m_united_value;
            return *this;
        }
// +=
        template< 
            typename AbstractQuantity1,
            typename Units1,
            typename Value_type1
        >
        typename boost::enable_if<
           boost::pqs::meta::dimensionally_equivalent<
                    AbstractQuantity,
                    AbstractQuantity1
           >,
           t1_quantity&  
        >::type
        operator += (
            t1_quantity<
                AbstractQuantity1,
                Units1,
                Value_type1
            > const  & in
        )
        {
            this->m_united_value += in.m_united_value;
            return *this;
        }
//-=
        template< 
            typename AbstractQuantity1,
            typename Units1,
            typename Value_type1
        >
        typename boost::enable_if<
           boost::pqs::meta::dimensionally_equivalent<
                    AbstractQuantity,
                    AbstractQuantity1
           >,
           t1_quantity&  
        >::type
        operator -= (
            t1_quantity<
                AbstractQuantity1,
                Units1,
                Value_type1
            > const  & in
        )
        {
            this->m_united_value -= in.m_united_value;
            return *this;
        }
//*=
        template <typename Value_type1>
        typename boost::enable_if<
            boost::pqs::meta::is_value_type<
                Value_type1
            >,
            t1_quantity&
        >::type
        operator *= (Value_type1 const & in)
        {
             this->m_united_value *= in;
             return *this;
        }
///=
        template <typename Value_type1>
        typename boost::enable_if<
            boost::pqs::meta::is_value_type<
                Value_type1
            >,
            t1_quantity&
        >::type
        operator /= (Value_type1 const & in)
        {
             this->m_united_value /= in;
             return *this;
        }
// unary +
        t1_quantity
        operator +()const
        {
           t1_quantity result( this->m_united_value.raw_value());
           return  result;
        }
//unary -
        t1_quantity
        operator -()const
        { 
            t1_quantity result( - this->m_united_value.raw_value());
            return  result;
        }

        bool operator!()const
        {
            bool result = this->m_united_value.raw_value() == 0;
            return result;
        }
//preinc
        t1_quantity& operator++()
        {
           ++ this->m_united_value.raw_value_ref();
            return *this;
        }
//postinc
        t1_quantity operator++(int)
        {
            t1_quantity t(*this);
            ++ this->m_united_value.raw_value_ref();
            return t;
        }
//predec
        t1_quantity& operator--()
        {
            --this->m_united_value.raw_value_ref();
            return *this;
        }
//postdec
        t1_quantity  operator--(int)
        {
            t1_quantity t(*this);
            --this->m_united_value.raw_value_ref();
            return t;
        } 
        Value_type numeric_value()const{
            Value_type result = this->m_united_value.raw_value();
            return result;
        }
        detail::united_value<
            Units,
            Value_type
        > 
        get_united_value()const
        {
             return this->m_united_value;  
        }

        static
        t1_quantity_basic_units_out<
            AbstractQuantity,
            Units
        >  
        units()
        {
            return t1_quantity_basic_units_out<
                AbstractQuantity,
                Units
            >();
        }                
    }; // t1_quantity

}}// boost::pqs


#endif
