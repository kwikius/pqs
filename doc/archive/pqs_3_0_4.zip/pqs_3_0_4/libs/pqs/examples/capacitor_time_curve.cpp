//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    capacitor discharge curve using compile_time
    and run time physical_quantities
*/

#include <boost/pqs/t1_quantity/types/capacitance.hpp>
#include <boost/pqs/t1_quantity/types/out/voltage.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>

int main()
{
    using boost::pqs::capacitance;
    using boost::pqs::voltage;
    using boost::pqs::resistance;
    using boost::pqs::time_; // for non default time with int value_type

    std::cout.setf(std::ios_base::fixed,std::ios_base::floatfield);
    std::cout.precision(3);
    capacitance::uF   const C(0.47);     //capacitor
    voltage::V        const V0(5);  //starting voltage across capacitor
    resistance::kR    const R(4.7);   // resistance between terminals
    
    // one possible useage of integer value_type
    for ( time_<int>::ms t ; t <= time_<int>::ms(50); ++t  ){
        voltage::V  Vt = V0 * std::exp(-t / (R * C)); 
        
        std::cout << "at " << t << " voltage is " ;
        //format
        if     (Vt >= voltage::V(1.0))    std::cout << Vt ;
        else if(Vt >= voltage::mV(1))     std::cout << voltage::mV(Vt);
        else if(Vt >= voltage::uV(1))     std::cout << voltage::uV(Vt);
        else if(Vt >= voltage::nV(1))     std::cout << voltage::nV(Vt);
        else                              std::cout << voltage::pV(Vt);
        std::cout << "\n";

    } 
}
