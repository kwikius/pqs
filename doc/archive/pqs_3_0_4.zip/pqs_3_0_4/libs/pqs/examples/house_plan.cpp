
#include <boost/pqs/t1_quantity/types/length.hpp>
#include <boost/pqs/t1_quantity/types/out/area.hpp>

struct room{
    boost::pqs::length::m length;
    boost::pqs::length::m width;
    room(boost::pqs::length::m const & l, boost::pqs::length::m const & w)
    : length(l) , width(w){}
    boost::pqs::area::m2 area() { return length * width;}
};

// area of house

int main()
{
    typedef  boost::pqs::length::m width;
    typedef  boost::pqs::length::m length;
   
    room kitchen(length(6),width(3) );
    room lounge(length(5), width(3.6));
    room bedroom1(length(3.6), width(3));
    room bedroom2(length(3.6), width(2.7));
    room bedroom3(length(2.1), width(3.6) );

    boost::pqs::area::m2 a 
    = kitchen.area()
    + lounge.area()
    + bedroom1.area()
    + bedroom2.area()
    + bedroom3.area();

    std::cout << "floor area = "<< a <<'\n';
}