#ifndef BOOST_PQS_TEST_HPP_INCLUDED
#define  BOOST_PQS_TEST_HPP_INCLUDED

//#define BOOST_PQS_MINIMAL_TEST

#ifdef BOOST_PQS_MINIMAL_TEST
#include <libs/pqs/test/simple.hpp>
#else
#include <boost/test/test_tools.hpp>
#include <boost/test/floating_point_comparison.hpp>
#endif

#include <boost/pqs/meta/quantity_unit.hpp>
#include <boost/pqs/meta/si_units.hpp>
#include <boost/pqs/meta/rational.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/equal_to.hpp>

#define CHECK_RAT(Rational, n, d) \
    BOOST_CHECK( static_cast<int>(Rational ::numerator) == n );\
    BOOST_CHECK( static_cast<int>(Rational ::denominator) == d );

#define CHECK_INT(Integral,T, v)\
    BOOST_CHECK(  (Integral ::type::value) == v);\
    BOOST_CHECK( (boost::is_same< Integral  ::value_type, T >::value) );

#define CHECK_QUANTITY_UNIT(Name,E,M,I) \
  BOOST_CHECK( (boost::mpl::equal_to< \
        Name  ::exponent BOOST_PP_COMMA()\
        boost::pqs::meta::rational< E > \
    >::type::value));\
    BOOST_CHECK( (boost::mpl::equal_to< \
        Name  ::multiplier BOOST_PP_COMMA() \
        boost::pqs::meta::rational< M > \
    >::type::value));\
    BOOST_CHECK( (boost::mpl::equal_to<\
        Name  ::id BOOST_PP_COMMA() \
       boost::mpl::int_< I >\
    >::type::value)); 

#define CHECK_SI_QUANTITY_UNIT( Prefix , E ) \
 CHECK_QUANTITY_UNIT( Prefix, E , 1, 0)


#endif
