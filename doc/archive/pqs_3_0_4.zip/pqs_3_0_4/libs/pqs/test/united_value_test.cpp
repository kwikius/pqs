// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.
#include <libs/pqs/test/test.hpp>
#include <boost/pqs/config.hpp>
#include <boost/pqs/detail/united_value/united_value.hpp>
#include <boost/pqs/detail/united_value/operations/dimensioned_multiply.hpp>
#include <boost/pqs/detail/united_value/operations/dimensionless_multiply.hpp>
#include <boost/pqs/detail/united_value/operations/dimensioned_divide.hpp>
#include <boost/pqs/detail/united_value/operations/dimensionless_divide.hpp>
//#include <boost/pqs/typeof_register.hpp>

void uv_dimensioned_multiply_test();
void uv_dimensioned_divide_test();
void uv_dimensionless_multiply_test();
void uv_dimensionless_divide_test();
void uv_addition_test();
void uv_subtraction_test();
void uv_initialise_test();
void uv_assign_test();

void united_value_test() ///////////////
{
    uv_dimensioned_multiply_test();
    uv_dimensioned_divide_test();
    uv_dimensionless_multiply_test();
    uv_dimensionless_divide_test();
    uv_addition_test();
    uv_subtraction_test();
    uv_initialise_test();
    uv_assign_test();
};

namespace{
    typedef  boost::pqs::meta::quantity_unit<
        boost::pqs::meta::rational<3>
    > coh_unit3;
    using boost::pqs::detail::united_value;
    typedef  boost::pqs::meta::quantity_unit<
        boost::pqs::meta::rational<0>
    > coh_unit0;
    typedef  boost::pqs::meta::quantity_unit<
        boost::pqs::meta::rational<-3>
    > coh_unitn3;

    typedef  boost::pqs::meta::quantity_unit<
        boost::pqs::meta::rational<3>
    > coh_unit3;
}

// simple si quantities
void uv_initialise_test()
{
    using boost::pqs::detail::united_value;
    united_value<coh_unit0,int> u0 = united_value<coh_unit3,int>(1);
    BOOST_CHECK_EQUAL(u0.raw_value(), 1000);
    
    united_value<coh_unit0,double> u1 = united_value<coh_unitn3,int>(1);
    BOOST_CHECK_CLOSE(u1.raw_value(), 1e-3, 1.e-15);
}
void uv_assign_test()
{
    using boost::pqs::detail::united_value;
    united_value<coh_unit0,int> u0(100);
    u0 = united_value<coh_unit3,int>(1);
    BOOST_CHECK_EQUAL(u0.raw_value(), 1000);
    
    united_value<coh_unit0,double> u1(0);
    u1 = united_value<coh_unitn3,int>(1);
    BOOST_CHECK_CLOSE(u1.raw_value(), 1e-3, 1.e-15);
}

void uv_dimensioned_multiply_test()
{
    BOOST_AUTO(result1,
        (dimensioned_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result1.raw_value() ,1., 1.e-12);

    BOOST_AUTO(result2,
        (dimensioned_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result2.raw_value(),1., 1.e-12);

    BOOST_AUTO(result2a,
        (dimensioned_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result2a.raw_value(),1., 1.e-12);

     BOOST_AUTO(result2b,
        (dimensioned_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result2b.raw_value(),1., 1.e-12);

}
void uv_dimensioned_divide_test()
{
    BOOST_AUTO(result11,
        (dimensioned_divide(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result11.raw_value(),1., 1.e-12);

    BOOST_AUTO(result12,(dimensioned_divide(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) )));
    BOOST_CHECK_CLOSE(result12.raw_value(),1., 1.e-12);

    BOOST_AUTO(result2a,
        (dimensioned_divide(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result2a.raw_value(),1., 1.e-12);

    BOOST_AUTO(result2b,
        (dimensioned_divide(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result2b.raw_value(),1., 1.e-12);
}
void uv_dimensionless_multiply_test()
{
    BOOST_AUTO(result7,
        (dimensionless_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result7 ,1000., 1.e-12);

    BOOST_AUTO(result8,
        (dimensionless_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result8,0.001, 1.e-12);

    BOOST_AUTO(result9,
        (dimensionless_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result9 ,1., 1.e-12);

    BOOST_AUTO(result10,
        (dimensionless_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) ))) ;
    BOOST_CHECK_CLOSE(result10,1., 1.e-12);
}

void uv_dimensionless_divide_test()
{
    BOOST_AUTO(result1,(dimensionless_divide(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) )));
    BOOST_CHECK_CLOSE(result1,.001, 1.e-12);
    
    BOOST_AUTO(result2,(dimensionless_divide(
            boost::pqs::detail::united_value<coh_unit0,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) )));
    BOOST_CHECK_CLOSE(result2,1000., 1.e-12);

    BOOST_AUTO(result3,(dimensionless_divide(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) )));
    BOOST_CHECK_CLOSE(result3,1e-6, 1.e-12);
    
    BOOST_AUTO(result4,(dimensionless_divide(
            boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) )));
    BOOST_CHECK_CLOSE(result4,1e6, 1.e-12);
}

void uv_addition_test()
{
    BOOST_AUTO(result3,(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        + boost::pqs::detail::united_value<coh_unit0,double>(1) )) ;
    BOOST_CHECK_CLOSE(result3.raw_value(),1001., 1.e-12);

    BOOST_AUTO(result4,(boost::pqs::detail::united_value<coh_unit3,double>(1)
        + boost::pqs::detail::united_value<coh_unit0,double>(1) )) ;
    BOOST_CHECK_CLOSE(result4.raw_value(),1001., 1.e-12);

}
void uv_subtraction_test()
{
    BOOST_AUTO(result5,(boost::pqs::detail::united_value<coh_unit3,double>(1)
        - boost::pqs::detail::united_value<coh_unit0,double>(1) )) ;
    BOOST_CHECK_CLOSE(result5.raw_value(),999., 1.e-12);

    BOOST_AUTO(result6,(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        - boost::pqs::detail::united_value<coh_unit0,double>(1) )) ;
    BOOST_CHECK_CLOSE(result6.raw_value(),-999., 1.e-12);
}
