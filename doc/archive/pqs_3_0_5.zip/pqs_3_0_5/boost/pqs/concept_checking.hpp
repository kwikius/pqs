#ifndef PQS_CONCEPTS_CONCEPT_CHECKING_HPP_INCLUDED
#define PQS_CONCEPTS_CONCEPT_CHECKING_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// After the boost version which is
//
// (C) Copyright Jeremy Siek 2000. Permission to copy, use, modify,
// sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.

// See http://www.boost.org/libs/concept_check

/*
    concept checking classes
*/
#include "boost/mpl/if.hpp"
#include "boost/type_traits/is_same.hpp"
#include "boost/type_traits/is_arithmetic.hpp"
#include <boost/concept_check.hpp>
#include "boost/type_traits/is_integral.hpp"
#include <boost/pqs/meta/to_arithmetic.hpp>
#include <boost/mpl/and.hpp>
#include <limits>

namespace boost{namespace pqs{ namespace concept_checking{

    template< bool Assertion>struct Assert;

    template<>struct Assert<true>{};

    template<typename ArithmeticType>
    struct AssertIsArithmetic 
    : Assert<boost::is_arithmetic<ArithmeticType>::value >{};

    template<typename ArithmeticTypeA, typename ArithmeticTypeB>
    struct AssertAreBothArithmetic 
    : Assert<
        (boost::is_arithmetic<ArithmeticTypeA>::value 
        && boost::is_arithmetic<ArithmeticTypeB>::value)  >{};

    template<typename IntegralType>
    struct AssertIsIntegral 
    : Assert<boost::is_integral<IntegralType>::value >{};

    template<typename IntegralTypeA, typename IntegralTypeB>
    struct AssertAreBothIntegral 
    : Assert<
        (boost::is_integral<IntegralTypeA>::value 
        && boost::is_integral<IntegralTypeB>::value)  >{};

    template<typename FundamentalType>
    struct AssertIsFundamentalType 
    : Assert<std::numeric_limits<FundamentalType>::is_specialized>{};

    template<typename FundamentalTypeA, typename FundamentalTypeB>
    struct AssertAreBothFundamentalTypes 
    : Assert< (std::numeric_limits<FundamentalTypeA>::is_specialized &&
        std::numeric_limits<FundamentalTypeB>::is_specialized) >{};

   
    // assert that the parameter can be converted to an arithmetic type via the 
    // pqs::meta::to_arithmetic metafunction
    template<typename ToArithmeticType>
    struct AssertToArithmetic 
    : Assert<
         boost::is_arithmetic< 
            typename boost::pqs::meta::
                to_arithmetic<ToArithmeticType>::type
        >::value 
    >{};
   
    template <
        typename AbstractQuantityA,
        typename AbstractQuantityB
    >
    struct DimensionallyEquivalentQuantityConcept{

        void constraints()  
        {  
            anonymous_abstract_quantityA = anonymous_abstract_quantityB;
        }

        typename AbstractQuantityA::anonymous_abstract_quantity_type anonymous_abstract_quantityA;
        typename AbstractQuantityB::anonymous_abstract_quantity_type anonymous_abstract_quantityB;

    }; 

    template <
        typename AbstractQuantity,
        typename OtherAbstractQuantity
    >
    struct CompatibleQuantityConcept{  
        
        
        void constraints()
        {    
            boost::function_requires<
                DimensionallyEquivalentQuantityConcept<
                    AbstractQuantity,
                    OtherAbstractQuantity
                >
            >(); 

            compatible_typeA = compatible_typeB;
           
        }
        // utility for types
        template <typename First, typename Second>
        struct Pair{
            typedef First first;
            typedef Second second;
        };

        typedef typename boost::mpl::if_c<
            ((AbstractQuantity::tag_type::value !=0 ) &&
                (OtherAbstractQuantity::tag_type::value ==0)),
            Pair<AbstractQuantity,AbstractQuantity>,
                typename boost::mpl::if_c<
                    ((AbstractQuantity::tag_type::value == 0 ) &&
                        (OtherAbstractQuantity::tag_type::value !=0)),
                    Pair<OtherAbstractQuantity,OtherAbstractQuantity>,
                    Pair<AbstractQuantity,OtherAbstractQuantity>
                >::type 
        >::type pair_type;
        typename pair_type::first    compatible_typeA;
        typename pair_type::second   compatible_typeB;
                
    };

    template <
        typename AbstractQuantity,
        typename OtherAbstractQuantity
    >
    struct CompatibleQuantityWarningConcept{

        void constraints()
        {
        //////check dimensionally equivalent
           boost::function_requires<
                DimensionallyEquivalentQuantityConcept<
                    AbstractQuantity,
                    OtherAbstractQuantity
                >
            >();
        ////////check dimensionally equivalent/////
        // also give warning on dimensionally-equivalent 
        // but different quantities being assigned
        // NOTE: warning can be removed by using anonymous_cast(q_XXX); 
            conversion_to = possibly_unsafe_from;
        }

       template <typename ConversionToWarningFlaggerAlias,
         typename ConversionFromWarningFlaggerAlias>
        struct ToFromPair{
            typedef ConversionToWarningFlaggerAlias to_type;
            typedef ConversionFromWarningFlaggerAlias from_type;
        };
    
        typedef typename boost::mpl::if_c<
            ((AbstractQuantity::tag_type::value !=0 ) &&
                (OtherAbstractQuantity::tag_type::value ==0)),
            ToFromPair<int,int>,
            typename boost::mpl::if_c<
                ((AbstractQuantity::tag_type::value == 0 ) &&
                    (OtherAbstractQuantity::tag_type::value !=0)),
                 ToFromPair<int,int>,
                 typename boost::mpl::if_c<
                    ((AbstractQuantity::tag_type::value == 
                    static_cast<int>(OtherAbstractQuantity::tag_type::value) ) ||
                    boost::is_same<
                        typename AbstractQuantity::anonymous_abstract_quantity_type ,
                        typename OtherAbstractQuantity::anonymous_abstract_quantity_type
                    >::value == 0),
                    ToFromPair<int,int>,
                    ToFromPair<int,long double>
                >::type
            >::type
        >::type conversion_type;
        typename conversion_type::to_type conversion_to; 
        typename conversion_type::from_type possibly_unsafe_from; 
       
    };

        
}}}//boost::pqs::concept_checking

//namespace pqs{
//
//    template<typename Target, typename Source>
//    struct ImplicitInitialisableConcept{
//
//        void constraints()
//        {
//            Target t = *ps;
//        }
//        Source* ps;
//    };
//
//    template<typename Target, typename Source>
//    struct ExplicitInitialisableConcept{
//
//        void constraints()
//        {
//            Target t(*ps);
//
//            concept_checking::ignore_unused_variable_warning(t);
//        }
//        Source * ps;
//    };
//
//    template<typename Target, typename Source>
//    struct AssignableConcept{
//
//        void constraints()
//        {
//            *pt = *ps;
//        }
//        Source* ps;
//        Target* pt;
//
//    };
//
//   /* template<typename Target>
//    struct ConstructibleConcept{
//
//        void constraints()
//        {
//            Source s = Source();
//            Target t = Target();
//            t = s;
//
//            concept_checking::ignore_unused_variable_warning(t);
//        }
//
//    };*/
//
//}

#endif
