#ifndef BOOST_PQS_CONFIG_HPP_INCLUDED
#define BOOST_PQS_CONFIG_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

#include <boost/cstdint.hpp>
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    Configuration options for boost::pqs
*/
#define PQS_COMPARISON_EPSILON 0.0

//#define BOOST_PQS_REAL_TYPE float
//#define BOOST_PQS_MAX_EXPONENT10 38
//#define BOOST_PQS_MIN_EXPONENT10 -38

#define BOOST_PQS_REAL_TYPE double
#define BOOST_PQS_MAX_EXPONENT10 64
#define BOOST_PQS_MIN_EXPONENT10 -64

// define to use boost.typeof for arithmetic results of ops
#define BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
// otherwise synthetic version used

// Typeofs's macro. use to test Boost.Typeof in compliant mode
#define BOOST_TYPEOF_COMPLIANT

// 32 bit int use in rational parameters
// needs to be a macro rather than a typedef 
// for use in template parameters
#if  (INT_MAX >= 0x7fffffff)
#define BOOST_PQS_INT32 int
#elif (LONG_MAX >= 0x7fffffff)
#define BOOST_PQS_INT32 long
#else
// long should be at least 32 bits so shouldlnt get here
#error need to define a 32-bit int in <boost/pqs/config.hpp>
#endif

 #define BOOST_PQS_SUPPRESS_VC8_ADL_BUG

#endif


