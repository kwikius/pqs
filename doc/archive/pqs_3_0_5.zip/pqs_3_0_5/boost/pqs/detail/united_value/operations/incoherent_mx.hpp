#ifndef BOOST_PQS_DETAIL_INCOHERENT_MX_HPP_INCLUDED
#define BOOST_PQS_DETAIL_INCOHERENT_MX_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/quantity_traits.hpp>
#include <boost/pqs/meta/min_type.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/or.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/utility/enable_if.hpp>
/*
    functor too return the runtime multiplier / divisor to apply
    when multiplying / dividing two quantities in a dimensionful way
    here L marked types are Lhs and R marked types are Rhs  from multiplier in unit
    of lhs and rhs quantities respectively.
    Value_type in is the minimal value_type wanted for the result_type, but 
    this may be promoted usually if an int is input and it must be promoted to a float
    to prevent conversion loss in the member result_type
    It may be possible to remove  Value_type input param
*/
namespace boost{namespace pqs{ namespace detail{
 
    template <
        typename Value_type,
        typename MxL,
        typename MxR,
        typename Enable = void
    >
    struct divide_incoherent_mx ;

/*
    if both multipliers are equal they cancel
*/
    template<
        typename Value_type,
        typename MxL,
        typename MxR
    >
    struct divide_incoherent_mx <
        Value_type,
        MxL, 
        MxR,
        typename boost::enable_if<
            boost::mpl::equal_to<MxL,MxR>
        >::type
    > : boost::pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required = false};
        typedef typename boost::pqs::meta::int_promote<
            Value_type
        >::type result_type;
       
        result_type operator()()const throw()
        {   
            return  1;
        } 
    };
/*
    if both numerators of muxes are equal then they cancel
*/
    template <
        typename Value_type,
        typename MxL,
        typename MxR
    >
    struct divide_incoherent_mx <
        Value_type,
        MxL,
        MxR,
        typename boost::enable_if_c<
            ((MxL::denominator == static_cast<BOOST_PQS_INT32>(MxR::denominator) )
            && (MxL::numerator != static_cast<BOOST_PQS_INT32>(MxR::numerator) ))
        >::type
    > : boost::pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required = true};
        typedef typename boost::pqs::quantity_traits::min_real<
            Value_type
        >::type result_type;
        result_type  operator()()const throw()
        {   
            result_type result
            = static_cast<result_type>(static_cast<BOOST_PQS_INT32>(MxL::numerator))
            / static_cast<BOOST_PQS_INT32>(MxR::numerator);
            return result;
        } 
    };

    template <
        typename Value_type,
        typename MxL,
        typename MxR
    >
    struct divide_incoherent_mx <
        Value_type,
        MxL,
        MxR,
        typename boost::enable_if_c<
            ((static_cast<BOOST_PQS_INT32>(MxL::denominator) != static_cast<BOOST_PQS_INT32>(MxR::denominator))
            && (static_cast<BOOST_PQS_INT32>(MxL::numerator) != static_cast<BOOST_PQS_INT32>(MxR::numerator) ))
        >::type
    > : boost::pqs::concept_checking::AssertIsArithmetic<Value_type>
    {
        enum{required = true};
        typedef typename boost::pqs::quantity_traits::min_real<
            Value_type
        >::type result_type;
        result_type  operator()()const throw()
        {   
            result_type result
            = (static_cast<result_type>(static_cast<BOOST_PQS_INT32>(MxL::numerator))
                / static_cast<BOOST_PQS_INT32>(MxL::denominator))
                    * (static_cast<result_type>( static_cast<BOOST_PQS_INT32>(MxR::denominator))
                        / static_cast<BOOST_PQS_INT32>(MxR::numerator));
            return result;
        } 
    };

// multiplier

     template<
        typename Value_type,
        typename MxL,
        typename MxR,
        typename Enable = void
     >
     struct multiply_incoherent_mx ;
  
     template<
        typename Value_type,
        typename MxL,
        typename MxR
     >
     struct multiply_incoherent_mx <
        Value_type,MxL,MxR,
        typename boost::enable_if<
            boost::mpl::and_<
                boost::mpl::equal_to<
                    MxL,
                    boost::pqs::meta::rational<1>
                >,
                boost::mpl::equal_to<
                   MxR,
                   boost::pqs::meta::rational<1>
                >
            >
        >::type
    >
     : boost::pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required =false};
        typedef typename boost::pqs::meta::int_promote<
                Value_type
        >::type  result_type;
  
        result_type  operator()() throw()
        {  
            return 1;
        } 
    };

    template<
        typename Value_type,
        typename MxL,
        typename MxR
     >
     struct multiply_incoherent_mx <
        Value_type,MxL,MxR,
        typename boost::enable_if<
            boost::mpl::or_<
                boost::mpl::not_equal_to<
                    MxL,
                    boost::pqs::meta::rational<1>
                >,
                boost::mpl::not_equal_to<
                    MxR,
                    boost::pqs::meta::rational<1>
                >
            >
        >::type
    > : boost::pqs::concept_checking::AssertIsArithmetic<Value_type> {
        enum{required =true};
        typedef typename boost::pqs::quantity_traits::min_real<
            Value_type
        >::type result_type;
  
        result_type  operator()() throw()
        {  
            result_type result 
             = (static_cast<result_type>( static_cast<BOOST_PQS_INT32>(MxL::numerator))
                    / static_cast<BOOST_PQS_INT32>(MxL::denominator))
                * (static_cast<result_type>(static_cast<BOOST_PQS_INT32>(MxR::numerator))
                    / static_cast<BOOST_PQS_INT32>(MxR::denominator))
            ;
            return result;
        } 
    };

}}}//boost::pqs::detail

#endif



