#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_BINARY_OPERATOR_EXTRA_KEYS_HPP_INCLUDED
#define GENERIC_BINARY_OPERATOR_EXTRA_KEYS_HPP_INCLUDED

//binary_operator_extra_keys.hpp
//  Copyright (C) Andy Little, White Light Device 2005.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    extra operator keys to supplemet std::plus etc
    for use with binary_operation 
*/

namespace boost{namespace pqs{namespace meta{

    struct plus;
    struct minus;
    struct times;
    struct divides;
    struct logical_or;
    struct logical_and;
    struct equal_to;
    struct not_equal_to;
    struct less_equal;
    struct equals;
    struct greater;
    struct greater_equal;
    struct less;
    struct pow;
 //   struct sqrt;
    struct bit_or;
    struct bit_xor;
    struct bit_and;
    struct shift_left;
    struct shift_right;
    struct modulus;
    
   // struct to_root;
   
}}}//boost::pqs::meta


#endif

