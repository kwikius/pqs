#ifndef BOOST_PQS_META_BINARY_OPERATOR_TRAITS_HPP_INCLUDED
#define BOOST_PQS_META_BINARY_OPERATOR_TRAITS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
    more refined traits of operators
    should probably be:
    binary_operator_expression_family<op>::value;
    binary_operator_associates_left<op>::value
    note commutivity is naff and will be removed!
    might need to be specialised
*/

#include <boost/pqs/meta/binary_operator_parameters.hpp>
#include <boost/pqs/meta/binary_operator_extra_keys.hpp>

namespace boost{namespace pqs{namespace meta{

    // per operator info
    // may require specialisation for udt
    template<
        typename Op
    >
    struct binary_operator_traits ;

    template<>
    struct binary_operator_traits<equals> {
        enum{
            expression_family 
            = binary_operator_parameters::assignment_expression,
            associativity
            = binary_operator_parameters::left_associative
        };
    };
   
    //logical_or
    template<>
    struct binary_operator_traits<logical_or> {
        enum{
            expression_family 
            = binary_operator_parameters::logical_or_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };
    
    //logical and
    template<>
    struct binary_operator_traits<logical_and> {
        enum{
            expression_family 
            = binary_operator_parameters::logical_and_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };

    //bit or,inclusive or
    template<>
    struct binary_operator_traits<bit_or> {
        enum{
            expression_family 
            = binary_operator_parameters::inclusive_or_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };

     //exclusive or
    template<>
    struct binary_operator_traits<bit_xor> {
        enum{
            expression_family 
            = binary_operator_parameters::exclusive_or_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };

    //bitand, and
    template<>
    struct binary_operator_traits<bit_and> {
        enum{
            expression_family 
            = binary_operator_parameters::and_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };

    // equality_expressions  == !=
    template<>
    struct binary_operator_traits<equal_to> {
        enum{
            expression_family 
            = binary_operator_parameters::equality_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };

    // equality_expressions  == !=
    template<>
    struct binary_operator_traits<not_equal_to> {
        enum{
            expression_family 
            = binary_operator_parameters::equality_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };

    //relational

    template<>
    struct binary_operator_traits<less_equal> {
        enum{
            expression_family 
            = binary_operator_parameters::relational_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };
    template<>
    struct binary_operator_traits<greater_equal> {
        enum{
            expression_family 
            = binary_operator_parameters::relational_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };
    template<>
    struct binary_operator_traits<greater> {
        enum{
            expression_family 
            = binary_operator_parameters::relational_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };
    template<>
    struct binary_operator_traits<less> {
        enum{
            expression_family 
            = binary_operator_parameters::relational_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };
//shift
    template<>
    struct binary_operator_traits<shift_left> {
        enum{
            expression_family 
            = binary_operator_parameters::shift_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };
    template<>
    struct binary_operator_traits<shift_right> {
        enum{
            expression_family 
            = binary_operator_parameters::shift_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };
  
    template<>
    struct binary_operator_traits<plus> {
        enum{
            expression_family 
            = binary_operator_parameters::additive_expression,
            associativity
            = binary_operator_parameters::right_associative
        };
    };

    template<>
    struct binary_operator_traits<minus> {
        enum{
            expression_family 
            = binary_operator_parameters::additive_expression,
            associativity 
            = binary_operator_parameters::right_associative
        };
    };

    template<>
    struct binary_operator_traits<times> {
        enum{
            expression_family 
            = binary_operator_parameters::multiplicative_expression,
            associativity 
            = binary_operator_parameters::right_associative
        };
    };

    template<>
    struct binary_operator_traits<divides> {
        enum{
            expression_family 
            = binary_operator_parameters::multiplicative_expression,
            associativity 
            = binary_operator_parameters::right_associative
        };
    };

    template<>
    struct binary_operator_traits<modulus>  {
        enum{
            expression_family 
            = binary_operator_parameters::multiplicative_expression,
            associativity 
            = binary_operator_parameters::right_associative
        };
    };
    template<>
    struct binary_operator_traits<pow>  {
        enum{
            expression_family 
        // = binary_operator_parameters::multiplicative_expression,
            = binary_operator_parameters::pow_expression,
            associativity 
            = binary_operator_parameters::right_associative
        };
    };


    template< 
        typename Op
    >
    struct is_assignment_operator{
        typedef is_assignment_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::assignment_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_conditional_operator{
        typedef is_conditional_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::conditional_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_logical_or_operator{
        typedef is_logical_or_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::logical_or_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_logical_and_operator{
        typedef is_logical_and_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::logical_and_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_inclusive_or_operator{
        typedef is_inclusive_or_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::inclusive_or_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_exclusive_or_operator{
        typedef is_exclusive_or_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::exclusive_or_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_and_operator{
        typedef is_and_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::and_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_equality_operator{
        typedef is_equality_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::equality_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_relational_operator{
        typedef is_relational_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::relational_expression))
        };
    };
    

    template< 
        typename Op
    >
    struct is_shift_operator{
        typedef is_shift_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::shift_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_additive_operator{
        typedef is_additive_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::additive_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_multiplicative_operator{
        typedef is_multiplicative_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::multiplicative_expression))
        };
    };

    template< 
        typename Op
    >
    struct is_pow_operator{
        typedef is_pow_operator type;
        enum{ 
        value =
           (binary_operator_traits<Op>::expression_family
            == static_cast<int>(binary_operator_parameters::pow_expression))
        };
    };
    
}}}//boost::pqs::meta

#endif
