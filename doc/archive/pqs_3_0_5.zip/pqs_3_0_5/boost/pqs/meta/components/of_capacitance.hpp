#ifndef BOOST_PQS_OF_CAPACITANCE_HPP_INCLUDED
#define BOOST_PQS_OF_CAPACITANCE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_capacitance : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "capacitance";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::pqs::meta::dimension<
            boost::pqs::meta::rational<-2>,
            boost::pqs::meta::rational<4>,
            boost::pqs::meta::rational<-1>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<2>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<9>,
                 meta::rational<1000000, 1000000>::type,
                boost::mpl::int_<1>
            > abfarad;
        };
        typedef  of_capacitance of_type;
    };
    template<>
    inline
    const char*
    of_capacitance::unprefixed_symbol<char>()
    {
        return "F";
    }
    template <>
    struct of_named_quantity_for<
        of_capacitance::type
    > : of_capacitance{};
}}}}//boost::pqs::meta::components
#endif
