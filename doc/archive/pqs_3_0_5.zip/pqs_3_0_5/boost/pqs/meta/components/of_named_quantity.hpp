#ifndef BOOST_PQS_T1_QUANTITY_COMPONENTS_OF_NAMED_QUANTITY_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_COMPONENTS_OF_NAMED_QUANTITY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    common include for headers reqd by OfNamedQuantityComponents concept
    eg the of_xxx structs
*/

#include <boost/pqs/meta/components/of_named_quantity_for.hpp>
#include <boost/pqs/meta/components/adjusted_coherent_prefix.hpp>
#include <boost/mpl/vector.hpp>
#include <boost/noncopyable.hpp>
#include <boost/pqs/t1_quantity/operations.hpp>
//#include <boost/pqs/meta/incoherent_multiplier.hpp>

#endif
