#ifndef BOOST_PQS_OF_PRESSURE_HPP_INCLUDED
#define BOOST_PQS_OF_PRESSURE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_pressure : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "pressure";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::pqs::meta::dimension<
            boost::pqs::meta::rational<-1>,
            boost::pqs::meta::rational<-2>,
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<5>,
                 meta::rational<1013250, 1000000>::type,
                boost::mpl::int_<0>
            > atm;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<4>,
                 meta::rational<9806650, 1000000>::type,
                boost::mpl::int_<0>
            > at;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<5>,
                 meta::rational<1000000, 1000000>::type,
                boost::mpl::int_<1>
            > bar;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<1333220, 1000000>::type,
                boost::mpl::int_<0>
            > cm_mercury0C;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<1333224, 1000000>::type,
                boost::mpl::int_<0>
            > cmHg;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<1>,
                 meta::rational<9806380, 1000000>::type,
                boost::mpl::int_<0>
            > cm_water4C;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<1>,
                 meta::rational<9806650, 1000000>::type,
                boost::mpl::int_<0>
            > cmH20;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<-1>,
                 meta::rational<1000000, 1000000>::type,
                boost::mpl::int_<1>
            > dyn_div_cm2;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<4>,
                 meta::rational<4063666, 1000000>::type,
                boost::mpl::int_<0>
            > ftHg;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<2988980, 1000000>::type,
                boost::mpl::int_<0>
            > ft_water39_2F;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<2989067, 1000000>::type,
                boost::mpl::int_<0>
            > ftH20;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<1>,
                 meta::rational<9806650, 1000000>::type,
                boost::mpl::int_<1>
            > gf_div_cm2;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<3386380, 1000000>::type,
                boost::mpl::int_<0>
            > in_mercury32F;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<3376850, 1000000>::type,
                boost::mpl::int_<0>
            > in_mercury60F;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<3386389, 1000000>::type,
                boost::mpl::int_<0>
            > inHg;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<2>,
                 meta::rational<2490820, 1000000>::type,
                boost::mpl::int_<0>
            > in_water39_2F;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<2>,
                 meta::rational<2490889, 1000000>::type,
                boost::mpl::int_<0>
            > inH20;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<4>,
                 meta::rational<9806650, 1000000>::type,
                boost::mpl::int_<1>
            > kgf_div_cm2;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<0>,
                 meta::rational<9806650, 1000000>::type,
                boost::mpl::int_<0>
            > kgf_div_m2;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<6>,
                 meta::rational<9806650, 1000000>::type,
                boost::mpl::int_<0>
            > kgf_div_mm2;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<6>,
                 meta::rational<6894757, 1000000>::type,
                boost::mpl::int_<0>
            > ksi;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<2>,
                 meta::rational<1000000, 1000000>::type,
                boost::mpl::int_<2>
            > mbar;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<2>,
                 meta::rational<1333224, 1000000>::type,
                boost::mpl::int_<0>
            > mmHg;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<0>,
                 meta::rational<9806650, 1000000>::type,
                boost::mpl::int_<1>
            > mmH20;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<1>,
                 meta::rational<4788026, 1000000>::type,
                boost::mpl::int_<0>
            > lbf_div_ft2;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<6894757, 1000000>::type,
                boost::mpl::int_<0>
            > psi;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<0>,
                 meta::rational<1488164, 1000000>::type,
                boost::mpl::int_<0>
            > poundal_div_ft2;
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<2>,
                 meta::rational<1333224, 1000000>::type,
                boost::mpl::int_<1>
            > torr;
        };
        typedef  of_pressure of_type;
    };
    template<>
    inline
    const char*
    of_pressure::unprefixed_symbol<char>()
    {
        return "Pa";
    }
    template <>
    struct of_named_quantity_for<
        of_pressure::type
    > : of_pressure{};
}}}}//boost::pqs::meta::components
#endif
