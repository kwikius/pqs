#ifndef BOOST_PQS_OF_RESISTANCE_HPP_INCLUDED
#define BOOST_PQS_OF_RESISTANCE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_resistance : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "resistance";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::pqs::meta::dimension<
            boost::pqs::meta::rational<2>,
            boost::pqs::meta::rational<-3>,
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<-2>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::quantity_unit<
                boost::pqs::meta::rational<-9>,
                 meta::rational<1000000, 1000000>::type,
                boost::mpl::int_<1>
            > abohm;
        };
        typedef  of_resistance of_type;
    };
    template<>
    inline
    const char*
    of_resistance::unprefixed_symbol<char>()
    {
        return "R";
    }
    template <>
    struct of_named_quantity_for<
        of_resistance::type
    > : of_resistance{};
}}}}//boost::pqs::meta::components
#endif
