
#ifndef GENERIC_META_DETAIL_RATIONAL_C_IMPL_HPP_INCLUDED
#define GENERIC_META_DETAIL_RATIONAL_C_IMPL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

#include "boost/math/common_factor_ct.hpp"
#include <boost/pqs/config.hpp>

namespace boost{namespace pqs{namespace meta{namespace detail{

    template<
        BOOST_PQS_INT32 N,
        BOOST_PQS_INT32 D 
    >
    struct rational_impl {
  
        enum{
            pos_nume_in = (N >= 0) ? N : -N,
            pos_denom_in = (D >= 0) ? D : -D
        };        
        typedef boost::math::static_gcd<
            static_cast<unsigned long>(pos_nume_in),
            static_cast<unsigned long>(pos_denom_in)
        > gcd_type;
        enum{
            gcd = (gcd_type::value),
            n_sign = (N >= 0)? 1 :-1,
            d_sign = (D >= 0)? 1 :-1,
            nume_in 
            = ((n_sign * d_sign) > 0)? pos_nume_in : -pos_nume_in
        };
        enum{
            numerator = nume_in / gcd,
            denominator = pos_denom_in / gcd
        };
        typedef rational_impl<numerator,denominator> type;
    };

    template<
        BOOST_PQS_INT32 N,
        BOOST_PQS_INT32 D
    >
    struct rational_impl_eval 
    {
        typedef typename rational_impl<N,D>::type rat_type;
        typedef double result_type;

        result_type operator()() const 
        {
            return static_cast<result_type>(static_cast<BOOST_PQS_INT32>(rat_type::numerator))
            / static_cast<BOOST_PQS_INT32>(rat_type::denominator);
        }
    };

    template<
        BOOST_PQS_INT32 N
    >
    struct rational_impl_eval<N,1>{
        typedef BOOST_PQS_INT32 result_type;
        result_type operator()() const
        {
            return N;
        }
    };
}}}}//boost::mpl::math::detail

#endif
