#ifndef BOOST_PQS_IS_T1_QUANTITY_VALUE_TYPE_HPP_INCLUDED
#define BOOST_PQS_IS_T1_QUANTITY_VALUE_TYPE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    for registering acceptable ct_quantity value_types
*/
 
#include <boost/type_traits/is_arithmetic.hpp>

namespace boost{namespace pqs{namespace meta{

    template <typename Value_type>
    struct is_t1_quantity_value_type {
            enum{value = ( boost::is_arithmetic<Value_type>::value !=0)};
            typedef is_t1_quantity_value_type  type; 
    };

}}}//boost::pqs::meta

#endif
