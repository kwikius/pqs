#ifndef BOOST_PQS_META_VALUE_TYPE_HPP_INCLUDED
#define  BOOST_PQS_META_VALUE_TYPE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/type_traits/is_arithmetic.hpp>
#include <boost/mpl/and.hpp>
namespace boost{namespace pqs{ namespace meta{

    template <typename ValueType>
    struct is_value_type : boost::is_arithmetic<ValueType>::type{};
    template <typename A, typename B>
    struct are_value_type2 : boost::mpl::and_<
            boost::is_arithmetic<A>,
            boost::is_arithmetic<B>
    >::type{};
                
}}}//boost::pqs::meta

#endif

