#ifndef BOOST_PQS_META_MIN_TYPE_HPP_INCLUDED
#define BOOST_PQS_META_MIN_TYPE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
    promotion convenience
    to a minimum type
*/

#include <boost/pqs/meta/arithmetic_promote.hpp>

namespace boost{namespace pqs{ namespace meta{

    template<typename T>
    struct int_promote : arithmetic_promote<int,T>{};
    template<typename T>
    struct long_promote : arithmetic_promote<long,T>{};
    template<typename T>
    struct float_promote : arithmetic_promote<float,T>{};
    template<typename T>
    struct double_promote : arithmetic_promote<double,T>{};
    template<typename T>
    struct long_double_promote : arithmetic_promote<long double,T>{};
   
}}}//boost::pqs::meta

#endif
