#ifndef PQS_META_STATIC_POW_HPP_INCLUDED
#define PQS_META_STATIC_POW_HPP_INCLUDED

#include <boost/pqs/meta/max_ice_exponent.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/mpl/assert.hpp>
/*
    compile time pow function
*/

namespace boost{namespace pqs{namespace meta{

    template<
        typename BaseIntegerType,
        BaseIntegerType Base,
        unsigned int Exp
    >
    struct pow_c;

    template<
        int Base
    >
    struct pow_c<int,Base ,0U>{
        enum{ value = 1};
    };

    template<
        unsigned int Base
    >
    struct pow_c<unsigned int,Base ,0U>{
        enum{ value = 1};
    };

    template<
        long Base
    >
    struct pow_c<long,Base ,0U>{
        enum{ value = 1};
    };
    template<
        unsigned long Base
    >
    struct pow_c<unsigned long,Base ,0U>{
        enum{ value = 1};
    };

    template<
        typename IntegerType,
        IntegerType Base, 
        unsigned int Exp
    >
    struct pow_c {
        BOOST_MPL_ASSERT_RELATION(Exp, 
            <=,(pqs::meta::max_ice_exponent<IntegerType,Base>::value));
        BOOST_MPL_ASSERT_RELATION(Exp,>,0);
        enum{ value = Base * pow_c<IntegerType,Base, Exp - 1 >::value };
    };

   
}}}//boost::pqs::meta



#endif

