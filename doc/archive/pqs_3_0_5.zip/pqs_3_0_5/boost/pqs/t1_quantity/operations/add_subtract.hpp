#ifndef BOOST_PQS_T1_QUANTITY_ADD_SUBTRACT_HPP_INCLUDED111
#define BOOST_PQS_T1_QUANTITY_ADD_SUBTRACT_HPP_INCLUDED111
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    addition and subtraction of t1-quantities
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>

namespace boost {namespace pqs{ namespace meta{

    template <
        template <typename, typename> class AbstractQuantity, 
        typename Dimension,
        typename IdL,
        typename UnitsL ,
        typename Value_typeL ,
        typename IdR,
        typename UnitsR ,
        typename Value_typeR
    > struct binary_operation<
        t1_quantity<
            AbstractQuantity<Dimension, IdL> ,
            UnitsL ,
            Value_typeL
        > ,
        plus ,
        t1_quantity<
            AbstractQuantity<Dimension, IdR> ,
            UnitsR ,
            Value_typeR
        >
    >{
        typedef typename binary_operation <
            UnitsL ,
            plus ,
            UnitsR 
        >::type units;
        typedef typename binary_operation<
            Value_typeL ,
            plus
            , Value_typeR
        >::type value_type;
        typedef typename t1_quantity<
            AbstractQuantity<
                Dimension,
                typename detail::plus_minus_quantity_id<
                    IdL,IdR
                >::type
            >,
            units ,
            value_type
        >::type type;
    };

     template <
        template <typename, typename> class AbstractQuantity, 
        typename Dimension,
        typename IdL,
        typename UnitsL ,
        typename Value_typeL ,
        typename IdR,
        typename UnitsR ,
        typename Value_typeR
    > struct binary_operation<
        t1_quantity<
            AbstractQuantity<Dimension, IdL> ,
            UnitsL ,
            Value_typeL
        > ,
        minus ,
        t1_quantity<
            AbstractQuantity< Dimension, IdR> ,
            UnitsR ,
            Value_typeR
        >
    >{
        typedef typename binary_operation <
            UnitsL,
            minus,
            UnitsR 
        >::type units;
        typedef typename binary_operation<
            Value_typeL ,
            minus
            , Value_typeR
        >::type value_type;
        typedef typename t1_quantity<
            AbstractQuantity<
                Dimension,
                typename detail::plus_minus_quantity_id<IdL,IdR>::type
            >,
            units ,
            value_type
        >::type type;
    };

}}} // boost::pqs::meta

#if !(defined _MSC_VER && _MSC_VER ==1400 && defined BOOST_PQS_SUPPRESS_VC8_ADL_BUG)
namespace boost{namespace pqs{
#else 
// namespace boost{namespace pqs{namespace meta{
#endif

	template < 
        template <typename, typename> class AbstractQuantity ,
        typename Dimension,
        typename IdL,
        typename UnitsL,
        typename Value_typeL,
        typename IdR,
        typename UnitsR ,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdL>, 
            UnitsL ,
            Value_typeL
        > ,
        boost::pqs::meta::plus ,
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdR>,
            UnitsR ,
            Value_typeR
        >
    >::type
    operator + (
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdL>,
            UnitsL ,
            Value_typeL
        > const & lhs ,
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdR> ,
            UnitsR ,
            Value_typeR
        > const & rhs
	)
	{
        typename boost::pqs::meta::binary_operation<
            boost::pqs::t1_quantity<
                AbstractQuantity<Dimension,IdL>,
                UnitsL ,
                Value_typeL
            > ,
            boost::pqs::meta::plus ,
			boost::pqs::t1_quantity<
                AbstractQuantity<Dimension,IdR> ,
                UnitsR ,
                Value_typeR
            >
        >::type result = lhs;
        result += rhs;
        return result;
    }

	template < 
        template <typename, typename> class AbstractQuantity ,
        typename Dimension,
        typename IdL,
        typename UnitsL ,
        typename Value_typeL ,
        typename IdR,
        typename UnitsR ,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdL> , 
            UnitsL ,
            Value_typeL
        > ,
        boost::pqs::meta::minus ,
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdR>,
            UnitsR ,
            Value_typeR
        >
    >::type
    operator -(
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdL> ,
            UnitsL ,
            Value_typeL
        >const& lhs ,
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdR> ,
            UnitsR ,
            Value_typeR
        >const& rhs
	)
    {
        typename boost::pqs::meta::binary_operation<
            boost::pqs::t1_quantity<
                AbstractQuantity<Dimension,IdL>,
                UnitsL ,
                Value_typeL
            > ,
            boost::pqs::meta::minus ,
            boost::pqs::t1_quantity<
                AbstractQuantity<Dimension,IdR> ,
                UnitsR ,
                Value_typeR
            >
        >::type result = lhs;
        result -= rhs;
        return result;
    }
#if !(defined _MSC_VER && _MSC_VER ==1400 && defined BOOST_PQS_SUPPRESS_VC8_ADL_BUG)
}}
#else
//}}}
#endif

#endif

