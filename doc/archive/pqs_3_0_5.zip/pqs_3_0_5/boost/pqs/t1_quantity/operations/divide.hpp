#ifndef BOOST_PQS_T1_QUANTITY_DIVIDE_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_DIVIDE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    division of ct-quantities
*/
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/pqs/detail/united_value/operations/dimensioned_divide.hpp>
#include <boost/pqs/detail/united_value/operations/dimensionless_divide.hpp>
//#include <boost/pqs/t1_quantity/operations/t1_quantity_bin_op_macros.hpp>

namespace boost {namespace pqs{namespace meta{

        template <
			typename AbstractQuantityL,
			typename UnitsL ,
			typename Value_typeL ,
            typename AbstractQuantityR,
			typename UnitsR ,
			typename Value_typeR
		> struct binary_operation<
			t1_quantity<
				AbstractQuantityL ,
				UnitsL ,
				Value_typeL
			> ,
			divides ,
			t1_quantity<
				AbstractQuantityR,
				UnitsR ,
				Value_typeR
			>
		>{
            typedef typename binary_operation <
				AbstractQuantityL ,
				divides ,
				AbstractQuantityR 
			>::type abstract_quantity;
			typedef typename binary_operation <
				UnitsL ,
				divides ,
				UnitsR 
			>::type units;
			typedef typename binary_operation<
				Value_typeL ,
				divides, 
				Value_typeR
			>::type value_type;
			typedef typename t1_quantity<
				abstract_quantity ,
				units ,
				value_type
			>::type type;
		};
}}}//boost::pqs::meta
#if !(defined _MSC_VER && _MSC_VER ==1400)
namespace boost{namespace pqs{
#endif
    //dimensionless result
    template<
        template <typename,typename> class AbstractQuantity,
	    typename Dimension,
		typename IdL,
        typename UnitsL,
        typename Value_typeL,
		typename IdR,
        typename UnitsR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation< 
        Value_typeL,
        boost::pqs::meta::divides,
        Value_typeR
    >::type
    operator / ( 
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdL>,
            UnitsL,
            Value_typeL
        > const & pqa,
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdR>,
            UnitsR,
            Value_typeR
        > const & pqb )
    {
        typename boost::pqs::meta::binary_operation< 
            Value_typeL,
            boost::pqs::meta::divides,
            Value_typeR
        >::type result 
        =   boost::pqs::detail::dimensionless_divide(
                pqa.get_united_value(),
                pqb.get_united_value()
        ); 
        return result;
    }
    
    //dimensioned result
    template< 
        typename AbstractQuantityL,
        typename UnitsL,
        typename Value_typeL,
        typename AbstractQuantityR,
        typename UnitsR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        boost::pqs::t1_quantity<
            AbstractQuantityL,
            UnitsL,
            Value_typeL
        >,
        boost::pqs::meta::divides,
        boost::pqs::t1_quantity<
            AbstractQuantityR,
            UnitsR,
            Value_typeR
        >
    >::type
    operator / ( 
        boost::pqs::t1_quantity<
            AbstractQuantityL,
            UnitsL,
            Value_typeL
        > const & pqa,
        boost::pqs::t1_quantity<
            AbstractQuantityR,
            UnitsR,
            Value_typeR
        > const & pqb )
    {
        typename boost::pqs::meta::binary_operation<
            boost::pqs::t1_quantity<
                AbstractQuantityL,
                UnitsL,
                Value_typeL
            >,
            boost::pqs::meta::divides,
            boost::pqs::t1_quantity<
                AbstractQuantityR,
                UnitsR,
                Value_typeR
            >
        >::type result(
            (
                boost::pqs::detail::dimensioned_divide(
                    pqa.get_united_value(),
                    pqb.get_united_value()
                )
             ).raw_value() 
        );
        return result;
    }
#if !(defined _MSC_VER && _MSC_VER ==1400)
}} //boost::pqs
#endif     

#endif
