//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.
/*
    very simple ct-quantity stream input demo. after C++ 3rd Ed 621.
    See examples/mapped_rt_quantity for more sophisticated input.
    However this can be used for retrieving ct-quantity data from file
    should work ok for, simple numeric value_types 
    in coherent or named-incoherent-quantity types.
    (If units have spaces etc ... needs further work.)
*/

#include <boost/pqs/t1_quantity/io/input.hpp>
#include <boost/pqs/t1_quantity/types/out/length.hpp>

using namespace boost::pqs;
int main()
{  
    length::in L;
    while (std::cin){
        std::cout << " value of L is : " <<  L <<'\n';
        std::cout << "enter length in inches ie 12 in\n...or bad units to quit\n";
        std::cin >> L;
        if (std::cin.bad()){
            std::cout << "bad input... quitting\n";
        }
        else{
            std::cout << "value is now : " << L <<'\n';
        }
    }
}
