
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#ifndef BOOST_PQS_MINIMAL_TEST
#include <boost/test/unit_test.hpp>
#include <boost/test/included/unit_test_framework.hpp>
#endif

void t1_quantity_test();
void test_units_data1();
void test_abstract_quantity();
void united_value_test();
void test_si_unit();
void test_units_data();

#ifdef BOOST_PQS_MINIMAL_TEST
int errors=0;
int main(int , char*[])
{
  t1_quantity_test();
  test_abstract_quantity();
  united_value_test();
  test_units_data();
  test_units_data1();
  test_si_unit();
  EPILOGUE
  return EXIT_SUCCESS;
}
#else
using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( int, char* [] ) {

    test_suite* test = BOOST_TEST_SUITE( "Unit test boost/pqs" );
    test->add(BOOST_TEST_CASE(t1_quantity_test));
    test->add(BOOST_TEST_CASE(test_abstract_quantity));
    test->add(BOOST_TEST_CASE(united_value_test));
    test->add(BOOST_TEST_CASE(test_units_data));
    test->add(BOOST_TEST_CASE(test_units_data1));
    test->add(BOOST_TEST_CASE(test_si_unit));
    return test;
}
#endif
