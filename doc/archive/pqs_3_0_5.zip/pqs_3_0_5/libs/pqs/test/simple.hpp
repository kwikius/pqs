#ifndef BOOST_PQS_SIMPLE_TEST_HPP_INCLUDED
#define BOOST_PQS_SIMPLE_TEST_HPP_INCLUDED


#include <boost/pqs/meta/binary_operation.hpp>
#include <iostream>
/// count errors
extern int errors;
inline
void check_function( char* filename ,  long line,char* pred, bool pred1)
{
    if(! pred1){
        std::cout << filename << ":" << line  << "( " << pred << " ) failed\n";
       // errors ++;
    }
}
template<typename Ta, typename Tb, typename Te>
inline
void check_close_function( char* filename ,long line,char* predac,char* predbc,char* epsc,Ta vala, Tb valb, Te eps)
{
    Te absval = vala - valb <= 0 ? vala - valb : valb - vala;
    if (! (absval < eps)){
        std::cout << filename << ":" << line  
        << "( " << predac << " == " << predbc << " +/- " << epsc << " ) failed\n";
       // errors ++;
    }
}
template<typename Ta, typename Tb>
inline
void check_equal_function( char* filename ,long line,char* predac,char* predbc,Ta vala, Tb valb)
{
    typedef typename boost::pqs::meta::binary_operation<
        Ta,boost::pqs::meta::minus,Tb
    >::type Te;
     Te  absval = vala - valb <= 0 ? vala - valb : valb - vala;
    if (! (absval == Te(0) )){
        std::cout << filename << ":" << line  
        << "( " << predac << " == " << predbc << " ) failed\n";
      //  errors ++;
    }
}

// simulate boost test macros
#define BOOST_CHECK(x) check_function( __FILE__ , __LINE__ , #x, x)
#define BOOST_CHECK_CLOSE(a,b,e) check_close_function( __FILE__ , __LINE__ , #a , #b ,#e, a, b, e)
#define BOOST_CHECK_EQUAL(a,b) check_equal_function( __FILE__ , __LINE__ , #a , #b , a , b )
// best show we've been on success
inline int epilogue(const char* file)
{
    if (errors){
        std::cout << file << " FAIL: found " << errors << " errors\n";
    }
    else{
        std::cout << file << " PASS (no errors)\n";
    }
    return errors;
}
#define EPILOGUE return epilogue(__FILE__);


//// incoherent-multiplier correct to 6 decimals
//// hence unreasonable expect greater accuaracy
//// 1 e-12 may be optimistic
//#ifndef FP_MAX_DIFFERENCE
//#define FP_MAX_DIFFERENCE 1e-12
//#endif
#endif


