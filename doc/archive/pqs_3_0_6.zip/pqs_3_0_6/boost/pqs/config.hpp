#ifndef BOOST_PQS_CONFIG_HPP_INCLUDED
#define BOOST_PQS_CONFIG_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/cstdint.hpp>

/*
    Configuration options for boost::pqs
*/
#ifndef BOOST_PQS_COMPARISON_EPSILON
#define BOOST_PQS_COMPARISON_EPSILON 0.0
#endif

// set to 1 to make double default value_type
#ifndef  BOOST_PQS_USE_DOUBLE_REAL_TYPE
#define BOOST_PQS_USE_DOUBLE_REAL_TYPE 1
#endif

#if (defined(BOOST_PQS_USE_DOUBLE_REAL_TYPE) && BOOST_PQS_USE_DOUBLE_REAL_TYPE !=0)
    #ifndef BOOST_PQS_REAL_TYPE
        #define BOOST_PQS_REAL_TYPE double
    #endif
    #ifndef BOOST_PQS_MAX_PLUS1_POW10_DOUBLE
        #define BOOST_PQS_MAX_PLUS1_POW10_DOUBLE 68
    #endif
    #ifndef BOOST_PQS_MAX_PLUS1_POW10_FLOAT
        #define BOOST_PQS_MAX_PLUS1_POW10_FLOAT 39
    #endif
    #define BOOST_PQS_MAX_PLUS1_POW10 BOOST_PQS_MAX_PLUS1_POW10_DOUBLE
#else
#define BOOST_PQS_REAL_TYPE float
    #ifndef BOOST_PQS_MAX_PLUS1_POW10_FLOAT
    #define BOOST_PQS_MAX_PLUS1_POW10_FLOAT 39
    #endif
    #define BOOST_PQS_MAX_PLUS1_POW10 BOOST_PQS_MAX_PLUS1_POW10_FLOAT
#endif

#ifndef BOOST_PQS_MAX_PLUS1_POW10_INT32
#define BOOST_PQS_MAX_PLUS1_POW10_INT32 10
#endif

// These reflect the number of compile time exponents instantiated
// see <boost/pqs/detail/united_value/operations/coherent_exponent_eval.hpp>
// for details
//#ifndef BOOST_PQS_MAX_EXPONENT10
//#define BOOST_PQS_MAX_EXPONENT10 64
//#endif
//
//#ifndef BOOST_PQS_MIN_EXPONENT10
//#define BOOST_PQS_MIN_EXPONENT10 -64
//#endif

// define to use boost.typeof for arithmetic results of ops
//#define BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
// otherwise synthetic version used

// Typeofs's macro. use to test Boost.Typeof in compliant mode
//#define BOOST_TYPEOF_COMPLIANT

// 32 bit int use in rational parameters
// needs to be a macro rather than a typedef 
// for use in template parameters
#if  (INT_MAX >= 0x7fffffff)
#define BOOST_PQS_INT32 int
#elif (LONG_MAX >= 0x7fffffff)
#define BOOST_PQS_INT32 long
#else
// long should be at least 32 bits so shouldlnt get here
#error need to define a 32-bit int in <boost/pqs/config.hpp>
#endif

// causes operators to be defined at global scope
// VC8 has problems with ADL on complicated types
#define BOOST_PQS_SUPPRESS_VC8_ADL_BUG

#endif


