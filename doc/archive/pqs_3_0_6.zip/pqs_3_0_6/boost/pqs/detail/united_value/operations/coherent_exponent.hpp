#ifndef BOOST_PQS_COHERENT_EXPONENT_HPP_INCLUDED
#define BOOST_PQS_COHERENT_EXPONENT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    the coherent exponent represents the exponent 
    of the unit of a coherent quantity.
    e.g kilometers has a coherent exponent of 3.
    Rational exponents are also valid.
    The is_integer and is_positive are used 
    to determine how to best optimise when evaluating.
    IOW where possible an int type is returned.
*/
#include <boost/pqs/quantity_traits.hpp>

#include <boost/pqs/detail/united_value/operations/coherent_exponent_eval.hpp>

namespace boost{namespace pqs{namespace concept_checking{
    // used to check that a coherent-exponent is computable
    namespace detail {
         template< BOOST_PQS_INT32 Expnume, BOOST_PQS_INT32 Expdenom>
         struct  CoherentExponentInRangeImpl{
            enum{ value 
            = (( (Expdenom == 1 ) 
           /* &&(Expnume >= boost::pqs::quantity_traits::min_int_coherent_exponent) 
            && (Expnume <= boost::pqs::quantity_traits::max_int_coherent_exponent)) 
                || ((Expnume <= boost::pqs::quantity_traits::max_rat_coherent_exponent * Expdenom)
                && (Expnume >= boost::pqs::quantity_traits::min_rat_coherent_exponent * Expdenom)) )*/
             &&(Expnume >=  -(BOOST_PQS_MAX_PLUS1_POW10 -1)) 
            && (Expnume <= (BOOST_PQS_MAX_PLUS1_POW10 -1))) 
                || ((Expnume <= (BOOST_PQS_MAX_PLUS1_POW10-1) * Expdenom)
                && (Expnume >= -(BOOST_PQS_MAX_PLUS1_POW10-1) * Expdenom)) )
            };
         };
    }// detail

     template< BOOST_PQS_INT32 Expnume, BOOST_PQS_INT32 Expdenom>
    ////////////////////////////////////////////////////////
     struct AssertCoherentExponentInRange
    ///////////////////////////////////////////////////////
     // Assertion fails if the coherent-exponent in a unit 
    // is too big or too small to be evaluated
    : Assert < (detail::CoherentExponentInRangeImpl<Expnume,Expdenom>::value)>
  {};
}}}//boost::pqs::concept_checking

namespace boost{namespace pqs{ namespace detail{

    template <BOOST_PQS_INT32 N ,BOOST_PQS_INT32 D>
    struct coherent_exponent : boost::pqs::concept_checking::AssertCoherentExponentInRange<N,D>
    {
         enum {numerator =  N,denominator = D };//Rational::denominator;
         enum {  
            is_integer = ( denominator == 1 ),
            is_positive = ( numerator >= 0 ),
            is_zero  = ( numerator == 0)
         };
        
        enum{ 
            param_check1 = (is_positive && is_integer),
            param_check = (is_positive? numerator:-numerator) 
            <= std::numeric_limits<BOOST_PQS_INT32>::digits10
        };
       // why not just say int as R?
        template <typename R>
        struct eval : coherent_exponent_eval<
            R,
            numerator,
            denominator,
            param_check
        >{};
        typedef coherent_exponent type; 
    };
}}}//boost::pqs::detail



 
#endif
