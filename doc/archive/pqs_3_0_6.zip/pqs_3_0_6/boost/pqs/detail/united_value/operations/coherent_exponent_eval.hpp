#ifndef BOOST_PQS_DETAIL_COHERENT_EXPONENT_EVAL_INCLUDED
#define BOOST_PQS_DETAIL_COHERENT_EXPONENT_EVAL_INCLUDED

#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    functors to evaluate the value of a coherent-exponent
*/

/*
    Thoughts: result_type min result_type etc is not ideal.
    Why not just return the minimmal type int or quantity_traits::default_value_type
    and forget about all that stuff. Todo

*/

#include <boost/pqs/meta/pow_c.hpp>
#include <boost/pqs/quantity_traits.hpp>
#include <boost/pqs/meta/min_type.hpp>
#include <cmath>
#include <limits>
//#include <boost/preprocessor/comma.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/preprocessor/repetition.hpp>
#include <boost/preprocessor/control/if.hpp>
#include <boost/preprocessor/comparison/equal.hpp>
#include <boost/preprocessor/empty.hpp>
#include <boost/static_assert.hpp>

namespace boost{namespace pqs{ namespace detail{

        // default  instantiated for any non-integer exponent
        // wants Arithmetic Type ??
        template <typename ResultType,BOOST_PQS_INT32 N, BOOST_PQS_INT32 D, bool WantInt>
        struct coherent_exponent_eval{

//****************************************************************
//****************************************************************
// If here specialisation of coherent_exponent_eval has failed
            BOOST_STATIC_ASSERT( ((D !=1)||( N <=0)));
// Basically dont want this version called unless necessary
// as it uses std::pow and has limited range
//*****************************************************************
//*****************************************************************

            enum{ required = true};
            typedef float min_result_type;
            typedef typename boost::pqs::quantity_traits::min_real<
                min_result_type
            >::type result_type;
            result_type operator()()const 
            {
                result_type result 
                = std::pow(
                    static_cast<result_type>(10),
                    static_cast<result_type>(N)/D
                );
                return result;
            }

        };

        // instantiated for very large/small integer powers but not used
        // really requires a mod
        template <typename ResultType,BOOST_PQS_INT32 N, bool WantInt>
        struct coherent_exponent_eval<
            ResultType,N,1, WantInt
        >{
            enum{ required = true};
            typedef ResultType min_result_type;
            typedef ResultType result_type;
            result_type operator()()const ;
           
        };

        //isntantiated for small positive exponents
        // fast and integer result
        template<typename ResultType,BOOST_PQS_INT32 N>
        struct coherent_exponent_eval<ResultType,N,1,true>{
            enum{ required = ( N !=0 ) };
            typedef BOOST_PQS_INT32 min_result_type;
            typedef typename meta::arithmetic_promote<
                BOOST_PQS_INT32,ResultType
            >::type result_type;
 
            result_type operator()()const 
            {
                result_type result
                = static_cast<result_type>(
                    boost::pqs::meta::pow_c<
                        BOOST_PQS_INT32,
                        10,N
                    >::value
                );
                return result;
            }
        };

#define BOOST_PQS_EXP_EVAL_CAT(a, b) BOOST_PQS_PRIMITIVE_EXP_EVAL_CAT(a, b)
#define BOOST_PQS_PRIMITIVE_EXP_EVAL_CAT(a, b) a ## b

 #define BOOST_PQS_COHERENT_EXPONENT_EVAL(Sign, Num, FLOAT)\
       template <>\
       struct coherent_exponent_eval< \
            FLOAT , Sign Num  ,\
             1 , false\
             >{\
           enum{ required = true};\
           typedef FLOAT min_result_type;\
           typedef FLOAT result_type;\
           result_type operator()()const\
           {    result_type result\
                = static_cast< FLOAT > ( BOOST_PQS_EXP_EVAL_CAT(BOOST_PQS_EXP_EVAL_CAT(1e, Sign), Num));\
                return result;\
            }\
       };

#define BOOST_PQS_COHERENT_EXPONENT_EVAL_I(Sign,Num)\
      template <>\
       struct coherent_exponent_eval<BOOST_PQS_INT32 , Sign Num , 1 , false>\
        : boost::pqs::concept_checking::Assert<\
           ((Sign Num >=0) && (std::numeric_limits<BOOST_PQS_INT32>::digits10 >= Sign Num))\
        >{\
           enum{required = true};\
           typedef boost::pqs::quantity_traits::default_value_type result_type;\
           result_type operator()()const\
           {return coherent_exponent_eval<\
            result_type  , Sign Num , 1 , false>()();}\
      };

#ifdef BOOST_PQS_MAX_PLUS1_POW10_DOUBLE
#define BOOST_PQS_COHERENT_EXPONENT_PLUS_DOUBLE(z,Num,unused) \
    BOOST_PQS_COHERENT_EXPONENT_EVAL(+,Num,double)

//#define BOOST_PQS_COHERENT_EXPONENT_EVAL_MINUS_NUM_DOUBLE_PRIMITIVE(Num) \
//    BOOST_PQS_COHERENT_EXPONENT_EVAL(-,Num,double)

//#define BOOST_PQS_COHERENT_EXPONENT_MINUS_DOUBLE(z,Num,Unused)     \
//BOOST_PP_IF(BOOST_PP_EQUAL(Num,0),BOOST_PP_EMPTY,                  \
//BOOST_PQS_COHERENT_EXPONENT_EVAL_MINUS_NUM_DOUBLE_PRIMITIVE)       \
//BOOST_PP_IF(BOOST_PP_EQUAL(Num,0),(),(Num))

#endif

#define BOOST_PQS_COHERENT_EXPONENT_PLUS_FLOAT(z,Num,unused) \
    BOOST_PQS_COHERENT_EXPONENT_EVAL(+,Num,float)

//#define BOOST_PQS_COHERENT_EXPONENT_EVAL_MINUS_NUM_FLOAT_PRIMITIVE(Num) \
//    BOOST_PQS_COHERENT_EXPONENT_EVAL(-,Num,float)

//#define BOOST_PQS_COHERENT_EXPONENT_MINUS_FLOAT(z,Num,unused)            \
//BOOST_PP_IF(BOOST_PP_EQUAL(Num,0),BOOST_PP_EMPTY,                       \
//BOOST_PQS_COHERENT_EXPONENT_EVAL_MINUS_NUM_FLOAT_PRIMITIVE)             \
//BOOST_PP_IF(BOOST_PP_EQUAL(Num,0),(),(Num))

//#define BOOST_PQS_COHERENT_EXPONENT_MINUS_FLOAT(z,Num,unused) \
//    BOOST_PQS_COHERENT_EXPONENT_EVAL(-,Num, float)

#define BOOST_PQS_COHERENT_EXPONENT_EVAL_I_PLUS(z,Num,unused) \
    BOOST_PQS_COHERENT_EXPONENT_EVAL_I(+,Num)

// note values are + 1 to actual instantiations
#ifdef BOOST_PQS_MAX_PLUS1_POW10_DOUBLE
BOOST_PP_REPEAT( BOOST_PQS_MAX_PLUS1_POW10_DOUBLE , BOOST_PQS_COHERENT_EXPONENT_PLUS_DOUBLE,~)
//BOOST_PP_REPEAT( BOOST_PQS_MAX_PLUS1_POW10_DOUBLE , BOOST_PQS_COHERENT_EXPONENT_MINUS_DOUBLE,~)
#endif

BOOST_PP_REPEAT( BOOST_PQS_MAX_PLUS1_POW10_FLOAT , BOOST_PQS_COHERENT_EXPONENT_PLUS_FLOAT,~)
//BOOST_PP_REPEAT( BOOST_PQS_MAX_PLUS1_POW10_FLOAT , BOOST_PQS_COHERENT_EXPONENT_MINUS_FLOAT,~)

BOOST_PP_REPEAT( BOOST_PQS_MAX_PLUS1_POW10_INT32, BOOST_PQS_COHERENT_EXPONENT_EVAL_I_PLUS,~)
    
#undef BOOST_PQS_EXP_EVAL_CAT
#undef BOOST_PQS_PRIMITIVE_EXP_EVAL_CAT
#undef BOOST_PQS_COHERENT_EXPONENT_EVAL_I
#undef BOOST_PQS_COHERENT_EXPONENT_EVAL

#undef BOOST_PQS_COHERENT_EXPONENT_PLUS_DOUBLE
#undef BOOST_PQS_COHERENT_EXPONENT_PLUS_FLOAT
#undef BOOST_PQS_COHERENT_EXPONENT_EVAL_I_PLUS

}}}//boost::pqs::detail
#endif

