#ifndef BOOST_PQS_OPERATIONS_VALUE_CAST_IMPL_HPP_INCLUDED
#define BOOST_PQS_OPERATIONS_VALUE_CAST_IMPL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    optimised functions for converting 
    two t1_quantity values of different units
*/

#include <boost/pqs/detail/united_value/operations/quantity_conversion_traits.hpp>

namespace boost{namespace pqs {namespace detail{

    template<
        typename ValueCastTraits,
        bool Incoh, bool Delog,bool PosAlg
    >
    struct value_cast_traits_fx;
    
    template <
        typename Target_value_type,
        typename Target_unit,
        typename Source_value_type,
        typename Source_unit

    > struct value_cast_traits{
        
        typedef quantity_conversion_traits<
            Target_value_type,
            Target_unit,
            Source_value_type,
            Source_unit
        > conversion_traits;
        typedef typename conversion_traits::source_value_type source_value_type;
        typedef typename conversion_traits::min_in_arith_value_type min_in_arith_value_type;
        typedef typename conversion_traits::incoherent_divide_fx incoherent_divide_fx;
        typedef typename conversion_traits::abs_difference_delog_fx abs_difference_delog_fx;
        typedef typename conversion_traits::first_difference_exponent first_difference_exponent;
        typedef typename value_cast_traits_fx<
                    value_cast_traits,
                    incoherent_divide_fx::required,
                    abs_difference_delog_fx::required,
                    (first_difference_exponent::numerator >=0)
        >::type eval;
        typedef typename eval::result_type result_type;
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required  == true;
    //abs_difference_delog_fx::required              == true;
    //use_positive_alg                == true;
    template<typename ValueCastTraits>
    struct value_cast_traits_fx <ValueCastTraits,true, true, true>{
      //  typedef typename ValueCastTraits::promoted_difference_divide_working_type result_type;
        
        typedef typename boost::pqs::meta::arithmetic_promote<
             typename boost::pqs::meta::arithmetic_promote<
                typename ValueCastTraits::incoherent_divide_fx::result_type,
                typename ValueCastTraits::abs_difference_delog_fx::result_type
             >::type ,
             typename ValueCastTraits::min_in_arith_value_type
        >::type result_type;   
            
        result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_uv_val)const
        {
            return typename ValueCastTraits::incoherent_divide_fx()() 
            * typename ValueCastTraits::abs_difference_delog_fx()() * source_uv_val;
        }
        typedef value_cast_traits_fx type;
    };
    
    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == true
    //abs_difference_delog_fx::required ==true;
    //use_positive_alg ==false
    template<typename ValueCastTraits>
    struct value_cast_traits_fx <ValueCastTraits,true, true, false>{
         typedef typename boost::pqs::meta::arithmetic_promote<
             typename boost::pqs::meta::arithmetic_promote<
                typename ValueCastTraits::incoherent_divide_fx::result_type,
                typename ValueCastTraits::abs_difference_delog_fx::result_type
             >::type ,
             typename ValueCastTraits::min_in_arith_value_type
        >::type result_type;  
        result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_uv_val)const
        {
            return typename ValueCastTraits::incoherent_divide_fx()() 
            / typename ValueCastTraits::abs_difference_delog_fx()() * source_uv_val;
        }
         typedef value_cast_traits_fx type;
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == true
    //abs_difference_delog_fx::required ==false;
    //use_positive_alg  == dont_care
    template<typename ValueCastTraits,bool X>
    struct value_cast_traits_fx <ValueCastTraits,true, false, X>{
       // typedef typename ValueCastTraits::promoted_difference_divide_working_type result_type;
         typedef typename boost::pqs::meta::arithmetic_promote<
             typename ValueCastTraits::abs_difference_delog_fx::result_type,
             typename ValueCastTraits::min_in_arith_value_type
        >::type result_type;  
        result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_uv_val)const
        {
            return typename ValueCastTraits::incoherent_divide_fx()() * source_uv_val ;
        }
         typedef value_cast_traits_fx type;
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == false
    //abs_difference_delog_fx::required ==true;
    //use_positive_alg == true
    template<typename ValueCastTraits>
    struct value_cast_traits_fx <ValueCastTraits,false, true, true>{
         typedef typename boost::pqs::meta::arithmetic_promote<
             typename ValueCastTraits::abs_difference_delog_fx::result_type,
             typename ValueCastTraits::min_in_arith_value_type
        >::type result_type;  
        result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_uv_val)const
        {
            return  source_uv_val 
            * typename ValueCastTraits::abs_difference_delog_fx()();
        }
         typedef value_cast_traits_fx type;
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == false
    //abs_difference_delog_fx::required ==true;
    //use_positive_alg == false
    template<typename ValueCastTraits>
    struct value_cast_traits_fx <ValueCastTraits,false, true, false>{
        typedef typename boost::pqs::meta::arithmetic_promote<
             typename ValueCastTraits::abs_difference_delog_fx::result_type,
             typename ValueCastTraits::min_in_arith_value_type
        >::type result_type;  
        result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_uv_val)const
        {
            return    source_uv_val / typename ValueCastTraits::abs_difference_delog_fx()(); 
        }
        typedef value_cast_traits_fx type;
    };

    //template<bool Incoh, bool Delog,bool PosAlg>
    //incoherent_divide_fx::required == false
    //abs_difference_delog_fx::required ==false;
    //use_positive_alg == dont_care
    template<typename ValueCastTraits,bool X>
    struct value_cast_traits_fx <ValueCastTraits,false, false, X>{
        typedef typename ValueCastTraits::source_value_type result_type;
        result_type 
        operator()(typename ValueCastTraits::source_value_type const& source_uv_val)const
        {
            return source_uv_val;
        }
         typedef value_cast_traits_fx type;
    };



}}}//boost::pqs::detail


#endif
