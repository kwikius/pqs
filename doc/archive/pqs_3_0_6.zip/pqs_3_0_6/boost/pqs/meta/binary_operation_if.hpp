#ifndef BOOST_PQS_META_BINARY_OPERATION_IF_HPP_INCLUDED
#define BOOST_PQS_META_BINARY_OPERATION_IF_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
    binary_operation with encapsulated_enable_if
    for use in function return types
*/

#include <boost/pqs/meta/binary_operation.hpp>

namespace boost{namespace pqs{ namespace meta{

    template <
        bool Condition,
        typename Left,
        typename Op,
        typename Right
    >
    struct binary_operation_if_c;

    template <
        typename Left,
        typename Op,
        typename Right
    >
    struct binary_operation_if_c<
        true,
        Left,
        Op,
        Right
    > {
        typedef  typename boost::pqs::meta::binary_operation<
            Left,Op,Right
        >::type type;
    };
    

    template <
        typename Left,
        typename Op,
        typename Right
    >
    struct binary_operation_if_c<
        false,
        Left,
        Op,
        Right
    >{};

    template <
        typename Condition,
        typename Left,
        typename Op,
        typename Right
    >
    struct binary_operation_if : binary_operation_if_c<
        (static_cast<bool>(Condition::value)),
        Left, Op, Right
     >{};
            
}}}//boost::pqs::meta


#endif
