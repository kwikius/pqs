#ifndef BOOST_PQS_CT_QUANTITY_ADJUSTED_COHERENT_PREFIX_HPP_INCLUDED
#define BOOST_PQS_CT_QUANTITY_ADJUSTED_COHERENT_PREFIX_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/meta/components/of_named_quantity_for.hpp>
#include <boost/pqs/meta/is_named_abstract_quantity.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/meta/unit_fwd.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/void.hpp>
#include <boost/pqs/meta/rational.hpp>
#include <boost/utility/enable_if.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{
/*
   adjusts the prefix for types such as mass, area etc
    dependent on the values in the OfNamedQuantityComponents Concept
    for getting the correct si prefix for output
*/
    template <
        typename AbstractQuantity, 
        typename QuantityUnit,
        typename Enable = void
    >
    struct adjusted_coherent_prefix;

    template <
        typename AbstractQuantity, 
        typename QuantityUnit
    >
    struct adjusted_coherent_prefix<
        AbstractQuantity,
        QuantityUnit,
        typename boost::disable_if<
            is_named_abstract_quantity<AbstractQuantity>
        >::type
    >
    {
        typedef  void type ;//QuantityUnit type;
    };

    // specialised for named-abstract_quantity,units combo
    // note assumes that the
    // of_named_quantity_for meta-function
    // has been specialised  

    template<
        typename AbstractQuantity,
        typename CoherentExponent,
        typename IncoherentMultiplier,
        typename QuantityUnitTag
    >
    struct adjusted_coherent_prefix<
        AbstractQuantity,
        unit<
            CoherentExponent,
            IncoherentMultiplier,
            QuantityUnitTag
        >,
        typename boost::enable_if<
               is_named_abstract_quantity<AbstractQuantity>    
        >::type
    >
    {
        // get OfNamedQuantityComponents concept
        typedef of_named_quantity_for<
            AbstractQuantity
        > of_type;
    /////////////////// CONCEPT CHECK ///////////////////////////
    // You may arrive here if you have created a named ct-quantity
    // without a (correct) specialisation of
    // pqs::of_named_quantity_for
    // to access its OfNamedQuantityComponents concept.
    // The unspecialised version has a member 'type of boost::mpl::void_
    // And docs/Concepts/OfNamedQuantityComponents for more details
      /*  pqs::concept_checking::Assert<
        (
            (boost::is_same<of_type,boost::mpl::void_>::value == false)
            && CoherentExponent::is_integer
            && ((CoherentExponent::numerator % of_type::extent) == 0)  
        )
        > assert_valid_OfNamedQuantityComponentsConcept;*/
    ///////////CONCEPT_CHECK///////////////////////////
        enum{ 
            adjusted_numerator
            = (CoherentExponent::numerator / of_type::extent)
                + of_type::prefix_offset
        };
        typedef unit<
            boost::pqs::meta::rational<adjusted_numerator>
         > type;
       
    };

}}}}//boost::pqs::meta::components


#endif
