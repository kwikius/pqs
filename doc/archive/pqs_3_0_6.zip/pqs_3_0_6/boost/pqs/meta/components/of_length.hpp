#ifndef BOOST_PQS_OF_LENGTH_HPP_INCLUDED
#define BOOST_PQS_OF_LENGTH_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_length : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "length";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::pqs::meta::dimension<
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::unit<
                boost::pqs::meta::rational<0>,
                 meta::rational<1828804, 1000000>::type,
                boost::mpl::int_<0>
            > fathom_us;
            typedef meta::unit<
                boost::pqs::meta::rational<11>,
                 meta::rational<1495979, 1000000>::type,
                boost::mpl::int_<0>
            > AU;
            typedef meta::unit<
                boost::pqs::meta::rational<1>,
                 meta::rational<2011684, 1000000>::type,
                boost::mpl::int_<0>
            > ch;
            typedef meta::unit<
                boost::pqs::meta::rational<0>,
                 meta::rational<1828800, 1000000>::type,
                boost::mpl::int_<0>
            > fathom;
            typedef meta::unit<
                boost::pqs::meta::rational<-1>,
                 meta::rational<3048000, 1000000>::type,
                boost::mpl::int_<0>
            > ft;
            typedef meta::unit<
                boost::pqs::meta::rational<-1>,
                 meta::rational<3048006, 1000000>::type,
                boost::mpl::int_<0>
            > ft_us;
            typedef meta::unit<
                boost::pqs::meta::rational<-2>,
                 meta::rational<2540000, 1000000>::type,
                boost::mpl::int_<0>
            > in;
            typedef meta::unit<
                boost::pqs::meta::rational<15>,
                 meta::rational<9460730, 1000000>::type,
                boost::mpl::int_<0>
            > l_y_;
            typedef meta::unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<1609344, 1000000>::type,
                boost::mpl::int_<0>
            > mi;
            typedef meta::unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<1852000, 1000000>::type,
                boost::mpl::int_<0>
            > naut_mile;
            typedef meta::unit<
                boost::pqs::meta::rational<16>,
                 meta::rational<3085678, 1000000>::type,
                boost::mpl::int_<0>
            > pc;
            typedef meta::unit<
                boost::pqs::meta::rational<-3>,
                 meta::rational<4233333, 1000000>::type,
                boost::mpl::int_<0>
            > pica_comp;
            typedef meta::unit<
                boost::pqs::meta::rational<-3>,
                 meta::rational<4217518, 1000000>::type,
                boost::mpl::int_<0>
            > pica_prn;
            typedef meta::unit<
                boost::pqs::meta::rational<-4>,
                 meta::rational<3527778, 1000000>::type,
                boost::mpl::int_<0>
            > point_comp;
            typedef meta::unit<
                boost::pqs::meta::rational<-4>,
                 meta::rational<3514598, 1000000>::type,
                boost::mpl::int_<0>
            > point_prn;
            typedef meta::unit<
                boost::pqs::meta::rational<0>,
                 meta::rational<5029210, 1000000>::type,
                boost::mpl::int_<0>
            > rd;
            typedef meta::unit<
                boost::pqs::meta::rational<-1>,
                 meta::rational<9144000, 1000000>::type,
                boost::mpl::int_<0>
            > yd;
            typedef meta::unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<4046873, 1000000>::type,
                boost::mpl::int_<0>
            > acre;
            typedef meta::unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<1233489, 1000000>::type,
                boost::mpl::int_<0>
            > acre_foot;
            typedef meta::unit<
                boost::pqs::meta::rational<-10>,
                 meta::rational<1000000, 1000000>::type,
                boost::mpl::int_<1>
            > angstrom;
        };
        typedef  of_length of_type;
    };
    template<>
    inline
    const char*
    of_length::unprefixed_symbol<char>()
    {
        return "m";
    }
    template <>
    struct of_named_quantity_for<
        of_length::type
    > : of_length{};
}}}}//boost::pqs::meta::components
#endif
