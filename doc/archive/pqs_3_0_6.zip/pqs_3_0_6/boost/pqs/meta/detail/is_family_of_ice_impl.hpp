#ifndef BOOST_MPL_AUX_IS_FAMILY_OF_ICE_IMPL_HPP_INCLUDED
#define BOOST_MPL_AUX_IS_FAMILY_OF_ICE_IMPL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/pqs/meta/has_member_type.hpp>

namespace boost{namespace pqs{namespace meta{namespace detail{
BOOST_TT_EXT_DEFINE_HAS_MEMBER_TYPE(tag);
        
        template <
            typename Family_tag, 
            typename T, 
            bool Has_tag = has_member_type_tag<T>::value 
        >
        struct is_family_of_ice_impl;
        template <
            typename Family_tag,
            typename T
        >
        struct is_family_of_ice_impl<
            Family_tag, 
            T, 
            true
        > : boost::is_same<
                Family_tag, 
                typename T::tag
        >{};
        template <
            typename Family_tag,
            typename T
        >
        struct  is_family_of_ice_impl<Family_tag, T, false> : boost::mpl::false_{};

}}}}//boost::pqs::meta::detail

#endif

