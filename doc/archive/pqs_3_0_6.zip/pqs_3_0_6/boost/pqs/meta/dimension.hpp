#ifndef BOOST_PQS_META_DIMENSION_HPP_INCLUDED
#define BOOST_PQS_META_DIMENSION_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/pqs/meta/pow.hpp>
#include <boost/pqs/meta/binary_log_transform.hpp>
#include <boost/mpl/bool.hpp>

namespace boost{namespace pqs{namespace meta{

    template <
        typename R1,
        typename R2,
        typename R3,
        typename R4,
        typename R5,
        typename R6,
        typename R7
    >
    struct dimension{
        typedef typename R1::type d1;
        typedef typename R2::type d2;
        typedef typename R3::type d3;
        typedef typename R4::type d4;
        typedef typename R5::type d5;
        typedef typename R6::type d6;
        typedef typename R7::type d7; 
        typedef dimension type;
    };

    template <
        typename DimensionL,
        typename DimensionR
    > 
    struct dimensionally_equivalent
    : boost::is_same< 
        DimensionL,
        DimensionR
    >{};

    template <typename Dimension>
    struct is_dimensionless{
        enum {
        value =
        ((    Dimension::d1::numerator
            || Dimension::d2::numerator
            || Dimension::d3::numerator
            || Dimension::d4::numerator
            || Dimension::d5::numerator
            || Dimension::d6::numerator
            || Dimension::d7::numerator
        )== 0 ) };
        typedef is_dimensionless type;  
    };
    
    template <
        typename D1L,
        typename D2L,
        typename D3L,
        typename D4L,
        typename D5L,
        typename D6L,
        typename D7L,
        typename Op,
        typename D1R,
        typename D2R,
        typename D3R,
        typename D4R,
        typename D5R,
        typename D6R,
        typename D7R
    >
    struct binary_operation<
        dimension<
            D1L,
            D2L,
            D3L,
            D4L,
            D5L,
            D6L,
            D7L
        >,
        Op,
        dimension<
            D1R,
            D2R,
            D3R,
            D4R,
            D5R,
            D6R,
            D7R
        > 
    > : dimension <
            typename binary_log_transform<D1L,Op,D1R>::type,
            typename binary_log_transform<D2L,Op,D2R>::type,
            typename binary_log_transform<D3L,Op,D3R>::type,
            typename binary_log_transform<D4L,Op,D4R>::type,
            typename binary_log_transform<D5L,Op,D5R>::type,
            typename binary_log_transform<D6L,Op,D6R>::type,
            typename binary_log_transform<D7L,Op,D7R>::type
        >{};

    template <
        typename D1,
        typename D2,
        typename D3,
        typename D4,
        typename D5,
        typename D6,
        typename D7,
        typename Exp
    >
    struct binary_operation<
        dimension<
            D1, D2, D3, D4, D5, D6, D7
        >,
        pow,
        Exp/*,
        typename boost::enable_if<
             not_0_or_1<Exp>
        >::type */
    > : dimension<
        typename binary_operation<D1,times,Exp>::type,
        typename binary_operation<D2,times,Exp>::type,
        typename binary_operation<D3,times,Exp>::type,
        typename binary_operation<D4,times,Exp>::type,
        typename binary_operation<D5,times,Exp>::type,
        typename binary_operation<D6,times,Exp>::type,
        typename binary_operation<D7,times,Exp>::type
     >{};
    
    template <
        typename D1,
        typename D2,
        typename D3,
        typename D4,
        typename D5,
        typename D6,
        typename D7
    >
    struct unary_operation<
        reciprocal,
        dimension<
            D1, D2, D3, D4, D5, D6, D7
        >
    >{
        typedef dimension<
            typename unary_operation<negate,D1>::type,
            typename unary_operation<negate,D2>::type,
            typename unary_operation<negate,D3>::type,
            typename unary_operation<negate,D4>::type,
            typename unary_operation<negate,D5>::type,
            typename unary_operation<negate,D6>::type,
            typename unary_operation<negate,D7>::type
        > type;
    };
   
}}}

#endif
