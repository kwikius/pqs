
#ifndef BOOST_PQS_IS_T1_QUANTITY_HPP_INCLUDED
#define BOOST_PQS_IS_T1_QUANTITY_HPP_INCLUDED

#include <boost/pqs/t1_quantity/t1_quantity_fwd.hpp>
#include <boost/mpl/bool.hpp>

namespace boost{namespace pqs{namespace meta{

    template <typename T>
    struct is_t1_quantity : boost::mpl::false_{};

    template <typename A,typename U, typename V>
    struct is_t1_quantity<
        boost::pqs::t1_quantity<
            A,U,V
        >
    > : boost::mpl::true_{};
}}}//boost::pqs:meta

#endif
