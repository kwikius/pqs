#ifndef BOOST_PQS_META_POW10_RATIONAL_HPP_INCLUDED
#define BOOST_PQS_META_POW10_RATIONAL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.
#include <boost/pqs/detail/united_value/operations/coherent_exponent.hpp>
#include <boost/pqs/meta/rational.hpp>
/*

    do 10 to power rational
    pow10::result_type is the minimum for loss of precision

*/

namespace boost{namespace pqs{namespace meta{

    template <typename Rational>
    struct pow10 {
        typedef typename boost::mpl::if_<
            boost::mpl::or_<
                boost::mpl::less<
                    Rational,
                    rational<0>
                >,
                boost::mpl::greater_equal<
                    Rational,
                    rational<
                        std::numeric_limits<BOOST_PQS_INT32>::digits10
                    >
                >,
                boost::mpl::bool_<
                   ( Rational::denominator != 1)
                >
            >,
            typename boost::pqs::quantity_traits::default_value_type,
            BOOST_PQS_INT32
        >::type result_type;
        typedef typename boost::pqs::detail::coherent_exponent<
            Rational::numerator,Rational::denominator
        > coh_exp;   
        typedef typename coh_exp::template eval<result_type> eval;
        
        result_type operator()()
        {
            eval eval_;
            result_type result = eval_();
            return result;
        }
    };
            
}}}

#endif
