#ifndef BOOST_PQS_META_SI_UNITS_HPP_INCLUDED
#define BOOST_PQS_META_SI_UNITS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
   si_unit - utility class for naming coherent si units,
   their names and prefixes
*/

#include <boost/pqs/meta/unit.hpp>

namespace boost{namespace pqs{namespace meta{

    struct si_unit{

        template <typename Exponent>
        struct prefix{
            enum{value = false};
           // typedef prefix type;
        };
        typedef unit<rational< 24> >  yotta;
        typedef unit<rational< 21> >  zetta;
        typedef unit<rational< 18> >  exa;
        typedef unit<rational< 15> >  peta;
        typedef unit<rational< 12> >  tera;
        typedef unit<rational<  9> >  giga;
        typedef unit<rational<  6> >  mega;
        typedef unit<rational<  3> >  kilo;
        typedef unit<rational<  2> >  hecto;
        typedef unit<rational<  1> >  deka;
        typedef unit<rational<  0> >  none;
        typedef unit<rational< -1> >  deci;
        typedef unit<rational< -2> >  centi;
        typedef unit<rational< -3> >  milli;
        typedef unit<rational< -6> >  micro;
        typedef unit<rational< -9> >  nano;
        typedef unit<rational<-12> >  pico;
        typedef unit<rational<-15> >  femto;
        typedef unit<rational<-18> >  atto;
        typedef unit<rational<-21> >  zepto;
        typedef unit<rational<-24> >  yocto;
                           
    };

    template<>
    struct si_unit::prefix<si_unit::yotta>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "yotta";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::yotta>::symbol<char>()
    {
        return "Y";
    }

    template<>
    struct si_unit::prefix<si_unit::zetta>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "zetta";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::zetta>::symbol<char>()
    {
        return "Z";
    }
    
    template<>
    struct si_unit::prefix<si_unit::exa>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "exa";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char* 
    si_unit::prefix<si_unit::exa>::symbol<char>()
    {
        return "E";
    }

    template<>
    struct si_unit::prefix<si_unit::peta>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "peta";}
        template<typename CharType>
        static const CharType* symbol();
    };

    template<>
    inline
    const char*
    si_unit::prefix<si_unit::peta>::symbol<char>()
    {
        return "P";
    }
    template<>
    struct si_unit::prefix<si_unit::tera>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "tera";}
         template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::tera>::symbol<char>()
    {
        return "T";
    }

    template<>
    struct si_unit::prefix<si_unit::giga>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "giga";}
        template<typename CharType>
        static const CharType* symbol(); 
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::giga>::symbol<char>()
    {
        return "G";
    }

    template<>
    struct si_unit::prefix<si_unit::mega>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "mega";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::mega>::symbol<char>()
    {
        return "M";
    }

    template<>
    struct si_unit::prefix<si_unit::kilo>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "kilo";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::kilo>::symbol<char>()
    {
        return "k";
    }
 
    template<>
    struct si_unit::prefix<si_unit::hecto>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "hecto";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::hecto>::symbol<char>()
    {
        return "h";
    }
 
    template<>
    struct si_unit::prefix<si_unit::deka>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "deka";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::deka>::symbol<char>()
    {
        return "da";
    }

    template<>
    struct si_unit::prefix<si_unit::none>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "";}
        template<typename CharType>
        static const CharType* symbol();  
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::none>::symbol<char>()
    {
        return "";
    }

    template<>
    struct si_unit::prefix<si_unit::deci>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "deci";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::deci>::symbol<char>()
    {
        return "d";
    }

    template<>
    struct si_unit::prefix<si_unit::centi>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "centi";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::centi>::symbol<char>()
    {
        return "c";
    }

    template<>
    struct si_unit::prefix<si_unit::milli>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "milli";}
        template<typename CharType>
        static const CharType* symbol(); 
    };
    template<>
    inline
    const char* si_unit::prefix<si_unit::milli>::symbol<char>()
    {
        return "m";
    }

    template<>
    struct si_unit::prefix<si_unit::micro>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "micro";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::micro>::symbol<char>()
    {
        return "u";
    }
 
    template<>
    struct si_unit::prefix<si_unit::nano>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "nano";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::nano>::symbol<char>()
    {
        return "n";
    }

    template<>
    struct si_unit::prefix<si_unit::pico>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "pico";}
        template<typename CharType>
        static const CharType* symbol();
    };

    template<>
    inline
    const char*
    si_unit::prefix<si_unit::pico>::symbol<char>()
    {
        return "p";
    }
    template<>
    struct si_unit::prefix<si_unit::femto>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "femto";}
        template<typename CharType>
        static const CharType* symbol();  
    };
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::femto>::symbol<char>()
    {
        return "f";
    }
    template<>
    struct si_unit::prefix<si_unit::atto>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "atto";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::atto>::symbol<char>()
    {
        return "a";
    }

    template<>
    struct si_unit::prefix<si_unit::zepto>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "zepto";}
        template<typename CharType>
        static const CharType* symbol();
    }; 
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::zepto>::symbol<char>()
    {
        return "z";
    }

    template<>
    struct si_unit::prefix<si_unit::yocto>{
        enum{value = true};
        typedef prefix type;
        static const char* name(){return "yocto";}
        template<typename CharType>
        static const CharType* symbol();
    };
    template<>
    inline
    const char*
    si_unit::prefix<si_unit::yocto>::symbol<char>()
    {
        return "y";
    }  
}}}//boost::pqs::meta

#endif
