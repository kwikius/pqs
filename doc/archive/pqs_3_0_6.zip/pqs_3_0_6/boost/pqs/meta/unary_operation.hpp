#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef GENERIC_META_UNARY_OPERATION_HPP_INCLUDED
#define GENERIC_META_UNARY_OPERATION_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    not all impl
    negate, reciprocal,square-root,cube-root,square,cube
*/
#include <boost/pqs/config.hpp>
#include <boost/mpl/void.hpp>
#include <boost/pqs/meta/unary_operators.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_integral.hpp>
#include <boost/type_traits/is_float.hpp>

namespace boost{namespace pqs {namespace meta{

    template <
       typename Op,
       typename T ,
       typename Enable = void
    >
    struct unary_operation;

    template<typename T>
    struct unary_operation<
        reciprocal,
        T,
        typename boost::enable_if<
            boost::is_float<T>
        >::type
    >{
         typedef T type;
    };
    template<typename T>
    struct unary_operation<
        reciprocal,
        T,
        typename boost::enable_if<
            boost::is_integral<T>
        >::type
    >{
         typedef BOOST_PQS_REAL_TYPE type;
    };

}}}//boost::pqs::meta

#endif
