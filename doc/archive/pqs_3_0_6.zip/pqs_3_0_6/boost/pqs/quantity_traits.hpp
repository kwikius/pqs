#ifndef PQS_OF_QUANTITY_HPP_INCLUDED2911030401
#define PQS_OF_QUANTITY_HPP_INCLUDED2911030401
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

/*
    config const in quantity_traits struct.
    currently not very portable...todo

*/

#include <boost/pqs/config.hpp>
#include <limits>
#include <boost/numeric/conversion/converter.hpp>
#include <boost/pqs/meta/arithmetic_promote.hpp>
#include <boost/pqs/meta/to_arithmetic.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/type_traits/is_convertible.hpp>

/*
    config,traits and scaling functions for all ct_quantities
*/

namespace boost{namespace pqs{

    struct quantity_traits {
        enum{
          /*  min_int_coherent_exponent = -60,
            max_int_coherent_exponent = 67,
            min_rat_coherent_exponent = -63,
            max_rat_coherent_exponent = 63,*/
        // If you define t1_quantities with
        // named_quantity_tag > than this value
        // then you need to write your own  
        // units functions
           max_default_named_quantity_tag = 100
        };    
        // for use as the default value_type for ct_quantities
        typedef  BOOST_PQS_REAL_TYPE  default_value_type;
        template <typename Value_type>
        struct  min_real{
            typedef typename pqs::meta::arithmetic_promote<
                Value_type,
               default_value_type
            >::type type;
        };
      
        template<typename T, typename S>
             // boost converter with nearest neighbour rounding
        struct value_type_converter : boost::numeric::converter<
                T,
                S,
                boost::numeric::conversion_traits<T,S>,
                boost::numeric::def_overflow_handler,
                boost::numeric::RoundEven<S>
            > /*, 
            concept_checking::Assert<
                boost::is_convertible< 
                    S,T
                >::value
            >*/
            {};
       
        // for comparison ==,< etc
        // The MACRO PQS_COMPARISON_EPSILON is 
        // defined in boost/pqs/config.hpp" and is actually used
        // raw as default ep in the compare(pqa,pqb,ep) function,
        //  which is basis for all comp ops
       
        template<typename T>
        static T epsilon()
        {
            return static_cast<T>(BOOST_PQS_COMPARISON_EPSILON);
        }  
          
    };
  
}}//boost::pqs

#endif
