
#ifndef BOOST_PQS_T1_QUANTITY_OPERATIONS_ANONYMOUS_CAST_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_OPERATIONS_ANONYMOUS_CAST_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    function to cast a named-concrete-quantity
    to an anonymous_concrete_quantity
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>

namespace boost{namespace pqs{

    template < 
        template<typename,typename > class AbstractQuantity,
        typename Dimension,
        typename AbstractQuantityID,
        typename QuantityUnit,
        typename Value_type
    >
    inline
    t1_quantity<
        AbstractQuantity< 
            Dimension,    
            meta::anonymous_abstract_quantity_id
        >,
        QuantityUnit,
        Value_type
    >
    anonymous_cast(
            t1_quantity<
                AbstractQuantity<
                    Dimension,
                    AbstractQuantityID
                >,
                QuantityUnit,
                Value_type
            > const& pq_in)
    {
        t1_quantity<
            AbstractQuantity< 
                Dimension,    
                meta::anonymous_abstract_quantity_id
            >,
            QuantityUnit,
            Value_type
        > t(pq_in.numeric_value());
        return t;
    }
}}//boost::pqs

#endif
