#ifndef BOOST_PQS_T1_QUANTITY_POWER_ROOT_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_POWER_ROOT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    power and root functions for inbuilts and ct-quantities
    for inbuilts pow<N>(v) to bring in to line with
*/

#include <cmath>
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/is_t1_quantity.hpp>
#include <boost/pqs/meta/rational.hpp>
#include <boost/pqs/meta/coherent_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
//#include <boost/pqs/meta/is_value_type.hpp>
#include <boost/pqs/meta/to_arithmetic.hpp>
#include <boost/pqs/meta/pow.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/equal_to.hpp>
#include <boost/mpl/not_equal_to.hpp>

namespace boost{namespace pqs{

    namespace meta{
 
        template <
            typename Exponent,
            typename AbstractQuantity,
            typename Units,
            typename Value_type
        >
        struct binary_operation<
            t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            pow, 
            Exponent
        >{
            typedef typename Exponent::type exp;
            typedef typename boost::mpl::if_<
                boost::is_same<
                    exp,
                    rational<0>
                >,
                int,
                typename boost::mpl::if_<
                    boost::is_same<
                        exp,
                        rational<1>
                    >,
                    t1_quantity<
                        AbstractQuantity,
                        Units,
                        Value_type
                    >,
                    typename t1_quantity <
                        typename binary_operation<
                            AbstractQuantity,
                            pow,
                            exp
                        >::type,
                        typename binary_operation<
                            Units,
                            pow,
                            exp
                        >::type,
                        typename binary_operation<
                            Value_type,
                            pow,
                            exp
                        >::type
                    >::type
                >::type
            >::type type;    
        };

    }// meta

   /* template<BOOST_PQS_INT32 N> struct deduced_int{};
    template<BOOST_PQS_INT32 N, BOOST_PQS_INT32 D> struct deduced_fraction{};*/

    template <
        BOOST_PQS_INT32 N,
        BOOST_PQS_INT32 D
    >
    inline
    double
    pow( double const& v)
    {
        double  result 
        = std::pow(
             v ,
            static_cast<double>( N ) / D
        );      
        return result;
    }
    template <
        BOOST_PQS_INT32 N,
        BOOST_PQS_INT32 D
    >
    inline
    double
    pow( int const& v)
    {
        double  result 
        = std::pow(
            static_cast<double>( v ),
            static_cast<double>( N ) / D
        );         
        return result;
    }

    namespace detail{

        template <
           typename Q,
           typename Rational
        >
        struct pow_t1_quantity_impl{
            typedef typename boost::pqs::meta::transform_coherent<
               Q
            >::type coherent_pq;
            typedef typename boost::pqs::meta::binary_operation<
                coherent_pq,
                boost::pqs::meta::pow,
                typename Rational::type
            >::type result_type;
            result_type operator()(Q const & in)
            {
                coherent_pq t = in;
                result_type result(
                    boost::pqs::pow<
                        Rational::numerator,Rational::denominator
                    >(t.numeric_value())
                );
                return result;
            }
        };

        template <
           typename Q
        >
        struct pow_t1_quantity_impl<
            Q,
            boost::pqs::meta::rational<0,1>
        >{
            typedef int result_type;
            result_type operator()(Q const & in)
            {
                return 1;
            }
        };

        template <
           typename Q
        >
        struct pow_t1_quantity_impl<
            Q,
            boost::pqs::meta::rational<1,1>
        >{
            typedef Q result_type;
            result_type operator()(Q const & in)
            {
                return in;
            }
        };

    }//detail

    template <
        BOOST_PQS_INT32 N,
        BOOST_PQS_INT32 D,
        typename AbstractQuantity,
        typename Units,
        typename Value_type
    >
    inline 
    typename meta::binary_operation<
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >,
        meta::pow,
        meta::rational<N,D>
    >::type
    pow(
        t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        > const & pq 
    )
    {   
        typedef t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
        > orig_quantity_type;
        typedef typename meta::rational<
            N,D
        >::type exponent_type;
        typedef detail::pow_t1_quantity_impl<
            orig_quantity_type,
            exponent_type
        > pow_impl;
        typename pow_impl::result_type result
        = pow_impl()(pq);
        return result;
    }

    template <
        BOOST_PQS_INT32 N,
        typename T
    >
    inline
    typename meta::binary_operation<
        T, 
        meta::pow,
        meta::rational<N,1>
    >::type
    pow( T const & t)
    {
        typename meta::binary_operation<
            T, 
            meta::pow,
            meta::rational<N,1>
        >::type result = boost::pqs::pow<N,1>(t);
        return result;
    }

    template <typename T>
    typename meta::binary_operation<
        T,
        meta::pow,
        meta::rational<1,2>
    >::type
    sqrt(T const & v)
    {
     typename meta::binary_operation<
        T,
        meta::pow,
        meta::rational<1,2>
      >::type result = pqs::pow<1,2>(v);
      return result;
    }
  
}}//boost::pqs

#endif

