#ifndef BOOST_PQS_RECIPROCAL_MASS_HPP_INCLUDED
#define BOOST_PQS_RECIPROCAL_MASS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_reciprocal_mass.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct reciprocal_mass_ : meta::components::of_reciprocal_mass{
        typedef t1_quantity<
            type,
            meta::unit<
                boost::pqs::meta::rational<27>
            >,
            Value_type
        > div_yg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::yotta, // coherent-exponent 24
            Value_type
        > div_zg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > div_ag;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > div_fg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > div_pg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > div_ng;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > div_ug;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > div_mg;

        typedef t1_quantity<
            type,
            meta::unit<
                boost::pqs::meta::rational<5>
            >,
            Value_type
        > div_cg;

        typedef t1_quantity<
            type,
            meta::unit<
                boost::pqs::meta::rational<4>
            >,
            Value_type
        > div_dg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > div_g;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > div_dag;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > div_hg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > div_kg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > div_Mg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > div_Gg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > div_Tg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > div_Pg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > div_Eg;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > div_Zg;

    };

    struct reciprocal_mass : reciprocal_mass_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
