#ifndef BOOST_PQS_RECIPROCAL_TIME_HPP_INCLUDED
#define BOOST_PQS_RECIPROCAL_TIME_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_reciprocal_time.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct reciprocal_time_ : meta::components::of_reciprocal_time{
        typedef t1_quantity<
            type,
            typename meta::si_unit::yotta, // coherent-exponent 24
            Value_type
        > div_ys;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > div_zs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > div_as;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > div_fs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > div_ps;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > div_ns;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > div_us;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > div_ms;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > div_cs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > div_ds;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > div_s;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > div_das;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > div_hs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > div_ks;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > div_Ms;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > div_Gs;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > div_Ts;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > div_Ps;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > div_Es;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > div_Zs;

    };

    struct reciprocal_time : reciprocal_time_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
