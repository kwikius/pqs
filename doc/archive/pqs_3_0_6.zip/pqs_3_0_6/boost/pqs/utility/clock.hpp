#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_CLOCK_HPP_INCLUDED
#define BOOST_PQS_CLOCK_HPP_INCLUDED

#include <boost/pqs/t1_quantity/types/time.hpp>
#include <ctime>

namespace boost{namespace pqs{
   
    inline 
    boost::pqs::time::ms clock()
    {
        return pqs::time::ms( 
            std::clock() 
            *   static_cast<
                    quantity_traits::default_value_type
                >(1000) / CLOCKS_PER_SEC
        );
    }
    
}}//boost::pqs

#endif
