#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TIMER_HPP_INCLUDED
#define PQS_TIMER_HPP_INCLUDED
/*
    modified from boost/timer
//  See http://www.boost.org/libs/timer 
*/
/*
    constructor with a boost::pqs::time::ms etc starts timing
    start rests and continues timing
    stop holds onto finish time
    operator ()() 
    gives either duration to last stop(0 if stopped
    or duration from init or start() if running;
    Nominally Correct for one overflow period of system timer.

   To do give various allowed  units;
    
*/
#include <boost/pqs/t1_quantity/types/out/time.hpp>
#include <boost/pqs/utility/clock.hpp>
//include <limits>

namespace boost{namespace pqs{
       
    class timer{
    public:
        timer(): running(true)
        {
            start_time = boost::pqs::clock();
        }
        void restart() 
        {
            running = true;
            start_time = boost::pqs::clock();
        }
        void stop() 
        {
            if (running){
                stop_time = boost::pqs::clock();
                running = false;
            }
        }
        
        boost::pqs::time::ms operator ()()const
        {
            boost::pqs::time::ms const current = boost::pqs::clock();
            boost::pqs::time::ms const wanted = running ? current : stop_time;
            // overflow deduction
          //  if ( wanted >= start_time){
                return wanted - start_time;
           // }
            // add overflow
            
           /* boost::pqs::time::ms last_period 
            =   boost::pqs::time::ms( 
                (std::numeric_limits<clock_t>::max() )
                * static_cast<boost::pqs::of_quantity::default_value_type>(1000)
                / (CLOCKS_PER_SEC) 
            ) - start_time;
            return last_period + wanted;*/
        }
        bool is_running() const {return running;}
        bool is_stopped() const {return !running;}
    private:
        bool running;
        boost::pqs::time::ms start_time;
        boost::pqs::time::ms stop_time;
    };

}}//boost::pqs

#endif
