//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    Extended implementation of the pq_box example dicussed in the abstract
*/

//comment out NO_PQS_CONSTANTS_LIBRARY if using constants in a library
#define NO_PQS_CONSTANTS_LIBRARY
#ifdef NO_PQS_CONSTANTS_LIBRARY
#include <libs/pqs/src/acceleration_g.cpp>
#endif

#include <boost/pqs/t1_quantity/types/out/length.hpp>
#include <boost/pqs/t1_quantity/types/out/volume.hpp>
#include <boost/pqs/t1_quantity/types/out/time.hpp>
#include <boost/pqs/t1_quantity/types/out/force.hpp>
#include <boost/pqs/t1_quantity/types/out/mass.hpp>
#include <boost/pqs/t1_quantity/types/out/density.hpp>

namespace pqs = boost::pqs;

class Box{
public:
    Box(pqs::length::m const & l,
        pqs::length::m const& w, 
        pqs::length::m const& h
    ): length(l),width(w),height(h){}
	
	pqs::force::N filled_weight()const
	{
		pqs::volume::m3 volume 
        = this->length * this->width * this->height;
		pqs::mass::kg mass = this->contents.density * volume;
		return mass * pqs::acceleration::g;  
	}
    pqs::length::m fill_level(pqs::mass::kg const & measured_mass)const
    {
        return this->height 
        * (measured_mass * pqs::acceleration::g) 
        / filled_weight();
    }
    struct contents{
        contents(){}
        pqs::density::kg_div_m3 density;
    }contents;
    void set_contents_density(pqs::density::kg_div_m3 const & density_in)
    {
        this->contents.density = density_in;
    }
  
    pqs::length::m const length;
	pqs::length::m const width;
    pqs::length::m const height;
   
};
//
int main()
{
   using pqs::length;
   using pqs::time;
   using pqs::mass;
   using pqs::density;
   Box box(length::mm(1000), length::mm(500),length::mm(200));
   box.set_contents_density(density::kg_div_m3(1000));
   
   time::s  fill_time(200); // time since starting fill
   mass::kg measured_mass(20); // measured mass at fill_time

   std::cout << "fill level at " << fill_time << " = " 
   << box.fill_level(measured_mass) <<'\n';
   std::cout << "input flow rate after " << fill_time 
   << " = " << measured_mass / fill_time <<'\n';
   std::cout << "fill level rate = " 
   << box.fill_level(measured_mass) / fill_time <<'\n';
   time::s fill_time_left 
   = (box.height / box.fill_level(measured_mass) - 1) * fill_time ;
   std::cout << "fill time left = " << fill_time_left <<'\n';
    
}
