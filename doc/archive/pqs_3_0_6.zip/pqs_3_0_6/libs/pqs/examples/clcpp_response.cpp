
#include <boost/pqs/t1_quantity/types/out/length.hpp>
#include <boost/pqs/t1_quantity/types/out/area.hpp>
#include <boost/pqs/t1_quantity/types/out/volume.hpp>
#include <boost/pqs/t1_quantity/types/out/time.hpp>

namespace pqs = boost::pqs;

// pqs can adopt the single type approach
void f_D_Abrahams()
{
    typedef pqs::length::km distance;
    typedef pqs::time::s time;

    distance const km(1.0); 
    distance const miles = pqs::length::mi(1);
    time const sec(1.0); 
    time const min = pqs::time::min(1);
    time const hr = pqs::time::h(1);; 

    // However it is probably not optimal for output:

    std::cout << "pqs can provide output using a single type:\n\n"; 
    std::cout << km << '\n';
    std::cout << miles << '\n';
    std::cout << sec << '\n';
    std::cout << min << '\n';
    std::cout << hr  <<  "\n\n";;
}

void f_pqs()
{
 
    using pqs::length;
    using pqs::time;

   length::km km(1);

// for convenience...
    typedef length distance;

    distance::mi miles(1);

// units symbols are based on those in the SI
    std::cout.precision(6);
    time::s     sec(1);
    time::min min(1);
    time::h   hr(1);

    std::cout << "but also provide output for each unit:\n\n"; 
    std::cout << km << '\n';
    std::cout << miles << '\n';
    std::cout << sec << '\n';
    std::cout << min << '\n';
    std::cout << hr  << "\n\n";

    length::m  meter(1);
    std::cout << "pqs has a wide range of pre-defined units,"
    " for consistency and repeatability across applications:\n\n";

    std::cout << meter << '\n' ;
   
    std::cout << " = " << length::AU(meter) << '\n'; 
    std::cout << " = " << length::acre(meter) << '\n';  
    std::cout << " = " << length::acre_foot(meter) << '\n'; 
    std::cout << " = " << length::angstrom(meter) << '\n'; 
    std::cout << " = " << length::ch(meter) << '\n'; 
    std::cout << " = " << length::fathom(meter) << '\n'; 
    std::cout << " = " << length::fathom_us(meter) << '\n';
    std::cout << " = " << length::ft(meter) << '\n'; 
    std::cout << " = " << length::ft_us(meter) << '\n';  
    std::cout << " = " << length::in(meter) << '\n'; 
    std::cout << " = " << length::l_y_(meter) << '\n';  
    std::cout << " = " << length::mi(meter) << '\n'; 
    std::cout << " = " << length::naut_mile(meter) << '\n'; 
    std::cout << " = " << length::pc(meter) << '\n'; 
    std::cout << " = " << length::pica_comp(meter) << '\n';  
    std::cout << " = " << length::pica_prn(meter) << '\n'; 
    std::cout << " = " << length::point_comp(meter) << '\n'; 
    std::cout << " = " << length::point_prn(meter) << '\n'; 
    std::cout << " = " << length::rd(meter) << '\n'; 
    std::cout << " = " << length::yd(meter) << '\n'; 
    

}
void calcs_comparison()
{
  //  std::cout.setf(std::ios_base::fixed/*,std::ios_base::floatfield*/);
    std::cout.precision(20);
    std::cout << "\nA distinct unit for each type";
    std::cout << " is efficient and accurate when adding"
    " two values of the same very big or very small type:\n\n";

    using pqs::length_;

    length_<float>::fm L1A(2);
    length_<float>::fm L2A(3);
    length_<float>::fm LrA = L1A + L2A;

    std::cout << L1A << " + " << L2A << "\n = " << LrA << "\n\n";

    std::cout << "The single unit method must convert large"
    " or small values in other units to meters."
    " This is both inefficient and inaccurate\n\n";

    length_<float>::m L1B = L1A;
    length_<float>::m L2B = L2A;
    length_<float>::m LrB = L1B + L2B;

    std::cout << L1B << " + " << L2B << "\n = " << LrB << "\n\n";

    std::cout << "In multiplication and division:\n\n";
    using pqs::area_;
    area_<float>::fm2 ArA = L1A * L2A ;
    std::cout << L1A << " * " << L2A << "\n = " << ArA << "\n\n";
    std::cout <<"similar problems arise\n\n";
    area_<float>::m2 ArB = L1B * L2B;
    std::cout << L1B << " * " << L2B << "\n = " << ArB << '\n';

}
int main()
{
   f_D_Abrahams();
   f_pqs();
    calcs_comparison();
}
