//  Copyright (C) Andy Little, White Light Device 2003.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
     some basic electronics calcs
*/

#include "boost/pqs/t1_quantity/types/out/voltage.hpp"
#include "boost/pqs/t1_quantity/types/out/resistance.hpp"
#include "boost/pqs/t1_quantity/types/out/current.hpp"
#include "boost/pqs/t1_quantity/types/out/time.hpp"
#include "boost/pqs/t1_quantity/types/out/power.hpp"
#include "boost/pqs/t1_quantity/types/out/energy.hpp"

int main()
{
    using boost::pqs::voltage;
    using boost::pqs::current;
    using boost::pqs::resistance;
    using boost::pqs::time;
    using boost::pqs::power;
    using boost::pqs::energy;
    using boost::pqs::pow;

    voltage::V        v(5.0);
    resistance::kR    r(1);
    current::mA       i = v/r;
    time::s           t(1.0);
    power::mW         w = pow<2>(v)/r;
    energy::mJ        e = w * t;
    std::cout 
    << "A current of " << i
    << "\nthrough a voltage of " << v 
    << "\nrequires a resistance of " << r 
    << "\nand produces "  << w << " of heat\n";
    std::cout 
    << "total energy in " << t 
    << " is " <<  e  << '\n';
}
