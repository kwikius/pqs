
/*
    Demonstrate boost::pqs::timer to see benefit of
    compile time computation of fibonacci seq over runtime
*/

#include <boost/pqs/utility/timer.hpp>

#include <boost/preprocessor/repetition.hpp>
#include <boost/preprocessor/control/if.hpp>
#include <boost/preprocessor/comparison/equal.hpp>
#include <boost/preprocessor/empty.hpp>
#include <boost/preprocessor/comma.hpp>
#include <boost/preprocessor/arithmetic/add.hpp>

#include <iostream>
#include <stdexcept>

template<int N>
struct fibonacci{
    static const int value 
    = fibonacci<N-1>::value 
    + fibonacci<N-2>::value;
};

template<>
struct fibonacci<0>{
    static const int value = 0;
};

template<>
struct fibonacci<1>{
    static const int value = 1;
};

#define FIB_SEQ1(N) \
BOOST_PP_IF(N,BOOST_PP_COMMA,BOOST_PP_EMPTY)()\
fibonacci< N >::value 

#define FIB_SEQUENCE(z,N,unused) FIB_SEQ1(N)

#define MAX_FIB 46

int ct_fibonacci(int n)
{
    static int const values[]  = {
       BOOST_PP_REPEAT( BOOST_PP_ADD(MAX_FIB,1) ,FIB_SEQUENCE,~) 
    };
    if( (n < 0) || (n > MAX_FIB)) {
        throw(std::out_of_range(
                "fibonacci input out of range"
            )
        );
    }
    return values[n];
}

int rt_fibonacci( int i ) { 
 int result[] = { 0, 1 }; 
   while ( i > 1 ) { 
      int t = result[0]; 
      result[0] = result[1]; 
      result[1] = result[0] + t; 
      --i; 
   } 
   return result[i]; 
} 
enum{ num_loops = 100000};
int main()
{
    int ar [MAX_FIB+1];

    std::cout << "\nstarting runtime calculated fibonacci loop  ...please wait\n";
    boost::pqs::timer trt;
    for(int j = 0;  j < num_loops; ++j){
        for(int i=0;i <=MAX_FIB;++i){
            ar[i] = rt_fibonacci(i) << '\n';
        }
    }
    trt.stop();
    std::cout << "runtime version time = " << trt() << "\n";

    std::cout << "\nstarting compiletime calculated fibonacci loop ...please wait\n";
    boost::pqs::timer tct;
    for(int j = 0;  j < num_loops; ++j){
        for(int i=0;i <=MAX_FIB;++i){
            ar[i] = ct_fibonacci(i) << '\n';
        }
    }
    tct.stop();
    std::cout << "compile time version time = " << tct() <<'\n';
}


