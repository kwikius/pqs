//  Copyright (C) Andy Little, White Light Device 2004.
//  andy@servocomm.freeserve.co.uk
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    Calculate Johnson noise voltage for 10 kHz LP RC filter
    From Horowitz and Hill ,The Art of Electronics.
    Example of definitions of constants
*/

//comment out NO_PQS_CONSTANTS_LIBRARY if using constants in a library
#define NO_PQS_CONSTANTS_LIBRARY

#ifdef NO_PQS_CONSTANTS_LIBRARY
#include <libs/pqs/src/boltzmanns_constant.cpp>
#include <libs/pqs/src/constant.cpp>
#else
#include <boost/pqs/t1_quantity/constants/boltzmanns_constant.hpp>
#include <boost/pqs/t1_quantity/constants/constant.hpp>
#endif
#include <boost/pqs/t1_quantity/types/out/temperature.hpp>
#include <boost/pqs/t1_quantity/types/out/resistance.hpp>
#include <boost/pqs/t1_quantity/types/out/frequency.hpp>
#include <boost/pqs/t1_quantity/types/out/voltage.hpp>

using namespace boost::pqs;
int main()
{
    // ambient temperature
    temperature::K    T(293);
    std::cout << "At " << T ;
    // resistance
    resistance_<int>::kR    R(10);
    std::cout << " a resistance of " <<  R ;
    // filter cut-off frequency
    frequency_<int>::kHz    f3db(10);
    std::cout << " and cut_off frequency of " << f3db;
    // resulting noise-bandwidth
    frequency::kHz          B
    = (math::constant::pi / 2) * f3db;
    std::cout << " ( noise-bandwidth " << B  << ")";
    // noise-voltage
    voltage::uV             V 
    = pow<1,2>( 4 * T * R * B * physics::boltzmanns_constant::K) ;
    
    std::cout << " gives johnson-noise voltage of " << V <<'\n';
  
}
