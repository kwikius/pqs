Up to and including pqs_3_0_6 the tests leave something to be desired. They are randomly organised and not systematic and comprehensive. This has become more and more clear as I have worked on the documentation.

I plan to systematically add tests for all the invariants and semantics in the documentation, but it takes time. The process has been started and a few of the planned new tests following the more systematic approach are in the <boost/libs/test/t1_quantity/> subdirectory. There is also a parallel set of tests which should fail at compile time. These are in the <boost/libs/test/compile_fail/t1_quantity/> subdirectory.

I also hope to make the etest more compatible with the boost build system. While making the transition I have put a Jamfile for the new tests in <libs/pqs/> subdirectory, though ultimately it will be in  <libs/pqs/test/>

Adding these more systematic tests has unearthed some problems in the implementation, and I expect they will continue to do so until the tests really are comprehensive, but they arent there yet. I hope to get them up to scratch in pqs_3_0_7.

regards
Andy Little
