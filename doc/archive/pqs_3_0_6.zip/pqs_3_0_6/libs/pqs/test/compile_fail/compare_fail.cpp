#include <boost/pqs/t1_quantity/types/force.hpp>
#include <boost/pqs/t1_quantity/types/energy.hpp>

int main()
{
    boost::pqs::force::kgf f1(1);
    boost::pqs::force::N f2(2);

    boost::pqs::force::mN ep(5);
    // These should work!
    compare(f1,f2,ep);
    compare(f2,f1,ep);
    compare(f2,f1);

    boost::pqs::energy::kJ e(20.);

    //Error: couldnt find compare
    compare(f1,e,ep);

    //Error: couldnt find compare
    compare(f1,e);
}