#include <boost/pqs/t1_quantity/types/reciprocal_time.hpp>
#include <boost/pqs/t1_quantity/types/capacitance.hpp>

int main()
{
    boost::pqs::reciprocal_time::div_s a(1);
    boost::pqs::reciprocal_time::div_ms b(2);

    // These should work!
    a <= b;
    b <= a;

    boost::pqs::capacitance::uF c(20.);

    //Error: couldnt find less
    a <= c;
    //Error: couldnt find less
    c <= a;
}