#include <libs/pqs/test/udt.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/acceleration.hpp>
#include <boost/pqs/t1_quantity/types/velocity.hpp>

/*
    t1_quantity value_type must be impilicitly convertible

    Note: 
    Currently test is revealing that t1_quantity 
    not working with UDT value_type
    
*/

namespace pqs=boost::pqs;
using my::udt;

int main()
{
    pqs::velocity_<udt<int> >::m_div_s      v1( udt<int>(1) );
    pqs::velocity_<udt<int> >::m_div_s      v2( udt<int>(1) );
    v1 + v2;

   /* pqs::velocity_<udt<int> >::mm_div_s      v3( udt<int>(1) );
    v1 + v3;*/
    // last above should work todo

    pqs::velocity::mm_div_s   v4(1);
    //v1 + v4;
}