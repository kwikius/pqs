#include <libs/pqs/test/test.hpp>

#include <boost/pqs/t1_quantity/types/out/length.hpp>
#include <boost/pqs/t1_quantity/types/out/force.hpp>
#include <boost/pqs/t1_quantity/types/out/torque.hpp>
#include <boost/pqs/t1_quantity/types/out/energy.hpp>

#include <sstream>
#include <string>
/*
   test of doc
   Demo of output of anonymous_quantity, 
   and two dimensionally_equivalent 
   but distinct quantities.
*/

namespace pqs = boost::pqs;
void dim_eq_output_test()
{
    std::ostringstream out;

    pqs::force::kN   force(1);
    pqs::length::mm  distance(1);

    // temporary result of f * d 
    // is an anonymous_quantity
    // so output is that for anonymous quantity
    out << force * distance << '\n';
    BOOST_CHECK(out.str() == "1 kg.m+2.s-2\n");

    //However can be assigned to energy
    out.str("");
    pqs::energy::J energy = force * distance;
    // output is particular to energy
    out << energy << '\n';
    BOOST_CHECK(out.str() == "1 J\n");

    // or torque
    out.str("");
    pqs::torque::N_m torque = force * distance;
    // output is particular to torque
    out << torque << '\n';
    BOOST_CHECK(out.str() == "1 N.m\n");
}
