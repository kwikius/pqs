
#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/out/length.hpp>
#include <boost/pqs/t1_quantity/types/out/force.hpp>
#include <boost/pqs/t1_quantity/types/out/torque.hpp>
#include <boost/pqs/t1_quantity/types/out/energy.hpp>

#include <string>
#include <sstream>
/*
    check add semantics work as in documentation
*/
//#include <iostream>

namespace pqs=boost::pqs;

void doc_add_semantics_test()
{
    std::ostringstream out;

    pqs::length::mm  L1(1); 
    pqs::length::m   L2(1);  

    out << L1 + L2 << '\n';
  //  std::cout << out.str();
    BOOST_CHECK( out.str() == "1001 mm\n" );
  
    out.str("");
    out << L2 + L1 << '\n';
   // std::cout << out.str();
    BOOST_CHECK( out.str() == "1001 mm\n" );
    
    out.str("");
     //larger coherent + smaller incoherent --> smaller units but coherent wins
    pqs::length::in  L3(1);  
    out << L2 + L3 << '\n';
  //  std::cout << out.str();
    BOOST_CHECK( out.str() == "102.54 cm\n" );

    out.str("");
     //small coherent + larger incoherent --> small coherent wins
    out << L1 + L3 << '\n';
  //  std::cout << out.str();
    BOOST_CHECK( out.str() == "26.4 mm\n" );

    out.str("");
    //small incoh + big incoh -> small incoh wins
    pqs::length::ft  L4(1);
    out <<  L3 + L4 << '\n';
  //  std::cout << out.str();
    BOOST_CHECK( out.str() == "13 in\n" );
    out .str("");
    pqs::force::kgf F1(1), F2(1);      // kgf is an incoherent-quantity
    out << F1 + F2 << '\n';	 // but addition of exactly matching units.
   // std::cout << out.str();
    BOOST_CHECK( out.str() == "2 kgf\n" );

    // different named_quantities
    out.str("");
    pqs::torque::N_m torque(1);
    pqs::energy::J  energy(1);
    out << torque + energy << '\n';
    BOOST_CHECK( out.str() == "2 kg.m+2.s-2\n" );
    
}




