
#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/io/input.hpp>
#include <boost/pqs/t1_quantity/types/out/time.hpp>
#include <boost/pqs/t1_quantity/types/out/length.hpp>
#include <fstream>
/*
    basic test of Input / output
    note :input probably needs work to make pqs input 
    standard conforming

*/

namespace pqs = boost::pqs;

void  io_test()
{
    pqs::time::min t1(1.5);
    pqs::time::s t2(22.2);
    pqs::length::ft  l1(.222);
    {
        std::ofstream out("data.txt");
        out << t1 << t2 << l1 ;
    }
    std::ifstream in("data.txt");
    pqs::time::min t3;
    pqs::time::s t4;
    pqs::length::ft  l2(1);
    in >> t3 >> t4 >> l2;    

    BOOST_CHECK(!in.bad());
    BOOST_CHECK(t1 == t3);
    BOOST_CHECK(t2 ==t4);
    BOOST_CHECK(l1 == l2);
 }
