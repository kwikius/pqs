
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#ifndef BOOST_PQS_MINIMAL_TEST
#include <boost/test/unit_test.hpp>
#include <boost/test/included/unit_test_framework.hpp>
#endif
void rational_test();
void t1_quantity_test();
void test_abstract_quantity();
void united_value_test();
void test_si_unit();
void test_units_data();
void test_units_data1();
void test_pq_initialise();
void test_anonymous_cast();
void test_pq_maths();
void test_int_maths();
void test_power_functions();
void pow10_test();
void small_unit_to_big_unit_assign_check();
void doc_add_semantics_test();
void dim_eq_output_test();
void io_test();

#ifdef BOOST_PQS_MINIMAL_TEST
int errors=0;
int main(int , char*[])
{
    std::cout << "starting pqs tests\n";
    t1_quantity_test();
    test_abstract_quantity();
    united_value_test();
    test_units_data();
    test_units_data1();
    test_si_unit();
    test_pq_initialise();
    test_anonymous_cast();
    test_pq_maths();
    test_int_maths();
    test_power_functions();
    pow10_test();
	rational_test();
    small_unit_to_big_unit_assign_check();
    doc_add_semantics_test();
    dim_eq_output_test();
    io_test();

    EPILOGUE
    return EXIT_SUCCESS;
}
#else
using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( int, char* [] ) 
{

    test_suite* test = BOOST_TEST_SUITE( "Unit test boost/pqs" );
    test->add(BOOST_TEST_CASE(t1_quantity_test));
    test->add(BOOST_TEST_CASE(test_abstract_quantity));
    test->add(BOOST_TEST_CASE(united_value_test));
    test->add(BOOST_TEST_CASE(test_units_data));
    test->add(BOOST_TEST_CASE(test_units_data1));
    test->add(BOOST_TEST_CASE(test_si_unit));
    test->add(BOOST_TEST_CASE(test_pq_initialise));
    test->add(BOOST_TEST_CASE(test_anonymous_cast));
    test->add(BOOST_TEST_CASE(test_pq_maths));
    test->add(BOOST_TEST_CASE(test_int_maths));
    test->add(BOOST_TEST_CASE(test_power_functions));
    test->add(BOOST_TEST_CASE(pow10_test));
	test->add(BOOST_TEST_CASE(rational_test));
    test->add(BOOST_TEST_CASE(small_unit_to_big_unit_assign_check));
    test->add(BOOST_TEST_CASE(doc_add_semantics_test));
    test->add(BOOST_TEST_CASE(dim_eq_output_test));
    test->add(BOOST_TEST_CASE(io_test));

    return test;
}
#endif
