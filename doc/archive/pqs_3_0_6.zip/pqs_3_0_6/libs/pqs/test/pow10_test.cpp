

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.
/*
    test of compile_time pow10 functions

       At what point does does std::pow fail ?
    Check this!
*/
#include <libs/pqs/test/test.hpp>
#include <boost/pqs/meta/pow10_rational.hpp>

#include <fstream>
#include <iostream>

#ifndef FP_MAX_DIFFERENCE
#define FP_MAX_DIFFERENCE 1e-15
#endif

using  boost::pqs::meta::rational;

template <typename Rational>
typename boost::pqs::meta::pow10<Rational>::result_type
pow10_test_impl()
{
    typedef typename boost::pqs::meta::pow10<Rational>::result_type result_type;
    boost::pqs::meta::pow10<Rational> p;
    BOOST_CHECK_CLOSE(static_cast<double>(p()),(std::pow(10.,static_cast<result_type>(Rational::numerator)/Rational::denominator)), FP_MAX_DIFFERENCE);
   /* std::cout << "10 ^(" << Rational::numerator << "/" << Rational::denominator << ")\n";
    std::cout << typeid(result_type).name() <<'\n';
    std::cout << p() <<'\n';;*/
    return p();
}

#define PQS_NUM_ITERS 20

#define POW10_TEST_IMPL(Sign,N,unused)\
    pow10_test_impl<rational< Sign N > >();

#define POW10_TEST_IMPL_PLUS(z,N,unused)\
    POW10_TEST_IMPL(+,N,unused);

#define POW10_TEST_IMPL_MINUS(z,N,unused)\
    POW10_TEST_IMPL(-,N,unused);


void pow10_test()
{
    /*
       At what point does does std::pow fail ?
    */
  
    BOOST_PP_REPEAT(PQS_NUM_ITERS,POW10_TEST_IMPL_PLUS,~)
}
