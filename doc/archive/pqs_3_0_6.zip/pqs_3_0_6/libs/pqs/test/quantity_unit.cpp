
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/meta/unit.hpp>
#include <boost/pqs/meta/si_units.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/equal_to.hpp>
// same si
// different si
// same inco
// different inco
// si inco
// same unit but diff tag
#include <iostream>

void test_unit()
{
    
    using boost::pqs::meta::unit;
    using boost::pqs::meta::si_unit;
    using boost::pqs::meta::binary_operation;
    using boost::pqs::meta::plus;
    using boost::pqs::meta::minus;
    using boost::pqs::meta::times;
    using boost::pqs::meta::divides;
    using boost::pqs::meta::rational;
   /* std::cout << boost::mpl::less<
        rational<1>, rational<2>
    >::value ;*/
//same si unit
    typedef unit<> default_type;
    CHECK_SI_QUANTITY_UNIT(default_type, 0);

    typedef binary_operation<
        si_unit::micro,
        plus,
        si_unit::micro 
    >::type plus_unit0;
    CHECK_SI_QUANTITY_UNIT(plus_unit0,-6);
    typedef binary_operation<
        si_unit::kilo,
        minus,
        si_unit::kilo 
    >::type minus_unit0;
    CHECK_SI_QUANTITY_UNIT(minus_unit0,3);
    typedef binary_operation<
            si_unit::nano,
            times,
            si_unit::nano 
    >::type times_unit0;
    CHECK_SI_QUANTITY_UNIT(times_unit0,-18);
      typedef binary_operation<
            si_unit::mega,
            divides,
            si_unit::mega 
    >::type divides_unit0;
    CHECK_SI_QUANTITY_UNIT(divides_unit0,0);
////////// different si unit
    typedef binary_operation<
            si_unit::nano,
            plus,
            si_unit::milli 
    >::type plus_unit1;
    CHECK_SI_QUANTITY_UNIT(plus_unit1,-9);
    typedef binary_operation<
            si_unit::nano,
            minus,
            si_unit::milli 
    >::type minus_unit1;
    CHECK_SI_QUANTITY_UNIT(minus_unit1,-9);
    typedef binary_operation<
            si_unit::nano,
            times,
            si_unit::milli 
    >::type times_unit1;
    CHECK_SI_QUANTITY_UNIT(times_unit1,-12);
      typedef binary_operation<
            si_unit::nano,
            divides,
            si_unit::milli 
    >::type divides_unit1;
    CHECK_SI_QUANTITY_UNIT(divides_unit1,-6);

// same non si unit
    typedef unit<
            rational<3>,
            rational<1020000,1000000>,
            boost::mpl::int_<1>
    > non_si_type0;
    typedef binary_operation<
        non_si_type0,
        plus,
        non_si_type0
    >::type plus_non_si_type0;
    BOOST_CHECK( (boost::is_same<
          plus_non_si_type0,
          non_si_type0
    >::value)); 
    typedef binary_operation<
        non_si_type0,
        minus,
        non_si_type0
    >::type minus_non_si_type0;
    BOOST_CHECK( (boost::is_same<
          non_si_type0,
          minus_non_si_type0
    >::value));
    typedef binary_operation<
        non_si_type0,
        times,
        non_si_type0
    >::type times_non_si_type0;
    CHECK_SI_QUANTITY_UNIT(times_non_si_type0,6);
    typedef binary_operation<
        non_si_type0,
        divides,
        non_si_type0
    >::type divides_non_si_type0;
    CHECK_SI_QUANTITY_UNIT(divides_non_si_type0,0);
// different non si
    typedef unit<
            rational<2>,
            rational<102000,1000000>,
            boost::mpl::int_<1>
    > non_si_type1;
////////
typedef binary_operation< // finest grained
        non_si_type0,
        plus,
        non_si_type1
    >::type plus_non_si_type1;
    BOOST_CHECK( (boost::is_same<
          plus_non_si_type1,
          non_si_type1
    >::value)); 
typedef binary_operation<
        non_si_type0,
        minus,
        non_si_type1
    >::type minus_non_si_type1;
    BOOST_CHECK( (boost::is_same<
          minus_non_si_type1,
          non_si_type1
    >::value)); 
 
    typedef binary_operation<
        non_si_type1,
        times,
        non_si_type0
    >::type times_non_si_type1;
    CHECK_SI_QUANTITY_UNIT(times_non_si_type1,5);
    typedef binary_operation<
        non_si_type0,
        divides,
        non_si_type1
    >::type divides_non_si_type1;
    CHECK_SI_QUANTITY_UNIT(divides_non_si_type1,1);
// special case same unit different id
   typedef unit<
            rational<2>,
            rational<1020000,1000000>,
            boost::mpl::int_<2>
    > non_si_type2;

    typedef binary_operation< 
        non_si_type1,
        plus,
        non_si_type2
    >::type plus_non_si_type2;
    BOOST_CHECK( (boost::is_same<
          plus_non_si_type2,
          non_si_type1
    >::value)); 

    typedef binary_operation< 
        non_si_type2,
        plus,
        non_si_type1
    >::type plus_non_si_type3;
    BOOST_CHECK( (boost::is_same<
          plus_non_si_type3,
          non_si_type2
    >::value)); 

    typedef binary_operation< 
        non_si_type1,
        minus,
        non_si_type2
    >::type minus_non_si_type2;
    BOOST_CHECK( (boost::is_same<
          minus_non_si_type2,
          non_si_type1
    >::value)); 

    typedef binary_operation< 
        non_si_type2,
        minus,
        non_si_type1
    >::type minus_non_si_type3;
    BOOST_CHECK( (boost::is_same<
          minus_non_si_type3,
          non_si_type2
    >::value)); 

//si v non si
    typedef binary_operation<
            si_unit::milli,
            plus,
            non_si_type0
    >::type plus_si_non_si0;
    CHECK_SI_QUANTITY_UNIT(plus_si_non_si0,-3);
    typedef binary_operation<
            si_unit::milli,
            minus,
            non_si_type0
    >::type minus_si_non_si0;
    CHECK_SI_QUANTITY_UNIT(minus_si_non_si0,-3);
    typedef binary_operation<
            si_unit::milli,
            times,
            non_si_type0
    >::type times_si_non_si0;
    CHECK_SI_QUANTITY_UNIT(times_si_non_si0,0);

    typedef binary_operation<
            si_unit::milli,
            divides,
            non_si_type0
    >::type divides_si_non_si0;
    CHECK_SI_QUANTITY_UNIT(divides_si_non_si0,-6);
    
    
 
}

