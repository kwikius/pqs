#include <libs/pqs/test/test.hpp>
#include <boost/pqs/meta/rational.hpp>
/*
    tests of pqs::meta::rational_c
*/

namespace pqs= boost::pqs;
void rational_test()
{
	BOOST_CHECK((std::numeric_limits<BOOST_PQS_INT32>::max() >= 0x7FFFFFFF) );
    typedef pqs::meta::rational<2,4> smaller;
	const static bool equal1 = boost::is_same<
        smaller::type,pqs::meta::rational<1,2> 
    >::value;
    BOOST_CHECK(equal1);
    const static bool equal1a = boost::is_same<
		smaller::type,pqs::meta::rational<1,2> 
    >::value;
    BOOST_CHECK(equal1);
	const static bool equal2 = boost::is_same<
        smaller::type, pqs::meta::rational<-10000,-20000>::type
    >::value;
    BOOST_CHECK(equal2);
	const static bool equal2a = boost::is_same<
		smaller::type, pqs::meta::rational<1,2> 
    >::value;
    BOOST_CHECK(equal2a);
    
    BOOST_CHECK(smaller::numerator == 1);  
    BOOST_CHECK(smaller::denominator == 2);
    
    typedef pqs::meta::rational<3,4> bigger;

	const static bool less = boost::mpl::less<
        smaller, bigger>::value;
    BOOST_CHECK(less);
    const static bool less_equal = boost::mpl::less_equal<
        smaller,  bigger>::value;
    BOOST_CHECK(less_equal);
    const static bool equal3 = boost::is_same<
        smaller::type, bigger::type>::value;
    BOOST_CHECK(!equal3);
    const static bool not_equal_to = boost::mpl::not_equal_to<
        smaller,  bigger>::value;
    BOOST_CHECK(not_equal_to);
    const static bool greater_equal = boost::mpl::greater_equal<
        smaller, bigger>::value;
    BOOST_CHECK(!greater_equal);
    const static bool greater = boost::mpl::greater<
        smaller, bigger>::value;
    BOOST_CHECK(!greater);
    
    typedef pqs::meta::rational<14,-16> negative;
    
    BOOST_CHECK(negative::numerator == -7);
    BOOST_CHECK(negative::denominator == 8); 
    typedef pqs::meta::binary_operation<
		smaller,pqs::meta::plus,bigger
    >::type sum;
    BOOST_CHECK(sum::numerator == 5);
    BOOST_CHECK(sum::denominator == 4);
    typedef pqs::meta::binary_operation<
		smaller,pqs::meta::minus,bigger
    >::type difference;
    BOOST_CHECK(difference::numerator == -1);
    BOOST_CHECK(difference::denominator == 4);
    typedef pqs::meta::binary_operation<
		smaller,pqs::meta::times,bigger
    >::type prod;
    BOOST_CHECK(prod::numerator == 3);
    BOOST_CHECK(prod::denominator == 8);
    typedef pqs::meta::binary_operation<
		smaller,pqs::meta::divides,bigger
    >::type div;
    BOOST_CHECK(div::numerator == 2);
    BOOST_CHECK(div::denominator== 3);
    // check reduction
    typedef pqs::meta::binary_operation<
		pqs::meta::rational<1,2>,pqs::meta::plus,pqs::meta::rational<1,2>
    >::type  reduced_result;
    BOOST_CHECK(reduced_result::numerator == 1);
    BOOST_CHECK(reduced_result::denominator == 1);

	typedef pqs::meta::unary_operation<
		pqs::meta::negate,
		prod
	>::type negated_prod;
	BOOST_CHECK(negated_prod::numerator == -3);
    BOOST_CHECK(negated_prod::denominator == 8);
	typedef pqs::meta::unary_operation<
		pqs::meta::reciprocal,
		negated_prod
	>::type reciprocal_n_prod;
	BOOST_CHECK(reciprocal_n_prod::numerator == -8);
    BOOST_CHECK(reciprocal_n_prod::denominator == 3);
}
