#include <libs/pqs/test/t1_quantity/test.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/velocity.hpp>
#include <boost/pqs/t1_quantity/types/mass.hpp>
#include <boost/pqs/t1_quantity/types/volume.hpp>
#include <boost/pqs/t1_quantity/types/energy.hpp>

/*
    check t1_quantity construction
    default ctor, value init
    copy ctor , anonymous copy ctor
    down conv value_type copy ctor
    downccast out of range checking
    downcast value init rounding checking

    see also compile_fail/t1_quantity
*/
#include <limits>

namespace pqs = boost::pqs;

void default_ctor()
{
    pqs::length::m L1;
    BOOST_CHECK( L1.numeric_value() == 0. );
    pqs::time_<int>::ps  T1;
    BOOST_CHECK( T1.numeric_value() == 0 );
}

void value_init()
{
    pqs::velocity::m_div_s V1(1.2345);
    BOOST_CHECK(V1.numeric_value() == 1.2345);

    pqs::velocity::km_div_h V2(250);
    BOOST_CHECK(V2.numeric_value() == 250); 
}

void down_cast_value_init()
{
    pqs::energy_<int>::kJ  E1(100.2);
    BOOST_CHECK(E1.numeric_value() == 100);
    
    pqs::energy_<int>::kJ  E2(-100.2);
    BOOST_CHECK(E2.numeric_value() == -100);

    pqs::energy_<int>::kJ  E3(99.49999999);
    BOOST_CHECK(E3.numeric_value() == 99);

    pqs::energy_<int>::kJ  E4(-99.49999999);
    BOOST_CHECK(E4.numeric_value() == -99);
}

void out_of_range_value_init()
{
    bool caught = false;

    try{
        pqs::volume_<double>::in3 Vo1(double(INT_MAX)+1); 
    } 
    catch ( boost::numeric::positive_overflow & ){
        caught = true;
    }
    BOOST_CHECK(caught == false);

    caught = false;
    try{
        pqs::volume_<int>::in3 Vo1(double(INT_MAX)+1); 
    } 
    catch ( boost::numeric::positive_overflow & ){
       caught = true;
    }
    BOOST_CHECK(caught);

    caught = false;
    try{
        pqs::volume_<double>::in3 Vo1(double(INT_MIN)-1); 
    } 
    catch ( boost::numeric::negative_overflow & ){
        caught = true;
    }
    BOOST_CHECK(caught == false);

    caught = false;
    try{
        pqs::volume_<int>::in3 Vo1(double(INT_MIN)-1); 
    } 
    catch ( boost::numeric::negative_overflow & ){
       caught = true;
    }
    BOOST_CHECK(caught);
}

void copy_ctor()
{
//incoherent
    pqs::velocity::mm_div_min V1(54321.12345);
    pqs::velocity::mm_div_min V2 = V1;
    BOOST_CHECK( V1.numeric_value() == V2.numeric_value()); 
//coherent
    pqs::time::ms  T1(100000.99999999);
    pqs::time::ms  T2 = T1;
    BOOST_CHECK( T2.numeric_value() == T1.numeric_value());
}

void down_cast_copy_ctor()
{
//incoherent
    pqs::velocity::mm_div_min V1(54321.12345);
    pqs::velocity_<int>::mm_div_min V2 = V1;
    BOOST_CHECK( V2.numeric_value() == 54321); 

    pqs::velocity::mm_div_min V3(-54321.12345);
    pqs::velocity_<int>::mm_div_min V4 = V3;
    BOOST_CHECK( V4.numeric_value() == -54321);

    pqs::velocity::mm_div_min V5(54321.52345);
    pqs::velocity_<int>::mm_div_min V6 = V5;
    BOOST_CHECK( V6.numeric_value() == 54322); 

    pqs::velocity::mm_div_min V7(-54321.52345);
    pqs::velocity_<int>::mm_div_min V8 = V7;
    BOOST_CHECK( V8.numeric_value() == -54322);  

//coherent
    pqs::velocity::mm_div_s Va1(54321.12345);
    pqs::velocity_<int>::mm_div_s Va2 = Va1;
    BOOST_CHECK( Va2.numeric_value() == 54321); 

    pqs::velocity::mm_div_s Va3(-54321.12345);
    pqs::velocity_<int>::mm_div_s Va4 = Va3;
    BOOST_CHECK( Va4.numeric_value() == -54321);

    pqs::velocity::mm_div_s Va5(54321.52345);
    pqs::velocity_<int>::mm_div_s Va6 = Va5;
    BOOST_CHECK( Va6.numeric_value() == 54322); 

    pqs::velocity::mm_div_s Va7(-54321.52345);
    pqs::velocity_<int>::mm_div_s Va8 = Va7;
    BOOST_CHECK( Va8.numeric_value() == -54322);  
}

void anonymous_copy_ctor()
{
    pqs::velocity::m_div_s V1 = pqs::length::m(10000) / pqs::time::s( 250);
    BOOST_CHECK_EQUAL(V1.numeric_value(), 10000./250); 

    typedef pqs::meta::binary_operation<
       pqs::length::m,
       pqs::meta::divides,
       pqs::time::s
    >::type anon;

    BOOST_CHECK( (
        boost::is_same<
        anon::abstract_quantity::id,
        boost::pqs::meta::anonymous_abstract_quantity_id
        >::value
    ));
         
}

void value_type_cast_copy_ctor()
{
    bool caught = false;

    try {
        boost::pqs::length_<double>::m L3( static_cast<double>(INT_MAX)+1 );
        boost::pqs::length_<double>::m L4 = L3;
    }
    catch ( boost::numeric::positive_overflow & ){
       caught = true;
    }
    BOOST_CHECK(caught == false);

    caught = false;
    try {
        boost::pqs::length_<double>::m L3( static_cast<double>(INT_MAX)+1 );
        boost::pqs::length_<int>::m L4 = L3;
    }
    catch ( boost::numeric::positive_overflow & ){
       caught = true;
    }
    BOOST_CHECK(caught);

    caught = false;
    try {
        boost::pqs::length_<double>::m L3( static_cast<double>(INT_MIN)-1 );
        boost::pqs::length_<double>::m L4 = L3;
    }
    catch ( boost::numeric::negative_overflow & ){
       caught = true;
    }
    BOOST_CHECK(caught==false);

    caught = false;
    try {
        boost::pqs::length_<double>::m L3( static_cast<double>(INT_MIN)-1 );
        boost::pqs::length_<int>::m L4 = L3;
    }
    catch ( boost::numeric::negative_overflow & ){
       caught = true;
    }
    BOOST_CHECK(caught);
}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( int, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs" );
    test->add(BOOST_TEST_CASE(default_ctor));
    test->add(BOOST_TEST_CASE(value_init));
    test->add(BOOST_TEST_CASE(down_cast_value_init));
    test->add(BOOST_TEST_CASE(out_of_range_value_init));
    test->add(BOOST_TEST_CASE(copy_ctor));
    test->add(BOOST_TEST_CASE(anonymous_copy_ctor));
    test->add(BOOST_TEST_CASE(down_cast_copy_ctor));
    test->add(BOOST_TEST_CASE(value_type_cast_copy_ctor));

   return test;
}
