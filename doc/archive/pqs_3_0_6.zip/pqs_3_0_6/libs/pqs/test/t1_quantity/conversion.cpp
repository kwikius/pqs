#include <libs/pqs/test/t1_quantity/test.hpp>
#include <boost/pqs/t1_quantity/types/out/pressure.hpp>
#include <utility>
/*
    check values are correct when initialising
     a t1_quantity with another of different units, both coherent and incoherent
     and optionally value_type

  

*/

/*
postcondition of a conversion: According to t1_quantity spec docs
after conversions (where rhs is the source and 'this' is the target):

this->numeric_value() == ( rhs.numeric_value() 
* pqs::meta::pow10< 
    binary_operation<
        typeof(rhs)::unit::exponent,
        minus,
        typeof(*this)::unit::exponent
    >::type
>() * rhs.units.multiplier / this->units.multiplier ).

Note that the following implementation adds some subtleties
*/

template <typename Rational>
struct eval_rational 
    : boost::pqs::meta::detail::rational_impl_eval<
        Rational::numerator, Rational::denominator
>{};

namespace pqs = boost::pqs;

template < typename To, typename From>

/*
Of course this test assumes the internal calc is correct!
It tries to exactly mirror real calc
so uses == for float comparisons!

*/
std::pair<bool,To> conv_impl(From const & rhs)
{
    typedef typename pqs::meta::arithmetic_promote<
            typename From::value_type,
            typename To::value_type
    >::type result_value_type;
    typedef eval_rational<typename From::unit::multiplier::type> from_mux_rat;
    typedef eval_rational<typename To::unit::multiplier::type> to_mux_rat;

    typedef typename pqs::meta::binary_operation<
        typename From::unit::exponent,
        pqs::meta::minus,
        typename To::unit::exponent
    >::type exp1;

// only positive exponents are used
//final calc must be adjusted to suit
    const static bool reverse_calc 
    = boost::mpl::less<
        exp1,
        pqs::meta::rational<0>
    >::value;
  
    typedef typename boost::mpl::if_c<
        reverse_calc,
        typename pqs::meta::unary_operation<
            pqs::meta::negate,
            exp1
        >::type,
        exp1            
    >::type exp2;
// type of calc intermediate types should be BOOST_PQS_INT32 if possible else float
    typedef typename boost::mpl::if_c<
        (reverse_calc || ( (exp2::numerator !=0 ) && (exp2::denominator!=1))),
        BOOST_PQS_REAL_TYPE,
        result_value_type
    >::type exp_result_type;
    
    typedef typename pqs::detail::coherent_exponent<
            exp2::numerator, exp2::denominator
    >::template eval<
       exp_result_type
    > exp_eval;
    
    typedef typename boost::pqs::meta::arithmetic_promote<
        typename from_mux_rat::result_type,
        typename to_mux_rat::result_type
    >::type prom1;
    typedef typename boost::mpl::if_<
        boost::is_same<
           typename From::unit::multiplier::type,
            pqs::meta::rational<1>
        >,
        BOOST_PQS_INT32,
        BOOST_PQS_REAL_TYPE
    >::type min_rational;

    typedef typename boost::pqs::meta::arithmetic_promote<
         min_rational,prom1
    >::type rat_eval_type;

    from_mux_rat from_mux_;
    to_mux_rat to_mux_;
    exp_eval  exp;
    exp_result_type exp_result = exp();
    rat_eval_type from_mux = from_mux_();
    rat_eval_type to_mux = to_mux_();
    
// comparisons provide automatic promtions
// could that give erroneous results
// so convert From.numeric_value() from source value_type to target value_type 
// before comparison
// uses round nearest
    typename pqs::quantity_traits::value_type_converter<
        typename To::value_type,
        typename From::value_type
    > convert;
    typename To::value_type cmp_val;
    if(!reverse_calc ){
        cmp_val = convert( rhs.numeric_value() * exp() * from_mux / to_mux );
    }
    else{
        cmp_val = convert( (rhs.numeric_value() / exp()) * from_mux / to_mux );
    }

    To to = rhs;  
//std::cout << "from = " << rhs << '\n';
//std::cout << "to = " << to << '\n';
    bool result1 = to.numeric_value() == cmp_val;

    std::pair<bool,To> result(result1,to);
    return result;
}


// conversion_test
//{
//    /*
//    coherent --> less coherent
//    coherent --> greater incoherent
//    coherent --> greater incoherent
//
//    incoherent --> greater incoherent
//    incoherent --> less incoherent
//    incoherent --> greater coherent
//    inccoherent --> greater coherent
//    */
// coherent --> greater coherent
void conv_coh_gt_coh()
{
    bool r1 
    = conv_impl<pqs::pressure::MPa>( pqs::pressure::Pa(5000000)).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure::MPa>( pqs::pressure::mPa(1.1e9)).first;
    BOOST_CHECK(r2);

    bool r3 
    = conv_impl<pqs::pressure::cPa>( pqs::pressure::fPa(10234.8976)).first;
    BOOST_CHECK(r3);

    bool r4 
    = conv_impl<pqs::pressure::MPa>( pqs::pressure::kPa(9e20)).first;
    BOOST_CHECK(r4); 

    bool r5
    = conv_impl<pqs::pressure::MPa>( pqs::pressure::Pa(10)).first;
    BOOST_CHECK(r5);
}
//coherent -> greater coherent and floatpt to BOOST_PQS_INT32
void conv_coh_gt_coh_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::kPa>( pqs::pressure::Pa(10)).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::MPa>( pqs::pressure::mPa(10)).first;
    BOOST_CHECK(r2);

    bool r3 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::cPa>( pqs::pressure::fPa(10)).first;
    BOOST_CHECK(r3);

    bool r4 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::MPa>( pqs::pressure::kPa(10)).first;
    BOOST_CHECK(r4); 
}
// coherent --> less coherent
void conv_coh_less_coh()
{
    bool r1 
    = conv_impl<pqs::pressure::Pa>( pqs::pressure::MPa(1e7)).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure::mPa>( pqs::pressure::MPa(232)).first;
    BOOST_CHECK(r2);

    bool r3 
    = conv_impl<pqs::pressure::fPa>( pqs::pressure::cPa(-34)).first;
    BOOST_CHECK(r3);

    bool r4 
    = conv_impl<pqs::pressure::kPa>( pqs::pressure::MPa(6789)).first;
    BOOST_CHECK(r4); 
}

void conv_coh_less_coh_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::Pa>( pqs::pressure::kPa(123)).first;
    BOOST_CHECK(r1);

    bool r2 = false;
    try{
         conv_impl<pqs::pressure_<BOOST_PQS_INT32>::Pa>( pqs::pressure::MPa(9876)).first;
    }
    catch(boost::numeric::positive_overflow &){
        r2 = true;
    }
    BOOST_CHECK(r2);
    
    bool r3 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::mPa>( pqs::pressure::cPa(-34)).first;
    BOOST_CHECK(r3);

    bool r4 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::kPa>( pqs::pressure::MPa(67)).first;
    BOOST_CHECK(r4); 
}
// coherent to greater incoherent
void conv_coh_to_gt_inco()
{
    bool r1 
    = conv_impl<pqs::pressure::cmHg>( pqs::pressure::mPa(1.676)).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure::mbar>( pqs::pressure::pPa(25e3)).first;
    BOOST_CHECK(r2);

    bool r3
    = conv_impl<pqs::pressure::dyn_div_cm2>( pqs::pressure::mPa(.0008)).first;
    BOOST_CHECK(r3);
}
// coherent  to greater incoherent int
void conv_coh_to_gt_inco_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::cmHg>( pqs::pressure::mPa(1.676)).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::mbar>( pqs::pressure::mPa(25.034)).first;
    BOOST_CHECK(r2);

    bool r3
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::dyn_div_cm2>( pqs::pressure::mPa(.0008)).first;
    BOOST_CHECK(r3);
}

    //coherent --> less incoherent
    //incoherent --> greater incoherent
    //incoherent --> less incoherent
    //incoherent --> greater coherent
    //inccoherent --> greater coherent

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs" );
    test->add(BOOST_TEST_CASE(conv_coh_gt_coh));
    test->add(BOOST_TEST_CASE(conv_coh_gt_coh_int));
    test->add(BOOST_TEST_CASE(conv_coh_less_coh));
    test->add(BOOST_TEST_CASE(conv_coh_less_coh_int));
    test->add(BOOST_TEST_CASE(conv_coh_to_gt_inco));
    test->add(BOOST_TEST_CASE(conv_coh_to_gt_inco_int));
    

    return test;
}
