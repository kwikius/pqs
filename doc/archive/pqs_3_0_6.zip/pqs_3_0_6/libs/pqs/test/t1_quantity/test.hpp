#ifndef BOOST_LIBS_PQS_TEST_T1_QUANTITY_HPP_INCLUDED
#define BOOST_LIBS_PQS_TEST_T1_QUANTITY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See ../../libs/pqs/index.html for documentation.

//epsilon for BOOST_CHECK_CLOSE
#ifndef FP_MAX_DIFFERENCE
#define FP_MAX_DIFFERENCE 1e-12
#endif

#include <boost/test/test_tools.hpp>
#include <boost/test/floating_point_comparison.hpp>
#include <boost/test/unit_test.hpp>
#include <boost/test/included/unit_test_framework.hpp>

#endif
