
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.
#include <libs/pqs/test/test.hpp>
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
#include <boost/pqs/typeof_register.hpp>
#endif
#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/t1_quantity/operations.hpp>
#include <boost/preprocessor/comma.hpp>

#include <iostream>

namespace boost{namespace pqs{
 
    namespace aux{

        typedef boost::pqs::meta::rational<0> zero;
        typedef boost::pqs::meta::rational<1,4> one_quarter;
        typedef boost::pqs::meta::rational<1,3> one_third;
        typedef boost::pqs::meta::rational<1,2> one_half;
        typedef boost::pqs::meta::rational<2,3> two_thirds;
        typedef boost::pqs::meta::rational<3,4> three_quarters;
        typedef boost::pqs::meta::rational<1> one;       
       
    typedef boost::pqs::meta::abstract_quantity <
            boost::pqs::meta::dimension< 
                aux::one_quarter,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::three_quarters
            >,
            boost::mpl::int_<1>
    > type;

    typedef ::boost::pqs::meta::abstract_quantity <
            boost::pqs::meta::dimension<
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero
            >,
            boost::mpl::int_<0>
    > dimless_type;
     typedef ::boost::pqs::meta::abstract_quantity <
           boost::pqs::meta::dimension< 
                aux::one,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero
            >,
            boost::mpl::int_<1>
    > length_type0;

  
    typedef  boost::pqs::meta::unit<
        boost::pqs::meta::rational<3>
    > coh_unit3;
    using boost::pqs::detail::united_value;
    typedef  boost::pqs::meta::unit<
        boost::pqs::meta::rational<0>
    > coh_unit0;
    typedef  boost::pqs::meta::unit<
        boost::pqs::meta::rational<-3>
    > coh_unitn3;

    typedef  boost::pqs::meta::unit<
        boost::pqs::meta::rational<3>
    > coh_unit3;
    }//aux
}}//boost::pqs

struct dummyA;
void  t1_quantity_test()
{
    typedef boost::pqs::t1_quantity<
        boost::pqs::aux::length_type0,
        boost::pqs::aux::coh_unit0,
        double
    > t11;

    typedef boost::pqs::t1_quantity<
        boost::pqs::aux::length_type0,
        boost::pqs::aux::coh_unit3,
        double
    > t12;
    
    BOOST_CHECK( (boost::pqs::meta::is_valid_binary_operation<
        dummyA,boost::pqs::meta::times,double
    >::type::value == false));
    t11 v1 = t12(2.);
    BOOST_CHECK_CLOSE( v1.numeric_value(),2000., 1e-15);

    t12 v2 = t11(2);
    BOOST_CHECK_CLOSE( v2.numeric_value(),.002, 1e-15);
    v2 = t11(3);
    BOOST_CHECK_CLOSE( v2.numeric_value(),.003, 1e-15);
    v2 = t12(5.009);
    BOOST_CHECK_CLOSE( v2.numeric_value(),5.009, 1e-15);   
    v1 = v1 + v1;
    BOOST_CHECK_CLOSE( v1.numeric_value(),4000., 1e-15);   
    v1 + v2;
	//BOOST_CHECK_CLOSE( v2.numeric_value(),5.009, 1e-15);

    v2 + v2;
    v1 - v1;
    v1 - v2;
    typedef boost::pqs::meta::unary_operation<
        boost::pqs::meta::reciprocal,
        boost::pqs::aux::length_type0
    >::type type1;     
   typedef boost::pqs::t1_quantity<
        type1,
        boost::pqs::aux::coh_unit0,
        double
    > tn11;
    // dimensionless multiply
     v1 * tn11();

    typedef
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_TYPEOF( (v1 * tn11()) ) 
#else
    boost::pqs::meta::binary_operation<
        t11,boost::pqs::meta::times,tn11
    >::type 
#endif
    typeof_v1xn1;
    BOOST_CHECK( (boost::is_same<typeof_v1xn1 BOOST_PP_COMMA() double>::value));   

    //    dimensionfull multiply
    v1 * v1;
///////////////
   BOOST_CHECK_CLOSE( (v1 * v1).numeric_value(),16000000., 1e-15);
///////////////
    // scalar multiply;
    v1 = v1 * 2; 
    BOOST_CHECK_CLOSE( (v1 * 2).numeric_value(),16000., 1e-15);
    v2 = 3 * v2;
    BOOST_CHECK_CLOSE( ( 3 * v2 ).numeric_value(),45.081, 1e-15);
    double valn = v1 / v2;
    v1 / tn11(1);
    v1 /2;
    2 / v2;

    BOOST_CHECK( (boost::pqs::pow<2>(v2) == v2 * v2) );
    BOOST_CHECK( (boost::pqs::pow<2>(v2) == boost::pqs::pow<2,1>(v2)) );
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO( val10 ,( boost::pqs::pow<2,1>(v2)));
    BOOST_AUTO( valll ,( boost::pqs::sqrt(2.)));
    BOOST_AUTO( vall2 , (v2 * v2));
    BOOST_AUTO( val3 , (v2 / 2));
    BOOST_AUTO( val4 , (v2 / v1) );
    t11 temp1(1);
    BOOST_AUTO( val5 , (boost::pqs::sqrt(temp1)));
    BOOST_AUTO( val6 , (boost::pqs::sqrt(v2)));
#else
     boost::pqs::pow<2,1>(v2);
     boost::pqs::sqrt(2.);
     v2 * v2;
     v2 / 2;
     2 / v1;
    t11 temp1(1);
    boost::pqs::sqrt(temp1);
    boost::pqs::sqrt(v2);
#endif

    v1 += v2;
    v1 += v1;
    v1 -= v2;
    v2 -= v2;
    
    v2 *= 2;
    v1 *= 2.;

    v1 /= 3.7;
    v2/= 3;

    v1 ++;
    ++v1;
    v1 --;
    --v2;
}
