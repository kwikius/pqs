// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
#include <boost/pqs/typeof_register.hpp>
#endif
#include <boost/pqs/t1_quantity/operations/anonymous_cast.hpp>
#include <boost/pqs/t1_quantity/types/pressure.hpp>
#include <boost/pqs/t1_quantity/types/torque.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
#include <boost/pqs/t1_quantity/types/area.hpp>
#include <boost/pqs/t1_quantity/types/volume.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/frequency.hpp>
#include <boost/pqs/t1_quantity/types/velocity.hpp>
#include <boost/pqs/t1_quantity/types/energy.hpp>
#include "boost/type_traits/is_same.hpp"

namespace pqs = boost::pqs;
void test_pq_initialise()
{
    // check dimensionless type --> numeric
    typedef pqs::t1_quantity<
        pqs::meta::abstract_quantity<
            pqs::meta::dimension<
                pqs::meta::rational<0>,
                pqs::meta::rational<0>,
                pqs::meta::rational<0>,
                pqs::meta::rational<0>,
                pqs::meta::rational<0>,
                pqs::meta::rational<0>,
                pqs::meta::rational<0>
            >,
            boost::mpl::int_<1>
        >,
        pqs::meta::unit<
            pqs::meta::rational<2>,
            pqs::meta::rational<1>,
            boost::mpl::int_<1>
        >,
        long double
    >::type null_qty_type;
    BOOST_CHECK((boost::is_same<null_qty_type,long double>::value));
  
    pqs::pressure::Pa a,b(1.9999999);
    a = b;
    pqs::pressure::Pa c = a;
    BOOST_CHECK( a == b && b == c);
    // compare tests
    BOOST_CHECK(compare( a, b, pqs::pressure::Pa(1e-6) ) == 0);
    BOOST_CHECK(compare(-a, -b, -pqs::pressure::Pa(1e-6) ) == 0);
    BOOST_CHECK(compare( a, b, -pqs::pressure::Pa(1e-6) ) == 0);
    BOOST_CHECK(compare(-a, -b, pqs::pressure::Pa(1e-6) ) == 0);

    BOOST_CHECK( a.numeric_value() == b.numeric_value()  
    &&  b.numeric_value() == c.numeric_value() );
    pqs::pressure::mbar d(1000);
    pqs::pressure::bar e(1);
    BOOST_CHECK(d == e);
    double ratio = d / e;
    BOOST_CHECK(ratio == 1.);
    BOOST_CHECK(d - e == pqs::pressure::bar() );
    BOOST_CHECK(e - d == pqs::pressure::mbar() );
    //compare tests
    BOOST_CHECK( ( compare( d, e, pqs::pressure::mbar(1e-6) ) == 0 ) );
    BOOST_CHECK( ( compare(-d, -e, -pqs::pressure::mbar(1e-6) ) == 0 ) );
    BOOST_CHECK( ( compare( d, e, -pqs::pressure::mbar(1e-6) ) == 0 ) );
    BOOST_CHECK( ( compare(-d, -e, pqs::pressure::mbar(1e-6) ) == 0 ) );

    ///
    pqs::pressure::bar neg_e = -e;
    BOOST_CHECK( neg_e == +neg_e);
    BOOST_CHECK( neg_e == -e);
    BOOST_CHECK( e + neg_e == pqs::pressure::bar() );
    BOOST_CHECK( neg_e + e == pqs::pressure::mbar() );
    BOOST_CHECK( d + neg_e == pqs::pressure::mbar() );
    BOOST_CHECK( neg_e + d == pqs::pressure::bar() );
    d *= 2;
    ratio = e/d;
    BOOST_CHECK(ratio == 0.5);
    e/=2.;
    ratio = d/e;
    BOOST_CHECK(ratio == 4.);

    pqs::torque::mN_m torque(1);
    BOOST_CHECK(torque++ == pqs::torque::mN_m(1.) );
    BOOST_CHECK(torque == pqs::torque::mN_m(2.) );
    BOOST_CHECK(++torque == pqs::torque::mN_m(3.) );
    BOOST_CHECK(torque-- == pqs::torque::mN_m(3.));
    BOOST_CHECK(torque == pqs::torque::mN_m(2.));
    BOOST_CHECK(--torque == pqs::torque::mN_m(1.));

    pqs::resistance::kR  same(2.5);
    pqs::resistance::kR  same1 = same - pqs::quantity_traits::epsilon<pqs::resistance::kR>()/1.1;
    pqs::resistance::kR  same2 = same + pqs::quantity_traits::epsilon<pqs::resistance::kR>()/1.1;
    BOOST_CHECK( same == same);
    BOOST_CHECK( same1 == same);
    BOOST_CHECK( same == same1);
    BOOST_CHECK( same2 == same);
    BOOST_CHECK( same == same2);
    pqs::resistance::kR smaller(2.4);
    BOOST_CHECK(smaller < same);

    // check sign of epsilon doesnt matter
    BOOST_CHECK(  compare(smaller,same,pqs::resistance::kR(.01) ) < 0 );  
    BOOST_CHECK(  compare(-smaller,-same,pqs::resistance::kR(.01) )  > 0 );
    BOOST_CHECK(  compare(smaller,same,-pqs::resistance::kR(.01)) < 0 ); 
    BOOST_CHECK(  compare(-smaller,-same,-pqs::resistance::kR(.01)) > 0 );
    BOOST_CHECK(  compare(same,smaller,pqs::resistance::kR(.01)) > 0 );
    BOOST_CHECK(  compare(same,smaller,-pqs::resistance::kR(.01)) > 0  ); 
    BOOST_CHECK(  compare(-same,-smaller,pqs::resistance::kR(.01)) < 0 );
    BOOST_CHECK(  compare(-same,-smaller,-pqs::resistance::kR(.01)) < 0 );

    BOOST_CHECK(smaller <= same);
    BOOST_CHECK(smaller != same);
    BOOST_CHECK(same != smaller);
    BOOST_CHECK(same > smaller);
    BOOST_CHECK(same >= smaller);

    pqs::resistance::R  samex(2500);
    BOOST_CHECK( samex == same);
    BOOST_CHECK( same == samex);

    pqs::resistance::R smallerx(2400);

    BOOST_CHECK(smallerx < same);
    BOOST_CHECK(smallerx <= same);
    BOOST_CHECK(smallerx != same);
    BOOST_CHECK(same != smallerx);
    BOOST_CHECK(same > smallerx);
    BOOST_CHECK(same >= smallerx);

    pqs::length_<int>::mm length1(5.3);
    BOOST_CHECK(length1.numeric_value() ==5);
    pqs::length_<int>::mm length2(5.6);
    BOOST_CHECK(length2.numeric_value() ==6);
    
}

void test_anonymous_cast()
{
     pqs::torque::N_m N_m(1.342e9);
    // check anonymous_cast function
    pqs::energy::J J = pqs::anonymous_cast(N_m) ;
    BOOST_CHECK( J == pqs::anonymous_cast(N_m) ); 
    BOOST_CHECK( N_m == pqs::anonymous_cast(J) ); 
    BOOST_CHECK( J.numeric_value() == N_m.numeric_value() );
}

void test_pq_maths()
{
    pqs::length::m m(3.5);
    pqs::length::mm mm = m;

    // should be exactly equivalent calc here
    BOOST_CHECK (mm == m );
    BOOST_CHECK (m == mm );
    BOOST_CHECK( mm.numeric_value() == m.numeric_value() * 1000); 
    BOOST_CHECK( m.numeric_value() == mm.numeric_value() / 1000); 
    m *= 3;
    BOOST_CHECK(m.numeric_value() == 10.5) ;
    mm /= 3;
    BOOST_CHECK(mm.numeric_value() ==  3500. / 3);

    // incoherent units only to 6 decimals
    pqs::length::in in( 144. );
    pqs::length::ft ft = in;
 
    BOOST_CHECK_CLOSE( ft.numeric_value(),in.numeric_value()/12., FP_MAX_DIFFERENCE); 
    BOOST_CHECK_CLOSE( ft.numeric_value(),12.0, FP_MAX_DIFFERENCE );
    BOOST_CHECK_CLOSE(1.0, ft/in, FP_MAX_DIFFERENCE);
    BOOST_CHECK_CLOSE(1.0, in/ft, FP_MAX_DIFFERENCE);
    pqs::length::yd yd(1);
    in = yd;
    BOOST_CHECK_CLOSE(in.numeric_value(), 36.,FP_MAX_DIFFERENCE);
    BOOST_CHECK_CLOSE( in / yd , 1., FP_MAX_DIFFERENCE);
    BOOST_CHECK_CLOSE( yd / in , 1., FP_MAX_DIFFERENCE);
    pqs::length::mi mi(2);
    yd = mi;
    BOOST_CHECK_CLOSE( yd / mi , 1., FP_MAX_DIFFERENCE);
    BOOST_CHECK_CLOSE( mi / yd , 1., FP_MAX_DIFFERENCE);
    BOOST_CHECK_CLOSE( yd.numeric_value(), 1760. * 2 ,FP_MAX_DIFFERENCE);
    pqs::length::yd yd1 = in /36;
    BOOST_CHECK_CLOSE (yd1.numeric_value(), 1/36., FP_MAX_DIFFERENCE);
    
    pqs::velocity::m_div_s v;
    BOOST_CHECK( !v );
    // two nots used as boolean true;
    BOOST_CHECK( !!m );
    BOOST_CHECK( + mm > -mm );
    BOOST_CHECK( + mm >= -mm );
    BOOST_CHECK( - mm  <= mm );
    BOOST_CHECK( v >= v);
    BOOST_CHECK( v <= v);
}
void test_int_maths()
{
 //check integer calcs accuracy
 //only useful for coherent-units. Incoherent units use float temporary

    pqs::pressure_<int>::mPa P1(5000);
    pqs::pressure_<int>::Pa  P2(5);
    BOOST_CHECK( P1/P2 == 1);
    BOOST_CHECK( P2/P1 == 1);
    BOOST_CHECK( P2 - P1 == pqs::pressure_<int>::Pa(0));
    BOOST_CHECK( P1 - P2 == pqs::pressure_<int>::Pa(0));
    BOOST_CHECK (!(P1 - P2));
    BOOST_CHECK (!(P2 - P1));
    BOOST_CHECK( P1 == P2);
    BOOST_CHECK( P2 == P1);
    //power functions cause promotion from integer type
    BOOST_CHECK( (pqs::pow<1,2>(P2 * P2)).numeric_value() == 5.); 
    BOOST_CHECK( (pqs::pow<2>(P2)).numeric_value() == 25.); 

    // check compile on large exponents with int value_type 
    pqs::frequency_<int>::GHz f(100);
    pqs::time_<int>::ns     t(5);
    int  count = t * f;
    BOOST_CHECK( count == 500 );
}
void test_power_functions()
{
//power functions
///////////////////////////////////
    pqs::length::m  L1(10.);
    BOOST_CHECK((boost::pqs::pow<0>(L1/3) == 1));
    //std::cout << typeid (boost::pqs::pow<0,1>(L1/3)).name() <<'\n';
    BOOST_CHECK_CLOSE ( 
        (pqs::pow<-1>(L1)).numeric_value() , 
        (1/L1).numeric_value(), 
        FP_MAX_DIFFERENCE
    ); 
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    typedef BOOST_TYPEOF( (pqs::pow<-1>(L1)) ) recipL1_type1;
    typedef BOOST_TYPEOF(1 / L1) recipL1_type2;
#else
    typedef pqs::meta::binary_operation<
        pqs::length::m,
        pqs::meta::pow,
        pqs::meta::rational<-1>
    >::type recipL1_type1;
    typedef pqs::meta::binary_operation<
        int,
        pqs::meta::divides,
        pqs::length::m
    >::type  recipL1_type2;
#endif
    BOOST_CHECK( (boost::is_same<recipL1_type1,recipL1_type2>::value != 0));
    BOOST_CHECK( (boost::is_same<pqs::length::m,recipL1_type2>::value ==0));

// check type of pow<1>
    pqs::length::m  Lt = boost::pqs::pow<1,1>(L1);
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    typedef BOOST_TYPEOF((boost::pqs::pow<1,1>(L1))) L1_identity_type;
#else
    typedef pqs::meta::binary_operation<
        pqs::length::m,
        pqs::meta::pow,
        pqs::meta::rational<1>
    >::type L1_identity_type;
#endif
    BOOST_CHECK( (boost::is_same<L1_identity_type,pqs::length::m>::value != 0));

// check type of pow<0> is int
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    typedef BOOST_TYPEOF((boost::pqs::pow<1,1>(L1))) pow0_type;
#else
    typedef pqs::meta::binary_operation<
        pqs::length::m,
        pqs::meta::pow,
        pqs::meta::rational<0>
    >::type pow0_type;
#endif
    BOOST_CHECK((boost::is_same<pow0_type,int>::value != 0));

    // should be exactly this calc
    BOOST_CHECK ( ((pqs::pow<3,2>(L1)).numeric_value() == std::pow(10., 3./2)));

    pqs::area::m2   A1 = pqs::pow<2>(L1);
    BOOST_CHECK( (A1.numeric_value() == 100.));

    pqs::volume::m3 V1 = pqs::pow<3,1>(L1);
    BOOST_CHECK(( V1.numeric_value() == 1000.));

   //inevitable loss of accuracy in roots
    pqs::area::m2 A2 = pqs::pow<2,3>(V1);
    BOOST_CHECK_CLOSE (A2.numeric_value() , 100., FP_MAX_DIFFERENCE);

    pqs::length::m L2 = pqs::pow<1,3>(V1);
    BOOST_CHECK_CLOSE (L2.numeric_value(),10., FP_MAX_DIFFERENCE);

    // should be exact calc
    pqs::area::mm2 A3 = pqs::pow<2,1>(L1);
    BOOST_CHECK( A3.numeric_value() == 100000000.);
    pqs::volume::km3 V3 = pqs::pow<3,1>(L1);
    BOOST_CHECK( V3.numeric_value() == 1e-6);

    boost::pqs::area::in2 A4 = boost::pqs::length::cm(100) * boost::pqs::length::cm(100);
    boost::pqs::length::in L4 = boost::pqs::sqrt(A4);
    BOOST_CHECK_CLOSE( L4.numeric_value(), 100. / 2.54, 0.01);
    boost::pqs::length::cm L4A = L4;
    BOOST_CHECK_CLOSE(L4A.numeric_value(),100., FP_MAX_DIFFERENCE);
}

void range_test()
{
    /*
        bad_numeric_cast is base for the others... try all 3.
    */
    bool caught = false;
    try {
        boost::pqs::length_<double>::m L3( static_cast<double>(INT_MAX)+1 );
        boost::pqs::length_<int>::m L4 = L3;
    }
    catch ( boost::numeric::bad_numeric_cast & ){
       caught = true;
    }
    BOOST_CHECK(caught);
    caught = false;
    try {
        boost::pqs::length_<double>::m L3( static_cast<double>(INT_MAX)+1 );
        boost::pqs::length_<int>::m L4 = L3;
    }
    catch ( boost::numeric::positive_overflow & ){
       caught = true;
    }
    BOOST_CHECK(caught);
    caught = false;
    try {
        boost::pqs::length_<double>::m L3( static_cast<double>(INT_MIN)-1 );
        boost::pqs::length_<int>::m L4 = L3;
    }
    catch ( boost::numeric::negative_overflow & ){
       caught = true;
    }
    BOOST_CHECK(caught);
}

void small_unit_to_big_unit_assign_check()
{
//    std::cout << std::numeric_limits<BOOST_PQS_REAL_TYPE>::digits10;
    
    boost::pqs::length::km big = boost::pqs::length::um(1);
    BOOST_CHECK_CLOSE(big.numeric_value(),1e-9, FP_MAX_DIFFERENCE);

    boost::pqs::length::km big1 = boost::pqs::length::nm(1);
    BOOST_CHECK_CLOSE(big1.numeric_value(),1e-12, 1e-15);

    boost::pqs::length::km big2 = boost::pqs::length::pm(1);
    BOOST_CHECK_CLOSE(big2.numeric_value(),1e-15, 1e-18);
    
    boost::pqs::length::km big3 = boost::pqs::length::fm(1);
    BOOST_CHECK_CLOSE(big3.numeric_value(),1e-18, 1e-24);

    boost::pqs::length::Mm big4 = boost::pqs::length::um(1);
    BOOST_CHECK_CLOSE(big4.numeric_value(),1e-12, 1e-15);

    boost::pqs::length::Mm big5 = boost::pqs::length::fm(1);
    BOOST_CHECK_CLOSE(big5.numeric_value(),1e-21, 1e-27);
    
}


