#ifndef BOOST_PQS_TEST_MY_UDT_HPP_INCLUDED
#define BOOST_PQS_TEST_MY_UDT_HPP_INCLUDED

#include <boost/typeof/typeof.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_convertible.hpp>
//#include <boost/static_assert.hpp>
#include <iostream>
#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP()
/*  
    dummy udt
*/


namespace my{
    template <typename T>
    struct udt;
}

BOOST_TYPEOF_REGISTER_TEMPLATE(my::udt,1);

namespace meta{
    template <typename Lhs, char Op, typename Rhs>
    struct bin_op;


    template<typename Lhs, typename Rhs>
    struct bin_op<Lhs,'+',Rhs>
    {
        typedef BOOST_TYPEOF_TPL(Lhs() + Rhs()) type;
    };
    template <typename Lhs, char Op, typename Rhs>
    struct bin_op;


    template<typename Lhs, typename Rhs>
    struct bin_op<Lhs,'-',Rhs>
    {
        typedef BOOST_TYPEOF_TPL(Lhs() - Rhs()) type;
    };

    template<typename Lhs, typename Rhs>
    struct bin_op<Lhs,'*',Rhs>
    {
        typedef BOOST_TYPEOF_TPL(Lhs() * Rhs()) type;
    };

    template<typename Lhs, typename Rhs>
    struct bin_op<Lhs,'/',Rhs>
    {
        typedef BOOST_TYPEOF_TPL(Lhs() / Rhs(1)) type;
    };

    template<typename Lhs, typename Rhs>
    struct bin_op<Lhs,'^',Rhs>
    {
        typedef BOOST_TYPEOF_TPL(Lhs() - Rhs()) type;
    };

}

BOOST_TYPEOF_REGISTER_TEMPLATE(my::udt,1);
namespace my{

    template <typename T>
    struct udt{
        typedef T value_type;
    private:
        T m_value;
    public:
        T get_value()const{ return m_value;}

        udt():m_value(1){} // no division by zero wanted
        explicit udt(T const & in) : m_value(in){}

        //template <typename T1>
        //udt ( T1 const & in, typename boost::enable_if<
        //            boost::is_convertible<T1,T>, int*
        //        >::type =0
        //): m_value(in){}

        //template <typename T1>
        //udt(udt<T1>  const &in): m_value(in.get_value()){}


        template <typename T1>
        udt<BOOST_TYPEOF_TPL(T(1) + T1(1))>
        operator +(  udt<T1> const & in)const
        {
            udt<BOOST_TYPEOF_TPL(T(1) + T1(1))> result(m_value + in.get_value());
            return result;
        }

        //template <typename T1>
        //udt<BOOST_TYPEOF_TPL(T(1) - T1(1))>
        //operator -(  udt<T1> const & in)const
        //{
        //    udt<BOOST_TYPEOF_TPL(T(1) - T1(1))> result(m_value - in.get_value());
        //    return result;
        //}

        //template <typename T1>
        //udt<BOOST_TYPEOF_TPL(T(1) * T1(1))>
        //operator *(  udt<T1> const & in)const
        //{
        //    udt<BOOST_TYPEOF_TPL(T(1) * T1(1))> result(m_value * in.get_value());
        //    return result;
        //}

        //template <typename T1>
        //udt<BOOST_TYPEOF_TPL(T(1) / T1(1))>
        //operator /(  udt<T1> const & in)const
        //{
        //    udt<BOOST_TYPEOF_TPL(T(1) / T1(1))> result(m_value / in.get_value());
        //    return result;
        //}

    }; 

    template <typename T>
    std::ostream & operator <<(std::ostream& os, udt<T> const & u)
    {
        os << "{" << u.get_value() << "}";
        return os;
    }
}

#endif
