
#ifndef BOOST_PQS_ANGLE_ANGLE_HPP_INCLUDED
#define BOOST_PQS_ANGLE_ANGLE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
/// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    interface betweeen mathematic_angle and fraction_of_revolution
    together with angle container giving convenient typedefs for
    angles
*/
#include <boost/pqs/config.hpp>
#include <boost/pqs/t1_quantity/constants/constant.hpp>
#include <boost/pqs/angle/mathematic_angle.hpp>
#include <boost/pqs/angle/fraction_of_revolution.hpp>
#include <boost/pqs/concept_checking.hpp>

namespace boost{namespace pqs{

// ctor for rad from fraction-of-rev
    template<
        typename Extent,
        typename Value_type
    >
    template<
        typename ReciprocalFraction,
        typename Value_type1
    >
    inline
    mathematic_angle<
        Extent,
        Value_type
    > ::mathematic_angle(
        fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            Value_type1
        > const & fr)
    : m_value ((Extent::numerator == 1)
        ?(fr.numeric_value() 
            * 2 * boost::pqs::math::constant_<Value_type>::pi 
                / boost::pqs::meta::eval_rational< ReciprocalFraction>()())
        :(fr.numeric_value() 
            /( 2 * boost::pqs::math::constant_<Value_type>::pi 
                * boost::pqs::meta::eval_rational< ReciprocalFraction>()())) 
     ){
    ///////////////////////////Concept Check//////////////////////////////////////
    // limit conversion to mathematic_angle and mathematic_angle ^-1
        boost::pqs::concept_checking::Assert<
             (((Extent::numerator == 1) && (Extent::denominator == 1)) 
            ||  ((Extent::numerator == -1) && (Extent::denominator == 1))) >();
    //////////////////////Concept Check //////////////////////////////////////////
    }
}}//boost::pqs

namespace boost{ namespace pqs{namespace meta{

// rad * fr
    template<
        typename ExtentL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::mathematic_angle<
            ExtentL,Value_typeL
        >,
        times,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            typename binary_operation<
                ExtentL,
                plus,
                ExtentR
            >::type,
            typename binary_operation<
                Value_typeL,
                times,
                Value_typeR
            >::type
        >::type type;
    };
// rad / fr
    template<
        typename ExtentL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::mathematic_angle<
            ExtentL,
            Value_typeL
        >,
        divides,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            typename binary_operation<
                ExtentL,
                minus,
                ExtentR
            >::type,
            typename binary_operation<
                Value_typeL,
                divides,
                Value_typeR
            >::type
        >::type type;
    };

//fr * rad    
    template<
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        times,
        boost::pqs::mathematic_angle<
            ExtentR,
            Value_typeR
        >
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            typename binary_operation<
                ExtentL,
                plus,
                ExtentR
            >::type,
            typename binary_operation<
                Value_typeL,
                times,
                Value_typeR
            >::type
        >::type type;
    };
// fr / rad
    template<
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        divides,
        boost::pqs::mathematic_angle<
            ExtentR,
            Value_typeR
        >
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            typename binary_operation<
                ExtentL,
                minus,
                ExtentR
            >::type,
            typename binary_operation<
                Value_typeL,
                divides,
                Value_typeR
            >::type
        >::type type;
    };
// fr + rad
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >,
        plus,
        boost::pqs::mathematic_angle<
            Extent,
            Value_typeR
        >
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_typeL,
                plus,
                Value_typeR
            >::type
        >::type type;
    };

// rad + fr
    template<
        typename Extent,
        typename Value_typeL,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::mathematic_angle<
            Extent,
            Value_typeL
        >,
        plus,
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_typeL,
                plus,
                Value_typeR
            >::type
        >::type type;
    };

//rad-fr
    template<
        typename Extent,
        typename Value_typeL,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::mathematic_angle<
            Extent,
            Value_typeL
        >,
        minus,
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_typeL,
                minus,
                Value_typeR
            >::type
        >::type type;
    };

// fr - rad
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >,
        minus,
        boost::pqs::mathematic_angle<
            Extent,
            Value_typeR
        >
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_typeL,
                minus,
                Value_typeR
            >::type
        >::type type;
    };

}}}//boost::pqs::meta

namespace boost{namespace pqs{

// fr + rad
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::plus,
        mathematic_angle<
            Extent,
            Value_typeR
        >
    >::type     
    operator +(
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        > const&  lhs,
        mathematic_angle<
            Extent,
            Value_typeR
        > const& rhs
    )
    {
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                Extent,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::plus,
            mathematic_angle<
                Extent,
                Value_typeR
            >
        >::type t(lhs);
        t += rhs;
        return t;    
    }

// rad + fr
    template<
        typename Extent,
        typename Value_typeL,
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        mathematic_angle<
            Extent,
            Value_typeL
        >,
        boost::pqs::meta::plus,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >
    >::type     
    operator +(
        mathematic_angle<
            Extent,
            Value_typeL
        > const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        > const& rhs
    )
    {
        typedef typename boost::pqs::meta::binary_operation<
            mathematic_angle<
                Extent,
                Value_typeL
            >,
            boost::pqs::meta::plus,
            fraction_of_revolution<
                Extent,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type rad;
        rad t(lhs);
        t += rad(rhs);
        return t;    
    } 
    
// rad - fr
    template<
        typename Extent,
        typename Value_typeL,
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        mathematic_angle<
            Extent,
            Value_typeL
        >,
        boost::pqs::meta::minus,
        fraction_of_revolution<
            Extent,ReciprocalFractionR,
            Value_typeR
        >
    >::type     
    operator -(
        mathematic_angle<
            Extent,
            Value_typeL
        > const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        > const& rhs)
    {
        typedef typename boost::pqs::meta::binary_operation<
            mathematic_angle<
                Extent,
                Value_typeL
            >,
            boost::pqs::meta::minus,
            fraction_of_revolution<
                Extent,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type rad;
        rad t(lhs);
        t -= rad(rhs);
        return t;    
    }
 
// fr - rad   
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::minus,
        mathematic_angle<
            Extent,
            Value_typeR
        >
    >::type     
    operator -(
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        > const&  lhs,
        mathematic_angle<
            Extent,
            Value_typeR
        > const& rhs
    )
    {
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                Extent,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::minus,
            mathematic_angle<
                Extent,
                Value_typeR
            >
        >::type t(lhs);
        t -= rhs;
        return t;    
    } 

// rad * fr
    template<
        typename ExtentL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        boost::pqs::mathematic_angle<
            ExtentL,
            Value_typeL
        >,
        boost::pqs::meta::times,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >::type
    operator * (
        boost::pqs::mathematic_angle<
            ExtentL,
            Value_typeL
        > const & lhs,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > const & rhs
    )
    {
        typedef typename pqs::meta::binary_operation<
            ExtentL,
            boost::pqs::meta::plus,
            ExtentR
        >::type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only multiplication  by angles
        // with resulting Extent of 0 is valid currently
        boost::pqs::concept_checking::Assert<
            boost::is_same<
                extent_type,
                boost::pqs::meta::rational<0>
            >::value
        >();
        //////////////////////CONCEPT CHECK/////////////////////////////
        typedef typename boost::pqs::meta::binary_operation<
            boost::pqs::mathematic_angle<
                ExtentL,
                Value_typeL
            >,
            boost::pqs::meta::times,
            boost::pqs::fraction_of_revolution<
                ExtentR,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type type;
        typedef typename boost::pqs::meta::binary_operation<
            Value_typeL,
            boost::pqs::meta::times,
            Value_typeR
        >::type result_value_type;
        boost::pqs::mathematic_angle<
            ExtentR,
            result_value_type
        > t(rhs);
        return (lhs.numeric_value() * t.numeric_value() );
    }
// fr * rad
    template<
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
         boost::pqs::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::times,
        boost::pqs::mathematic_angle<
            ExtentR,
            Value_typeR
        >
    >::type
    operator * ( 
        boost::pqs::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        > const  & lhs,
        boost::pqs::mathematic_angle<
            ExtentR,
            Value_typeR
        > const& rhs
    )
    {
         ////////////////////CONCEPT CHECK////////////////////////////////
        // only multiplication  by non rad angles
        // with resulting Extent of 0 is valid currently
        typedef typename pqs::meta::binary_operation<
            ExtentL,
            boost::pqs::meta::plus,
            ExtentR
        >::type extent_type;
        boost::pqs::concept_checking::Assert<
            boost::is_same<
                extent_type,
                boost::pqs::meta::rational<0>
            >::value
        >();
        //////////////////////CONCEPT CHECK/////////////////////////////
        typedef typename boost::pqs::meta::binary_operation<
            boost::pqs::fraction_of_revolution<
                ExtentL,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::times,
            boost::pqs::mathematic_angle<ExtentR,Value_typeR>
        >::type type;
        typedef typename boost::pqs::meta::binary_operation<
            Value_typeL,
            boost::pqs::meta::times,
            Value_typeR
        >::type result_value_type;
        boost::pqs::mathematic_angle<ExtentL,result_value_type> t(lhs);
        return (t.numeric_value() * rhs.numeric_value()  );
    }
// rad / fr
    template<
        typename ExtentL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        boost::pqs::mathematic_angle<ExtentL,Value_typeL>,
        boost::pqs::meta::divides,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >::type
    operator / (boost::pqs::mathematic_angle<ExtentL,Value_typeL> const & lhs,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > const & rhs)
    {
        typedef typename boost::pqs::meta::binary_operation<
            typename ExtentL::type,
            boost::pqs::meta::minus,
            typename ExtentR::type
        >::type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only multiplication  by different angles
        // with resulting Extent of 0 is valid currently
        boost::pqs::concept_checking::Assert<
            boost::is_same<
                extent_type,
                boost::pqs::meta::rational<0>
            >::value
        >();
        //////////////////////CONCEPT CHECK/////////////////////////////
        typedef typename boost::pqs::meta::binary_operation<
        boost::pqs::mathematic_angle<ExtentL,Value_typeL>,
        boost::pqs::meta::divides,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
        >::type type;
        typedef typename boost::pqs::meta::binary_operation<
            Value_typeL,
            boost::pqs::meta::divides,
            Value_typeR
        >::type result_value_type;
        boost::pqs::mathematic_angle<ExtentR,result_value_type> t(rhs);
        return (lhs.numeric_value() / t.numeric_value() );
    }
// fr / rad
    template<
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
         boost::pqs::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::divides,
        boost::pqs::mathematic_angle<ExtentR,Value_typeR>
    >::type
    operator / ( boost::pqs::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        > const  & lhs,
        boost::pqs::mathematic_angle<ExtentR,Value_typeR> const& rhs)
    {
         typedef typename pqs::meta::binary_operation<
            ExtentL,
            boost::pqs::meta::minus,
            ExtentR
         >::type extent_type;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only multiplication  by non rad angles
        // with resulting Extent of 0 is valid currently
          boost::pqs::concept_checking::Assert<
            boost::is_same<
                extent_type,
                boost::pqs::meta::rational<0>
            >::value
        >();
        //////////////////////CONCEPT CHECK/////////////////////////////
        typedef typename boost::pqs::meta::binary_operation<
            boost::pqs::fraction_of_revolution<
                ExtentL,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::divides,
            boost::pqs::mathematic_angle<ExtentR,Value_typeR>
        >::type type;
        typedef typename boost::pqs::meta::binary_operation<
            Value_typeL,
            boost::pqs::meta::divides,
            Value_typeR
        >::type result_value_type;
        boost::pqs::mathematic_angle<ExtentL,result_value_type> t(lhs);
        return result_value_type(t.numeric_value() / rhs.numeric_value()  );
    }

    template<typename ReciprocalFraction,typename Value_type>
    inline
    Value_type cos(fraction_of_revolution<boost::pqs::meta::rational<1>,ReciprocalFraction,Value_type>const& r)
    {
        mathematic_angle<boost::pqs::meta::rational<1>,Value_type> t(r);
        return cos(t);
    }
    template<typename ReciprocalFraction,typename Value_type>
    inline
    Value_type sin(fraction_of_revolution<boost::pqs::meta::rational<1>,ReciprocalFraction,Value_type>const& r)
    {
        mathematic_angle<boost::pqs::meta::rational<1>,Value_type> t(r);
        return sin(t);
    }
    template<typename ReciprocalFraction,typename Value_type>
    inline
    Value_type 
    tan(
        fraction_of_revolution<
            boost::pqs::meta::rational<1>,
            ReciprocalFraction,
            Value_type
        >const& r
    )
    {
        mathematic_angle<boost::pqs::meta::rational<1>,Value_type> t(r);
        return tan(t);
    }

   
//comparisons
    
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline int compare( 
        mathematic_angle<Extent,Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>const& rhs,
        typename boost::pqs::meta::binary_operation<
            mathematic_angle<Extent, Value_typeL>,
            boost::pqs::meta::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>    
        >::type const & eps 
        =typename boost::pqs::meta::binary_operation<
            mathematic_angle<Extent, Value_typeL>,
            boost::pqs::meta::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>    
        >::type(BOOST_PQS_COMPARISON_EPSILON)
    )
    {
        typedef typename boost::pqs::meta::binary_operation<
            mathematic_angle<Extent, Value_typeL>,
            boost::pqs::meta::minus,
            fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>
        >::type comp_type;
        comp_type rhs1(rhs);
        typedef typename comp_type::value_type comp_value_type;
        return ((abs(lhs-rhs1)).numeric_value() <= abs(eps).numeric_value())
        ? 0 
        :(((lhs-rhs1).numeric_value() < static_cast<comp_value_type>(0))
            ? -1
            : 1);
    } 

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline int compare( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        mathematic_angle<Extent, Value_typeR>const& rhs,
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>,
            boost::pqs::meta::minus,
            mathematic_angle<Extent, Value_typeR>
        >::type const & eps 
        = typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>,
            boost::pqs::meta::minus,
            mathematic_angle<Extent, Value_typeR>
        >::type(BOOST_PQS_COMPARISON_EPSILON)
    )     
    {
        typedef typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>,
            boost::pqs::meta::minus,
            mathematic_angle<Extent, Value_typeR>
        >::type comp_type;
        typedef typename comp_type::value_type comp_value_type;
        comp_type lhs1(lhs);
        return ((abs(lhs1-rhs)).numeric_value() <= eps.numeric_value() )
        ? 0 
        :(((lhs1-rhs).numeric_value() < static_cast<comp_value_type>(0))
            ? -1
            : 1);
    }
// <
  template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator <( 
        mathematic_angle<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) < 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator <( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        mathematic_angle<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) < 0;
    }

// <=
 
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator <=( 
        mathematic_angle<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) <= 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator <=( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        mathematic_angle<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) <= 0;
    }
 
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator ==( 
        mathematic_angle<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) == 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator ==( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        mathematic_angle<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) == 0;
    }

//!=
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator !=( 
        mathematic_angle<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR,Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) != 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator !=( 
        fraction_of_revolution<Extent,ReciprocalFractionL,Value_typeL>const& lhs,
        mathematic_angle<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) != 0;
    }

//>=
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator >=( 
        mathematic_angle<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) >= 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator >=( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        mathematic_angle<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) >= 0;
    }

// >
    template< 
        typename Extent, 
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator >( 
        mathematic_angle<Extent, Value_typeL>const& lhs,
        fraction_of_revolution<Extent,ReciprocalFractionR, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) > 0;
    }

    template< 
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename Value_typeR
    >
    inline bool operator >( 
        fraction_of_revolution<Extent,ReciprocalFractionL, Value_typeL>const& lhs,
        mathematic_angle<Extent, Value_typeR>const& rhs)
    {
        return compare(lhs,rhs) > 0;
    }

 // useful container for angles

    template<typename Value_type>
    struct angle_{
        
        typedef fraction_of_revolution<
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<360>,
            Value_type
        > deg;
        typedef fraction_of_revolution<
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<21600>,
            Value_type
        > min;
        typedef fraction_of_revolution<
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<1296000>,
            Value_type
        > s;
        typedef fraction_of_revolution<
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<1>,
            Value_type
        > rev;
        typedef mathematic_angle<
            boost::pqs::meta::rational<1>,
            Value_type
        > rad;
        typedef mathematic_angle<
            boost::pqs::meta::rational<2>,
            Value_type
        > sr; 
      //  static const rad   one;
        static const rad   pi;
        static const rad   two_pi;
    };

#ifdef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS

    template<typename Value_type>
    typename angle_<Value_type>::rad const
    angle_<Value_type>::pi 
    = typename angle_<
        Value_type
    >::rad(3.141592653589793238462643383279502884197);

    template<typename Value_type>
    typename angle_<Value_type>::rad const
    angle_<Value_type>::two_pi 
    = typename angle_<
        Value_type
    >::rad(2 * 3.141592653589793238462643383279502884197);

#endif

 struct angle : angle_<boost::pqs::quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
