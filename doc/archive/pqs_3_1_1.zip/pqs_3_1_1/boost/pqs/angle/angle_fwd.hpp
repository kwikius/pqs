#ifndef BOOST_PQS_ANGULAR_ANGLE_FWD_HPP
#define BOOST_PQS_ANGULAR_ANGLE_FWD_HPP
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    forward decl of angles types
*/

namespace boost{namespace pqs{
 
    //radians,steradians etc
    template <
        typename Extent,    // to power 1 -1, 2 etc
        typename Value_type
    >
    class mathematic_angle;

    // degree, minutes, seconds etc
    template<
        typename Extent,    // to power 1 -1, 2 etc
        typename Fraction,  // a compile time fraction of a revolution
        typename Value_type
    >
    class fraction_of_revolution;

}}//boost::pqs

#endif
