#ifndef BOOST_PQS_ANGLE_FRACTION_OF_REVOLUTION_HPP_INCLUDED
#define BOOST_PQS_ANGLE_FRACTION_OF_REVOLUTION_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

/// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/* 
    fraction of revolution for angles such as degrees etc
*/
#include <cmath>
#include <boost/pqs/config.hpp>
#include <boost/pqs/angle/angle_fwd.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/pqs/t1_quantity/constants/constant.hpp>
#include <boost/pqs/meta/is_angle_value_type.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
#include <boost/pqs/meta/rational.hpp>
#include <boost/pqs/meta/eval_rational.hpp>
#include <boost/mpl/and.hpp>
#include <boost/implicit_cast.hpp>

namespace boost{namespace pqs{

    template<
        typename Extent,    // boost::pqs::meta::rational<N,D>
        typename ReciprocalFraction,  // pqs::meta::rational<N,D>
        typename Value_type
    >
    class fraction_of_revolution{
        Value_type m_value;
    public:
        typedef typename Extent::type extent;
        typedef typename ReciprocalFraction::type fraction_type;
        typedef Value_type value_type;
        typedef fraction_of_revolution type;
        fraction_of_revolution(): m_value(static_cast<Value_type>(0)){}
        explicit fraction_of_revolution(Value_type const& v)
        :m_value(v){}
        template < typename Value_type1>
        explicit fraction_of_revolution(Value_type1 const & v)
        :m_value(boost::implicit_cast<Value_type>(v)){}
        fraction_of_revolution(fraction_of_revolution const& fr)
        :m_value(fr.m_value){}
        template<
            typename ReciprocalFraction1, 
            typename Value_type1
        >
        fraction_of_revolution(
            fraction_of_revolution<
                Extent,
                ReciprocalFraction1,
                Value_type1
            > const & fr
        )
        : m_value( fr.numeric_value() 
            * boost::pqs::meta::eval_rational<
                typename boost::pqs::meta::binary_operation<
                    ReciprocalFraction, 
                    boost::pqs::meta::divides,
                    ReciprocalFraction1
                >::type
            >()()){}
        template< typename Value_type1>
        fraction_of_revolution(
            boost::pqs::mathematic_angle<
                Extent,
                Value_type1
            > const & r
        )
        : m_value( r.numeric_value() 
            * boost::pqs::meta::eval_rational<
                ReciprocalFraction
            >()() 
            / (2.0 * boost::pqs::math::constant::pi)){}
        Value_type numeric_value()const{return m_value;}
       // Value_type const& operator()() const {return m_value;}
        // add rad ops
        fraction_of_revolution operator +()const
        {
            return *this;
        }
        fraction_of_revolution operator -()const
        {
            fraction_of_revolution t(-this->numeric_value());
            return t;
        }
        
        fraction_of_revolution& operator +=(fraction_of_revolution const & in)
        {
            m_value += in.m_value;
            return *this;
        }

        fraction_of_revolution& operator -=(fraction_of_revolution const & in)
        {
            m_value -= in.m_value;
             return *this;
        }

        template<
            typename ReciprocalFraction1, 
            typename Value_type1
        >
        fraction_of_revolution& operator +=(fraction_of_revolution<
            Extent,
            ReciprocalFraction1,
            Value_type1
        > const & in)
        {
            fraction_of_revolution t(in);
            m_value += t.m_value;
            return *this;
        }

        template<typename ReciprocalFraction1, typename Value_type1>
        fraction_of_revolution& operator -=(fraction_of_revolution<
            Extent,
            ReciprocalFraction1,
            Value_type1
        > const & in)
        {
            fraction_of_revolution t(in);
            m_value -= t.m_value;
            return *this;
        }
       
        template<typename Value_type1>
        fraction_of_revolution& operator *=(Value_type1 const & in)
        {
            m_value *= in;
            return *this;
        }

        template<typename Value_type1>
        fraction_of_revolution& operator /=(Value_type1 const & in)
        {
            m_value /= in;
            return *this;
        }           
    };

    template< 
        BOOST_PQS_INT32 D,
        typename ReciprocalFraction,
        typename Value_type
    >
    class fraction_of_revolution<
        boost::pqs::meta::rational<0,D>,
        ReciprocalFraction, Value_type
    >{
    public:
       typedef Value_type type;
    };

}}//boost::pqs


namespace boost{namespace pqs{namespace meta{

//binary operations between fraction_of_revolution's (e.g degrees minutes etc)
//frl + frr
    template<
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >,
        plus,
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >
    >{
        typedef typename boost::pqs::fraction_of_revolution<
            Extent,
            typename boost::mpl::if_<
                boost::mpl::greater<
                    typename ReciprocalFractionL::type,
                    typename ReciprocalFractionR::type
                >,
                typename ReciprocalFractionL::type,
                typename ReciprocalFractionR::type
            >::type,
            typename binary_operation<
                Value_typeL,
                plus,
                Value_typeR
            >::type
        >::type type;
    };

// frl - frr
    template<
        typename Extent,
        typename ReciprocalFractionL, 
        typename Value_typeL, 
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >,
        minus,
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >
    >{
        typedef typename boost::pqs::fraction_of_revolution<
            Extent,
            typename boost::mpl::if_<
                boost::mpl::greater<
                    typename ReciprocalFractionL::type,
                    typename ReciprocalFractionR::type
                >,
                typename ReciprocalFractionL::type,
                typename ReciprocalFractionR::type
            >::type,
            typename binary_operation<
                Value_typeL,
                minus,
                Value_typeR
            >::type
        >::type type;
    };

// fr * v
    template<
        typename Extent,
        typename ReciprocalFraction, 
        typename Value_type,  
        typename Value_type1
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            Value_type
        >,
        times,
        Value_type1,
        typename boost::enable_if<
            boost::mpl::and_<
                is_angle_value_type<Value_type1>,
                is_valid_binary_operation<
                    Value_type,
                    times,
                    Value_type1
                >
            >
        >::type
    >{
        typedef typename boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            typename binary_operation<
                Value_type,
                times,
                Value_type1
            >::type
        >::type type;
    };

// v * fr
    template<
        typename Value_type1,
        typename Extent,
        typename ReciprocalFraction, 
        typename Value_type
    >
    struct binary_operation<
        Value_type1,
        times,
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            Value_type
        >,
        typename boost::enable_if<
            boost::mpl::and_<
                is_angle_value_type<Value_type1>,
                is_valid_binary_operation<
                    Value_type1,
                    times,
                    Value_type
                >
            >
        >::type
    >{
        typedef typename boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            typename binary_operation<
                Value_type,
                times,
                Value_type1
            >::type
        >::type type;
    };

// fr / v
    template<
        typename Extent,
        typename ReciprocalFraction, 
        typename Value_type,  
        typename Value_type1
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            Value_type
        >,
        divides,
        Value_type1,
        typename boost::enable_if<
            boost::mpl::and_<
                is_angle_value_type<Value_type1>,
                is_valid_binary_operation<
                    Value_type,
                    divides,
                    Value_type1
                >
            >
        >::type
    >{
        typedef typename boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            typename binary_operation<
                Value_type,
                divides,
                Value_type1
            >::type
        >::type type;
    };

// v / fr;
    template<
        typename Extent,
        typename ReciprocalFraction, 
        typename Value_type,  
        typename Value_type1
    >
    struct binary_operation<
        Value_type1,
        divides,
        boost::pqs::fraction_of_revolution<
            Extent,
            ReciprocalFraction,
            Value_type
        >,
        typename boost::enable_if<
            boost::mpl::and_<
                is_angle_value_type<Value_type1>,
                is_valid_binary_operation<
                    Value_type1,
                    divides,
                    Value_type
                >
            >
        >::type
    >{
        typedef typename boost::pqs::fraction_of_revolution<
            typename unary_operation<
                negate,
                Extent
            >::type,
            typename unary_operation<
                reciprocal,
                ReciprocalFraction
            >::type,
            typename binary_operation<
                Value_type,
                divides,
                Value_type1
            >::type
        >::type type;
    };

// fra / frb 
    template < 
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        divides,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >{
        typedef typename boost::pqs::fraction_of_revolution<
           typename binary_operation<
                ExtentL,
                minus,
                ExtentR
            >::type,
        // other way up ???
            typename binary_operation<
                ReciprocalFractionL,
                divides,
                ReciprocalFractionR
            >::type,
            typename binary_operation<
                Value_typeL,
                divides,
                Value_typeR
            >::type
        >::type  type;
    };

// fra * frb
    template < 
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    struct binary_operation<
        boost::pqs::fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        times,
        boost::pqs::fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >{
        typedef typename boost::pqs::fraction_of_revolution<
           typename binary_operation<
                ExtentL,
                plus,
                ExtentR
            >::type,
            typename binary_operation<
                ReciprocalFractionL,
                times,
                ReciprocalFractionR
            >::type,
            typename binary_operation<
                Value_typeL,
                times,
                Value_typeR
            >::type
        >::type  type;
    };
}}}//boost::pqs::meta

namespace boost{namespace pqs{ 
// fr + fr
    template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::plus,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >
    >::type     
    operator +(
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        > const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        > const& rhs)
    {
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                Extent,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::plus,
            fraction_of_revolution<
                Extent,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type t(lhs);
        t += rhs;
        return t;    
    }

// fr - fr
     template<
        typename Extent,
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR, 
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::minus,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >
    >::type     
    operator -(
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        > const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        > const& rhs)
    {
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                Extent,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::minus,
            fraction_of_revolution<
                Extent,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type t(lhs);
        t -= rhs;
        return t;    
    } 

// fr * fr
    template < 
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::times,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >::type
    operator*(
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        > const & lhs,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > const & rhs
    )
    {
        typedef typename boost::pqs::meta::binary_operation<
            ExtentL,
            boost::pqs::meta::plus,
            ExtentR
        >::type extent;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // unlike radians for fraction-of-revolution types
        // only multiplication by fraction_of_revolution;s
        // with resulting Extent of 0 is valid
        pqs::concept_checking::Assert<
            boost::is_same<
                extent,
                boost::pqs::meta::rational<0>
            >::value
        >();
        //////////////////////CONCEPT CHECK/////////////////////////////

        typedef typename boost::pqs::meta::binary_operation<
            ReciprocalFractionL,
            boost::pqs::meta::times,
            ReciprocalFractionR
        >::type eval_type;
 
        return typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                ExtentL,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::times,
            fraction_of_revolution<
                ExtentR,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type( lhs.numeric_value() * rhs.numeric_value() /
            boost::pqs::meta::eval_rational<
                eval_type
            >()()
        ); 
    }

    template < 
        typename ExtentL,
        typename ReciprocalFractionL,
        typename Value_typeL,
        typename ExtentR,
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation<
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::divides,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >
    >::type
    operator/(
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        > const & lhs,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > const & rhs)
    {
        typedef typename boost::pqs::meta::binary_operation<
            ExtentL,
            boost::pqs::meta::minus,
            ExtentR
        >::type extent;
        ////////////////////CONCEPT CHECK////////////////////////////////
        // only division by fraction_of_revolution;s
        // with resulting extent of 0 is valid
        pqs::concept_checking::Assert<
            boost::is_same<
                extent,
                boost::pqs::meta::rational<0>
            >::value
        >();
        //////////////////////CONCEPT CHECK/////////////////////////////

        typedef typename boost::pqs::meta::binary_operation<
            ReciprocalFractionR,
            boost::pqs::meta::divides,
            ReciprocalFractionL
        >::type eval_type;
 
        return typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                ExtentL,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::divides,
            fraction_of_revolution<
                ExtentR,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type( 
            lhs.numeric_value() / rhs.numeric_value() 
            * boost::pqs::meta::eval_rational<
                eval_type
            >()()
        ); 
    }

// fr * v
    template<
        typename ExtentL,
        typename ReciprocalFractionL, 
        typename Value_typeL,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation_if<
        boost::pqs::meta::is_angle_value_type<Value_type>,
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::times,
        Value_type
    >::type    
    operator *(
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >const& lhs,
        Value_type const& rhs)
    {
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                ExtentL,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::times,
            Value_type
        >::type t(lhs);
        t *= rhs;
        return t;   
    }
// v * fr
    template<
        typename Value_type,
        typename ExtentR,
        typename ReciprocalFractionR, 
        typename Value_typeR>
    inline
    typename pqs::meta::binary_operation_if<
        boost::pqs::meta::is_angle_value_type<Value_type>,
        Value_type,
        boost::pqs::meta::times,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > 
    >::type     
    operator *(
        Value_type const&  lhs,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs
    )
    {
        return typename boost::pqs::meta::binary_operation<
            Value_type,
            boost::pqs::meta::times,
            fraction_of_revolution<
                ExtentR,
                ReciprocalFractionR,
                Value_typeR
            > 
        >::type ( lhs * rhs.numeric_value());   
    }

//fr / v 
    template<
        typename ExtentL,
        typename ReciprocalFractionL, 
        typename Value_typeL,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation_if<
        boost::pqs::meta::is_angle_value_type<Value_type>,
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >,
        boost::pqs::meta::divides,
        Value_type
    >::type     
    operator /(
        fraction_of_revolution<
            ExtentL,
            ReciprocalFractionL,
            Value_typeL
        >const& lhs,
        Value_type const& rhs)
    {
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                ExtentL,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::divides,
            Value_type
        >::type t(lhs);
        t /= rhs;
        return t;   
    }

// v / fr
    template<
        typename Value_type,
        typename ExtentR,
        typename ReciprocalFractionR, 
        typename Value_typeR>
    inline
    typename pqs::meta::binary_operation_if<
        boost::pqs::meta::is_angle_value_type<Value_type>,
        Value_type,
        boost::pqs::meta::divides,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        > 
    >::type 
    operator /(
        Value_type const&  lhs,
        fraction_of_revolution<
            ExtentR,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs
    )
    {
        return typename boost::pqs::meta::binary_operation<
            Value_type,
            boost::pqs::meta::divides,
            fraction_of_revolution<
                ExtentR,
                ReciprocalFractionR,
                Value_typeR
            > 
        >::type ( lhs / rhs.numeric_value());   
    }

    // abs
    template<
        typename Extent, 
        typename ReciprocalFraction,
        typename Value_type
    >
    inline 
    fraction_of_revolution<
        Extent,
        ReciprocalFraction,
        Value_type
    >
    abs(fraction_of_revolution<Extent,ReciprocalFraction, Value_type>const& in)
    {
      return in.numeric_value() < 0 ? -in : in;   
    }

    //comparisons
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline int compare( 
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL, 
            Value_typeL
        >const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs,
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                Extent,
                ReciprocalFractionL,
                Value_typeL
            >,
            boost::pqs::meta::minus,
            fraction_of_revolution<
                Extent,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type const & eps =
        typename boost::pqs::meta::binary_operation<
            fraction_of_revolution<
                Extent,
                ReciprocalFractionL, 
                Value_typeL
            >,
            boost::pqs::meta::minus,
            fraction_of_revolution<
                Extent,
                ReciprocalFractionR,
                Value_typeR
            >
        >::type(BOOST_PQS_COMPARISON_EPSILON)
     )   
    {
        typedef typename boost::pqs::meta::binary_operation<
            Value_typeL,
            boost::pqs::meta::minus,
            Value_typeR
        >::result_type comp_value_type;
        return ((abs(lhs-rhs)).numeric_value() <= abs(eps).numeric_value()())
        ? 0 
        :(((lhs-rhs).numeric_value() < static_cast<comp_value_type>(0))
            ? -1
            : 1);
    }
// <
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator<( 
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs
    )
    {
        return compare(lhs,rhs) < 0;
    }

 // <=
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator<=( 
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs)
    {
        return compare(lhs,rhs) <= 0;
    }

 //==
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator==( 
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs)
    {
        return compare(lhs,rhs) == 0;
    }
//!=
    template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator !=( 
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL,
            Value_typeL
        >const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs)
    {
        return compare(lhs,rhs) != 0;
    }
// >=
 template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator>=( 
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL, 
            Value_typeL
        >const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs)
    {
        return compare(lhs,rhs) >= 0;
    }

// >
     template< 
        typename Extent, 
        typename ReciprocalFractionL,
        typename Value_typeL, 
        typename ReciprocalFractionR,
        typename Value_typeR
    >
    inline bool operator >( 
        fraction_of_revolution<
            Extent,
            ReciprocalFractionL, 
            Value_typeL
        >const& lhs,
        fraction_of_revolution<
            Extent,
            ReciprocalFractionR,
            Value_typeR
        >const& rhs)
    {
        return compare(lhs,rhs) > 0;
    }

    template< 
        typename Extent, 
        typename ReciprocalFraction,
        typename Value_type
    >
    fraction_of_revolution<
        Extent,
        ReciprocalFraction,
        Value_type
    >
    modulo( fraction_of_revolution<
        Extent,
        ReciprocalFraction,
        Value_type
    > const & fr)
    {
        Value_type v = fr.numeric_value()/ 
            boost::pqs::meta::eval_rational<ReciprocalFraction>()();
        Value_type n;
        Value_type fract = std::modf(v,&n);
        return fraction_of_revolution<
            Extent,
            ReciprocalFraction, 
            Value_type
        >(
            fract * boost::pqs::meta::eval_rational<ReciprocalFraction>()()
        );
    }

}}//boost::pqs

#endif
