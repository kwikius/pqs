#ifndef BOOST_PQS_ANGLE_MATHEMATICAL_ANGLE_HPP_INCLUDED
#define BOOST_PQS_ANGLE_MATHEMATICAL_ANGLE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

/// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    mathematic_angle implementation(radians, steradians)
    mathematic_angle can be seen as a numeric type with extra attributes
    therefore it can be 'decayed' to its numeric value_type.
    The Extent parameter is a rational number e.g radians  has an extent of 1
    , while steradians has an extent of two.
    Therefore radians * radians --> steradians
    etc

    Also see <boost/pqs/angles/fraction_of-revolution.hpp> for
    e.g degrees,minutes, seconds
*/

#include <cmath>
#include <boost/pqs/config.hpp>
#include <boost/pqs/angle/meta_math_angle.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/implicit_cast.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/pqs/t1_quantity/constants/constant.hpp>

namespace boost{namespace pqs{

    template < 
        typename Extent, //Is a boost::pqs::meta::rational
        typename Value_type
    >
    class mathematic_angle{
        Value_type m_value; 
    public:
        typedef Value_type value_type;
        typedef Extent extent;
        typedef typename boost::mpl::if_<
            boost::is_same<
                Extent,
                boost::pqs::meta::rational<0>
            >,
            value_type,
            mathematic_angle
        >::type type;
        mathematic_angle(): m_value(static_cast<Value_type>(0)){}

      //  mathematic_angle(Value_type const & v): m_value(v){}

        template<typename Value_type1>
        mathematic_angle(
            Value_type1 const & v,
            typename boost::enable_if<
                boost::pqs::meta::is_angle_value_type<Value_type1>,
                void*
            >::type = 0 )
        : m_value(boost::implicit_cast<Value_type>(v)){}

        mathematic_angle(const mathematic_angle& in)
        :m_value(in.m_value){}

        template< 
            typename Value_type1
        >
        mathematic_angle(
            mathematic_angle<Extent,Value_type1> const & r
        )
        :m_value(boost::implicit_cast<Value_type>(r.m_value)){}

        template<
            typename ReciprocalFraction,
            typename Value_type1
        >
        inline mathematic_angle(
            fraction_of_revolution<
                Extent,
                ReciprocalFraction,
                Value_type1
            > const & fr
        );

        Value_type numeric_value()const {return m_value;}

      /*  template <typename Value_type1>
        operator 
        typename boost::enable_if<
             boost::pqs::meta::is_angle_value_type<Value_type1>,
             Value_type1
        >::type() const {return m_value;}*/
        operator Value_type()const {return m_value;}

        mathematic_angle operator -()const
        {
            return mathematic_angle(-this->m_value);
        }

        mathematic_angle operator +()const
        {
            return mathematic_angle( this->m_value);
        }

        //add fraction_of_rev ops
        template<
            typename Value_type1
        >
        mathematic_angle &
        operator +=(
            mathematic_angle<Extent,Value_type1> const & in)
        {
            this->m_value += in.numeric_value();
            return *this;
        }

        template<
            typename Value_type1
        >
        mathematic_angle &
        operator -=(mathematic_angle<Extent,Value_type1> const & in)
        {
            this->m_value -= in.numeric_value();
            return *this;
        }

        template<typename Value_type1>
        typename boost::enable_if<
            boost::pqs::meta::is_angle_value_type<Value_type1>,
            mathematic_angle &
        >::type  operator *=(Value_type1 const & in)
        {
            this->m_value *= in;
            return *this;
        }
        template<typename Value_type1>
        typename boost::enable_if<
            boost::pqs::meta::is_angle_value_type<Value_type1>,
            mathematic_angle &
        >::type operator /=(Value_type1 const & in)
        {
            this->m_value /= in;
            return *this;
        }

    };//mathematic_angle

    template<
        typename Extent,
        typename Value_typeA,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        mathematic_angle<Extent,Value_typeA>,
        boost::pqs::meta::plus,
        mathematic_angle<Extent,Value_typeB>
    >::type   
    operator + (
        mathematic_angle<Extent,Value_typeA> const & ra,
        mathematic_angle<Extent,Value_typeB> const & rb
    )
    {
        typename boost::pqs::meta::binary_operation<
            mathematic_angle<Extent,Value_typeA>,
            boost::pqs::meta::plus,
            mathematic_angle<Extent,Value_typeB>
        >::type  result = ra;
        result += rb;
        return result;       
    }

    template<
        typename Extent,
        typename Value_typeA,
        typename Value_typeB
    >
    inline
    typename boost::pqs::meta::binary_operation<
        mathematic_angle<Extent,Value_typeA>,
        boost::pqs::meta::minus,
        mathematic_angle<Extent,Value_typeB>
    >::type
    operator - (
        mathematic_angle<Extent,Value_typeA> const & ra,
        mathematic_angle<Extent,Value_typeB> const & rb
    )
    {
        typename boost::pqs::meta::binary_operation<
            mathematic_angle<Extent,Value_typeA>,
            boost::pqs::meta::minus,
            mathematic_angle<Extent,Value_typeB>
        >::type t = ra;
        t -= rb;
        return t;       
    }

    template<
        typename ExtentA,
        typename Value_typeA,
        typename ExtentB,
        typename Value_typeB
    >
    inline
    typename meta::binary_operation<
        mathematic_angle<ExtentA,Value_typeA>,
        boost::pqs::meta::times,
        mathematic_angle<ExtentB,Value_typeB>
    >::type
    operator * (
        mathematic_angle<ExtentA,Value_typeA> const & ra,
        mathematic_angle<ExtentB,Value_typeB> const & rb
    )
    {
        typename boost::pqs::meta::binary_operation<
            mathematic_angle<ExtentA,Value_typeA>,
            boost::pqs::meta::times,
            mathematic_angle<ExtentB,Value_typeB>
        >::type t (ra.numeric_value() * rb.numeric_value());
        return t;       
    }

    template<
        typename Extent,
        typename Value_type,
        typename Value_type1
    >
    inline
    typename pqs::meta::binary_operation_if<
        boost::pqs::meta::is_angle_value_type<Value_type1>,
        mathematic_angle<Extent,Value_type>,
        boost::pqs::meta::times,
        Value_type1
    >::type
    operator * (
        mathematic_angle<Extent,Value_type> const & ra,
        Value_type1 const & b)
    {
        typename boost::pqs::meta::binary_operation<
            mathematic_angle<Extent,Value_type>,
            boost::pqs::meta::times,
            Value_type1
        >::type t (ra.numeric_value() * b);
        return t;       
    }

    template<
        typename Value_type1,
        typename Extent,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation_if<
        boost::pqs::meta::is_angle_value_type<Value_type1>,
        Value_type1,
        boost::pqs::meta::times,
        mathematic_angle<Extent,Value_type>  
    >::type
    operator * (
        Value_type1 const & b,
        mathematic_angle<Extent,Value_type> const & ra
    )
    {
        typename boost::pqs::meta::binary_operation<
            Value_type1,
            boost::pqs::meta::times,
            mathematic_angle<Extent,Value_type>
        >::type t (b * ra.numeric_value());
        return t;       
    }

    template<
        typename ExtentA,
        typename Value_typeA,
        typename ExtentB,
        typename Value_typeB
    >
    inline
    typename boost::pqs::meta::binary_operation<
        mathematic_angle<ExtentA,Value_typeA>,
        boost::pqs::meta::divides,
        mathematic_angle<ExtentB,Value_typeB>
    >::type
    operator /(
        mathematic_angle<ExtentA,Value_typeA> const & ra,
        mathematic_angle<ExtentB,Value_typeB> const & rb
    )
    {
        typename boost::pqs::meta::binary_operation<
            mathematic_angle<ExtentA,Value_typeA>,
            boost::pqs::meta::divides,
            mathematic_angle<ExtentB,Value_typeB>
        >::type t (ra.numeric_value() / rb.numeric_value());
        return t;       
    }

    template<
        typename Extent,
        typename Value_type,
        typename Value_type1
    >
    inline
    typename pqs::meta::binary_operation_if<
        boost::pqs::meta::is_angle_value_type<Value_type1>,
        mathematic_angle<Extent,Value_type>,
        boost::pqs::meta::divides,
        Value_type1
    >::type
    operator / (
        mathematic_angle<Extent,Value_type> const & ra,
        Value_type1 const & b
    )
    {
        typename boost::pqs::meta::binary_operation<
            mathematic_angle<Extent,Value_type>,
            boost::pqs::meta::divides,
            Value_type1
        >::type t (ra.numeric_value() / b);
        return t;       
    }

    template<
        typename Value_type1,
        typename Extent,
        typename Value_type
    >
    inline
    typename pqs::meta::binary_operation_if<
        boost::pqs::meta::is_angle_value_type<Value_type1>,
        Value_type1,
        boost::pqs::meta::divides,
        mathematic_angle<Extent,Value_type>  
    >::type
    operator / (
        Value_type1 const & b,
        mathematic_angle<Extent,Value_type> const & ra)
    {
        typename boost::pqs::meta::binary_operation<
            Value_type1,
            boost::pqs::meta::divides,
            mathematic_angle<Extent,Value_type>
        >::type t (b / ra.numeric_value());
        return t;       
    }

    template<typename Value_type>
    inline
    Value_type cos(
        mathematic_angle<
            boost::pqs::meta::rational<1>,
            Value_type
        >const& r)
    {
        using std::cos;
        return cos(r.numeric_value());

    }

    template<typename Value_type>
    inline
    Value_type sin(mathematic_angle<boost::pqs::meta::rational<1>,Value_type>const& r)
    {
        using std::sin;
        return sin(r.numeric_value());

    }

    template<typename Value_type>
    inline
    Value_type tan(mathematic_angle<boost::pqs::meta::rational<1>,Value_type>const& r)
    {
        using std::tan;
        return tan(r.numeric_value());
    }

    template <
        BOOST_PQS_INT32 N,
        BOOST_PQS_INT32 D,
        typename Extent,
        typename Value_type
    >
    inline
    typename boost::pqs::meta::binary_operation<
        typename mathematic_angle<Extent,Value_type>::type,
        boost::pqs::meta::pow,
        typename boost::pqs::meta::rational<N,D>::type
    >::type
        
    pow(mathematic_angle<Extent,Value_type> const& r)
    {
        typedef  typename boost::pqs::meta::binary_operation<
            typename mathematic_angle<Extent,Value_type>::type,
            boost::pqs::meta::pow,
            typename boost::pqs::meta::rational<N,D>::type
        >::type result_type;
        return result_type(boost::pqs::pow<N,D>(r.numeric_value()));
       
    }

    template <
        BOOST_PQS_INT32 N,
        typename Extent,
        typename Value_type
    >
    inline
    typename boost::pqs::meta::binary_operation<
        typename mathematic_angle<Extent,Value_type>::type,
        boost::pqs::meta::pow,
        typename boost::pqs::meta::rational<N,1>::type
    >::type
        
    pow(mathematic_angle<Extent,Value_type> const& r)
    {
        typedef  typename boost::pqs::meta::binary_operation<
            typename mathematic_angle<Extent,Value_type>::type,
            boost::pqs::meta::pow,
            typename boost::pqs::meta::rational<N,1>::type
        >::type result_type;
        return result_type(pqs::pow<N,1>(r.numeric_value()));
       
    }
    template< typename Extent, typename Value_type>
    inline
    mathematic_angle<Extent,Value_type>
    abs(mathematic_angle<Extent,Value_type> const& r)
    {
        mathematic_angle<Extent,Value_type> ret =
        ( r.numeric_value() < static_cast<Value_type>(0))
        ? -r : r;
        return ret;
    }

    template<
        typename Extent, 
        typename Value_typeL,
        typename Value_typeR
    >
    inline
    int
    compare(mathematic_angle<Extent,Value_typeL>const & lhs, 
        mathematic_angle<Extent,Value_typeR> const& rhs ,
        mathematic_angle<
            Extent,
            typename boost::pqs::meta::binary_operation<
                Value_typeL,
                boost::pqs::meta::minus,
                Value_typeR
            >::type
        > const & epsilon =
         mathematic_angle<
            Extent,
            typename boost::pqs::meta::binary_operation<
                Value_typeL,
                boost::pqs::meta::minus,
                Value_typeR
            >::type
        >(BOOST_PQS_COMPARISON_EPSILON)       
    )
    {
        typedef typename boost::pqs::meta::binary_operation<
            mathematic_angle<Extent, Value_typeL>,
            boost::pqs::meta::minus,
            mathematic_angle<Extent, Value_typeR>
        >::type comp_type;
        return ((abs(lhs-rhs)).numeric_value() <= abs(epsilon).numeric_value())
        ? 0 
        :(((lhs-rhs).numeric_value() < comp_type(0).numeric_value())
            ? -1
            : 1);
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator <(
        mathematic_angle<Extent, Value_typeL>const & lhs, 
        mathematic_angle<Extent,Value_typeR>const& rhs
    )
    {
        return compare(lhs,rhs) < 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator <=(
        mathematic_angle<Extent,Value_typeL>const & lhs, 
        mathematic_angle<Extent,Value_typeR>const& rhs
    )
    {
        return compare(lhs,rhs) <= 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator ==(
        mathematic_angle<Extent, Value_typeL>const & lhs, 
        mathematic_angle<Extent,Value_typeR>const& rhs
    )
    {
        return compare(lhs,rhs) == 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator !=(
        mathematic_angle<Extent, Value_typeL>const & lhs, 
        mathematic_angle<Extent,Value_typeR>const& rhs
    )
    {
        return compare(lhs,rhs) != 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator >=(
        mathematic_angle<Extent, Value_typeL>const & lhs, 
        mathematic_angle<Extent,Value_typeR>const& rhs
    )
    {
        return compare(lhs,rhs) >= 0;
    }

    template<typename Extent, typename Value_typeL,typename Value_typeR>
    inline
    bool operator >(
        mathematic_angle<Extent, Value_typeL>const & lhs, 
        mathematic_angle<Extent,Value_typeR>const& rhs
    )
    {
        return compare(lhs,rhs) > 0;
    }

    template< 
        typename Extent, 
        typename Value_type
    >
    mathematic_angle<Extent, Value_type>
    modulo( mathematic_angle<Extent,Value_type> const & fr)
    {
        // check extent == 1
        Value_type v = fr.numeric_value() / (2* boost::pqs::math::constant_<Value_type>::pi);
        Value_type n;
        Value_type fract = std::modf(v,&n);
        mathematic_angle<
            Extent, 
            Value_type
        > result(fract * 2 * boost::pqs::math::constant_<Value_type>::pi);
        return result;
    }

}}//boost::pqs

#endif
