#ifndef BOOST_PQS_ANGLE_META_MATH_ANGLE_HPP_INCLUDED
#define BOOST_PQS_ANGLE_META_MATH_ANGLE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

/// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/angle/angle_fwd.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
#include <boost/pqs/meta/rational.hpp>
#include <boost/pqs/meta/is_angle_value_type.hpp>
#include <boost/mpl/and.hpp>
#include <boost/utility/enable_if.hpp>

namespace boost{namespace pqs{namespace meta{

//r + r
    template< 
        typename Value_typeA,
        typename Extent,
        typename Value_typeB
    >
    struct binary_operation<
            boost::pqs::mathematic_angle<Extent,Value_typeA>,
            plus,
            boost::pqs::mathematic_angle<Extent,Value_typeB>
    >
    {
        typedef  typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_typeA,
                plus,
                Value_typeB
            >::type
        >::type  type;

    };
// r - r
    template< 
        typename Value_typeA,
        typename Extent,
        typename Value_typeB
    >
    struct binary_operation<
            boost::pqs::mathematic_angle<Extent,Value_typeA>,
            minus,
            boost::pqs::mathematic_angle<Extent,Value_typeB>
    >
    {
        typedef  typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_typeA,
                minus,
                Value_typeB
            >::type
        >::type  type;

    };
// ra * rb
    template<
        typename ExtentA,
        typename Value_typeA,
        typename ExtentB,
        typename Value_typeB
    >
    struct binary_operation<
            boost::pqs::mathematic_angle<ExtentA,Value_typeA>,
            times,
            boost::pqs::mathematic_angle<ExtentB,Value_typeB>
    >
    {
        typedef  typename boost::pqs::mathematic_angle<
            typename binary_operation<
                ExtentA,
                plus,
                ExtentB
            >::type,
            typename binary_operation<
                Value_typeA,
                times,
                Value_typeB
            >::type
        >::type  type;

    };
// r * v
    template<
        typename Extent,
        typename Value_type,
        typename Value_type1
    >
    struct binary_operation<
            boost::pqs::mathematic_angle<Extent,Value_type>,
            times,
            Value_type1,
            typename boost::enable_if<
                boost::mpl::and_<
                    is_angle_value_type<Value_type1>,
                    is_valid_binary_operation<
                        Value_type,
                        times,
                        Value_type1
                    >
                >
            >::type
    >
    {
        typedef  typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_type,
                times,
                Value_type1
            >::type
        >::type  type;
    };
// v * r
    template<
        typename Value_type1,
        typename Extent,
        typename Value_type
    >
    struct binary_operation<
            Value_type1,
            times,
            boost::pqs::mathematic_angle<Extent,Value_type>,
            typename boost::enable_if<
                boost::mpl::and_<
                    is_angle_value_type<Value_type1>,
                    is_valid_binary_operation<
                        Value_type1,
                        times,
                        Value_type
                    >
                >
            >::type  
    >
    {
        typedef  typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_type1,
                times,
                Value_type
            >::type
        >::type  type;
    };
// ra / rb
    template<
        typename ExtentA,
        typename Value_typeA,
        typename ExtentB,
        typename Value_typeB
    >
    struct binary_operation<
            boost::pqs::mathematic_angle<ExtentA,Value_typeA>,
            divides,
            boost::pqs::mathematic_angle<ExtentB,Value_typeB>
    >
    {
        typedef  typename boost::pqs::mathematic_angle<
            typename binary_operation<
                ExtentA,
                minus,
                ExtentB
            >::type,
            typename binary_operation<
                Value_typeA,
                divides,
                Value_typeB
            >::type
        >::type  type;

    };
// r / v
    template< 
        typename Extent,
        typename Value_type,
        typename Value_type1
    >
    struct binary_operation<
            boost::pqs::mathematic_angle<Extent,Value_type>,
            divides,
            Value_type1,
            typename boost::enable_if<
                boost::mpl::and_<
                    is_angle_value_type<Value_type1>,
                    is_valid_binary_operation<
                        Value_type,
                        divides,
                        Value_type1
                    >
                >
            >::type
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            Extent,
            typename binary_operation<
                Value_type,
                divides,
                Value_type1
            >::type
        >::type  type;

    };

// v / r
    template< 
        typename Value_type1,
        typename Extent,
        typename Value_type
    >
    struct binary_operation<
            Value_type1,
            divides,
            boost::pqs::mathematic_angle<Extent,Value_type>,
            typename boost::enable_if<
                boost::mpl::and_<
                    is_angle_value_type<Value_type1>,
                    is_valid_binary_operation<
                        Value_type1,
                        divides,
                        Value_type
                    >
                >
            >::type
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            typename unary_operation<
                negate,
                Extent
            >::type,
            typename binary_operation<
                Value_type1,
                divides,
                Value_type
            >::type
        >::type  type;

    };
    // r to power rational<int,N,D>
    template <typename Extent,typename Value_type, int N, int D>
    struct binary_operation<
         boost::pqs::mathematic_angle<Extent,Value_type>,
         pow,
         rational<N,D>
    >
    {
        typedef typename boost::pqs::mathematic_angle<
            typename binary_operation<
                Extent,
                times,
                typename rational<N,D>::type
            >::type,
            typename binary_operation<
                Value_type,
                pow,
                typename rational<N,D>::type
            >::type
        >::type type;
    };
    
}}}//boost::pqs::meta

#endif
