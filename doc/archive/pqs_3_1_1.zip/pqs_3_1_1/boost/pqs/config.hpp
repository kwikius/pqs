#ifndef BOOST_PQS_CONFIG_HPP_INCLUDED
#define BOOST_PQS_CONFIG_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See <libs/pqs> for documentation.

#include <boost/cstdint.hpp>

/*
    Configuration options for Boost.Pqs
*/


//-------------------------------------------------------
//Default epsilon used by compare function

#ifndef BOOST_PQS_COMPARISON_EPSILON
#define BOOST_PQS_COMPARISON_EPSILON 0.0
#endif
//-------------------------------------------------------
//Set to 1 to make double default value_type, 
//else float will be default

#ifndef  BOOST_PQS_USE_DOUBLE_REAL_TYPE
#define BOOST_PQS_USE_DOUBLE_REAL_TYPE 1
#endif
//-------------------------------------------------------
//Default definitions of the macros: 
/* 
BOOST_PQS_MAX_PLUS1_POW10_DOUBLE
BOOST_PQS_MAX_PLUS1_POW10_FLOAT
BOOST_PQS_MAX_PLUS1_POW10_INT
*/
// The above macros set out the range of static Pow(V,E) functions
// Used to return rational powers of 10 as a double, float, int respectively.
// This useage is designed to prevent for example truncation of pow of 10 as int etc. 
// used in 
//<boost/pqs/detail/united_value/operations/coherent_exponent_eval.hpp>

#if (defined(BOOST_PQS_USE_DOUBLE_REAL_TYPE) && BOOST_PQS_USE_DOUBLE_REAL_TYPE !=0)
    #ifndef BOOST_PQS_REAL_TYPE
        #define BOOST_PQS_REAL_TYPE double
    #endif
    #ifndef BOOST_PQS_MAX_PLUS1_POW10_DOUBLE
        #define BOOST_PQS_MAX_PLUS1_POW10_DOUBLE 68
    #endif
    #ifndef BOOST_PQS_MAX_PLUS1_POW10_FLOAT
        #define BOOST_PQS_MAX_PLUS1_POW10_FLOAT 39
    #endif
    #define BOOST_PQS_MAX_PLUS1_POW10 BOOST_PQS_MAX_PLUS1_POW10_DOUBLE
#else
#define BOOST_PQS_REAL_TYPE float
    #ifndef BOOST_PQS_MAX_PLUS1_POW10_FLOAT
    #define BOOST_PQS_MAX_PLUS1_POW10_FLOAT 39
    #endif
    #define BOOST_PQS_MAX_PLUS1_POW10 BOOST_PQS_MAX_PLUS1_POW10_FLOAT
#endif

#ifndef BOOST_PQS_MAX_PLUS1_POW10_INT32
#define BOOST_PQS_MAX_PLUS1_POW10_INT32 10
#endif

//-----------------------------------------------------
// define to use boost.typeof for arithmetic results of ops
// otherwise synthetic type deduction is used

//#define BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
//-------------------------------------------------------
// Boost.Typeofs's macro. Use to test Boost.Typeof in compliant mode
// see Typeof documenttion for more details
//#define BOOST_TYPEOF_COMPLIANT

// Define so that t1_quantity wont have a user defined default ctor
// Theoretically gives a performance advantage. 
// Disadvantage is that member value is not initialsised

// #define BOOST_PQS_T1_QUANTITY_DONT_DEFINE_DEFAULT_CTOR
//-------------------------------------------------------

// 32bit int for use in rational parameters.
// Must be a macro rather than a typedef 
// for use in non-type template parameters

#if  (INT_MAX >= 0x7fffffff)
#define BOOST_PQS_INT32 int
#elif (LONG_MAX >= 0x7fffffff)
#define BOOST_PQS_INT32 long
#else
// long should be at least 32 bits so should never get here
#error need to define a 32-bit int in <boost/pqs/config.hpp>
#endif

//-------------------------------------------------------
// If defined, cause operators to be defined at global scope
// VC8 has problems with ADL on complicated types

#define BOOST_PQS_SUPPRESS_VC8_ADL_BUG
//-------------------------------------------------------

// define to allow physical constants to be defined in headers
// According to the standard this doesnt violate ODR rules

#define BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS

#endif


