#ifndef BOOST_PQS_META_BINARY_LOG_TRANSFORM_HPP_INCLUDED
#define BOOST_PQS_META_BINARY_LOG_TRANSFORM_HPP_INCLUDED
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.
#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/concept_checking.hpp>
#include <boost/type_traits/is_same.hpp>

namespace boost{namespace pqs{namespace meta{

    template <typename Lhs ,typename Op, typename Rhs>
    struct binary_log_transform;

    template <
        typename A,
        typename B
    > 
    struct binary_log_transform<A,plus,B> 
    : concept_checking::Assert<
        boost::is_same<A,B>::value 
    >{
        typedef A type;
    };

    template <
        typename A,
        typename B
    > 
    struct binary_log_transform<A,minus,B> 
    : concept_checking::Assert<
        boost::is_same<A,B>::value 
    >{
        typedef A type;
    };

    template <
        typename A,
        typename B
    > 
    struct binary_log_transform<A,times,B> : binary_operation<A,plus,B>{};

    template <
        typename A,
        typename B
    > 
    struct binary_log_transform<A,divides,B>: binary_operation<A,minus,B>{};

}}}

#endif
