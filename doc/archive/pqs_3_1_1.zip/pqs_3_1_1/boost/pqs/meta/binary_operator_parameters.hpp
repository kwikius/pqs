#ifndef GENERIC_BINARY_OPERATOR_PARAMETERS_HPP_INCLUDED
#define GENERIC_BINARY_OPERATOR_PARAMETERS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    traits of operators
*/
namespace boost{namespace pqs{namespace meta{
    // information about binary operators, associativity, precedence

    struct binary_operator_parameters{
       enum assoc {left_associative,right_associative};
        
        enum{     
            assignment_expression = 1,
            conditional_expression=2,
            logical_or_expression=3,
            logical_and_expression=4,
            inclusive_or_expression=5,
            exclusive_or_expression=6,
            and_expression=7,
            equality_expression=8, 
            relational_expression=9,
            shift_expression=10,
            additive_expression=11,
            multiplicative_expression=12,
            pow_expression = 13
        };
        
    };        

}}}//boost::pqs::meta

#endif
