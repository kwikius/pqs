#ifndef BOOST_PQS_OF_TIME_HPP_INCLUDED
#define BOOST_PQS_OF_TIME_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_time : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "time";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };

        typedef boost::pqs::meta::dimension<
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<1>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::unit<
                boost::pqs::meta::rational<4>,
                 meta::rational<8640000, 1000000>::type,
                boost::mpl::int_<0>
            > d;
            typedef meta::unit<
                boost::pqs::meta::rational<4>,
                 meta::rational<8616409, 1000000>::type,
                boost::mpl::int_<0>
            > d_sid;
            typedef meta::unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<3600000, 1000000>::type,
                boost::mpl::int_<0>
            > h;
            typedef meta::unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<3590170, 1000000>::type,
                boost::mpl::int_<0>
            > h_sid;
            typedef meta::unit<
                boost::pqs::meta::rational<1>,
                 meta::rational<6000000, 1000000>::type,
                boost::mpl::int_<0>
            > min;
            typedef meta::unit<
                boost::pqs::meta::rational<1>,
                 meta::rational<5983617, 1000000>::type,
                boost::mpl::int_<0>
            > min_sid;
            typedef meta::unit<
                boost::pqs::meta::rational<-1>,
                 meta::rational<9972696, 1000000>::type,
                boost::mpl::int_<0>
            > s_sid;
            typedef meta::unit<
                boost::pqs::meta::rational<5>,
                 meta::rational<6048000, 1000000>::type,
                boost::mpl::int_<0>
            > wk;
            typedef meta::unit<
                boost::pqs::meta::rational<7>,
                 meta::rational<3153600, 1000000>::type,
                boost::mpl::int_<0>
            > yr;
            typedef meta::unit<
                boost::pqs::meta::rational<7>,
                 meta::rational<3155815, 1000000>::type,
                boost::mpl::int_<0>
            > yr_sid;
            typedef meta::unit<
                boost::pqs::meta::rational<7>,
                 meta::rational<3155693, 1000000>::type,
                boost::mpl::int_<0>
            > yr_trop;
        };
        typedef  of_time of_type;
    };
    template<>
    inline
    const char*
    of_time::unprefixed_symbol<char>()
    {
        return "s";
    }
    template <>
    struct of_named_quantity_for<
        of_time::type
    > : of_time{};
}}}}//boost::pqs::meta::components
#endif
