#ifndef BOOST_PQS_OF_VOLUME_HPP_INCLUDED
#define BOOST_PQS_OF_VOLUME_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_volume : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "volume";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 3,
            prefix_offset = 0
        };

        typedef boost::pqs::meta::dimension<
            boost::pqs::meta::rational<3>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>,
            boost::pqs::meta::rational<0>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1>
        > type;
        struct incoherent_unit{
            typedef meta::unit<
                boost::pqs::meta::rational<3>,
                 meta::rational<1233489, 1000000>::type,
                boost::mpl::int_<0>
            > acre_foot;
            typedef meta::unit<
                boost::pqs::meta::rational<-1>,
                 meta::rational<1589873, 1000000>::type,
                boost::mpl::int_<0>
            > bbl;
            typedef meta::unit<
                boost::pqs::meta::rational<2>,
                 meta::rational<3523907, 1000000>::type,
                boost::mpl::int_<0>
            > bu;
            typedef meta::unit<
                boost::pqs::meta::rational<0>,
                 meta::rational<3624556, 1000000>::type,
                boost::mpl::int_<0>
            > cord;
            typedef meta::unit<
                boost::pqs::meta::rational<-2>,
                 meta::rational<2831685, 1000000>::type,
                boost::mpl::int_<0>
            > ft3;
            typedef meta::unit<
                boost::pqs::meta::rational<-5>,
                 meta::rational<1638706, 1000000>::type,
                boost::mpl::int_<0>
            > in3;
            typedef meta::unit<
                boost::pqs::meta::rational<9>,
                 meta::rational<4168182, 1000000>::type,
                boost::mpl::int_<0>
            > mi3;
            typedef meta::unit<
                boost::pqs::meta::rational<-1>,
                 meta::rational<7645549, 1000000>::type,
                boost::mpl::int_<0>
            > yd3;
            typedef meta::unit<
                boost::pqs::meta::rational<-4>,
                 meta::rational<2365882, 1000000>::type,
                boost::mpl::int_<0>
            > cup;
            typedef meta::unit<
                boost::pqs::meta::rational<-5>,
                 meta::rational<2957353, 1000000>::type,
                boost::mpl::int_<0>
            > fl_oz_US;
            typedef meta::unit<
                boost::pqs::meta::rational<-3>,
                 meta::rational<4546090, 1000000>::type,
                boost::mpl::int_<0>
            > gal;
            typedef meta::unit<
                boost::pqs::meta::rational<-3>,
                 meta::rational<3785412, 1000000>::type,
                boost::mpl::int_<0>
            > gal_US;
        };
        typedef  of_volume of_type;
    };
    template<>
    inline
    const char*
    of_volume::unprefixed_symbol<char>()
    {
        return "m3";
    }
    template <>
    struct of_named_quantity_for<
        of_volume::type
    > : of_volume{};
}}}}//boost::pqs::meta::components
#endif
