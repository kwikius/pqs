#ifndef BOOST_PQS_OF_XXXX_HPP_INCLUDED
#define BOOST_PQS_OF_XXXX_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_named_quantity.hpp>

namespace boost{namespace pqs{namespace meta{namespace components{

    struct of_xxxx : boost::noncopyable{

        static const char* abstract_quantity_name()
        {
            return "xxxx";
        }

        template<typename CharType>
        static const CharType* unprefixed_symbol();

        enum{
            extent = 1,
            prefix_offset = 0
        };
        // see docs for information on these two enums

        typedef boost::pqs::meta::dimension<
            boost::pqs::meta::rational<LENGTH_DIMENSION_OF_xxxx>,
            boost::pqs::meta::rational<TIME_DIMENSION_OF_xxxx>,
            boost::pqs::meta::rational<MASS_DIMENSION_OF_xxxx>,
            boost::pqs::meta::rational<TEMPERATURE_DIMENSION_OF_xxxx>,
            boost::pqs::meta::rational<CURRENT_DIMENSION_OF_xxxx>,
            boost::pqs::meta::rational<AMOUNT_OF_SUBSTANCE_DIMENSION_OF_xxxx>,
            boost::pqs::meta::rational<LUMINOUS_INTENSITY_DIMENSION_OF_xxxx>
        > anonymous_type;

        typedef meta::abstract_quantity<
            anonymous_type,
            boost::mpl::int_<1> // this may need to change 
                //if it clashes with a dimensionaly equivalent quantity
        > type;

        struct incoherent_unit{
            typedef meta::unit<
                boost::pqs::meta::rational<EXPONENT>,
                 meta::rational<MULTIPLIER_X_DENOMINATOR, DENOMINATOR>::type,
                boost::mpl::int_<0>
            > some_incoherent_xxxx_unit;
            
            /*
                other incoherent units
            */
        };
        typedef  of_xxxx of_type;
    };

    template<>
    inline
    const char*
    of_xxxx::unprefixed_symbol<char>()
    {
        return "???"; // replace with the unprefixed coherent-unit output symbol
    }

    template <>
    struct of_named_quantity_for<
        of_xxxx::type
    > : of_xxxx{};


}}}}//boost::pqs::meta::components
#endif
