#ifndef BOOST_PQS_GET_VALUE_TYPE_OF_HPP_INCLUDED
#define BOOST_PQS_GET_VALUE_TYPE_OF_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/pqs/meta/arithmetic_promote.hpp>
#include <boost/mpl/integral_c.hpp>
#include <boost/mpl/math/rational.hpp>
#include <boost/pqs/preboost/simplify_rational_or_numeric.hpp>
#include <boost/mpl/math/numerator.hpp>
#include <boost/mpl/math/denominator.hpp>

namespace boost{namespace pqs{namespace meta{

    namespace detail{

            template <typename Tag>
            struct get_value_type_of_impl;
            template <typename T>
            struct get_value_type_of;
           
            template<>
            struct get_value_type_of_impl<
                typename boost::mpl::integral_c_tag
            >
            {
                template <typename T> 
                struct apply{
                    typedef typename T::value_type type;
                };
            };
            template<>
            struct get_value_type_of_impl<
                typename boost::mpl::math::rational_tag
            >
            {
                template <typename T> 
                struct apply{
                    typedef typename boost::pqs::meta::arithmetic_promote<
                        typename get_value_type_of<
                            typename boost::mpl::math::numerator<T>::type
                        >::type,
                        typename get_value_type_of<
                            typename boost::mpl::math::denominator<T>::type
                        >::type
                    >::type type;
                };
            };
            template <typename T>
            struct get_value_type_of{
                typedef typename get_value_type_of_impl<
                    typename T::tag
                >::apply<T>::type type;
            };
           
    } // detail
}}}//boost::pqs::meta

#endif
