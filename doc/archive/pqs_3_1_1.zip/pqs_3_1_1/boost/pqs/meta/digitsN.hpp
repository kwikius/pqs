#ifndef BOOST_PQS_DIGITS_N_HPP_INCLUDED
#define BOOST_PQS_DIGITS_N_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

#include <boost/static_assert.hpp>
#include <boost/utility/enable_if.hpp>
#include <limits>

namespace boost{ namespace pqs{ namespace meta{

    template< 
        int Base, 
        typename IntegerType,
        typename Enable = void
    >
    struct digits;

    template <typename IntegerType>
    struct digits<
            10, 
            IntegerType , 
            typename boost::enable_if_c<
                std::numeric_limits<IntegerType>::is_specialized
            >::type
    >{
        static const int value = std::numeric_limits<IntegerType>::digits10;
    };

}}}// boost::pqs::meta

#endif
