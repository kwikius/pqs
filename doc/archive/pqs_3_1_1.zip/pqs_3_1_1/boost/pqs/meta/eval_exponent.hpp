#ifndef BOOST_PQS_META_EVAL_EXPONENT_HPP_INCLUDED
#define BOOST_PQS_META_EVAL_EXPONENT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    evaluate a rational as an exponent to base 10
*/

#include <boost/pqs/detail/united_value/operations/coherent_exponent.hpp>
#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/mpl/if.hpp>
#include <limits>

namespace boost{namespace pqs { namespace meta{namespace detail{

template <typename Exponent,typename ResultType, bool Negate>
struct pos_neg_eval_exponent;

// dont negate and return exp
template <typename Exponent, typename ResultType>
struct pos_neg_eval_exponent<Exponent, ResultType,false>
{
    typedef typename boost::pqs::detail::coherent_exponent<
         Exponent::numerator, Exponent::denominator
    >::template eval<
       ResultType
    > eval;
    ResultType operator()()
    {
       eval ev;
       ResultType  result = ev(); 
       return result;
    }
};

//negate and return 1/exp
template <typename Exponent, typename ResultType>
struct pos_neg_eval_exponent<Exponent, ResultType,true>
{
    typedef typename pqs::detail::coherent_exponent<
         Exponent::numerator, Exponent::denominator
    >::template eval<
       ResultType
    > eval;
    
    ResultType operator()()
    {
       eval ev;
       ResultType  result = 1 / ev(); 
       return result;
    }
};

template <typename Exponent>
struct eval_exponent_impl {

    const static bool reverse_calc 
    = boost::mpl::less<
        Exponent,
        pqs::meta::rational<0>
    >::value;
  
    typedef typename boost::mpl::if_c<
        reverse_calc,
        typename pqs::meta::unary_operation<
            pqs::meta::negate,
            Exponent
        >::type,
        Exponent            
    >::type exponent;

    typedef typename boost::pqs::detail::coherent_exponent<
         exponent::numerator, exponent::denominator
    >::template eval<
        typename boost::mpl::if_<
            boost::mpl::greater< 
                exponent , 
                boost::pqs::meta::rational<
                    std::numeric_limits<BOOST_PQS_INT32>::digits10
                >
            >,
            BOOST_PQS_REAL_TYPE,
            int 
        >::type
    > dummy;
// if its a rational not int must use float
    typedef typename boost::mpl::if_c<
        (reverse_calc ||( (exponent::numerator !=0 ) && (exponent::denominator!=1))),
        BOOST_PQS_REAL_TYPE,
        typename dummy::result_type
    >::type result_type;

    typedef pos_neg_eval_exponent<exponent,result_type, reverse_calc> eval;
    
};

}}}}//boost::pqs::meta::detail

namespace boost{ namespace pqs{namespace meta{

template <typename Exponent>
struct eval_exponent {
// eval functor
    typedef typename detail::eval_exponent_impl<Exponent>::eval eval;
    typedef typename detail::eval_exponent_impl<Exponent>::result_type result_type;   
};

}}}//boost::pqs::meta

#endif
