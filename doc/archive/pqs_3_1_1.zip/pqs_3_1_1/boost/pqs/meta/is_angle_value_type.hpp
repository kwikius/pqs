#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_META_IS_ANGLE_VALUE_TYPE_HPP_INCLUDED
#define BOOST_PQS_META_IS_ANGLE_VALUE_TYPE_HPP_INCLUDED

/*
    used to identify if a type is a valid angle value_type
    basically same as boost::is_arithmetic but designed to be customised
    if necessary
*/

#include <boost/type_traits/is_arithmetic.hpp>

namespace boost{namespace pqs{ namespace meta{

    template <typename Value_type>
    struct is_angle_value_type : boost::is_arithmetic<Value_type>{};

}}}//boost::pqs::geometry

#endif
