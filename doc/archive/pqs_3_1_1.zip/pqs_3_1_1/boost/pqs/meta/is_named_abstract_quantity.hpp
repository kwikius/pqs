#ifndef  BOOST_PQS_META_IS_NAMED_ABSTRACT_QUANTITY_HPP_INCLUDED
#define  BOOST_PQS_META_IS_NAMED_ABSTRACT_QUANTITY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    Is this AbstractQuantity a NamedAbstractQuantity
    with a specialisation of the OfNamedQuantityComponents concept
*/
#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/t1_quantity/t1_quantity_fwd.hpp>
#include <boost/pqs/meta/components/of_named_quantity_for_fwd.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/not.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/void.hpp>

namespace boost{namespace pqs{namespace meta{
   

    template <
        typename AbstractQuantity
    >
    struct is_named_abstract_quantity
    : boost::mpl::and_<
        boost::mpl::not_equal_to<
            typename AbstractQuantity::id,
            anonymous_abstract_quantity_id
        >, 
        boost::mpl::not_<
            boost::is_same<
                typename components::of_named_quantity_for<
                    AbstractQuantity
                >::type,
                boost::mpl::void_
            >
        >
    >{};  
}}}//boost::pqs::meta
#endif
