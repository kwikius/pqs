#ifndef PQS_META_IS_VALID_BINARY_OPERATION_HPP_INCLUDED
#define PQS_META_IS_VALID_BINARY_OPERATION_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
  value is true if binary_operation is defined on the two type
,then
  valid binary_operation has a result_type != boost::mpl::void
 invalid binary_operation has a result_type == boost::mpl::void
*/

#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/type_traits/is_same.hpp>

namespace boost{namespace pqs{ namespace meta{

    template <
        typename Left, 
        typename Op, 
        typename Right
    >
    struct is_valid_binary_operation {
        enum{
            value = (boost::is_same<
                typename boost::pqs::meta::binary_operation<
                     Left, Op, Right,void
                >::type,
                boost::mpl::void_
             >::value == 0)
        };
        typedef is_valid_binary_operation type;
    };

}}}// boost::pqs::meta

#endif
