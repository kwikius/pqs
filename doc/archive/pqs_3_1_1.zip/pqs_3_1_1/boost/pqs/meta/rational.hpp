#ifndef BOOST_PQS_META_RATIONAL_HPP_INCLUDED
#define BOOST_PQS_META_RATIONAL_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    compile time rational number
    from original impl by Matthias Schabel and ideas from Jan Langer
*/

#include <boost/pqs/config.hpp>
#include <boost/pqs/meta/rational_fwd.hpp>
#include <boost/pqs/meta/detail/rational_impl.hpp>
#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/comparison.hpp>

namespace boost {namespace pqs{namespace meta{

    template<
       BOOST_PQS_INT32 N,
       BOOST_PQS_INT32 D 
    >
    struct rational {
        enum{
           numerator 
            = boost::pqs::meta::detail::rational_impl<
                N,D
            >::numerator,
            denominator = detail::rational_impl<
                N,D
            >::denominator
        };
        
        typedef rational<numerator,denominator> type;
    };
   
    template<
       BOOST_PQS_INT32 N,
       BOOST_PQS_INT32 D 
    > 
    struct unary_operation<
         negate, 
         rational<N,D>
    >{
        typedef typename rational<-N,D>::type type;
    };

    template<
        BOOST_PQS_INT32 N,
        BOOST_PQS_INT32 D 
    > 
    struct unary_operation<
         reciprocal, 
         rational<N,D>
    >{
        typedef typename rational<D,N>::type type;
    };
 
 
    template <
        BOOST_PQS_INT32 Nlhs,
        BOOST_PQS_INT32 Dlhs,
        BOOST_PQS_INT32 Nrhs,
        BOOST_PQS_INT32 Drhs
    > struct binary_operation<
        rational<Nlhs,Dlhs>,
        plus,
        rational<Nrhs,Drhs>
    >{
      /*  typedef rational<Nlhs,Dlhs> lhs;
        typedef rational<Nrhs,Drhs> rhs;*/
        typedef typename rational<Nlhs,Dlhs>::type lhs;
        typedef typename rational<Nrhs,Drhs>::type rhs;
        enum{
            lhsn = lhs::numerator,
            lhsd = lhs::denominator,
            rhsn = rhs::numerator,
            rhsd = rhs::denominator
        };
        typedef typename rational<
            static_cast<BOOST_PQS_INT32>(lhsn) * rhsd 
                + static_cast<BOOST_PQS_INT32>(rhsn) * lhsd, 
            static_cast<BOOST_PQS_INT32>(lhsd) * rhsd
        >::type type;
    };

    template <
       BOOST_PQS_INT32 Nlhs,BOOST_PQS_INT32 Dlhs,
       BOOST_PQS_INT32 Nrhs,BOOST_PQS_INT32 Drhs
    > struct binary_operation<
        rational<Nlhs,Dlhs>,
        minus,
        rational<Nrhs,Drhs>
    >{
       /* typedef rational<Nlhs,Dlhs> lhs;
        typedef rational<Nrhs,Drhs> rhs;*/
        typedef typename rational<Nlhs,Dlhs>::type lhs;
        typedef typename rational<Nrhs,Drhs>::type rhs;
        enum{
            lhsn = lhs::numerator,
            lhsd = lhs::denominator,
            rhsn = rhs::numerator,
            rhsd = rhs::denominator
        };
        typedef typename rational<
            static_cast<BOOST_PQS_INT32>(lhsn) * rhsd - static_cast<BOOST_PQS_INT32>(rhsn) * lhsd, 
            static_cast<BOOST_PQS_INT32>(lhsd) * rhsd
        >::type type;
    };

    template <
       BOOST_PQS_INT32 Nlhs,BOOST_PQS_INT32 Dlhs,
        BOOST_PQS_INT32 Nrhs, BOOST_PQS_INT32 Drhs
    > struct binary_operation<
        rational<Nlhs,Dlhs>,
        times,
        rational<Nrhs,Drhs>
    >{
      /*  typedef rational<Nlhs,Dlhs> lhs;
        typedef rational<Nrhs,Drhs> rhs;*/
        typedef typename rational<Nlhs,Dlhs>::type lhs;
        typedef typename rational<Nrhs,Drhs>::type rhs;
        /*enum{
            lhsn = lhs::numerator,
            lhsd = lhs::denominator,
            rhsn = rhs::numerator,
            rhsd = rhs::denominator
        };*/
        const static BOOST_PQS_INT32 n = lhs::numerator * rhs::numerator;
        const static BOOST_PQS_INT32 d = lhs::denominator * rhs::denominator;
        typedef typename rational<
          n , d
        >::type type;
    };

    template <
        BOOST_PQS_INT32 Nlhs,BOOST_PQS_INT32 Dlhs,
        BOOST_PQS_INT32 Nrhs, BOOST_PQS_INT32 Drhs
    > struct binary_operation<
        rational<Nlhs,Dlhs>,
        divides,
        rational<Nrhs,Drhs>
    >{
        typedef typename rational<Nlhs,Dlhs>::type lhs;
        typedef typename rational<Nrhs,Drhs>::type rhs;
        enum{
            lhsn = lhs::numerator,
            lhsd = lhs::denominator,
            rhsn = rhs::numerator,
            rhsd = rhs::denominator
        };
        typedef typename rational<
            static_cast<BOOST_PQS_INT32>(lhsn) * rhsd , 
            (static_cast<BOOST_PQS_INT32>(lhsn) == 0) 
                ? 1 
                : static_cast<BOOST_PQS_INT32>(lhsd) * rhsn
        >::type type;
    };
    template <typename T>
    struct is_rational : boost::mpl::false_{};   
    template <BOOST_PQS_INT32 N, BOOST_PQS_INT32 D>
    struct is_rational<rational<N,D> > : boost::mpl::true_{};

}}}//boost::pqs::meta

namespace boost{namespace mpl{

    #define BOOST_PQS_META_RATIONAL_COMPARISON_OP( Operator,OpSymbol)\
    template <\
            BOOST_PQS_INT32 Nlhs BOOST_PP_COMMA()\
            BOOST_PQS_INT32 Dlhs BOOST_PP_COMMA()\
            BOOST_PQS_INT32 Nrhs BOOST_PP_COMMA()\
            BOOST_PQS_INT32 Drhs\
    >\
    struct  Operator <\
        boost::pqs::meta::rational<Nlhs BOOST_PP_COMMA() Dlhs > BOOST_PP_COMMA()\
        boost::pqs::meta::rational<Nrhs BOOST_PP_COMMA() Drhs >\
    >{\
        typedef typename boost::pqs::meta::rational<Nlhs BOOST_PP_COMMA() Dlhs>::type lhs;\
        typedef typename boost::pqs::meta::rational<Nrhs BOOST_PP_COMMA() Drhs>::type rhs;\
        enum{\
            lhsn = lhs::numerator BOOST_PP_COMMA()\
            lhsd = lhs::denominator BOOST_PP_COMMA()\
            rhsn = rhs::numerator BOOST_PP_COMMA()\
            rhsd = rhs::denominator BOOST_PP_COMMA()\
            value = ((static_cast<BOOST_PQS_INT32>(lhsn) \
                * rhsd) OpSymbol (static_cast<BOOST_PQS_INT32>(rhsn) * lhsd) )\
        };\
        typedef bool_<value> type;\
    };
 
// defining these may be problematic  

    BOOST_PQS_META_RATIONAL_COMPARISON_OP( less , < )
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( less_equal, <= )
   // BOOST_PQS_META_RATIONAL_COMPARISON_OP( equal_to, == )
  //  BOOST_PQS_META_RATIONAL_COMPARISON_OP( not_equal_to, != )
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( greater_equal, >= )
    BOOST_PQS_META_RATIONAL_COMPARISON_OP( greater, > )

    template <
            BOOST_PQS_INT32 Nlhs ,
            BOOST_PQS_INT32 Dlhs ,
            BOOST_PQS_INT32 Nrhs ,
            BOOST_PQS_INT32 Drhs\
    >\
    struct  not_equal_to <
        boost::pqs::meta::rational<Nlhs , Dlhs > ,
        boost::pqs::meta::rational<Nrhs , Drhs >
    > : not_<
        boost::is_same<
            typename boost::pqs::meta::rational<Nlhs,Dlhs>::type ,
            typename  boost::pqs::meta::rational<Nrhs,Drhs>::type
        >
    >{};
    #undef BOOST_PQS_META_RATIONAL_COMPARISON_OP


}}//boost:mpl


#endif //PQS_META_RATIONAL_C_HPP_INCLUDED
