#ifndef BOOST_PQS_META_TRANSFORM_COHERENT_HPP_INCLUDED
#define BOOST_PQS_META_TRANSFORM_COHERENT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

namespace boost{namespace pqs {namespace meta{
  
    template<
        typename T
    >
    struct transform_coherent;
}}}//boost::pqs::meta

#endif
