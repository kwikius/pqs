#ifndef BOOST_PQS_QUANTITY_UNIT_FWD_HPP_INCLUDED
#define  BOOST_PQS_QUANTITY_UNIT_FWD_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

#include <boost/pqs/config.hpp>
#include <boost/mpl/int.hpp>
#include <boost/pqs/meta/rational.hpp>
namespace boost{namespace pqs {namespace meta{

    struct default_unit_exponent{
        typedef rational<0> type;
    };
    
    struct default_unit_multiplier{
        typedef rational<1> type;
    };

// == anonymous_unit_id
    struct default_unit_id{
        typedef boost::mpl::int_<0> type;
    };

    template <
        typename Exponent   = typename default_unit_exponent::type,
        typename Multiplier = typename default_unit_multiplier::type,
        typename Id         = typename default_unit_id::type
    >
    struct unit;

}}}//boost::pqs::meta


#endif
