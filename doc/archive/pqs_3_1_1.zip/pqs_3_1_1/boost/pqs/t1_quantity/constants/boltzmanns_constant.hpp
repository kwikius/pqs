#ifndef PQS_BOLTZMANNS_CONSTANT_HPP_INCLUDED
#define PQS_BOLTZMANNS_CONSTANT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    declaration of boltzmanns constant.
    definition in "libs/pqs/src/boltzmanns_constant.cpp"
    required to link
*/

#include <boost/pqs/t1_quantity/operations.hpp>

namespace boost{namespace pqs{ namespace physics{

    template<typename Value_type=double>
    struct boltzmanns_constant_{
       typedef  t1_quantity< // boltzmanns constant
            meta::abstract_quantity<
                meta::dimension<
                    meta::rational<2>,
                    meta::rational<-2>,
                    meta::rational<1>,
                    meta::rational<-1>,
                    meta::rational<0>,
                    meta::rational<0>,
                    meta::rational<0>
                >,
                boost::mpl::int_<0>
            >,
            meta::unit<
                meta::rational<-23>
            >,
            Value_type
        > type;
        static type const & K;
    };
    struct boltzmanns_constant 
    : boltzmanns_constant_<boost::pqs::quantity_traits::default_value_type>{};

#ifdef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS
template <typename T>
typename boltzmanns_constant_<T>::type const&
boltzmanns_constant_<T>::K 
= typename boltzmanns_constant_<T>::type(1.380658);
#endif
}}}//boost::pqs::physics

#endif
