#ifndef BOOST_PQS_MATH_CONSTANT_HPP_INCLUDED
#define BOOST_PQS_MATH_CONSTANT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

//constants values provided by Paul Bristow
/*
    struct container for math constants
    note requires compilation/link of "libs/pqs/src/constant.cpp"
*/

#include <boost/pqs/config.hpp>

namespace boost{namespace pqs{ namespace math {

   template<typename Value_type>
   struct constant_{
        static Value_type const & pi;
        static Value_type const & e;
        static Value_type const & sqrt2;
   };

   struct constant : constant_<double>{};

#ifdef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS

template<typename T>
T const &  constant_<T>::pi 
= static_cast<T>(3.141592653589793238462643383279502884197);

template<typename T>
T const & constant_<T>::e  
= static_cast<T>(0.5772156649015328606065120900824024310422);

template<typename T>
T const &  constant_<T>::sqrt2 
= static_cast<T>(1.41421356237309504880168872420969807857);

#endif


 }}}//pqs::math
 
#endif

