#ifndef BOOST_PQS_GAS_CONSTANT_HPP_INCLUDED
#define BOOST_PQS_GAS_CONSTANT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    declaration of gas_constant.
    definition in "libs/pqs/src/gas_constant.cpp"
    required to link
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/mpl/int.hpp>

namespace boost{namespace pqs{ namespace physics{

    template<typename Value_type>
    struct gas_constant_{
        typedef boost::pqs::t1_quantity<       // gas constant
           boost::pqs::meta::abstract_quantity<
                boost::pqs::meta::dimension<
                    boost::pqs::meta::rational<2>,
                    boost::pqs::meta::rational<-2>,
                    boost::pqs::meta::rational<1>,
                    boost::pqs::meta::rational<-1>,
                    boost::pqs::meta::rational<0>,
                    boost::pqs::meta::rational<-1>,
                    boost::pqs::meta::rational<0> 
                >,
                boost::mpl::int_<0>
            >,
            boost::pqs::meta::unit<>,
            Value_type
        > type;
        static type const&  R;
    };

    struct gas_constant : gas_constant_<
            boost::pqs::quantity_traits::default_value_type
    >{};

#ifdef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS

template<typename T>
typename gas_constant_<T>::type const&
gas_constant_<T>::R 
= typename gas_constant_<T>::type(8.3145);

#endif

}}}//boost::pqs::physics

#endif
