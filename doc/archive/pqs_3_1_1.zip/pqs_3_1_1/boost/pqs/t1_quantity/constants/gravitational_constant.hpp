#ifndef BOOST_PQS_GRAVITATIONAL_CONSTANT_HPP_INCLUDED
#define BOOST_PQS_GRAVITATIONAL_CONSTANT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    gravitational constant declaration
    note:
    requires compilation of "lis/pqs/src/gravitational_constant.cpp"
    for linking
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/mpl/int.hpp>
namespace boost{namespace pqs{namespace physics{

    template <typename Value_type>
    struct gravitational_constant_{
        typedef  boost::pqs::t1_quantity<     //pqs-1-00-03 style
            boost::pqs::meta::abstract_quantity<
                boost::pqs::meta::dimension<
                    boost::pqs::meta::rational<3>,
                    boost::pqs::meta::rational<-2>,
                    boost::pqs::meta::rational<-1>,
                    boost::pqs::meta::rational<0>,
                    boost::pqs::meta::rational<0>,
                    boost::pqs::meta::rational<0>,
                    boost::pqs::meta::rational<0> 
                >,
                boost::mpl::int_<0>
            >,
            boost::pqs::meta::unit<
                boost::pqs::meta::rational<-11>
            >,
            Value_type
        > type;
   
        static type const& G;
    };

    struct gravitational_constant : gravitational_constant_<double>{};

#ifdef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS
template<typename T>
typename gravitational_constant_<T>::type const & 
gravitational_constant_<T>::G
= typename gravitational_constant_<T>::type(6.6726);
#endif

}}}//boost::pqs::physics

#endif

