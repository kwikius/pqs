#ifndef BOOST_PQS_T1_QUANTITY_UNITS_OSTREAM_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_UNITS_OSTREAM_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    default stream output of ct-quantity.
    defines std::ostream& operator << (std::ostream& ,
         physical_quantity_basic_units_out<...> );
    where physical_quantity_basic_units_out<...>
    is the dummy object returned by invoking pq.units()
*/
#include <iostream>
#include <sstream>
#include <cstring>
#include <string>

#include <boost/pqs/quantity_traits.hpp>
#include <boost/pqs/t1_quantity/io/detail/put_rational.hpp>
#include <boost/pqs/t1_quantity/io/units_out.hpp>
//#include <boost/mpl/at.hpp>
#include <boost/mpl/not_equal_to.hpp>
#include <boost/pqs/t1_quantity/operations/power_root.hpp>
#include <boost/mpl/or.hpp>
//#include <boost/pqs/preboost/check_zero.hpp>
#include <boost/mpl/bool.hpp>


namespace boost{namespace pqs{

// This ostream operator << picks up the physical_quantity_basic_units_out class
// returned by pq.units(). The general idea is to use the p.units() form for
// output of the basic units (and any scaling). The units(pq) form is meant
// for overloading on  eg for a pqs::force::kgf pq;
// pq.units() gives  "[kg.m.s-2 * 9.8XX]"
// units(pq) gives   "kgf"
// this is the pq.units() format definition

    namespace detail{
        template <typename Rat>
        struct rational_not_zero : mpl::bool_<(static_cast<bool>(Rat::numerator))>{};
    }
    template<
        typename CharType,
        typename AbstractQuantity,
        typename Unit
    >
    inline std::basic_ostream<CharType>& 
    operator << 
        (std::basic_ostream<CharType>& os,
            t1_quantity_basic_units_out< 
                AbstractQuantity,
                Unit
            > const&  )
    {
        typedef typename AbstractQuantity::dimension dimension;
        typedef typename dimension::d1 p_length;
        typedef typename dimension::d2 p_time;
        typedef typename dimension::d3 p_mass;
        typedef typename dimension::d4 p_temperature;
        typedef typename dimension::d5 p_current;
        typedef typename dimension::d6 p_substance;
        typedef typename dimension::d7 p_intensity;

        typedef boost::pqs::detail::rational_not_zero<p_length> has_length;
        typedef boost::pqs::detail::rational_not_zero<p_time> has_time;
        typedef boost::pqs::detail::rational_not_zero<p_mass> has_mass;
        typedef boost::pqs::detail::rational_not_zero<p_temperature> has_temperature;
        typedef boost::pqs::detail::rational_not_zero<p_current> has_current;
        typedef boost::pqs::detail::rational_not_zero<p_substance> has_substance;
        typedef boost::pqs::detail::rational_not_zero<p_intensity> has_intensity;

        // fractional exponent or non 1 incoherent multiplier 
        typedef typename boost::mpl::or_<
            boost::mpl::not_equal_to<
                typename Unit::multiplier,
                meta::rational<1>
            >,
            boost::mpl::bool_<
                (Unit::exponent::denominator != 1)
            >
            /*boost::mpl::not_equal_to<
                typename Unit::exponent,
                meta::rational<1>
            >*/
        >::type has_brackets;
        std::ostringstream ost;
        if( has_brackets::value){
            ost << '[';
        }
        if ( has_mass::value){
            ost << "kg";
            detail::put_rational<p_mass>(ost);
            if (
                has_length::value ||has_time::value 
                || has_temperature::value ||has_current::value 
                ||has_substance::value 
                || has_intensity::value
            ){
                ost << '.';
            }
        }
        
        if (has_length::value) {
            ost << 'm';
            detail::put_rational<p_length>(ost);
            if (
                has_time::value || has_temperature::value 
                || has_current::value ||has_substance::value 
                || has_intensity::value
            ){
                ost << '.';
            }
        }
        if (has_time::value){
            ost << 's';
            detail::put_rational<p_time>(ost);
            if ( 
                has_temperature::value ||has_current::value 
                ||has_substance::value || has_intensity::value
            ){
                ost << '.';
            }
        }
        if (has_temperature::value){
            ost << 'K';
            detail::put_rational<p_temperature>(ost);
            if ( has_current::value ||has_substance::value || has_intensity::value){
                ost << '.';
            }
        }
        if (has_current::value){
            ost << 'A';
             detail::put_rational<p_current>(ost);
            if ( has_substance::value || has_intensity::value){
                ost << '.';
            }
        }
        if (has_substance::value){
            ost << "mol";
            detail::put_rational<p_substance>(ost);
            if (has_intensity::value){
                ost << '.';
            }
        }
        if (has_intensity::value){
            ost << "cd";
            detail::put_rational<p_intensity>(ost);
        }
        if( boost::mpl::not_equal_to<
                typename Unit::multiplier,
                boost::pqs::meta::rational<1>
            >::value
        ){
            double mux =
                (static_cast<double>(Unit::multiplier::numerator) 
                / (Unit::multiplier::denominator))
            *
               pqs::pow<
                    Unit::exponent::numerator,
                    Unit::exponent::denominator
                >(10.);
            ost << " * " << mux ;
        } 
        else if(Unit::exponent::numerator !=0 ){
            if (Unit::exponent::denominator == 1){
                // neat exponent
                ost << " * 1e" << Unit::exponent::numerator; 
            }
            else {
                // messy exponent
                ost << " * " 
                <<   pqs::pow<
                    Unit::exponent::numerator,
                    Unit::exponent::denominator
                >(10.) ;
            } 
        }
        if( has_brackets::value){
            ost << ']';
        }
        os << ost.str();
        return os;
    }
    
}}//boost::pqs

#endif

