#ifndef BOOST_PQS_T1_QUANTITY_ABS_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_ABS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    abs t1_quantity
*/
#include <boost/pqs/t1_quantity/t1_quantity.hpp>

namespace boost{namespace pqs{

    template<
        typename AbstractQuantity,
        typename QuantityUnit,
        typename Value_type
    >
    inline 
    t1_quantity<
        AbstractQuantity,
        QuantityUnit,
        Value_type
    >
    abs(
        t1_quantity<
            AbstractQuantity,
            QuantityUnit,
            Value_type
        >const & in)
    {
        return (in.numeric_value() >=0 )
        ? in
        : -in;
    }  
}}//boost::pqs

#endif
