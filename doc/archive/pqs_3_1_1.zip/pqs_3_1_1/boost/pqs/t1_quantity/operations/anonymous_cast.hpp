#ifndef BOOST_PQS_T1_QUANTITY_OPERATIONS_ANONYMOUS_CAST_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_OPERATIONS_ANONYMOUS_CAST_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.
/*
    function to cast a named-concrete-quantity
    to an anonymous_concrete_quantity
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>

namespace boost{namespace pqs{

    template < 
        template<typename,typename > class AbstractQuantity,
        typename Dimension,
        typename AbstractQuantityID,
        typename QuantityUnit,
        typename Value_type
    >
    inline
    t1_quantity<
        AbstractQuantity< 
            Dimension,    
            meta::anonymous_abstract_quantity_id
        >,
        QuantityUnit,
        Value_type
    >
    anonymous_cast(
            t1_quantity<
                AbstractQuantity<
                    Dimension,
                    AbstractQuantityID
                >,
                QuantityUnit,
                Value_type
            > const& pq_in)
    {
        t1_quantity<
            AbstractQuantity< 
                Dimension,    
                meta::anonymous_abstract_quantity_id
            >,
            QuantityUnit,
            Value_type
        > t(pq_in.numeric_value());
        return t;
    }
}}//boost::pqs

#endif
