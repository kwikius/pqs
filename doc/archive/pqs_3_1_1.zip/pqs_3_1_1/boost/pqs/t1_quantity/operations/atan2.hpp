#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef BOOST_PQS_T1_QUANTITY_ATAN2_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_ATAN2_HPP_INCLUDED
//  Copyright (C) Andy Little, White Light Device 2003.
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied warranty,
//  and with no claim as to its suitability for any purpose.

/*
    atan2 for t1_quantities
    returns boost::pqs:::angle::rad
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/angle/angle.hpp>
#include <cmath>

namespace boost{namespace pqs{

    template < 
        template <typename,typename> class AbstractQuantity,
        typename Dimension,
        typename TagA,
        typename UnitsA,
        typename Value_typeA,
        typename TagB,
        typename UnitsB,
        typename Value_typeB
    >
    inline
    mathematic_angle<
        boost::pqs::meta::rational<1>,
        typename quantity_traits::min_real<
            typename boost::pqs::meta::binary_operation<
                Value_typeA,
                boost::pqs::meta::divides,
                Value_typeB
            >::type
        >::type
    >
    atan2( t1_quantity<
            AbstractQuantity<Dimension,TagA>,
            UnitsA,
            Value_typeA
        >const& pqa,
        t1_quantity<
            AbstractQuantity<Dimension,TagB>,
            UnitsB,
            Value_typeB
        >const& pqb )
    {
        typedef  mathematic_angle<
            boost::pqs::meta::rational<1>,
            typename quantity_traits::min_real<
                typename boost::pqs::meta::binary_operation<
                    Value_typeA,
                    boost::pqs::meta::divides,
                    Value_typeB
                >::type
            >::type
        > result_type;
        // maybe should do "finest_grained" here
        typedef typename boost::pqs::meta::binary_operation<
            t1_quantity<
                AbstractQuantity<Dimension,TagA>,
                UnitsA,
                Value_typeA
            >,
            boost::pqs::meta::plus,
            t1_quantity<
                AbstractQuantity<Dimension,TagB>,
                UnitsB,
                Value_typeB
            >
        >::type promoted_type;

        promoted_type ta = pqa;
        promoted_type tb = pqb;

        using std::atan2;
        return result_type(atan2(ta.numeric_value(),tb.numeric_value()));
    }

}}//boost::pqs

#endif
