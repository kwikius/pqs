#ifndef BOOST_PQS_T1_QUANTITY_COMPARE_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_COMPARE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    compare(pqa,pqb) works like strcmp and string::compare:
    if( a == b ) return 0;
    if( a > b ) return 1;
    if( a < b ) return -1;

    compare is basis of all other comp functions
    added 23/09/04 optional 'epsilon' arg to compare
    modified config so default param is type(0)
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/t1_quantity/operations/add_subtract.hpp>
#include <boost/pqs/meta/is_value_type.hpp>
#include <boost/mpl/and.hpp>
#include <boost/pqs/t1_quantity/operations/abs.hpp>
#include <cmath>
#include <cstdlib>

namespace boost{namespace pqs{

    // for compatibility  of built_in types;
    // fails overload resolution
    template<typename TL, typename TR>
    inline
    typename boost::enable_if<
      meta::are_value_type2<TL,TR>,
      int 
    >::type
    compare( TL const & a, TR const & b,
         typename meta::binary_operation<TL,meta::minus,TR>::type const & eps 
            = typename meta::binary_operation<TL,meta::minus,TR>::type(0) )
    {
        using std::abs;
        return ( abs(a-b) <= abs(eps))
        ? 0 
        :( ((a-b) < 0)? -1: 1 );
    }

    template<
        template <typename,typename> class AbstractQuantity,
        typename Dimension,
        typename IdA,
        typename QuantityUnitA,
        typename Value_typeA,
        typename IdB,
        typename QuantityUnitB,
        typename Value_typeB
    >
    inline 
    int 
    compare(
        t1_quantity< 
            AbstractQuantity<Dimension,IdA>,
            QuantityUnitA,
            Value_typeA
        >const & lhs,
        t1_quantity<
            AbstractQuantity<Dimension,IdB>,
            QuantityUnitB,
            Value_typeB
        >const& rhs,
        //ouch :-)
        typename meta::binary_operation<
            t1_quantity< 
                AbstractQuantity<Dimension,IdA>,
                QuantityUnitA,
                Value_typeA
            >,
            meta::minus,
            t1_quantity<
                AbstractQuantity<Dimension,IdB>,
                QuantityUnitB,
                Value_typeB
            >
        >::type const &  ep
        = typename pqs::meta::binary_operation<
            t1_quantity< 
                AbstractQuantity<Dimension,IdA>,
                QuantityUnitA,
                Value_typeA
            >,
            meta::minus,
            t1_quantity<
                AbstractQuantity<Dimension,IdB>,
                QuantityUnitB,
                Value_typeB
            >
        >::type( 
             static_cast<
                typename meta::binary_operation<
                    Value_typeA,
                    meta::minus,
                    Value_typeB
                >::type
            >(BOOST_PQS_COMPARISON_EPSILON)
        )
    )
    {
        typedef typename meta::binary_operation<
                Value_typeA,meta::minus,Value_typeB
        >::type comp_type;
        comp_type cmp = (lhs-rhs).numeric_value();
        using std::abs; // for inbuilts
        int result
        =( abs(cmp) <= abs(ep.numeric_value()))
        ? 0 
        :((cmp < static_cast<comp_type>(0))
            ? -1
            : 1 );
        return result;
    }


    #define BOOST_PQS_COMPARISON_OPERATOR(Op) \
    template<\
        template <typename,typename> class AbstractQuantity,\
        typename Dimension,\
        typename IdA,\
        typename QuantityUnitA,\
        typename Value_typeA,\
        typename IdB,\
        typename QuantityUnitB,\
        typename Value_typeB\
    >\
    inline \
    bool\
    operator Op (  \
        t1_quantity< \
            AbstractQuantity<Dimension,IdA>,\
            QuantityUnitA,\
            Value_typeA\
        >const & a,\
        t1_quantity<\
            AbstractQuantity<Dimension,IdB>,\
            QuantityUnitB,\
            Value_typeB\
        >const& b )\
    {\
        return (compare(a,b) Op 0); \
    }
   
    BOOST_PQS_COMPARISON_OPERATOR(<)
    BOOST_PQS_COMPARISON_OPERATOR(<=)
    BOOST_PQS_COMPARISON_OPERATOR(==)
    BOOST_PQS_COMPARISON_OPERATOR(!=)
    BOOST_PQS_COMPARISON_OPERATOR(>=)
    BOOST_PQS_COMPARISON_OPERATOR(>)
    #undef BOOST_PQS_COMPARISON_OPERATOR
    
}}//boost::pqs

#endif
