#ifndef BOOST_PQS_T1_QUANTITY_MULTIPLY_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_MULTIPLY_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    multiply two t1-quantities
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>
//#include <boost/pqs/meta/unit.hpp>

#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/unary_operation.hpp>
#include <boost/pqs/detail/united_value/operations/dimensioned_multiply.hpp>
#include <boost/pqs/detail/united_value/operations/dimensionless_multiply.hpp>
//#include <boost/pqs/t1_quantity/operations/t1_quantity_bin_op_macros.hpp>

namespace boost{namespace pqs{
    namespace meta{
     // binary operation for multiplication of two quantities
        template <
            typename AbstractQuantityL,
            typename UnitsL ,
            typename Value_typeL ,
            typename AbstractQuantityR,
            typename UnitsR ,
            typename Value_typeR
        > struct binary_operation<
            t1_quantity<
                AbstractQuantityL ,
                UnitsL ,
                Value_typeL
            > ,
            times ,
            t1_quantity<
                AbstractQuantityR ,
                UnitsR ,
                Value_typeR
            >
        >{
            typedef typename binary_operation <
                AbstractQuantityL ,
                times ,
                AbstractQuantityR 
            >::type abstract_quantity;
            typedef typename binary_operation <
                UnitsL ,
                times ,
                UnitsR 
            >::type units;
//#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
//             typedef BOOST_TYPEOF_TPL(
//                Value_typeL() * Value_typeR()
//            ) value_type;
//#else
            typedef typename binary_operation<
                Value_typeL ,
                times, 
                Value_typeR
            >::type value_type;
//#endif
            typedef typename t1_quantity<
                abstract_quantity ,
                units ,
                value_type
            >::type type;
        };
    }}}//meta
    
#if !(defined _MSC_VER && _MSC_VER ==1400)
namespace boost{namespace pqs{
#endif
    // dimensionless
    template< 
        template<typename ,typename> class AbstractQuantity,
        typename Dimension,
        typename IdL,
        typename UnitsL,
        typename Value_typeL,
        typename IdR,
        typename UnitsR,
        typename Value_typeR
    >
    inline
//#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
//    BOOST_TYPEOF_TPL( Value_typeL(1) * Value_typeR(1))
//#else
    typename boost::pqs::meta::binary_operation<
        Value_typeL,
        boost::pqs::meta::times,
        Value_typeR
    >::type
//#endif
    operator *( 
        boost::pqs::t1_quantity<
            AbstractQuantity<Dimension,IdL>,
            UnitsL,
            Value_typeL
        > const & lhs,
        boost::pqs::t1_quantity<
            AbstractQuantity<
                typename boost::pqs::meta::unary_operation<
                    boost::pqs::meta::reciprocal,
                    Dimension
                >::type,
                IdR
            >,
            UnitsR,
            Value_typeR
        > const & rhs )
    {
//#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
//    BOOST_TYPEOF_TPL(
//        Value_typeL() * Value_typeR()
//    )
//#else
        typename boost::pqs::meta::binary_operation<
            Value_typeL,
            boost::pqs::meta::times,
            Value_typeR
        >::type 
//#endif
       result 
        = boost::pqs::detail::dimensionless_multiply(
                lhs.get_united_value(), rhs.get_united_value()
        );
        return result;      
    }
    
////////////non dimensionless//////////////////////////
    template< 
        typename AbstractQuantityL,
        typename UnitsL,
        typename Value_typeL,
        typename AbstractQuantityR,
        typename UnitsR,
        typename Value_typeR
    >
    inline
    typename boost::pqs::meta::binary_operation< 
        boost::pqs::t1_quantity<
            AbstractQuantityL,
            UnitsL,
            Value_typeL
        >,
        boost::pqs::meta::times,
        boost::pqs::t1_quantity<
            AbstractQuantityR,
            UnitsR,
            Value_typeR
        >
    >::type
    operator * ( 
        boost::pqs::t1_quantity<
            AbstractQuantityL,
            UnitsL,
            Value_typeL
        > const & lhs ,
        boost::pqs::t1_quantity<
            AbstractQuantityR,
            UnitsR,
            Value_typeR
        > const & rhs )
        {
            typedef boost::pqs::t1_quantity<
                AbstractQuantityL,
                UnitsL,
                Value_typeL
            > pqL_type;
            typedef boost::pqs::t1_quantity<
                AbstractQuantityR,
                UnitsR,
                Value_typeR
            > pqR_type;
            typename boost::pqs::meta::binary_operation<
                pqL_type,
                boost::pqs::meta::times,
                pqR_type
            >::type result (
                (   
                    boost::pqs::detail::dimensioned_multiply( 
                        lhs.get_united_value(),
                        rhs.get_united_value() 
                    )
                ).raw_value()
            );
            return result;
        }
#if !(defined _MSC_VER && _MSC_VER ==1400)
}} //boost::pqs
#endif


#endif
