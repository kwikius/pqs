#ifndef BOOST_PQS_T1_QUANTITY_SCALAR_DIVIDE_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_SCALAR_DIVIDE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    division of ct-quantity by numeric
*/

#include <boost/pqs/t1_quantity/t1_quantity.hpp>
#include <boost/pqs/meta/binary_operation_if.hpp>
#include <boost/pqs/meta/is_valid_binary_operation.hpp>
//#include <boost/pqs/meta/is_t1_quantity_value_type.hpp>
#include <boost/pqs/meta/is_value_type.hpp>
#include <boost/mpl/and.hpp>

namespace boost{namespace pqs{
    namespace meta{
        //value_type / pq
        template<
            typename ArithmeticType,
            typename AbstractQuantity,
            typename Units,
            typename Value_type
        >
        struct binary_operation<
            ArithmeticType,
            divides,
            boost::pqs::t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            typename boost::enable_if<
                boost::mpl::and_<
                    is_value_type<ArithmeticType>,
                    is_valid_binary_operation<
                        ArithmeticType,
                        divides,
                        Value_type
                    >
                >
            >::type
            
        >{
            typedef boost::pqs::t1_quantity<
                typename unary_operation<
                    reciprocal,
                    AbstractQuantity
                >::type,
                typename unary_operation<
                    reciprocal,
                    Units
                >::type,
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
                BOOST_TYPEOF_TPL(
                    ArithmeticType() / Value_type(1)
                )
#else
                typename binary_operation<
                    ArithmeticType,
                    divides,
                    Value_type
                >::type
#endif
            > type;
        };   

        //pq / value_type
        template<
            typename AbstractQuantity,
            typename Units,
            typename Value_type,
            typename ArithmeticType
        >
        struct binary_operation<
            typename boost::pqs::t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            divides,
            ArithmeticType,
            typename boost::enable_if<
                boost::mpl::and_<
                    is_value_type<ArithmeticType>,
                    is_valid_binary_operation<
                        Value_type,
                        divides,
                        ArithmeticType
                    >
                >
            >::type
        >{
            typedef boost::pqs::t1_quantity<
                AbstractQuantity,
                Units,
                typename binary_operation<
                    Value_type,
                    divides,
                    ArithmeticType
                >::type
            > type;
        };
             
}}}//boost::pqs::meta
#if !(defined _MSC_VER && _MSC_VER ==1400)
namespace boost{namespace pqs{
#endif
    //scalar / PQ 
    template<
        typename ArithmeticType,
        typename AbstractQuantity,
        typename Units,
        typename Value_type 
    >
    inline 
    typename boost::pqs::meta::binary_operation_if<
        boost::pqs::meta::is_value_type<ArithmeticType>,
        ArithmeticType,
        boost::pqs::meta::divides,
        boost::pqs::t1_quantity<
            AbstractQuantity,
            typename boost::pqs::meta::transform_coherent<
                Units
            >::type,
            Value_type
        >
    >::type
    operator / (
        ArithmeticType const & v,
        boost::pqs::t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >const & pq)
    {   
        typedef boost::pqs::t1_quantity<
            AbstractQuantity,
            typename boost::pqs::meta::transform_coherent<
                Units
            >::type,
            Value_type
        > coherent_type;
        coherent_type coh(pq);
            
        typename boost::pqs::meta::binary_operation<
            ArithmeticType,
            boost::pqs::meta::divides,
            coherent_type
        >::type result( v/coh.numeric_value() );
        return result;
    }

    // PQ / scalar
    template<
        typename AbstractQuantity,
        typename Units,
        typename Value_type,
        typename ArithmeticType
    >
    inline 
    typename boost::pqs::meta::binary_operation_if<
        boost::pqs::meta::is_value_type<ArithmeticType>,
        boost::pqs::t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >,
        boost::pqs::meta::divides,
        ArithmeticType
    >::type
    operator / (
        boost::pqs::t1_quantity<
            AbstractQuantity,
            Units,
            Value_type
        >const & pq,
        ArithmeticType const& v)
    {
        typename boost::pqs::meta::binary_operation<
            boost::pqs::t1_quantity<
                AbstractQuantity,
                Units,
                Value_type
            >,
            boost::pqs::meta::divides,
            ArithmeticType
        >::type result(pq.numeric_value() / v);
        return result;
    }
#if !(defined _MSC_VER && _MSC_VER ==1400)
}} //boost::pqs
#endif


#endif
