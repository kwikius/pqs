#ifndef BOOST_PQS_T1_QUANTITY_TO_ARITHMETIC_HPP_INCLUDED
#define BOOST_PQS_T1_QUANTITY_TO_ARITHMETIC_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    to_arithmetic for t1_quantity
*/

#include <boost/pqs/meta/to_arithmetic.hpp>
#include <boost/pqs/t1_quantity/t1_quantity.hpp>

namespace boost{namespace pqs{namespace meta{

    template <typename D, typename U, typename V>
    struct to_arithmetic<
        boost::pqs::t1_quantity<D,U,V>
    >{

       typedef V type;
    
        type operator()( boost::pqs::t1_quantity<D,U,V> const & in)
        {
            return in.numeric_value();
        }
    };

}}}//boost::pqs::meta

#endif
 