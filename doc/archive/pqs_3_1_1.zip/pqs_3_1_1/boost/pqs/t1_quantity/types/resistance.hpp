#ifndef BOOST_PQS_RESISTANCE_HPP_INCLUDED
#define BOOST_PQS_RESISTANCE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_resistance.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct resistance_ : meta::components::of_resistance{
        typedef t1_quantity<
            type,
            typename meta::si_unit::yocto, // coherent-exponent -24
            Value_type
        > yR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > zR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > aR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > fR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > pR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > nR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > uR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > mR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > cR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > dR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > R;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > daR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > hR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > kR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > MR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > GR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > TR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > PR;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > ER;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZR;

        typedef t1_quantity<
            type,
            typename incoherent_unit::abohm,
            Value_type
        > abohm;

    };

    struct resistance : resistance_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
