#ifndef BOOST_PQS_XXXX_HPP_INCLUDED
#define BOOST_PQS_XXXX_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/pqs/meta/components/of_xxxx.hpp>

namespace boost{namespace pqs{

    template<
        typename Value_type
    >
    struct xxxx_ : meta::components::of_xxxx{

///////////////////////////////////////////////////////////////////////////////////
        // This asserts as a reminder. Read this and remove it for the particular quantity
        BOOST_STATIC_ASSERT((extent == 1 && prefix_offset == 0));
        // The simple relationship between the exponent for the unit
        // and the prefix only holds if the above conditions hold.
        // If not then the typedef_name prefix for the unit below is found by
        //typedef_name_prefix == si_unit_exponent / extent + offset

    //Note. Obviously you only need to define the quantities you actually require to use. Just delete the rest.
///////////////////////////////////////////////////////////////////////////////////

        typedef t1_quantity<
            type,
            typename meta::si_unit::yocto, // coherent-exponent -24
            Value_type
        > yXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zepto, // coherent-exponent -21
            Value_type
        > zXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::atto, // coherent-exponent -18
            Value_type
        > aXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::femto, // coherent-exponent -15
            Value_type
        > fXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::pico, // coherent-exponent -12
            Value_type
        > pXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::nano, // coherent-exponent -9
            Value_type
        > nXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::micro, // coherent-exponent -6
            Value_type
        > uXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::milli, // coherent-exponent -3
            Value_type
        > mXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::centi, // coherent-exponent -2
            Value_type
        > cXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deci, // coherent-exponent -1
            Value_type
        > dXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::none, // coherent-exponent 0
            Value_type
        > XXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::deka, // coherent-exponent 1
            Value_type
        > daXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::hecto, // coherent-exponent 2
            Value_type
        > hXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::kilo, // coherent-exponent 3
            Value_type
        > kXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::mega, // coherent-exponent 6
            Value_type
        > MXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::giga, // coherent-exponent 9
            Value_type
        > GXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::tera, // coherent-exponent 12
            Value_type
        > TXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::peta, // coherent-exponent 15
            Value_type
        > PXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::exa, // coherent-exponent 18
            Value_type
        > EXXXXXX;

        typedef t1_quantity<
            type,
            typename meta::si_unit::zetta, // coherent-exponent 21
            Value_type
        > ZXXXXXX;

//incoherent units
        typedef t1_quantity<
            type,
            typename incoherent_unit::some_incoherent_xxxx_unit,
            Value_type
        > some_incoherent_xxxx_unit;

    /*
        More incoherent units
    */

    };

    struct xxxx : xxxx_<quantity_traits::default_value_type>{};

}}//boost::pqs

#endif
