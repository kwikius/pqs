#ifndef BOOST_PQS_THREE_D_GNOS_VECT_HPP_INCLUDED
#define BOOST_PQS_THREE_D_GNOS_VECT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
     3d homogeneous vector for use in matrices etc.
    ("gnos_vect" is meant to be short for homogeneous_vect)
    converts to from ordinary vect
*/
#include <boost/tuple/tuple.hpp>
#include <boost/typeof/typeof.hpp>
#include <boost/pqs/three_d/vect_def.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_arithmetic.hpp>
#include <boost/implicit_cast.hpp>

namespace boost{namespace pqs{ namespace three_d{
 
    namespace detail{

        template <typename T>
        struct gnos_vect_base{
            typedef BOOST_TYPEOF_TPL( T() / T(1) ) value_type;
            typedef BOOST_TYPEOF_TPL( value_type() / T(1)) reciprocal_type;
            typedef boost::tuples::tuple<
                value_type,
                value_type,
                value_type, 
                reciprocal_type
            > base_type;
        };
    }//detail

    template <typename T>
    struct gnos_vect : detail::gnos_vect_base<T>::base_type
    {
        typedef detail::gnos_vect_base<T> base_container_type;
        typedef typename base_container_type::base_type base_type;
        typedef typename base_container_type::value_type value_type;
        typedef typename base_container_type::reciprocal_type reciprocal_type;

        gnos_vect() 
        : base_type(value_type(0),value_type(0),value_type(0),reciprocal_type(1)){} 
    template <typename T1>
        gnos_vect(vect<T1> const & in)
        :base_type( 
             boost::implicit_cast<value_type>(in.x / T(1))
            ,boost::implicit_cast<value_type>(in.y / T(1))
            ,boost::implicit_cast<value_type>(in.z / T(1))
            , reciprocal_type(1)
        ){} 
        template<typename T0, typename T1, typename T2, typename T3>
        gnos_vect(T0 const & t0, T1 const & t1, T2 const & t2, T3 const& t3 ) 
        : base_type(
            boost::implicit_cast<value_type>(t0)
            ,boost::implicit_cast<value_type>(t1)
            ,boost::implicit_cast<value_type>(t2)
           , boost::implicit_cast<reciprocal_type>(t3)
        ){} 
        template<typename T0, typename T1, typename T2>
        gnos_vect(T0 const & t0, T1 const & t1, T2 const & t2 ) 
        : base_type(
            boost::implicit_cast<value_type>(t0)
            ,boost::implicit_cast<value_type>(t1)
            ,boost::implicit_cast<value_type>(t2)
           , reciprocal_type(1)
        ){} 
        
        template <int N>
        struct type_at{
            typedef typename boost::tuples::element<
                N,
               base_type
            >::type type;
        };

        template<int N>
        typename type_at<N>::type
        at()const
        {
            typename type_at<N>::type t = this->get<N>();
            return t;
        }
        template<int N>
        typename type_at<N>::type &
        at()
        {
            typename type_at<N>::type& t = this->get<N>();
            return t;
        }
    };

}}}//boost::pqs::three_d

#endif


