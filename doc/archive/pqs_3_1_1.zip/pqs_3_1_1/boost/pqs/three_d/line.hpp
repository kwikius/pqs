#ifndef BOOST_PQS_THREE_D_LINE_HPP_INCLUDED
#define BOOST_PQS_THREE_D_LINE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    simple 3d line
*/

namespace boost {namespace pqs{ namespace three_d{

    template <typename PointType>
    struct line{
        typedef PointType point_type;
        line(point_type const & p1_in ,point_type const & p2_in)
        : from(p1_in),to(p2_in){}
        template<typename T1>
        line(line<T1> const & in)
        : p1(in.p1),p2(in.p2){}
        point_type from, to;
    };

}}}//boost::pqs::three_d




#endif
