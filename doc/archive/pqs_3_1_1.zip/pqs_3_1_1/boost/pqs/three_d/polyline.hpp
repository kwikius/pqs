#ifndef BOOST_PQS_THREE_D_POLYLINE_HPP_INCLUDED
#define BOOST_PQS_THREE_D_POLYLINE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    Dubious polyline. derivation from std::vector ok?   
    Currently Not same paradigm as e.g line where 
    PointType is param rather than value_type
    to do
*/

#include <vector>
#include <boost/pqs/three_d/vect.hpp>

namespace boost{namespace pqs{namespace three_d{

    template <typename T>
    struct polyline : std::vector<vect<T> >{

     polyline(): std::vector<vect<T> >(){}
     };

}}}///pqs::three_d


#endif
