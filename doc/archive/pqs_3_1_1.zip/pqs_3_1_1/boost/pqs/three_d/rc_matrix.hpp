#ifndef BOOST_PQS_THREE_D_RC_MATRIX_HPP_INCLUDED
#define BOOST_PQS_THREE_D_RC_MATRIX_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    3d row column transform matrix
*/

#include "boost/tuple/tuple.hpp"
#include <boost/typeof/typeof.hpp>
#include <boost/utility/enable_if.hpp>

namespace boost{namespace pqs{namespace three_d{

    namespace detail{
            template <typename T>
        struct rc_matrix_base{
            typedef T quantity_type;
            typedef BOOST_TYPEOF_TPL( T() / T(1)) value_type;
            typedef BOOST_TYPEOF_TPL( value_type() / T(1)) reciprocal_type;
            typedef boost::tuple<
                value_type,value_type,value_type,reciprocal_type
            > row0_type;
            typedef boost::tuple<
                value_type,value_type,value_type,reciprocal_type
            > row1_type;
            typedef boost::tuple<
                value_type,value_type,value_type,reciprocal_type
            > row2_type;
            typedef boost::tuple<
                    quantity_type,quantity_type,quantity_type,value_type
            > row3_type;
            typedef row0_type                                          row_vector;
            typedef boost::tuple<row0_type,row1_type,row2_type,row3_type>        matrix;
        };
    }//detail

    template<typename Quantity>
    struct rc_matrix : private detail::rc_matrix_base<Quantity>::matrix{

        typedef detail::rc_matrix_base<Quantity> base_type;
        typedef Quantity quantity_type;
        typedef typename base_type::matrix base_matrix_type;
        typedef typename base_type::value_type value_type ;
        typedef typename base_type::reciprocal_type reciprocal_type;
        typedef rc_matrix type;
        rc_matrix()
        : base_matrix_type(
            typename base_type::row0_type(value_type(0),value_type(0),value_type(0),reciprocal_type(0)),
            typename base_type::row1_type(value_type(0),value_type(0),value_type(0),reciprocal_type(0)),
            typename base_type::row2_type(value_type(0),value_type(0),value_type(0),reciprocal_type(0)),
            typename base_type::row3_type(quantity_type(0),quantity_type(0),quantity_type(0),value_type(1))
        ){}
        
        rc_matrix(
            value_type const& m0_0,value_type const& m0_1,value_type const& m0_2, reciprocal_type const & m0_3,
            value_type const& m2_0,value_type const& m2_1, value_type const& m2_2,reciprocal_type const & m2_3,
            value_type const& m1_0,value_type const& m1_1, value_type const& m1_2,reciprocal_type const & m1_3,
            quantity_type const& m3_0 = quantity_type(0) ,
                quantity_type const& m3_1 = quantity_type(0),   
                    quantity_type const& m3_2 = quantity_type(0), 
                                value_type const & m3_3 = value_type(1)
        )
        : base_matrix_type(
            typename base_type::row0_type(m0_0,m0_1,m0_2,m0_3),
            typename base_type::row1_type(m1_0,m1_1,m1_2,m1_3),
            typename base_type::row2_type(m2_0,m2_1,m2_2,m2_3),
            typename base_type::row3_type(m3_0,m3_1,m3_2,m3_3)
        ){}
        template <typename Q1>
        rc_matrix(rc_matrix<Q1> const & in)
        : base_matrix_type(
            typename base_type::row0_type(
            in.at<0,0>(),in.at<0,1>(),in.at<0,2>(),in.at<0,3>()),
            typename base_type::row1_type(
            in.at<1,0>(),in.at<1,1>(), in.at<1,2>(),in.at<1,3>()),
            typename base_type::row2_type(
            in.at<2,0>(),in.at<2,1>(),in.at<2,2>(),in.at<2,3>()),
            typename base_type::row3_type(
            in.at<3,0>(),in.at<3,1>(),in.at<3,2>(),in.at<3,3>())
        ){}

        template<int R>
        struct row_type_at{
            typedef typename boost::tuples::element<
                R,
                base_matrix_type
            >::type type;
        };
        //element type
        template<int R, int C>
        struct type_at{
         
            typedef typename boost::tuples::element<
                C,
                typename row_type_at<R>::type
            >::type type;
        };

        template<int R, int C>
        typename type_at<R,C>::type
        at()const   
        {
            typename type_at<R,C>::type t = this->get<R>().get<C>();
            return t;
        }
        template<int R, int C>
        typename type_at<R,C>::type &
        at()   
        {
            typename type_at<R,C>::type& t = this->get<R>().get<C>();
            return t;
        }
//row 0
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 0 && C ==0,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<1,1>()
                        * ( this->at<2,2>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,2>()) 
                    - this->at<1,2>() 
                        * ( this->at<2,1>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,1>())
                    + this->at<1,3>()
                        * ( this->at<2,1>() * this->at<3,2>() - this->at<2,2>() *  this->at<3,1>())
                 );
            return t;
        }
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 0 && C ==1,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<1,0>()
                        * ( this->at<2,2>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,2>()) 
                    - this->at<1,2>() 
                        * ( this->at<2,0>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,0>())
                    + this->at<1,3>()
                        * ( this->at<2,0>() * this->at<3,2>() - this->at<2,2>() *  this->at<3,0>())
                 );
            return t;
        }
    
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 0 && C ==2,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<1,0>()
                        * ( this->at<2,1>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,1>()) 
                    - this->at<1,1>() 
                        * ( this->at<2,0>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,0>())
                    + this->at<1,3>()
                        * ( this->at<2,0>() * this->at<3,1>() - this->at<2,1>() *  this->at<3,0>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 0 && C ==3,
           quantity_type
        >::type 
        cofactor()const
        {   
            quantity_type t 
                = (   this->at<1,0>()
                        * ( this->at<2,1>() * this->at<3,2>() - this->at<2,2>() *  this->at<3,1>()) 
                    - this->at<1,1>() 
                        * ( this->at<2,0>() * this->at<3,2>() - this->at<2,2>() *  this->at<3,0>())
                    + this->at<1,2>()
                        * ( this->at<2,0>() * this->at<3,1>() - this->at<2,1>() *  this->at<3,0>())
                 );
            return t;
        }
//row 1
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 1 && C ==0,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<0,1>()
                        * ( this->at<2,2>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,2>()) 
                    - this->at<0,2>() 
                        * ( this->at<2,1>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,1>())
                    + this->at<0,3>()
                        * ( this->at<2,1>() * this->at<3,2>() - this->at<2,2>() *  this->at<3,1>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 1 && C ==1,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<0,0>()
                        * ( this->at<2,2>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,2>()) 
                    - this->at<0,2>() 
                        * ( this->at<2,0>() * this->at<3,3>() - this->at<2,3>() *  this->at<3,0>())
                    + this->at<0,3>()
                        * ( this->at<2,0>() * this->at<3,2>() - this->at<2,2>() *  this->at<3,0>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 1 && C ==2,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<0,0>()
                        * ( this->at<1,1>() * this->at<3,3>() - this->at<1,3>() *  this->at<3,1>()) 
                    - this->at<0,1>() 
                        * ( this->at<1,0>() * this->at<3,3>() - this->at<1,3>() *  this->at<3,0>())
                    + this->at<0,3>()
                        * ( this->at<1,0>() * this->at<3,1>() - this->at<1,1>() *  this->at<3,0>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 1 && C ==3,
           quantity_type
        >::type 
        cofactor()const
        {   
            quantity_type t 
                = (   this->at<0,0>()
                        * ( this->at<2,1>() * this->at<3,2>() - this->at<2,2>() *  this->at<3,1>()) 
                    - this->at<0,1>() 
                        * ( this->at<2,0>() * this->at<3,2>() - this->at<2,2>() *  this->at<3,0>())
                    + this->at<0,2>()
                        * ( this->at<2,0>() * this->at<3,1>() - this->at<1,1>() *  this->at<3,0>())
                 );
            return t;
        }
//row 2

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 2 && C ==0,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<0,1>()
                        * ( this->at<1,2>() * this->at<3,3>() - this->at<1,3>() *  this->at<3,2>()) 
                    - this->at<0,2>() 
                        * ( this->at<1,1>() * this->at<3,3>() - this->at<1,3>() *  this->at<3,1>())
                    + this->at<0,3>()
                        * ( this->at<1,1>() * this->at<3,2>() - this->at<1,2>() *  this->at<3,1>())
                 );
            return t;
        }
        
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 2 && C ==1,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<0,0>()
                        * ( this->at<1,2>() * this->at<3,3>() - this->at<1,3>() *  this->at<3,2>()) 
                    - this->at<0,2>() 
                        * ( this->at<1,0>() * this->at<3,3>() - this->at<1,3>() *  this->at<3,0>())
                    + this->at<0,3>()
                        * ( this->at<1,0>() * this->at<3,2>() - this->at<1,2>() *  this->at<3,0>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 2 && C ==2,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<0,0>()
                        * ( this->at<1,1>() * this->at<3,3>() - this->at<1,3>() *  this->at<3,1>()) 
                    - this->at<0,1>() 
                        * ( this->at<1,0>() * this->at<3,3>() - this->at<1,3>() *  this->at<3,0>())
                    + this->at<0,3>()
                        * ( this->at<1,0>() * this->at<3,1>() - this->at<1,1>() *  this->at<3,0>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 2 && C ==3,
            quantity_type
        >::type 
        cofactor()const
        {   
            quantity_type t 
                = (   this->at<0,0>()
                        * ( this->at<1,1>() * this->at<3,2>() - this->at<1,2>() *  this->at<3,1>()) 
                    - this->at<0,1>() 
                        * ( this->at<1,0>() * this->at<3,2>() - this->at<1,2>() *  this->at<3,0>())
                    + this->at<0,2>()
                        * ( this->at<1,0>() * this->at<3,1>() - this->at<1,1>() *  this->at<3,0>())
                 );
            return t;
        }

//row 3

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 3 && C ==0,
            reciprocal_type
        >::type 
        cofactor()const
        {   
            reciprocal_type t 
                = (   this->at<0,1>()
                        * ( this->at<1,2>() * this->at<2,3>() - this->at<1,3>() *  this->at<2,2>()) 
                    - this->at<0,2>() 
                        * ( this->at<1,1>() * this->at<2,3>() - this->at<1,3>() *  this->at<2,1>())
                    + this->at<0,3>()
                        * ( this->at<1,1>() * this->at<2,2>() - this->at<1,2>() *  this->at<2,1>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 3 && C ==1,
            reciprocal_type
        >::type 
        cofactor()const
        {   
            reciprocal_type t 
                = (   this->at<0,0>()
                        * ( this->at<1,2>() * this->at<2,3>() - this->at<1,3>() *  this->at<2,2>()) 
                    - this->at<0,2>() 
                        * ( this->at<1,0>() * this->at<2,3>() - this->at<1,3>() *  this->at<2,0>())
                    + this->at<0,3>()
                        * ( this->at<1,0>() * this->at<2,2>() - this->at<1,2>() *  this->at<2,0>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 3 && C ==2,
            reciprocal_type
        >::type 
        cofactor()const
        {   
            reciprocal_type t 
                = (   this->at<0,0>()
                        * ( this->at<1,1>() * this->at<2,3>() - this->at<1,3>() *  this->at<1,2>()) 
                    - this->at<0,1>() 
                        * ( this->at<1,0>() * this->at<2,3>() - this->at<1,3>() *  this->at<2,0>())
                    + this->at<0,3>()
                        * ( this->at<1,0>() * this->at<2,1>() - this->at<1,1>() *  this->at<2,0>())
                 );
            return t;
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 3 && C ==3,
            value_type
        >::type 
        cofactor()const
        {   
            value_type t 
                = (   this->at<0,0>()
                        * ( this->at<1,1>() * this->at<2,2>() - this->at<1,2>() *  this->at<2,1>()) 
                    - this->at<0,1>() 
                        * ( this->at<1,0>() * this->at<2,2>() - this->at<1,2>() *  this->at<2,0>())
                    + this->at<0,2>()
                        * ( this->at<1,0>() * this->at<2,1>() - this->at<1,1>() *  this->at<2,0>())
                 );
            return t;
        }
    };
        

}}}//boost::pqs::three_d

#endif
