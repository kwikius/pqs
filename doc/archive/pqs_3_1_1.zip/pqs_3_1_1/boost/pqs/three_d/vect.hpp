#ifndef BOOST_PQS_THREE_D_VECT_HPP_INCLUDED
#define BOOST_PQS_THREE_D_VECT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    3d vect definition + operations
*/
#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/three_d/vect_def.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_arithmetic.hpp>

#if !(defined _MSC_VER && _MSC_VER ==1400 && defined BOOST_PQS_SUPPRESS_VC8_ADL_BUG)
namespace boost{namespace pqs{namespace three_d{
#endif

    template <typename TL, typename TR>
    inline
    boost::pqs::three_d::vect<
        typename boost::pqs::meta::binary_operation< 
            TL,
            boost::pqs::meta::plus,
            TR
        >::type
    >
    operator +( 
        boost::pqs::three_d::vect<TL> const & lhs, 
        boost::pqs::three_d::vect<TR> const & rhs
    )
    {
        boost::pqs::three_d::vect<
            typename boost::pqs::meta::binary_operation< 
                TL,
                boost::pqs::meta::plus,
                TR
            >::type
        > result(lhs.x +rhs.x, lhs.y+rhs.y, lhs.z + rhs.z);
        return result;
    }

    template <typename TL, typename TR>
    inline
    boost::pqs::three_d::vect<
        typename boost::pqs::meta::binary_operation< 
            TL,
            boost::pqs::meta::minus,
            TR
        >::type
    >
    operator -( 
        boost::pqs::three_d::vect<TL> const & lhs,
         boost::pqs::three_d::vect<TR> const & rhs)
    {
        boost::pqs::three_d::vect<
            typename boost::pqs::meta::binary_operation< 
                TL,
                boost::pqs::meta::minus,
                TR
            >::type
        > result(lhs.x -rhs.x, lhs.y-rhs.y, lhs.z - rhs.z);
        return result;
    }

    template <typename TL, typename TR>
    inline
    boost::pqs::three_d::vect<
        typename boost::pqs::meta::binary_operation< 
            TL,
            boost::pqs::meta::times,
            TR
        >::type
    >
    operator *( boost::pqs::three_d::vect<TL> const & lhs, TR const & rhs)
    {
        typedef typename boost::pqs::meta::binary_operation< 
            TL,
            boost::pqs::meta::times,
            TR
        >::type value_type;
        value_type x = lhs.x * rhs, y =lhs.y * rhs, z = lhs.z * rhs;   
        boost::pqs::three_d::vect<value_type> result(x,y,z);
        return result;
    }

    template <typename TL, typename TR>
    inline
    boost::pqs::three_d::vect<
        typename boost::pqs::meta::binary_operation< 
            TL,
            boost::pqs::meta::times,
            TR
        >::type
    >
    operator  *( TL const & lhs, boost::pqs::three_d::vect<TR> const & rhs)
    {
         boost::pqs::three_d::vect<
            typename boost::pqs::meta::binary_operation< 
                TL,
                boost::pqs::meta::times,
                TR
            >::type
        > result(lhs *rhs.x, lhs * rhs.y,lhs * rhs.z);
        return result;
    }

    template <typename TL, typename TR>
    inline
    boost::pqs::three_d::vect<
        typename boost::pqs::meta::binary_operation< 
            TL,
            boost::pqs::meta::divides,
            TR
        >::type
    > 
    operator  /( boost::pqs::three_d::vect<TL> const & lhs, TR const & rhs)
    {
        boost::pqs::three_d::vect<
            typename boost::pqs::meta::binary_operation< 
                TL,
                boost::pqs::meta::divides,
                TR
            >::type
        > result(lhs.x / rhs, lhs.y / rhs, lhs.z / rhs);
        return result;
    }
    template <typename Value_type>
    Value_type
    magnitude( boost::pqs::three_d::vect<Value_type> const & v)
    {
        Value_type result = sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
        return result;
    }

    template <typename T1,typename T2>
    inline 
    typename boost::pqs::meta::binary_operation< 
        T1,
        boost::pqs::meta::times,
        T2
    >::type
    dot_product( 
        boost::pqs::three_d::vect<T1> const & lhs,
        boost::pqs::three_d::vect<T2> const & rhs
    ){
        typedef typename boost::pqs::meta::binary_operation< 
            T1,
            boost::pqs::meta::times,
            T2
        >::type result_type;
        result_type result 
        = lhs.x * rhs.x + lhs.y * rhs.y  + lhs.z * rhs.z;
        return result;
    }

    template<typename T1, typename T2>
    inline
    boost::pqs::three_d::vect<
        typename boost::pqs::meta::binary_operation< 
            T1,
            boost::pqs::meta::times,
            T2
        >::type
    >
    cross_product(
        boost::pqs::three_d::vect<T1> const & lhs,
        boost::pqs::three_d::vect<T2> const & rhs
    ){
        boost::pqs::three_d::vect<
            typename boost::pqs::meta::binary_operation< 
                T1,
                boost::pqs::meta::times,
                T2
            >::type
        > result(
            lhs.y * rhs.z - lhs.z * rhs.y,
            lhs.z * rhs.x - lhs.x * rhs.z, 
            lhs.x * rhs.y - lhs.y * rhs.x
        );
        return result;
    }
#if !(defined _MSC_VER && _MSC_VER ==1400 && defined BOOST_PQS_SUPPRESS_VC8_ADL_BUG)
}}}//boost::pqs::three_d
#endif

#endif
