#ifndef BOOST_PQS_THREE_D_VECT_DEF_HPP_INCLUDED
#define BOOST_PQS_THREE_D_VECT_DEF_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    3d vect definition
*/

#include <boost/implicit_cast.hpp>
#include <boost/static_assert.hpp>
#include <stdexcept>

namespace boost{namespace pqs{ namespace three_d{
 
   template <typename T>
    struct vect
    {
        typedef T value_type;
        vect() 
        : x( static_cast<T>(0) )
        , y( static_cast<T>(0) )
        , z( static_cast<T>(0) )
        {}
        template <typename Tx, typename Ty, typename Tz>
        vect(Tx const & x_in, Ty const & y_in, Tz const & z_in)
        : x( boost::implicit_cast<T>(x_in) )
        , y( boost::implicit_cast<T>(y_in) )
        , z( boost::implicit_cast<T>(z_in) ){}
        T x,y,z;

        template <typename T1>
        vect &
        operator = (vect<T1> const & in)
        {
            this->x = in.x;
            this->y = in.y;
            this->z = in.z;
            return * this;
        }

        template <typename T1>
        vect &
        operator += (vect<T1> const & in)
        {
            this->x += in.x;
            this->y += in.y;
            this->z += in.z;
            return * this;
        }
        template <typename T1>
        vect &
        operator -= (vect<T1> const & in)
        {
            this->x -= in.x;
            this->y -= in.y;
            this->z -= in.z;
            return * this;
        }

        
        T & operator[](int n)
        {
            BOOST_STATIC_ASSERT( (sizeof(vect) == 3 * sizeof(T)) );
            if( (n < 0) || (n >2)){
                throw std::length_error("array subscript out of range in vect");
            }
            
            T* p = & x;
            return p[n];
        }
        T const & operator[](int n)const
        {
            BOOST_STATIC_ASSERT( (sizeof(vect) == 3 * sizeof(T)) );
            if( (n < 0) || (n >2)){
                throw std::length_error("array subscript out of range in vect");
            }
            
            T const * p = & x;
            return p[n];
        }
        
    };

}}}//boost::pqs::three_d

#endif

