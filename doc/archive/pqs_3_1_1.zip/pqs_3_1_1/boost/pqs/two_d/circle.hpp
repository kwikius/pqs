#ifndef BOOST_PQS_TWO_D_CIRCLE_HPP_INCLUDED
#define BOOST_PQS_TWO_D_CIRCLE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    circle by center-position and radius
*/

#include <boost/pqs/two_d/vect.hpp>
namespace boost{namespace pqs{namespace two_d{

    template<typename Value_type>
    struct circle{
        circle(
            vect<Value_type>const & position_in, 
            Value_type const & radius_in
        )
        : position(position_in),radius(radius_in){}
        vect<Value_type> position;
        Value_type radius;
    };

}}}//boost::pqs::two_d


#endif
