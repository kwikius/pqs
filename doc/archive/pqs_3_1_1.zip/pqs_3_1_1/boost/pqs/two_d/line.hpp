#ifndef BOOST_PQS_TWO_D_LINE_HPP_INCLUDED
#define BOOST_PQS_TWO_D_LINE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    simple 2d line.
    Note that this is identical to 3d line
    except for namespace.
*/

namespace boost {namespace pqs{ namespace two_d{

    template <typename PointType>
    struct line{
        typedef PointType point_type;
        
        line(point_type const & p1_in ,point_type const & p2_in)
        : p1(p1_in),p2(p2_in){}
        template<typename T1>
        line(line<T1> const & in)
        : p1(in.p1),p2(in.p2){}
        point_type p1,p2;
    };

}}}//boost::pqs::two_d

#endif
