#ifndef BOOST_PQS_TWO_D_RC_MATRIX_HPP_INCLUDED
#define BOOST_PQS_TWO_D_RC_MATRIX_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    transformation matrix for homogeneous row vector
    in Row major format, Column major format might be better
*/

#include <cassert>
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_arithmetic.hpp>
#include <boost/pqs/two_d/rc_matrix_base.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/static_assert.hpp>

namespace boost{namespace pqs{namespace two_d{

    template <typename T>
    struct is_rc_matrix;
    template<typename Quantity>
    struct rc_matrix : private detail::rc_matrix_base<Quantity>::matrix{
        typedef detail::rc_matrix_base<Quantity> base_type;
        typedef Quantity quantity_type;
        typedef typename base_type::matrix base_matrix_type;
        typedef typename base_type::value_type value_type ;
        typedef typename base_type::reciprocal_type reciprocal_type;
        typedef rc_matrix type;
        rc_matrix()
        : base_matrix_type(
            typename base_type::row0_type(value_type(0),value_type(0),reciprocal_type(0)),
            typename base_type::row1_type(value_type(0),value_type(0),reciprocal_type(0)),
            typename base_type::row2_type(quantity_type(0),quantity_type(0),value_type(1))
        ){}
        
        rc_matrix(
            value_type const& m0_0,value_type const& m0_1, reciprocal_type const & m0_2,
            value_type const& m1_0,value_type const& m1_1, reciprocal_type const & m1_2,
            quantity_type const& m2_0 = quantity_type(0) ,
                quantity_type const& m2_1 = quantity_type(0), 
                    value_type const & m2_2 = value_type(1)
        )
        : base_matrix_type(
            typename base_type::row0_type(m0_0,m0_1,m0_2),
            typename base_type::row1_type(m1_0,m1_1,m1_2),
            typename base_type::row2_type(m2_0,m2_1,m2_2)
        ){}
        template <typename Q1>
        rc_matrix(rc_matrix<Q1> const & in)
        : base_matrix_type(
            typename base_type::row0_type(
            in.at<0,0>(),in.at<0,1>(),in.at<0,2>()),
            typename base_type::row1_type(
            in.at<1,0>(),in.at<1,1>(), in.at<1,2>()),
            typename base_type::row2_type(
            in.at<2,0>(),in.at<2,1>(),in.at<2,2>())
        ){}
        template<int R>
        struct row_type_at{
            typedef typename boost::tuples::element<
                R,
                base_matrix_type
            >::type type;
        };
        //element type
        template<int R, int C>
        struct type_at{
         
            typedef typename boost::tuples::element<
                C,
                typename row_type_at<R>::type
            >::type type;
        };

        template<int R, int C>
        typename type_at<R,C>::type
        at()const   
        {
            typename type_at<R,C>::type t = this->get<R>().get<C>();
            return t;
        }
        template<int R, int C>
        typename type_at<R,C>::type &
        at()   
        {
            typename type_at<R,C>::type& t = this->get<R>().get<C>();
            return t;
        }
//row 0
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 0 && C ==0,
            value_type
        >::type 
        cofactor()const
        {        
            value_type t  
            = this->at<1,1>() * this->at<2,2>() - this->at<2,1>() * this->at<1,2>();
            return t; 
        }
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 0 && C == 1,
            value_type
        >::type 
        cofactor() const
        {        
            value_type t 
            = this->at<1,0>() * this->at<2,2>() - this->at<2,0>() * this->at<1,2>() ;
            return t; 
        }
        
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 0 && C == 2,
            quantity_type
        >::type 
        cofactor() const
        {        
            quantity_type t 
            = this->at<1,0>() * this->at<2,1>() - this->at<2,0>() * this->at<1,1>() ;
            return t; 
        }
//row 1
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 1 && C ==0,
            value_type
        >::type 
        cofactor() const
        {        
            value_type t  
            = this->at<0,1>() * this->at<2,2>() - this->at<2,1>() * this->at<0,2>();
            return t; 
        }
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 1 && C == 1,
            value_type
        >::type 
        cofactor() const
        {        
            value_type t 
            = this->at<0,0>() * this->at<2,2>() - this->at<2,0>() * this->at<0,2>() ;
            return t; 
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 1 && C == 2,
            quantity_type
        >::type 
        cofactor() const
        {        
            quantity_type t 
            = this->at<0,0>() * this->at<2,1>() - this->at<2,0>() * this->at<0,1>() ;
            return t; 
        }
//row 2
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 2 && C ==0,
            reciprocal_type
        >::type 
        cofactor() const
        {        
            reciprocal_type t  
            = this->at<0,1>() * this->at<1,2>() - this->at<1,1>() * this->at<0,2>();
            return t; 
        }
        template<int R, int C> 
        typename boost::enable_if_c<
            R == 2 && C == 1,
            reciprocal_type
        >::type 
        cofactor() const
        {        
            reciprocal_type t 
            = this->at<0,0>() * this->at<1,2>() - this->at<1,0>() * this->at<0,2>() ;
            return t; 
        }

        template<int R, int C> 
        typename boost::enable_if_c<
            R == 2 && C == 2,
            value_type
        >::type 
        cofactor() const
        {        
            value_type t 
            = this->at<0,0>() * this->at<1,1>() - this->at<1,0>() * this->at<0,1>() ;
            return t; 
        }

        template<typename QR>
        inline
        rc_matrix &
        operator *= ( rc_matrix<QR> const & rhs)
        {
           *this = rc_matrix (
                detail::eval_row_column<0,0>(*this,rhs),
                    detail::eval_row_column<0,1>(*this,rhs),
                        detail::eval_row_column<0,2>(*this,rhs),
                detail::eval_row_column<1,0>(*this,rhs),
                    detail::eval_row_column<1,1>(*this,rhs),
                        detail::eval_row_column<1,2>(*this,rhs),
                detail::eval_row_column<2,0>(*this,rhs),
                    detail::eval_row_column<2,1>(*this,rhs),
                        detail::eval_row_column<2,2>(*this,rhs)
            );
            return *this;
        }
//        inline 
//        typename boost::enable_if<
//            boost::is_arithmetic<Quantity>,
//            Quantity*
//        >::type
//        operator[](int n)
//        { 
/////////////// reinterpret_cast for operator [] fails if cast is invalid//////////
//            BOOST_STATIC_ASSERT( sizeof(rc_matrix<Quantity>)== sizeof( Quantity) * 9); 
/////////////////////////////////////////////////////////////////////////////////////
//            void* pp = reinterpret_cast<void*>(this);
//            Quantity* ar = static_cast<Quantity*>(pp);
//            return &ar[ 3* n ];
//        }      
    };

    template <typename Q>
    struct is_rc_matrix<rc_matrix<Q> > : boost::mpl::true_{};

}}}//boost::pqs::two_d
#endif
