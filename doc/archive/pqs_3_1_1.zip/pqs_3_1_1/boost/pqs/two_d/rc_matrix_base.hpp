#ifndef BOOST_PQS_TWO_D_RC_MATRIX_BASE_HPP_INCLUDED
#define BOOST_PQS_TWO_D_RC_MATRIX_BASE_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    base for rc_matrix
*/
#include <boost/typeof/typeof.hpp>
#include <boost/tuple/tuple.hpp>

namespace boost{namespace pqs{namespace two_d{

namespace detail{

    template <typename Quantity>
    struct rc_matrix_base{
        typedef Quantity quantity_type;
        typedef BOOST_TYPEOF_TPL( Quantity() / Quantity()) value_type;
        typedef BOOST_TYPEOF_TPL( 1 / Quantity() )   reciprocal_type;
        typedef boost::tuple<
            value_type,value_type,reciprocal_type
        > row0_type;
        typedef boost::tuple<
            value_type,value_type,reciprocal_type
        > row1_type;
        typedef boost::tuple<
                quantity_type,quantity_type,value_type
        > row2_type;
        typedef row0_type  row_vector;
        typedef boost::tuple<
            row0_type,
            row1_type,
            row2_type
        >        matrix;
    };

}//detail
}}}//boost::pqs::two_d
#endif

