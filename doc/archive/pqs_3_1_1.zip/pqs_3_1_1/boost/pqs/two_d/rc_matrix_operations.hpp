#ifndef BOOST_PQS_TWO_D_HOMOGENEOUS_OPERATIONS_HPP_INCLUDED
#define BOOST_PQS_TWO_D_HOMOGENEOUS_OPERATIONS_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    transformation matrix ops for homogeneous row vector
*/
#include <boost/pqs/two_d/gnos_vect.hpp>
#include <boost/pqs/two_d/rc_matrix.hpp>
#include <boost/typeof/typeof.hpp>
#include "boost/utility/enable_if.hpp"
#include "boost/type_traits/is_arithmetic.hpp"

namespace boost{namespace pqs{namespace two_d{

    template<typename QL, typename QR>
    inline
    gnos_vect<BOOST_TYPEOF_TPL(QL() + QR())>
    operator * (gnos_vect<QL> const & v, rc_matrix<QR> const & m)
    {
        typedef BOOST_TYPEOF_TPL(v * m) result_type;
        result_type t(
              v.at<0>() * m.at<0,0>()
            + v.at<1>() * m.at<1,0>()
            + v.at<2>() * m.at<2,0>(),
              v.at<0>() * m.at<0,1>()
            + v.at<1>() * m.at<1,1>()
            + v.at<2>() * m.at<2,1>(),
              v.at<0>() * m.at<0,2>()
            + v.at<1>() * m.at<1,2>()
            + v.at<2>() * m.at<2,2>()
        );
        return t;
    }

    template<typename QL, typename QR>
    inline
    gnos_vect<BOOST_TYPEOF_TPL(QL() + QR())>
    operator * ( rc_matrix<QL> const & m, gnos_vect<QR> const & v)
    {
        typedef BOOST_TYPEOF_TPL( m * v ) result_type;
        result_type t(
            m.at<0,0>() * v.at<0>() 
            + m.at<1,0>() * v.at<1>()
            + m.at<2,0>() * v.at<2>() ,
            m.at<0,1>() * v.at<0>() 
            +  m.at<1,1>() * v.at<1>()
            +  m.at<2,1>() * v.at<2>(),
            m.at<0,2>() * v.at<0>()
            +  m.at<1,2>() * v.at<1>()
            +  m.at<2,2>() * v.at<2>()
        );
        return t;
    }
   
    namespace detail{
        template< int R, int C, typename QL, typename QR>
        inline
        typename rc_matrix<BOOST_TYPEOF_TPL( QL() +  QR() )>::template type_at<R,C>::type
        eval_row_column(rc_matrix<QL> const & lhs, rc_matrix<QR> const & rhs)
        {
            typedef BOOST_TYPEOF_TPL(eval_row_column<R BOOST_PP_COMMA() C>(lhs BOOST_PP_COMMA()rhs)) result_type;
            result_type t
                = lhs.at<R,0>() * rhs.at<0,C>()
                + lhs.at<R,1>() * rhs.at<1,C>()
                + lhs.at<R,2>() * rhs.at<2,C>();
            return t;
        }
    }//detail
 
    template<typename QL, typename QR>
    inline
    rc_matrix<BOOST_TYPEOF_TPL( QL() + QR())>
    operator * (rc_matrix<QL> const & lhs, rc_matrix<QR> const & rhs)
    {
        typedef BOOST_TYPEOF_TPL(lhs * rhs) result_type;
        result_type t (
            detail::eval_row_column<0,0>(lhs,rhs),
                detail::eval_row_column<0,1>(lhs,rhs),
                    detail::eval_row_column<0,2>(lhs,rhs),
            detail::eval_row_column<1,0>(lhs,rhs),
                detail::eval_row_column<1,1>(lhs,rhs),
                    detail::eval_row_column<1,2>(lhs,rhs),
            detail::eval_row_column<2,0>(lhs,rhs),
                detail::eval_row_column<2,1>(lhs,rhs),
                    detail::eval_row_column<2,2>(lhs,rhs)
        );
        return t;
    }

    template <typename QL, typename Value_type>
    inline
    typename boost::enable_if<
        boost::is_arithmetic<Value_type>,
        rc_matrix<BOOST_TYPEOF_TPL(QL() * Value_type())>
    >::type
    operator * (
        rc_matrix<QL> const & m,
        Value_type const & v
    )
    {
        typedef BOOST_TYPEOF_TPL( m * v ) result_type;
        result_type t(
            m.at<0,0>() * v, m.at<0,1>() * v, m.at<0,2>() * v,
            m.at<1,0>() * v, m.at<1,1>() * v, m.at<1,2>() * v,
            m.at<2,0>() * v, m.at<2,1>() * v, m.at<2,2>() * v
        );
        return t; 

    }

    template <typename Value_type,typename QR>
    inline
    typename boost::enable_if<
        boost::is_arithmetic<Value_type>,
        rc_matrix<BOOST_TYPEOF_TPL(Value_type() * QR())>
    >::type
    operator * (
        Value_type const & v,
        rc_matrix<QR> const & m
        
    )
    {
       typedef BOOSY_TYPEOF_TPL( v * m) result_type;
        result_type t(
            v * m.at<0,0>(), v * m.at<0,1>(), v * m.at<0,2>(),
            v * m.at<1,0>(), v * m.at<1,1>(), v * m.at<1,2>(),
            v * m.at<2,0>(), v*  m.at<2,1>(), v * m.at<2,2>()
        );
        return t; 
    }

    template <typename QL, typename Value_type>
    inline
    typename boost::enable_if<
        boost::is_arithmetic<Value_type>,
        rc_matrix<BOOST_TYPEOF_TPL(QL() / Value_type() )>
    >::type
    operator / (
        rc_matrix<QL> const & m,
        Value_type const & v
    )
    {
        typedef BOOST_TYPEOF( m/v) result_type;
        result_type t(
            m.at<0,0>() / v, m.at<0,1>() / v, m.at<0,2>() / v,
            m.at<1,0>() / v, m.at<1,1>() / v, m.at<1,2>() / v,
            m.at<2,0>() / v, m.at<2,1>() / v, m.at<2,2>() / v
        );
        return t; 
    }

    template<typename Q>
    inline
    typename rc_matrix<Q>::value_type
    determinant_of(rc_matrix<Q> const & m)
    {
        typedef typename rc_matrix<Q>::value_type value_type;
        value_type t1 = m.at<0,0>() * m.cofactor<0,0>();
        value_type t2 = m.at<0,1>() * m.cofactor<0,1>();
        value_type t3 = m.at<0,2>() * m.cofactor<0,2>();
        value_type result 
        = t1 - t2 + t3; 
        return result;  
    }

    template <typename Q>
    inline
    rc_matrix<BOOST_TYPEOF_TPL( Q() / (Q() * Q()) )>
    cofactor_matrix_of(rc_matrix<Q> const & m)
    {
       typedef BOOST_TYPEOF_TPL( cofactor_matrix_of(m)) result_type;
        result_type t(
            m.cofactor<0,0>(),-m.cofactor<0,1>(), m.cofactor<0,2>(),
            -m.cofactor<1,0>(),m.cofactor<1,1>(), -m.cofactor<1,2>(),
            m.cofactor<2,0>(),-m.cofactor<2,1>(), m.cofactor<2,2>()
        );
        return t; 
    }

    template <typename Q>
    inline
    rc_matrix<BOOST_TYPEOF_TPL( Q() / (Q() * Q()) )>
    transpose_of(rc_matrix<Q> const & m)
    {
        typedef BOOST_TYPEOF_TPL( transpose_of(m)) result_type;
        result_type t(
            m.at<0,0>(),m.at<1,0>(), m.at<2,0>(),
            m.at<0,1>(),m.at<1,1>(), m.at<2,1>(),
            m.at<0,2>(),m.at<1,2>(), m.at<2,2>()
        );
        return t; 
    }

    template <typename Q>
    inline
    rc_matrix<Q>
    inverse_of(rc_matrix<Q> const & m)
    {
        rc_matrix<Q> t = transpose_of(cofactor_matrix_of(m) ) / determinant_of(m);
        return t; 
    }
    
    
}}}//boost::pqs::two_d

#endif
 