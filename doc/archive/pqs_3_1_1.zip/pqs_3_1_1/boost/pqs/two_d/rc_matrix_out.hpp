#ifndef BOOST_PQS_TWO_D_TRANSFORM_MATRIX_OUT_HPP_INCLUDED
#define BOOST_PQS_TWO_D_TRANSFORM_MATRIX_OUT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    homogeneous transform matrix out
*/

#include "boost/pqs/two_d/rc_matrix.hpp"

namespace boost{namespace pqs{namespace two_d{

    template<typename Q>
    std::ostream& operator << (std::ostream& os, rc_matrix<Q> const & m)
    {
        os << "|" << m.at<0,0>() << ", " << m.at<0,1>() << ", " << m.at<0,2>() << "|\n|";
        os << m.at<1,0>() << ", " << m.at<1,1>() << ", " << m.at<1,2>() << "|\n|"; 
        os << m.at<2,0>() << ", " << m.at<2,1>() << ", " << m.at<2,2>() << "|";
        return os;
    }

}}}//boost::pqs::two_d

#endif
