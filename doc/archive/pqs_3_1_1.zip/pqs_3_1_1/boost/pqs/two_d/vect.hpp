#ifndef BOOST_PQS_TWO_D_VECT_HPP_INCLUDED
#define BOOST_PQS_TWO_D_VECT_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    2d vect definition and ops
*/

#include <boost/pqs/two_d/vect_def.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_arithmetic.hpp>
#include <boost/typeof/typeof.hpp>
#include <cmath>

namespace boost{namespace pqs{ namespace two_d{

 template <typename TL, typename TR>
    inline
    vect <BOOST_TYPEOF_TPL( TL() + TR())>
    operator +( vect<TL> const & lhs, vect<TR> const & rhs)
    {
        BOOST_TYPEOF_TPL(lhs + rhs) result(lhs.x +rhs.x, lhs.y+rhs.y);
        return result;
    }

    template <typename TL, typename TR>
    inline
    vect <BOOST_TYPEOF_TPL( TL() - TR())>
    operator -( vect<TL> const & lhs, vect<TR> const & rhs)
    {
        BOOST_TYPEOF_TPL(lhs - rhs) result(lhs.x -rhs.x, lhs.y-rhs.y);
        return result;
    }

    template <typename TL, typename TR>
    inline
    typename boost::enable_if<
        boost::is_arithmetic<TR>,
        vect <BOOST_TYPEOF_TPL( TL() * TR())>
    >::type 
    operator  *( vect<TL> const & lhs, TR const & rhs)
    {
        BOOST_TYPEOF_TPL(lhs * rhs) result(lhs.x *rhs, lhs.y * rhs);
        return result;
    }

    template <typename TL, typename TR>
    inline
    typename boost::enable_if<
        boost::is_arithmetic<TR>,
        vect <BOOST_TYPEOF_TPL( TL() / TR())>
    >::type 
    operator  /( vect<TL> const & lhs, TR const & rhs)
    {
        BOOST_TYPEOF_TPL(lhs / rhs) result(lhs.x / rhs, lhs.y / rhs);
        return result;
    }
    template <typename Value_type>
    Value_type
    magnitude( vect<Value_type> const & v)
    {
        Value_type result = sqrt(v.x * v.x + v.y * v.y);
        return result;
    }

    template <typename T>
    BOOST_TYPEOF_TPL( T() * T()) 
    dot_product( 
        vect<T> const & lhs,
        vect<T> const & rhs
    ){
        typedef BOOST_TYPEOF_TPL( T() * T()) result_type;
        result_type result = lhs.x * rhs.x + lhs.y * rhs.y;
        return result;
    }
    
}}}//boost::pqs::two_d

#endif
