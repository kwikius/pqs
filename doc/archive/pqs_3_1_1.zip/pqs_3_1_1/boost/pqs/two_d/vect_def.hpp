#ifndef BOOST_PQS_TWO_D_VECT_DEF_HPP_INCLUDED
#define BOOST_PQS_TWO_D_VECT_DEF_HPP_INCLUDED
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

// Copyright Andy Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

/*
    2d vect class template definition
*/

#include <boost/implicit_cast.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_arithmetic.hpp>

namespace boost{namespace pqs{ namespace two_d{

    template <typename T>
    struct vect{
        vect() : x( static_cast<T>(0) ),  y( static_cast<T>(0) ){}
        template <typename Ta, typename Tb>
        vect(Ta const & x_in, Tb const & y_in)
        : x( boost::implicit_cast<T>(x_in) ),  y( boost::implicit_cast<T>(y_in) ){}
        T x,y;
        template <typename T1>
        vect& operator =( vect<T1> const & in)
        {
            this->x = in.x;
            this->y = in.y;
            return *this;
        } 
        template <typename T1>
        vect& operator +=( vect<T1> const & in)
        {
            this->x += in.x;
            this->y += in.y;
            return *this;
        } 
        template <typename T1>
        vect& operator -=( vect<T1> const & in)
        {
            this->x -= in.x;
            this->y -= in.y;
            return *this;
        }

        template <typename Arithmetic>
        typename boost::enable_if<
            boost::is_arithmetic<Arithmetic>,
            vect<T> &
        >::type
        operator *=(Arithmetic const & in)
        {
            this->x *=in;
            this->y *=in;
            return *this;
        }
        template <typename Arithmetic>
        typename boost::enable_if<
            boost::is_arithmetic<Arithmetic>,
            vect &
        >::type
        operator /=(Arithmetic const & in)
        {
            this->x /=in;
            this->y /=in;
            return *this;
        }
    };

}}}// boost::pqs::two_d
#endif
