#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif
#ifndef PQS_TIMER_HPP_INCLUDED
#define PQS_TIMER_HPP_INCLUDED

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    modified from boost/timer
  See http://www.boost.org/libs/timer 
*/
/*
    construction starts timing
    restart resets and then continues timing
    stop stops or holds onto finish time
    operator ()() 
    gives either duration to last stop(0 if stopped
    or duration from init or start() if running;
    Nominally Correct for one overflow period of system timer.
    ( using difftime )
   *** now templated on required time units ***
    
*/

#include <boost/pqs/t1_quantity/types/out/time.hpp>
#include <boost/pqs/meta/eval_rational.hpp>

#include <ctime>

namespace boost{namespace pqs{
 
    template <typename TimeType = pqs::time::ms>
    class timer{
    public:
        timer(): running(true)
        {
            start_time = std::clock();
        }
        void restart() 
        {
            running = true;
            start_time = std::clock();
        }
        void stop() 
        {
            if (running){
                stop_time = std::clock();
                running = false;
            }
        }
        
        TimeType operator ()()const
        {
            std::clock_t const wanted = running ? std::clock() : stop_time;

            typedef typename boost::pqs::meta::rational<
                1000,CLOCKS_PER_SEC
                >::type divider;
   
            boost::pqs::meta::eval_rational<divider> eval;
            
            TimeType result = boost::pqs::time::ms( 
                difftime(wanted , start_time) * eval()
            );
            return result;
        }
        bool is_running() const {return running;}
        bool is_stopped() const {return !running;}
    private:
        bool running;
        std::clock_t start_time,stop_time;
    };

}}//boost::pqs

#endif
