// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/* 
    Compiler database Search ;-)
    One method for finding if a particular abstract_quantity_id has already 
    been taken by a dimensionally equivalent quantity.
   
 */
// The all_types header includes every current type that is defined
// Any newly defined types should be added in the header too of course
#include <boost/pqs/t1_quantity/types/all_types.hpp>
  
namespace boost{namespace pqs{namespace meta{namespace components{

 //This should fail to compile because an 
 // of_named_quantity_for specialisation has 
 // already been defined for the named_quantity length at Line 162 in
 //< boost/pqs/meta/components/of_length.hpp> 
 // which is (included by all_types.hpp above)

    template <>
    struct of_named_quantity_for<
        boost::pqs::meta::abstract_quantity<

        // of_energy::type::dimension is just used here as an example dimension .
        // Could be any dimension where you want to know if the abstract_quantity_id
        // has already been defined.
        // (dimension definition is in <boost/pqs/meta/dimension.hpp>)
            of_energy::type::dimension, 
        
        //########################
        // comment out this and...
           boost::mpl::int_<2>
        // uncomment the line below ...
        // boost::mpl::int_<3> 
        // ... to solve the duplicate definition issue 
        // for this particular quantity  
        //########################

        // FWIW this one is also already taken
        // boost::mpl::int_<1>

        >
    > {};

}}}}
#include <iostream>
int main(){
    std::cout << "Good choice!\n";
}
