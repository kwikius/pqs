// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    Demo of output of anonymous_quantity, 
    and two dimensionally_equivalent 
    but distinct quantities.
*/

#include <boost/pqs/t1_quantity/types/out/force.hpp>
#include <boost/pqs/t1_quantity/types/out/length.hpp>
#include <boost/pqs/t1_quantity/types/out/torque.hpp>
#include <boost/pqs/t1_quantity/types/out/energy.hpp>

namespace pqs = boost::pqs;
int main()
{
    pqs::force::kN    force(1);
    pqs::length::mm  distance(1);
    
    // temporary result of f * d 
    // is an anonymous_quantity
    // so output is that for anonymous quantity
    std::cout << force * distance << '\n';

    //However can be assigned to energy
    pqs::energy::J energy = force * distance;
    // output is particular to energy
    std::cout << energy << '\n';

    // or torque
    pqs::torque::N_m torque = force * distance;
    // output is particular to torque
    std::cout << torque << '\n';
}


