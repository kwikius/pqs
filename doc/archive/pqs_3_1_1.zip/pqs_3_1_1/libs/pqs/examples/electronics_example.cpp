// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
     some basic electronics calcs
*/

#include "boost/pqs/t1_quantity/types/out/voltage.hpp"
#include "boost/pqs/t1_quantity/types/out/resistance.hpp"
#include "boost/pqs/t1_quantity/types/out/current.hpp"
#include "boost/pqs/t1_quantity/types/out/time.hpp"
#include "boost/pqs/t1_quantity/types/out/power.hpp"
#include "boost/pqs/t1_quantity/types/out/energy.hpp"

int main()
{
    using boost::pqs::voltage;
    using boost::pqs::current;
    using boost::pqs::resistance;
    using boost::pqs::time;
    using boost::pqs::power;
    using boost::pqs::energy;
    using boost::pqs::pow;

    voltage::V        v(5.0);
    resistance::kR    r(1);
    current::mA       i = v/r;
    time::s           t(1.0);
    power::mW         w = pow<2>(v)/r;
    energy::mJ        e = w * t;
    std::cout 
    << "A current of " << i
    << "\nthrough a voltage of " << v 
    << "\nrequires a resistance of " << r 
    << "\nand produces "  << w << " of heat\n";
    std::cout 
    << "total energy used in " << t 
    << " is " <<  e  << '\n';
}
