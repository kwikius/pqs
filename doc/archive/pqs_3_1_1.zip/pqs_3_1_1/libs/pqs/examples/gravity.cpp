// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    calculate very small force due to gravity
*/

#include <boost/pqs/t1_quantity/types/out/length.hpp>
#include <boost/pqs/t1_quantity/types/out/density.hpp>
#include <boost/pqs/t1_quantity/types/out/mass.hpp>
#include <boost/pqs/t1_quantity/types/out/force.hpp>
#include <boost/pqs/t1_quantity/constants/constant.hpp>

#ifndef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS
#include <libs/pqs/src/gravitational_constant.cpp>
#else
#include <boost/pqs/t1_quantity/constants/gravitational_constant.hpp>
#endif

int main()
{
    using boost::pqs::math::constant;
    using boost::pqs::physics::gravitational_constant;
    using boost::pqs::length;
    using boost::pqs::density;
    using boost::pqs::mass;
    using boost::pqs::force;
    using boost::pqs::pow;
    std::cout.precision(5);
    length::km         const planet_radius(6400); //roughly !
    density::kg_div_m3 const planet_density(5487); // roughly!
    mass::kg const planet_mass = (4.0/3.0)* constant::pi 
    * pow<3>(planet_radius) * planet_density;

    std::cout << "mass of planet is roughly " << planet_mass <<'\n';

    //an object
    mass::kg const object_mass(1);

    // ...on the planet surface
    force::N const exerted_force_at_surface 
    = (object_mass * planet_mass * gravitational_constant::G)
    / pow<2>(planet_radius);

    std::cout << "force on object at surface is roughly " 
    << exerted_force_at_surface <<'\n';

    // ...and a long way away
    length::pc object_distance(64e13/3.085678); // pc =  3.085678e16 m

    std::cout << "force on object at " << object_distance << " is roughly "
    << force::yN((object_mass * planet_mass * gravitational_constant::G)
        / pow<2>(object_distance)) <<'\n';
}



