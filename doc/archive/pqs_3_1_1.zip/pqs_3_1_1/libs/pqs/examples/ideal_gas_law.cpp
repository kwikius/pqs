// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    Calculation of amount of substance in a gas using gas constant
    from discussion on www.boost.org
*/
#include <boost/pqs/t1_quantity/types/temperature.hpp>
#include <boost/pqs/t1_quantity/types/pressure.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
#include <boost/pqs/t1_quantity/types/volume.hpp>
#include <boost/pqs/t1_quantity/types/out/substance.hpp>


// comment out NO_PQS_CONSTANTS_LIBRARY 
// if using the constants in a library
#ifndef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS
#include <libs/pqs/src/constant.cpp>
#include <libs/pqs/src/gas_constant.cpp>
#else 
// pi etc
#include <boost/pqs/t1_quantity/constants/constant.hpp>
// dimensionally correct gas_constant
#include <boost/pqs/t1_quantity/constants/gas_constant.hpp>
#endif


int main()
{  
   
    using boost::pqs::physics::gas_constant;
    using boost::pqs::pow;
    using boost::pqs::temperature;
    using boost::pqs::pressure;
    using boost::pqs::length;
    using boost::pqs::volume;
    using boost::pqs::substance;
    double const & pi = boost::pqs::math::constant::pi;

    temperature::K  T(310);
    pressure::Pa    P(1.01325e5);
    length::m       r(0.5e-6);
    volume::m3      V = 4.0 / 3.0 * pi * pow<3>(r);
    substance::mol  subst = P * V /(gas_constant::R * T);
    std::cout << subst <<'\n';
}


