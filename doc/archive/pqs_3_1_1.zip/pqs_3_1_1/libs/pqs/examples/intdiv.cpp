// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/* 
    This example shows how it is possible to use integer value_types,
    in different units without loss of precision (eg int 1/1000)
    up in the code at compile time the function attempts to decide 
    how to do the adds, subs, divs and muls to give best resolution. 

    NB Only works accurately for coherent-quantities.
    (for incoherent-quantities use a floating point value_type).
*/

#include <boost/pqs/t1_quantity/types/out/length.hpp>


int main()
{
    boost::pqs::length_<int>::m L1(1);
    boost::pqs::length_<int>::mm L2(1000);

    std::cout << L1 + L2 <<'\n';
    std::cout << L2 + L1 <<'\n';
  
    std::cout << L2 - L1 <<'\n';
    std::cout << L1 - L2 <<'\n';
  
    std::cout << L1 / L2 <<'\n';
    std::cout << L2 / L1 <<'\n'; 

    std::cout << L1 * L2 <<'\n';
    std::cout << L2 * L1 <<'\n';   

    boost::pqs::length_<int>::mm L3 = L1;
    std::cout << L3 << '\n'; 
    
    boost::pqs::length_<int>::m L4 = L2;
    std::cout << L4 <<'\n';

// add partial
}
