// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    This example was originally presented on the boost mailing list:
    http://lists.boost.org/MailArchives/boost/msg55344.php
*/

#include <boost/pqs/t1_quantity/types/out/velocity.hpp>
#include <boost/pqs/t1_quantity/types/out/mass.hpp>
#include <boost/pqs/t1_quantity/types/out/force.hpp>
#include <boost/pqs/t1_quantity/types/out/time.hpp>
#include <boost/pqs/t1_quantity/types/out/density.hpp>
#include <boost/pqs/t1_quantity/types/out/volume.hpp>


 boost::pqs::force::N  Force(
        const boost::pqs::mass::kg   & mass_in,
        boost::pqs::velocity::mm_div_s const & initial_veloc,
        const boost::pqs::velocity::m_div_s   & final_veloc,
        const boost::pqs::time::s   & t)
{
    boost::pqs::force::N result =  mass_in * (final_veloc - initial_veloc) / t;
    return result;
}

int main()
{
    typedef boost::is_same<
    boost::pqs::velocity::m_div_s,boost::pqs::velocity::m_div_s
    > type;
    std::cout << type::value << '\n';
    //lab technician works in "odd units"...

    boost::pqs::mass::g               const mass(0.1f);
    boost::pqs::velocity::mm_div_min  const initial_v(5);
    boost::pqs::velocity::mm_div_min  const final_v(5.5);
    boost::pqs::time::min             const t_min(10);
    boost::pqs::time::s               const t_sec( 12);

    // function does the work ... he doesnt have to...

    std::cout << "force on mass = " << Force(mass,initial_v, final_v, t_min + t_sec) << '\n';
    boost::pqs::density::kg_div_m3 density = mass / boost::pqs::volume::m3(1);
    return 0;
}
