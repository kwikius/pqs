// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

#include <boost/pqs/t1_quantity/types/out/temperature.hpp>
#include <boost/pqs/t1_quantity/types/out/resistance.hpp>
#include <boost/pqs/t1_quantity/types/out/frequency.hpp>
#include <boost/pqs/t1_quantity/types/out/voltage.hpp>

#include <libs/pqs/src/boltzmanns_constant.cpp>
/*
    Just demonstrates a quantity using a rational(rather than integer)dimension.
    noise voltage density here
    From The Art of Electronics Horovitz and Hill 7.11 Johnson Noise.
    Note the result for the power of 10 of 1.27 x 10-4 seems wrong 
    in one part of the chapter in my version (2nd Ed) of the book
*/

namespace boost{namespace pqs{

    template <typename T>
    struct noise_voltage_density_{
        typedef meta::abstract_quantity<
                meta::dimension<
                    meta::rational<2>,
                    meta::rational<-5,2>,
                    meta::rational<1>,
                    meta::rational<0>,
                    meta::rational<-1>,
                    meta::rational<0>,
                    meta::rational<0>
                >,
            boost::mpl::int_<1>
         > abstract_quantity;

        typedef t1_quantity<
            abstract_quantity,
            typename meta::si_unit::nano,
            T
        > nV_div_sqrt_hz;
    };
    struct noise_voltage_density : noise_voltage_density_<
        quantity_traits::default_value_type
    >{};

    template <typename CharType, typename T>
    std::basic_ostream<CharType>& 
    operator <<(
        std::basic_ostream<CharType> & os, 
        t1_quantity<
            typename noise_voltage_density_::abstract_quantity,
            typename meta::si_unit::nano ,
            T
        > const & pq)
    {
        os << pq.numeric_value() << " nV.Hz-1/2";
        return os;
    }  
}}//boost::pqs

#include <iostream>
namespace pqs = boost::pqs;
int main()
{
    using pqs::physics::boltzmanns_constant;
    pqs::temperature::K t(293.16);
    pqs::resistance::kR r(10);
    pqs::noise_voltage_density::nV_div_sqrt_hz nvd 
    = sqrt( 4 * boltzmanns_constant::K * t * r);

    std::cout << "noise voltage density  of " << r << " at " 
    << t << " = " << nvd  << '\n';
    pqs::frequency ::kHz f(10);
    pqs::voltage::uV v = nvd * sqrt(f);

    std::cout << "noise voltage at " << f << " = " << v << '\n';
}