// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.

/*
    exception on out of range 
*/

#include <boost/pqs/t1_quantity/types/out/length.hpp>
  

int main()
{
 
    try {
        boost::pqs::length_<double>::m L1( INT_MAX);
        boost::pqs::length_<int>::m L2 = L1;

        std::cout << "conversion 1 succeeded\n";

        boost::pqs::length_<double>::m L3( static_cast<double>(INT_MAX)+1 );
        boost::pqs::length_<int>::m L4 = L3;

        std::cout << "conversion 2 succeeded\n";
    }
    catch ( std::exception & e){
        std::cout << "conversion failed with " << e.what() <<'\n';
    }

}

