// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/pqs for documentation.
/*
    pi as an angle, and two_pi;
*/

//constants values in <libs/pqs/src/constant.cpp> provided by Paul Bristow

#include <boost/pqs/angle/angle.hpp>

#ifndef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS

template<typename Value_type>
typename boost::pqs::angle_<Value_type>::rad const
boost::pqs::angle_<Value_type>::pi 
= typename boost::pqs::angle_<
    Value_type
>::rad(3.141592653589793238462643383279502884197);

template<typename Value_type>
typename boost::pqs::angle_<Value_type>::rad const
boost::pqs::angle_<Value_type>::two_pi 
= typename boost::pqs::angle_<
    Value_type
>::rad(2 * 3.141592653589793238462643383279502884197);

#endif

