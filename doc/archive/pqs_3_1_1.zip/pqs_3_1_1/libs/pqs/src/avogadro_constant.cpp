
// Copyright David Walthall 2006
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.


/*
    avogadros constant definition required to link
*/
#include <boost/pqs/t1_quantity/constants/avogadro_constant.hpp>

#ifndef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS
template<>
boost::pqs::chemistry::avogadro_constant_<double>::type const&
boost::pqs::chemistry::avogadro_constant_<double>::Na
= boost::pqs::chemistry::avogadro_constant_<double>::type(6.0221415);

template<>
boost::pqs::chemistry::avogadro_constant_<long double>::type const&
boost::pqs::chemistry::avogadro_constant_<long double>::Na
= boost::pqs::chemistry::avogadro_constant_<long double>::type(6.0221415L);

template<>
boost::pqs::chemistry::avogadro_constant_<float>::type const&
boost::pqs::chemistry::avogadro_constant_<float>::Na
= boost::pqs::chemistry::avogadro_constant_<float>::type(6.0221415f);
#endif


