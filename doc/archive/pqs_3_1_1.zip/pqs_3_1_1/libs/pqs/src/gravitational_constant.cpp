// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.


#include <boost/pqs/t1_quantity/constants/gravitational_constant.hpp>
/*
    gravitational_constant definition required to link
*/
#ifndef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS
template<>
boost::pqs::physics::gravitational_constant_<long double>::type const & 
boost::pqs::physics::gravitational_constant_<long double>::G
= boost::pqs::physics::gravitational_constant_<long double>::type(6.6726L);

template<>
boost::pqs::physics::gravitational_constant_<double>::type const & 
boost::pqs::physics::gravitational_constant_<double>::G
= boost::pqs::physics::gravitational_constant_<double>::type(6.6726);

template<>
boost::pqs::physics::gravitational_constant_<float>::type const & 
boost::pqs::physics::gravitational_constant_<float>::G
= boost::pqs::physics::gravitational_constant_<float>::type(6.6726F);
#endif

