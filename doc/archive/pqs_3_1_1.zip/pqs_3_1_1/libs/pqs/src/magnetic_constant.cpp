// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.


/*
    gas constant definition required to link
*/

#include <boost/pqs/t1_quantity/constants/magnetic_constant.hpp>

#ifndef BOOST_PQS_DEFINE_PHYSICAL_CONSTANTS_IN_HEADERS
template<>
boost::pqs::physics::magnetic_constant_<double>::type const&
boost::pqs::physics::magnetic_constant_<double>::mu0 
= boost::pqs::physics::magnetic_constant_<double>::type(12.566370614);

template<>
boost::pqs::physics::magnetic_constant_<long double>::type const&
boost::pqs::physics::magnetic_constant_<long double>::mu0 
= boost::pqs::physics::magnetic_constant_<long double>::type(12.566370614L);

template<>
boost::pqs::physics::magnetic_constant_<float>::type const&
boost::pqs::physics::magnetic_constant_<float>::mu0
= boost::pqs::physics::magnetic_constant_<float>::type(12.566370614f);
#endif
