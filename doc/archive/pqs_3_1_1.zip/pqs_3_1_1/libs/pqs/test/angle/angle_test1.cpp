// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    Very preliminary tests on angle types
*/

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/angle/out/angle.hpp>
#include <boost/pqs/t1_quantity/operations/atan2.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
//-----------------------------------
// required for linking the definition of
// boost::pqs::angle::pi
#include <libs/pqs/src/angle.cpp>

//-------------------------------------

namespace pqs = boost::pqs;

void angle_test1()
{
    pqs::angle::deg a(90);

#ifndef min
    a += pqs::angle::min(1);
#else
// 'min' macro definition workaround
    typedef pqs::angle::min min_;
    a += min_(1);
#endif
    a += pqs::angle::s(1);
    pqs::angle::rad b = a;
    pqs::angle::rad c = pqs::angle::deg(180);
#ifndef min
    c = pqs::angle::min(1);
#else
// 'min' macro definition workaround
    c = min_(1);
#endif
////not working currently ... should work!
// //   c += pqs::angle::min(1);
    c = pqs::angle::pi;
 //   a = pqs::angle::two_pi;
//    pqs::angle::sr d = b * c;
//    b = b + 1;
//    b *= 1;
//    b = b - 1;
//    b + c;
//    b - c;
//    a + b;
//    b + a;
//    a - b;
//    b - a;
// // doesnt work currently by design
// // maybe should work
// //   b * a;
// //   a * b;
//    b / c;
//    b / a;
//    a / b;
//    b -=c;
//    b * c;
//    b == c;
//    b == a;
//    b > c;
//    b > a;
//    a > b;
//    b < c;
//    b < a;
//    a < b;
//    b >= c;
//    b >= a;
//    a >= b;
//    b <= c;
//    b <= a;
//    a <= b;
//    a = atan2(pqs::length::m(1),pqs::length::m(1));
//    double sina = sin(a);
//    double cosa = cos(a);
//    double tana = tan(a);
}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs angle_test" );
    test->add(BOOST_TEST_CASE(angle_test1));
    return test;
}
