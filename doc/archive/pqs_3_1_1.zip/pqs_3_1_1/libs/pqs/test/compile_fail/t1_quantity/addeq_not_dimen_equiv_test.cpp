// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/velocity.hpp>

/*
    check dimensionally_invalid calcs fail
    example from documentation
*/

namespace pqs=boost::pqs;

int main()
{
    pqs::velocity::m_div_s      v(1);
    pqs::time::s t(2); 
    v += t;
}