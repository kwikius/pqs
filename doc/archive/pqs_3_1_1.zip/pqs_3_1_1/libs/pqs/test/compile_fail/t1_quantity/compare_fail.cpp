// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/t1_quantity/types/force.hpp>
#include <boost/pqs/t1_quantity/types/energy.hpp>

int main()
{
    boost::pqs::force::kgf f1(1);
    boost::pqs::force::N f2(2);

    boost::pqs::force::mN ep(5);
    // These should work!
    compare(f1,f2,ep);
    compare(f2,f1,ep);
    compare(f2,f1);

    boost::pqs::energy::kJ e(20.);

    //Error: couldnt find compare
  //  compare(f1,e,ep);

    //Error: couldnt find compare
    compare(f1,e);
}