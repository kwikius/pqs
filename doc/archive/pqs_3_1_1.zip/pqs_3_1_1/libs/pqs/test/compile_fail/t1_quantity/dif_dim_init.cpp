// Copyright Andrew Little 2006
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    Try to initialise a t1_quantity with 
    another of same unit but not dimensionally_equivalent
*/
/*
    Should fail to compile
*/

#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/capacitance.hpp>

using namespace boost::pqs;

int main()
{
    resistance::R  R = capacitance::F(1.);
}