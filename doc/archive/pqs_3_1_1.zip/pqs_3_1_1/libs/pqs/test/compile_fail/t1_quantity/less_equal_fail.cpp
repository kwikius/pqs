// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/t1_quantity/types/reciprocal_time.hpp>
#include <boost/pqs/t1_quantity/types/capacitance.hpp>

int main()
{
    boost::pqs::reciprocal_time::div_s a(1);
    boost::pqs::reciprocal_time::div_ms b(2);

    // These should work!
    a <= b;
    b <= a;

    boost::pqs::capacitance::uF c(20.);

    //Error: couldnt find lessequal
    a <= c;
    //Error: couldnt find lessequal
  //  c <= a;
}