// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/utility/udt.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/acceleration.hpp>
#include <boost/pqs/t1_quantity/types/velocity.hpp>

/*
    t1_quantity value_type must be implicitly convertible
*/

namespace pqs=boost::pqs;
//using my::udt;

int main()
{
    typedef my::udt<int> udti;
    typedef my::udt<double> udtd;
    udti udt1, udt2;
    udtd udt3, udt4;
// check udt adds work ok
    udt1 + udt2;
    udt3 + udt4;
    udt1 + udt3;
    
    pqs::velocity_<udti >::m_div_s      v1( udti(1) );
    pqs::velocity_<udti >::m_div_s      v2( udti(1) );

    typedef boost::pqs::meta::binary_operation<
        pqs::velocity_<udti>::m_div_s,
        pqs::meta::plus,
        pqs::velocity_<udti>::m_div_s
    >::type result;
    v1 + v2;
    std::cout << typeid(result).name() << '\n';
// cross value_type udt
    pqs::velocity_<udtd >::mm_div_s      v3( udtd(1) );
    v1 + v3;
 
    pqs::velocity::mm_div_s   v4(1); 
//###################################
// should fail here /////////////////
    v4 + v1;
/////////////////////////////
//#################################
}