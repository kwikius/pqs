// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/voltage.hpp>

/*
    should fail to compile
*/

namespace pqs=boost::pqs;

int main()
{
    pqs::voltage::uV     v(1);
    v -= 1.;
}