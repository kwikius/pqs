
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    test abstract_quantity
*/
#include <libs/pqs/test/test.hpp>
#include <libs/pqs/test/low_level/aux_test.hpp>
#include <boost/pqs/meta/abstract_quantity.hpp>
#include <boost/pqs/meta/rational.hpp>

namespace boost{namespace pqs{
 
    namespace aux{

        typedef boost::pqs::meta::rational<0> zero;
        typedef boost::pqs::meta::rational<1,4> one_quarter;
        typedef boost::pqs::meta::rational<1,3> one_third;
        typedef boost::pqs::meta::rational<1,2> one_half;
        typedef boost::pqs::meta::rational<2,3> two_thirds;
        typedef boost::pqs::meta::rational<3,4> three_quarters;
        typedef boost::pqs::meta::rational<1>  one;      
    }
   
    typedef boost::pqs::meta::abstract_quantity <
            boost::pqs::meta::dimension<
                aux::one_quarter,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::three_quarters
            >,
            boost::mpl::int_<1>
    > type;

    typedef ::boost::pqs::meta::abstract_quantity <
            boost::pqs::meta::dimension< 
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero
            >,
            boost::mpl::int_<0>
    > dimless_type;
     typedef boost::pqs::meta::abstract_quantity <
           boost::pqs::meta::dimension<
                aux::one,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero
            >,
            boost::mpl::int_<1>
    > length_type0;
    typedef ::boost::pqs::meta::abstract_quantity <
           boost::pqs::meta::dimension<
                aux::one,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero,
                aux::zero
            >,
            boost::mpl::int_<1>
    > length_type1;
}}

void test_abstract_quantity()
{
    using boost::pqs::meta::binary_operation;
    using boost::pqs::meta::plus;
    using boost::pqs::meta::minus;
    using boost::pqs::meta::times;

    typedef binary_operation<
        boost::pqs::type,
        plus,
        boost::pqs::type
    >::type plus_type;
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type,plus_type
    >::value));
    BOOST_CHECK((boost::pqs::meta::is_dimensionless<
        boost::pqs::type
    >::value == false));
    BOOST_CHECK((boost::pqs::meta::is_dimensionless<
        boost::pqs::meta::dimension<
            boost::pqs::aux::zero,
            boost::pqs::aux::zero,
            boost::pqs::aux::zero,
            boost::pqs::aux::zero,
            boost::pqs::aux::zero,
            boost::pqs::aux::zero,
            boost::pqs::aux::zero
        >
    >::value == true));
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type::dimension,
        plus_type::dimension
    >::value));
    typedef binary_operation<
        boost::pqs::length_type1,
        plus,
        boost::pqs::length_type1
    >::type plus_type_l;

    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::length_type1,boost::pqs::length_type0
    >::value));
    typedef binary_operation<
        boost::pqs::type,
        minus,
        boost::pqs::type
    >::type minus_type;
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type,minus_type
    >::value));
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type::dimension,minus_type::dimension
    >::value));
    BOOST_CHECK((boost::pqs::meta::is_dimensionless<
        minus_type
    >::value == false) );
    BOOST_CHECK( (boost::pqs::meta::is_dimensionless<
        minus_type::dimension
    >::value ==false));
    
    typedef binary_operation<
        boost::pqs::type,
        times,
        boost::pqs::type
    >::type multiplies_type;
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type,multiplies_type
    >::value == false));
    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::type::dimension,multiplies_type::dimension
    >::value == false));
    BOOST_CHECK((boost::pqs::meta::is_dimensionless<
        multiplies_type
    >::value == false) );
    BOOST_CHECK( (boost::pqs::meta::is_dimensionless<
        multiplies_type::dimension
    >::value ==false));
    
    typedef multiplies_type::dimension::d1 mux1;
    CHECK_RAT( mux1,1,2);
   
    typedef boost::pqs::meta::binary_operation<
        boost::pqs::type,
        boost::pqs::meta::divides,
        boost::pqs::type
    >::type divides_type;
    BOOST_CHECK(boost::pqs::meta::is_dimensionless<divides_type>::value == true );
    BOOST_CHECK(boost::pqs::meta::is_dimensionless<divides_type::dimension>::value == true);
  
    
    typedef boost::pqs::meta::binary_operation<
            boost::pqs::type,
            boost::pqs::meta::pow,
            boost::pqs::meta::rational<3>  
    >::type pow_type;

    typedef pow_type::dimension::d1 pow_t1;
    CHECK_RAT( pow_t1,3,4);
    typedef pow_type::dimension::d2 pow_t2;
    CHECK_RAT( pow_t2,0,1);
    typedef pow_type::dimension::d3 pow_t3;
    CHECK_RAT( pow_t3,0,1);
    typedef pow_type::dimension::d4 pow_t4;
    CHECK_RAT( pow_t4,0,1);
    typedef pow_type::dimension::d5 pow_t5;
    CHECK_RAT( pow_t5,0,1);
    typedef pow_type::dimension::d6 pow_t6;
    CHECK_RAT( pow_t6,0,1);
    typedef pow_type::dimension::d7 pow_t7;
    CHECK_RAT( pow_t7,9,4);

    BOOST_CHECK((boost::pqs::meta::dimensionally_equivalent<
        boost::pqs::meta::abstract_quantity <
            boost::pqs::meta::dimension< 
                boost::pqs::aux::one,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::meta::rational<1,2>
            >,
            boost::mpl::int_<1>
        >,
         boost::pqs::meta::abstract_quantity <
            boost::pqs::meta::dimension< 
            boost::pqs::meta::rational<1>,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::aux::zero,
                boost::pqs::meta::rational<1,2>
            >,
            boost::mpl::int_<0>
        >
    >::value ));
 
    BOOST_CHECK( ( boost::pqs::meta::is_dimensionless<
            boost::pqs::dimless_type
    >::value ) == true);
    BOOST_CHECK( (boost::pqs::meta::is_dimensionless<
            boost::pqs::type
    >::value ) == false );
   
  }

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs low_level test_abstract_quantity" );
        test->add(BOOST_TEST_CASE(test_abstract_quantity));
        
    return test;
}
