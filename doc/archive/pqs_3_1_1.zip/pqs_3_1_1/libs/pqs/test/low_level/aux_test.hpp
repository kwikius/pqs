#ifndef BOOST_PQS_TEST_HPP_INCLUDED
#define  BOOST_PQS_TEST_HPP_INCLUDED

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

//#ifdef __GNUC__
//#define BOOST_PQS_MINIMAL_TEST
//#endif

//epsilon for BOOST_CHECK_CLOSE
#ifndef FP_MAX_DIFFERENCE
#define FP_MAX_DIFFERENCE 1e-12
#endif

#include <boost/test/test_tools.hpp>
#include <boost/test/floating_point_comparison.hpp>
#include <boost/pqs/meta/unit.hpp>
#include <boost/pqs/meta/si_units.hpp>
#include <boost/pqs/meta/rational.hpp>
#include <boost/type_traits/is_same.hpp>
//#include <boost/mpl/equal_to.hpp>

#define CHECK_RAT(Rational, n, d) \
    BOOST_CHECK( static_cast<int>(Rational ::numerator) == n );\
    BOOST_CHECK( static_cast<int>(Rational ::denominator) == d );

#define CHECK_INT(Integral,T, v)\
    BOOST_CHECK(  (Integral ::type::value) == v);\
    BOOST_CHECK( (boost::is_same< Integral  ::value_type, T >::value) );

#define CHECK_QUANTITY_UNIT(Name,E,M,I) \
    BOOST_CHECK( (boost::is_same< \
        Name ::exponent::type ,\
        boost::pqs::meta::rational< E > \
    >::value));\
    BOOST_CHECK( (boost::is_same< \
        Name  ::multiplier::type , \
        boost::pqs::meta::rational< M > \
    >::type::value));\
    BOOST_CHECK( (boost::is_same<\
        Name  ::id::type , \
       boost::mpl::int_< I >\
    >::type::value));

#define CHECK_SI_QUANTITY_UNIT( Prefix , E ) \
 CHECK_QUANTITY_UNIT( Prefix, E , 1, 0)


#endif
