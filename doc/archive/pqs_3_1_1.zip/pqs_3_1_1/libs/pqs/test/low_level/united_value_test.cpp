// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
//#include <libs/pqs/test/low_level/aux_test.hpp>
#include <boost/pqs/config.hpp>
#include <boost/pqs/detail/united_value/united_value.hpp>
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
#include <boost/pqs/typeof_register.hpp>
#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP()
BOOST_TYPEOF_REGISTER_TEMPLATE(boost::pqs::detail::united_value, 2);
#endif
#include <boost/pqs/detail/united_value/operations/dimensioned_multiply.hpp>
#include <boost/pqs/detail/united_value/operations/dimensionless_multiply.hpp>
#include <boost/pqs/detail/united_value/operations/dimensioned_divide.hpp>
#include <boost/pqs/detail/united_value/operations/dimensionless_divide.hpp>

void uv_dimensioned_multiply_test();
void uv_dimensioned_divide_test();
void uv_dimensionless_multiply_test();
void uv_dimensionless_divide_test();
void uv_addition_test();
void uv_subtraction_test();
void uv_initialise_test();
void uv_assign_test();

void united_value_test() ///////////////
{
    uv_dimensioned_multiply_test();
    uv_dimensioned_divide_test();
    uv_dimensionless_multiply_test();
    uv_dimensionless_divide_test();
    uv_addition_test();
    uv_subtraction_test();
    uv_initialise_test();
    uv_assign_test();
};

namespace{
    typedef  boost::pqs::meta::unit<
        boost::pqs::meta::rational<3>
    > coh_unit3;
    using boost::pqs::detail::united_value;
    typedef  boost::pqs::meta::unit<
        boost::pqs::meta::rational<0>
    > coh_unit0;
    typedef  boost::pqs::meta::unit<
        boost::pqs::meta::rational<-3>
    > coh_unitn3;

    typedef  boost::pqs::meta::unit<
        boost::pqs::meta::rational<3>
    > coh_unit3;
}

void uv_initialise_test()
{
    using boost::pqs::detail::united_value;
    united_value<coh_unit0,int> u0 = united_value<coh_unit3,int>(1);
    BOOST_CHECK_EQUAL(u0.raw_value(), 1000);
    
    united_value<coh_unit0,double> u1 = united_value<coh_unitn3,int>(1);
    BOOST_CHECK_CLOSE(u1.raw_value(), 1e-3, 1.e-15);
}
void uv_assign_test()
{
    using boost::pqs::detail::united_value;
    united_value<coh_unit0,int> u0(100);
    u0 = united_value<coh_unit3,int>(1);
    BOOST_CHECK_EQUAL(u0.raw_value(), 1000);
    
    united_value<coh_unit0,double> u1(0);
    u1 = united_value<coh_unitn3,int>(1);
    BOOST_CHECK_CLOSE(u1.raw_value(), 1e-3, 1.e-15);
}

void uv_dimensioned_multiply_test()
{
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result1,
        (dimensioned_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
#else
        boost::pqs::detail::dimensioned_multiply_functor<
            coh_unit3,double,coh_unit0,double
        >::result_type result1
        = dimensioned_multiply(
            boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) 
        );
#endif
    BOOST_CHECK_CLOSE(result1.raw_value() ,1., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result2,
        (dimensioned_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
#else
        boost::pqs::detail::dimensioned_multiply_functor<
            coh_unitn3,double,coh_unit0,double
        >::result_type result2
        = dimensioned_multiply(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) 
        );
#endif
    BOOST_CHECK_CLOSE(result2.raw_value(),1., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result2a,
        (dimensioned_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) ))) ;
#else
     boost::pqs::detail::dimensioned_multiply_functor<
            coh_unitn3,double,coh_unit3,double
     >::result_type result2a
     = dimensioned_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result2a.raw_value(),1., 1.e-12);
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
     BOOST_AUTO(result2b,
        (dimensioned_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) ))) ;
#else
     boost::pqs::detail::dimensioned_multiply_functor<
            coh_unit3,double,coh_unitn3,double
     >::result_type result2b
     = dimensioned_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) );
#endif 
    BOOST_CHECK_CLOSE(result2b.raw_value(),1., 1.e-12);
}
void uv_dimensioned_divide_test()
{
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result11,
        (dimensioned_divide(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
#else
     boost::pqs::detail::dimensioned_divide_functor<
            coh_unit3,double,coh_unit0,double
     >::result_type result11
     = dimensioned_divide(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result11.raw_value(),1., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result12,(dimensioned_divide(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) )));
#else
    boost::pqs::detail::dimensioned_divide_functor<
            coh_unitn3,double,coh_unit0,double
     >::result_type result12
     = dimensioned_divide(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result12.raw_value(),1., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result2a,
        (dimensioned_divide(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) ))) ;
#else
    boost::pqs::detail::dimensioned_divide_functor<
           coh_unitn3,double,coh_unit3, double
     >::result_type result2a
     = dimensioned_divide(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result2a.raw_value(),1., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result2b,
        (dimensioned_divide(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) ))) ;
#else
    boost::pqs::detail::dimensioned_divide_functor<
            coh_unit3,double,coh_unitn3,double
     >::result_type result2b
     = dimensioned_divide(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result2b.raw_value(),1., 1.e-12);
}
void uv_dimensionless_multiply_test()
{
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result7,
        (dimensionless_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
#else
    boost::pqs::detail::dimensionless_multiply_functor<
        double,coh_unit3,double,coh_unit0
    >::result_type result7
    = dimensionless_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ) ;
#endif
    BOOST_CHECK_CLOSE(result7 ,1000., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result8,
        (dimensionless_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) ))) ;
#else
     boost::pqs::detail::dimensionless_multiply_functor<
        double,coh_unitn3,double,coh_unit0
    >::result_type result8
    = dimensionless_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result8,0.001, 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result9,
        (dimensionless_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) ))) ;
#else
    boost::pqs::detail::dimensionless_multiply_functor<
        double,coh_unit3,double,coh_unitn3
    >::result_type result9
    = dimensionless_multiply(boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result9 ,1., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result10,
        (dimensionless_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) ))) ;
#else
     boost::pqs::detail::dimensionless_multiply_functor<
        double,coh_unitn3,double,coh_unit3
    >::result_type result10
    = dimensionless_multiply(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) );
#endif
     BOOST_CHECK_CLOSE(result10,1., 1.e-12);
}

void uv_dimensionless_divide_test()
{
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result1,(dimensionless_divide(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) )));
#else
     boost::pqs::detail::dimensionless_divide_functor<
        double,coh_unitn3,double,coh_unit0
    >::result_type result1
    = dimensionless_divide(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit0,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result1,.001, 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result2,(dimensionless_divide(
            boost::pqs::detail::united_value<coh_unit0,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) )));
#else
     boost::pqs::detail::dimensionless_divide_functor<
        double,coh_unit0,double,coh_unitn3
    >::result_type result2
    = dimensionless_divide(
            boost::pqs::detail::united_value<coh_unit0,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result2,1000., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result3,(dimensionless_divide(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) )));
#else
     boost::pqs::detail::dimensionless_divide_functor<
        double,coh_unitn3,double,coh_unit3
    >::result_type result3
    = dimensionless_divide(
            boost::pqs::detail::united_value<coh_unitn3,double>(1)
        , boost::pqs::detail::united_value<coh_unit3,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result3,1e-6, 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result4,(dimensionless_divide(
            boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) )));
#else
  boost::pqs::detail::dimensionless_divide_functor<
        double,coh_unit3,double,coh_unitn3
    >::result_type result4
    = dimensionless_divide(
            boost::pqs::detail::united_value<coh_unit3,double>(1)
        , boost::pqs::detail::united_value<coh_unitn3,double>(1) );
#endif
    BOOST_CHECK_CLOSE(result4,1e6, 1.e-12);
}

void uv_addition_test()
{
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result3,(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        + boost::pqs::detail::united_value<coh_unit0,double>(1) )) ;
#else
    boost::pqs::meta::binary_operation<
       boost::pqs::detail::united_value<coh_unitn3,double>,
       boost::pqs::meta::plus ,
        boost::pqs::detail::united_value<coh_unit0,double>
    >::type result3 
    = boost::pqs::detail::united_value<coh_unitn3,double>(1)
        + boost::pqs::detail::united_value<coh_unit0,double>(1);
#endif
    BOOST_CHECK_CLOSE(result3.raw_value(),1001., 1.e-12);

#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result4,(boost::pqs::detail::united_value<coh_unit3,double>(1)
        + boost::pqs::detail::united_value<coh_unit0,double>(1) )) ;
#else
    boost::pqs::meta::binary_operation<
       boost::pqs::detail::united_value<coh_unit3,double>,
       boost::pqs::meta::plus ,
        boost::pqs::detail::united_value<coh_unit0,double>
    >::type result4
    = boost::pqs::detail::united_value<coh_unit3,double>(1)
        + boost::pqs::detail::united_value<coh_unit0,double>(1);
#endif
    BOOST_CHECK_CLOSE(result4.raw_value(),1001., 1.e-12);

}
void uv_subtraction_test()
{
 #ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result5,(boost::pqs::detail::united_value<coh_unit3,double>(1)
        - boost::pqs::detail::united_value<coh_unit0,double>(1) )) ;
#else
     boost::pqs::meta::binary_operation<
       boost::pqs::detail::united_value<coh_unit3,double>,
       boost::pqs::meta::plus ,
        boost::pqs::detail::united_value<coh_unit0,double>
    >::type result5
    = boost::pqs::detail::united_value<coh_unit3,double>(1)
        - boost::pqs::detail::united_value<coh_unit0,double>(1);
#endif
    BOOST_CHECK_CLOSE(result5.raw_value(),999., 1.e-12);

 #ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
    BOOST_AUTO(result6,(boost::pqs::detail::united_value<coh_unitn3,double>(1)
        - boost::pqs::detail::united_value<coh_unit0,double>(1) )) ;
#else
    boost::pqs::meta::binary_operation<
       boost::pqs::detail::united_value<coh_unitn3,double>,
       boost::pqs::meta::minus ,
        boost::pqs::detail::united_value<coh_unit0,double>
    >::type result6
    = boost::pqs::detail::united_value<coh_unitn3,double>(1)
        - boost::pqs::detail::united_value<coh_unit0,double>(1);
#endif
    BOOST_CHECK_CLOSE(result6.raw_value(),-999., 1.e-12);

}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs low_level united_value_test" );
        test->add(BOOST_TEST_CASE(uv_dimensioned_multiply_test));
        test->add(BOOST_TEST_CASE(uv_dimensioned_divide_test));
        test->add(BOOST_TEST_CASE(uv_dimensionless_multiply_test));
        test->add(BOOST_TEST_CASE(uv_dimensionless_divide_test));
        test->add(BOOST_TEST_CASE(uv_addition_test));
        test->add(BOOST_TEST_CASE(uv_subtraction_test));
        test->add(BOOST_TEST_CASE(uv_initialise_test));
        test->add(BOOST_TEST_CASE(uv_assign_test));
    return test;
}
