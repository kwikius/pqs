// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/pressure.hpp>
#include <boost/pqs/t1_quantity/types/torque.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>

namespace pqs = boost::pqs;
void compare_test()
{
    pqs::pressure::Pa a,b(1.9999999);
    a = b;
    pqs::pressure::Pa c = a;
    BOOST_CHECK( a == b && b == c);

    BOOST_CHECK(compare( a, b, pqs::pressure::Pa(1e-6) ) == 0);
    BOOST_CHECK(compare(-a, -b, -pqs::pressure::Pa(1e-6) ) == 0);
    BOOST_CHECK(compare( a, b, -pqs::pressure::Pa(1e-6) ) == 0);
    BOOST_CHECK(compare(-a, -b, pqs::pressure::Pa(1e-6) ) == 0);

    BOOST_CHECK( a.numeric_value() == b.numeric_value()  
    &&  b.numeric_value() == c.numeric_value() );
    pqs::pressure::mbar d(1000);
    pqs::pressure::bar e(1);
    BOOST_CHECK(d == e);
    double ratio = d / e;
    BOOST_CHECK(ratio == 1.);
    BOOST_CHECK(d - e == pqs::pressure::bar() );
    BOOST_CHECK(e - d == pqs::pressure::mbar() );
    BOOST_CHECK( ( compare( d, e, pqs::pressure::mbar(1e-6) ) == 0 ) );
    BOOST_CHECK( ( compare(-d, -e, -pqs::pressure::mbar(1e-6) ) == 0 ) );
    BOOST_CHECK( ( compare( d, e, -pqs::pressure::mbar(1e-6) ) == 0 ) );
    BOOST_CHECK( ( compare(-d, -e, pqs::pressure::mbar(1e-6) ) == 0 ) );

    pqs::pressure::bar neg_e = -e;
    BOOST_CHECK( neg_e == +neg_e);
    BOOST_CHECK( neg_e == -e);
    BOOST_CHECK( e + neg_e == pqs::pressure::bar() );
    BOOST_CHECK( neg_e + e == pqs::pressure::mbar() );
    BOOST_CHECK( d + neg_e == pqs::pressure::mbar() );
    BOOST_CHECK( neg_e + d == pqs::pressure::bar() );
    d *= 2;
    ratio = e/d;
    BOOST_CHECK(ratio == 0.5);
    e/=2.;
    ratio = d/e;
    BOOST_CHECK(ratio == 4.);

    pqs::torque::mN_m torque(1);
    BOOST_CHECK(torque++ == pqs::torque::mN_m(1.) );
    BOOST_CHECK(torque == pqs::torque::mN_m(2.) );
    BOOST_CHECK(++torque == pqs::torque::mN_m(3.) );
    BOOST_CHECK(torque-- == pqs::torque::mN_m(3.));
    BOOST_CHECK(torque == pqs::torque::mN_m(2.));
    BOOST_CHECK(--torque == pqs::torque::mN_m(1.));

    pqs::resistance::kR  same(2.5);
    pqs::resistance::kR  same1 
    = same - pqs::quantity_traits::epsilon<pqs::resistance::kR>()/1.1;
    pqs::resistance::kR  same2 
    = same + pqs::quantity_traits::epsilon<pqs::resistance::kR>()/1.1;
    BOOST_CHECK( same == same);
    BOOST_CHECK( same1 == same);
    BOOST_CHECK( same == same1);
    BOOST_CHECK( same2 == same);
    BOOST_CHECK( same == same2);
    pqs::resistance::kR smaller(2.4);
    BOOST_CHECK(smaller < same);

    // check sign of epsilon doesnt matter
    BOOST_CHECK(  compare(smaller,same,pqs::resistance::kR(.01) ) < 0 );  
    BOOST_CHECK(  compare(-smaller,-same,pqs::resistance::kR(.01) )  > 0 );
    BOOST_CHECK(  compare(smaller,same,-pqs::resistance::kR(.01)) < 0 ); 
    BOOST_CHECK(  compare(-smaller,-same,-pqs::resistance::kR(.01)) > 0 );
    BOOST_CHECK(  compare(same,smaller,pqs::resistance::kR(.01)) > 0 );
    BOOST_CHECK(  compare(same,smaller,-pqs::resistance::kR(.01)) > 0  ); 
    BOOST_CHECK(  compare(-same,-smaller,pqs::resistance::kR(.01)) < 0 );
    BOOST_CHECK(  compare(-same,-smaller,-pqs::resistance::kR(.01)) < 0 );

    BOOST_CHECK(smaller <= same);
    BOOST_CHECK(smaller != same);
    BOOST_CHECK(same != smaller);
    BOOST_CHECK(same > smaller);
    BOOST_CHECK(same >= smaller);

    pqs::resistance::R  samex(2500);
    BOOST_CHECK( samex == same);
    BOOST_CHECK( same == samex);

    pqs::resistance::R smallerx(2400);

    BOOST_CHECK(smallerx < same);
    BOOST_CHECK(smallerx <= same);
    BOOST_CHECK(smallerx != same);
    BOOST_CHECK(same != smallerx);
    BOOST_CHECK(same > smallerx);
    BOOST_CHECK(same >= smallerx);

    pqs::length::in L1(36);
    pqs::length::ft L2(3);
    BOOST_CHECK(compare(L1,L2,pqs::length::in(1e-9)) == 0);
        
    pqs::length::yd L3 = L2;
    BOOST_CHECK(compare(L3,L2, pqs::length::ft(1e-6)) == 0);

    pqs::length::mi L4(1);
    BOOST_CHECK(compare(L4,L2 * 1760, pqs::length::yd(1e-6)) == 0);
}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs compare" );

    test->add(BOOST_TEST_CASE(compare_test));
    return test;
}

