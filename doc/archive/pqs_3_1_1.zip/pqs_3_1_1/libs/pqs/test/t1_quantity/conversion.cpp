// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/out/pressure.hpp>
#include <boost/pqs/meta/eval_rational.hpp>
#include <boost/pqs/meta/eval_exponent.hpp>
#include <utility>
/*
    check values are correct when initialising
    a t1_quantity with another of different units, both coherent and incoherent
    and optionally value_type

    Also checks t1_quantity::numeric_value();
    exceptions on out of range double to int value_type

    postcondition of a conversion: 

According to t1_quantity spec docs,
after conversions (where rhs is the source and 'this' is the target):

this->numeric_value() == ( rhs.numeric_value() 
* pqs::meta::eval_exponent< 
    binary_operation<
        typeof(rhs)::unit::exponent,
        minus,
        typeof(*this)::unit::exponent
    >::type
>() * rhs.units.multiplier / this->units.multiplier ).

*/
namespace pqs = boost::pqs;

template < typename To, typename From>

/*
This test assumes the internal calc is correct!
It tries to exactly mirror real calc
so uses == for float comparisons!
Though if that fails uses +/- eps
*/

std::pair<bool,To> conv_impl(From const & rhs, BOOST_PQS_REAL_TYPE eps = 0.)
{
    // sort  exponent functor
    typedef typename boost::pqs::meta::binary_operation<
        typename From::unit::exponent,
        boost::pqs::meta::minus,
        typename To::unit::exponent
    >::type exponent;

    typedef boost::pqs::meta::eval_exponent<exponent> exp_eval;

    // sort multiplier functors
    typedef boost::pqs::meta::eval_rational<
        typename From::unit::multiplier::type
    > from_mux_rat;
    typedef boost::pqs::meta::eval_rational<
        typename To::unit::multiplier::type
    > to_mux_rat;

    // get promoted value_type for calculation
    typedef typename boost::pqs::meta::arithmetic_promote<
        typename from_mux_rat::result_type,
        typename to_mux_rat::result_type
    >::type prom1;
    typedef typename boost::mpl::if_<
        boost::is_same<
           typename From::unit::multiplier::type,
            boost::pqs::meta::rational<1>
        >,
        BOOST_PQS_INT32,
        BOOST_PQS_REAL_TYPE
    >::type min_rational;

    typedef typename boost::pqs::meta::arithmetic_promote<
         min_rational,prom1
    >::type rat_eval_type;

    from_mux_rat from_mux_;
    to_mux_rat to_mux_;

    typename exp_eval::eval  exp;
    typename exp_eval::result_type exp_result = exp();
    rat_eval_type from_mux = from_mux_();
    rat_eval_type to_mux = to_mux_();
    
// comparisons provide automatic promotions
// that will give erroneous results,
// so convert From.numeric_value() from source value_type to target value_type 
// before comparison. conversion must use boost numeric converter 
// using round-nearest algorithm.
    typename boost::pqs::quantity_traits::value_type_converter<
        typename To::value_type,
        typename From::value_type
    > convert;
    typename To::value_type cmp_val;
        cmp_val = convert( (rhs.numeric_value() * exp_result ) * from_mux  / to_mux );
   
    To to = rhs;  

    To to1(rhs);
    BOOST_CHECK_EQUAL(to.numeric_value(),to1.numeric_value());
    bool result1 = (to.numeric_value() == cmp_val);
    
    if( !result1){
        typename To::value_type abs_to = (to.numeric_value() >=0) ? to.numeric_value() : -to.numeric_value();
        typename To::value_type abs_from = (cmp_val >=0) ? cmp_val :-cmp_val;
        typename To::value_type dif = abs_to - abs_from;
        typename To::value_type abs_diff = (dif >=0) ? dif : -dif;
        BOOST_PQS_REAL_TYPE abs_eps = (eps>=0) ? eps : -eps;
       
        result1 = ( abs_diff < abs_eps);
        if (!result1){
            std::cout.precision(35);
            std::cout << "not equal detected:\n"; 
            std::cout << "lhs.value == " << abs_to <<'\n';
            std::cout << "rhs.value == " << abs_from <<'\n';
            std::cout << "abs error = " << abs_diff << '\n';
            std::cout << "eps = " << abs_eps << '\n';
        }
    }
    std::pair<bool,To> result(result1,to);
    return result;
}
template <typename Exp, typename To, typename From>
std::pair<bool,To> conv_impl(From const & rhs)
{
    typename boost::pqs::meta::eval_exponent<Exp>::eval ev;
    return conv_impl<To>(rhs,ev());
}

// conversion_test
//{
//    /*
//    coherent --> finer-grained units coherent
//    coherent --> coarser-grained units coherent
//    coherent --> coarser-grained units incoherent
//
//    incoherent --> coarser-grained units incoherent
//    incoherent --> finer-grained units incoherent
//    incoherent --> coarser-grained units coherent
//    */

// coherent , floating-pt --> coarser-grained units coherent , floating-pt
void conv_coh_gt_coh()
{
    bool r1 
    = conv_impl<pqs::pressure::MPa>( pqs::pressure::Pa(5000000),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure::MPa>( pqs::pressure::mPa(1.1e9),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);

    bool r3 
    = conv_impl<pqs::pressure::cPa>( pqs::pressure::fPa(10234.8976),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);

    bool r4 
    = conv_impl<pqs::pressure::MPa>( pqs::pressure::kPa(9e20),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r4); 

    bool r5
    = conv_impl<pqs::pressure::MPa>( pqs::pressure::Pa(10),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r5);
}

//coherent, floating-pt --> coarser-grained units coherent, int value_type
void conv_coh_gt_coh_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::kPa>( pqs::pressure::Pa(10),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::MPa>( pqs::pressure::mPa(10),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);

    bool r3 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::cPa>( pqs::pressure::fPa(10),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);

    bool r4 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::MPa>( pqs::pressure::kPa(10),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r4); 
}

// coherent, floating-pt --> finer-grained units coherent, floating-pt
void conv_coh_less_coh()
{
    bool r1 
    = conv_impl<pqs::pressure::Pa>( pqs::pressure::MPa(1e7),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure::mPa>( pqs::pressure::MPa(232),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);

    bool r3 
    = conv_impl<pqs::pressure::fPa>( pqs::pressure::cPa(-34),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);

    bool r4 
    = conv_impl<pqs::pressure::kPa>( pqs::pressure::MPa(6789),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r4); 
}

//coherent, floating-pt --> finer-grained units coherent with int value_type
void conv_coh_less_coh_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::Pa>( pqs::pressure::kPa(123),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);

    bool r2 = false;
    try{
         conv_impl<pqs::pressure_<BOOST_PQS_INT32>::Pa>( pqs::pressure::MPa(9876),FP_MAX_DIFFERENCE).first;
    }
    catch(boost::numeric::positive_overflow &){
        r2 = true;
    }
    BOOST_CHECK(r2);
    
    bool r3 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::mPa>( pqs::pressure::cPa(-34),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);

    bool r4 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::kPa>( pqs::pressure::MPa(67),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r4); 
}

// coherent, floating-pt --> coarser-grained units incoherent, floating-pt
void conv_coh_to_gt_inco()
{
    bool r1 
    = conv_impl<pqs::pressure::cmHg>( pqs::pressure::mPa(1.676),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure::mbar>( pqs::pressure::pPa(25e3),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);

    bool r3
    = conv_impl<pqs::pressure::dyn_div_cm2>( pqs::pressure::mPa(.0008),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);
}

// coherent, floating-pt --> coarser-grained units incoherent , int value_type
void conv_coh_to_gt_inco_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::cmHg>( pqs::pressure::mPa(1.676),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);

    bool r2
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::mbar>( pqs::pressure::mPa(25.034),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);

    bool r3
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::dyn_div_cm2>( pqs::pressure::mPa(.0008),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);

    bool r4
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::atm>( pqs::pressure::Pa(.08),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r4);
}

    //coherent, floating-pt --> finer-grained units incoherent, floating-pt
void coh_to_less_inco()
{
    bool r1 
    = conv_impl<pqs::pressure::dyn_div_cm2>( pqs::pressure::Pa(1.676),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);
    
    bool r2
    = conv_impl<pqs::pressure::kgf_div_m2>( pqs::pressure::kPa(201.7867),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);
     
    bool r3
    = conv_impl<pqs::pressure::in_water39_2F>( 
        pqs::pressure::MPa(1.676),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);

     bool r4
    = conv_impl<pqs::pressure::atm>( 
        pqs::pressure::MPa(-45.3333),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r4);
}

//coherent, floating-pt --> finer-grained units incoherent, int
   
void coh_to_less_inco_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::dyn_div_cm2>( 
        pqs::pressure::Pa(1.676),FP_MAX_DIFFERENCE
    ).first;
    BOOST_CHECK(r1);
    
    bool r2
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::kgf_div_m2>( 
        pqs::pressure::kPa(201.7867),FP_MAX_DIFFERENCE
    ).first;
    BOOST_CHECK(r2);
     
    bool r3
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::in_water39_2F>( 
        pqs::pressure::MPa(1.676),FP_MAX_DIFFERENCE
    ).first;
    BOOST_CHECK(r3);

     bool r4
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::atm>( 
        pqs::pressure::MPa(1.676),FP_MAX_DIFFERENCE
    ).first;
    BOOST_CHECK(r4);
}

 //incoherent, floating-pt --> coarser-grained units incoherent, floating-pt
void incoh_gt_inco()
{
    bool r1 
    = conv_impl<pqs::pressure::dyn_div_cm2>( pqs::pressure::atm(1999.),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);
    
    bool r2
    = conv_impl<pqs::pressure::kgf_div_cm2>( pqs::pressure::kgf_div_m2(201.7867),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);
     
    bool r3
    = conv_impl<pqs::pressure::ksi>( 
        pqs::pressure::lbf_div_ft2(1.676),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);

     bool r4
    = conv_impl<pqs::pressure::atm>( 
        pqs::pressure::ftHg(-45.3333),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r4);
}
    //incoherent, floating-pt --> coarser-grained units incoherent, int
void incoh_gt_inco_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::dyn_div_cm2>( pqs::pressure::atm(1999.),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);
    
    bool r2
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::kgf_div_cm2>( pqs::pressure::kgf_div_m2(201.7867),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);
     
    bool r3
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::ksi>( 
        pqs::pressure::lbf_div_ft2(1.676),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r3);

     bool r4
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::atm>( 
        pqs::pressure::ftHg(-45.3333),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r4);
}

//incoherent, floating-pt --> finer-grained units incoherent, floating-pt
   
void incoh_less_inco()
{
    bool r1 
    = conv_impl<pqs::pressure::atm>(  pqs::pressure::dyn_div_cm2(1999.),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);
    
    bool r2
    = conv_impl<pqs::pressure::kgf_div_m2 >( pqs::pressure::kgf_div_cm2(2.7867),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);
     
    bool r3
    = conv_impl<
        boost::pqs::meta::rational<-10>,
        pqs::pressure::lbf_div_ft2
    >( pqs::pressure::ksi(.0676)).first;
    BOOST_CHECK(r3);

    bool r4
    = conv_impl<
        boost::pqs::meta::rational<-12>,
        pqs::pressure::ftHg>( pqs::pressure::atm(-45.3333)).first;
    BOOST_CHECK(r4);
}

//incoherent, floating-pt --> finer-grained units incoherent, int
void incoh_less_inco_int()
{
    bool r1 
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::atm>(  pqs::pressure::dyn_div_cm2(1999.),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r1);
    
    bool r2
    = conv_impl<pqs::pressure_<BOOST_PQS_INT32>::kgf_div_m2 >( pqs::pressure::kgf_div_cm2(2.7867),FP_MAX_DIFFERENCE).first;
    BOOST_CHECK(r2);
     
    bool r3
    = conv_impl<
        boost::pqs::meta::rational<-10>,
        pqs::pressure_<BOOST_PQS_INT32>::lbf_div_ft2
    >( pqs::pressure::ksi(.0676)).first;
    BOOST_CHECK(r3);

    bool r4
    = conv_impl<
        boost::pqs::meta::rational<-12>,
        pqs::pressure_<BOOST_PQS_INT32>::ftHg>( pqs::pressure::atm(-45.3333)).first;
    BOOST_CHECK(r4);
}

//add
    //incoherent, floating-pt --> coarser-grained units coherent, floating-pt
    //incoherent, floating-pt --> coarser-grained units coherent, int
    //incoherent, floating-pt --> coarser-grained units coherent, floating-pt
    //incoherent, floating-pt --> coarser-grained units coherent, floating-pt

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs conversion" );
    test->add(BOOST_TEST_CASE(conv_coh_gt_coh));
    test->add(BOOST_TEST_CASE(conv_coh_gt_coh_int));
    test->add(BOOST_TEST_CASE(conv_coh_less_coh));
    test->add(BOOST_TEST_CASE(conv_coh_less_coh_int));
    test->add(BOOST_TEST_CASE(conv_coh_to_gt_inco));
    test->add(BOOST_TEST_CASE(conv_coh_to_gt_inco_int));
    test->add(BOOST_TEST_CASE(coh_to_less_inco));
    test->add(BOOST_TEST_CASE(coh_to_less_inco_int));
    test->add(BOOST_TEST_CASE(incoh_gt_inco));
    test->add(BOOST_TEST_CASE(incoh_gt_inco_int));
    test->add(BOOST_TEST_CASE(incoh_less_inco));
    test->add(BOOST_TEST_CASE(incoh_less_inco_int));

    return test;
}
