// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/all_types.hpp>
#include <libs/pqs/src/constant.cpp>
#include <libs/pqs/src/magnetic_constant.cpp>

/*
    Do some calculations to check dimensional 
    errors in predefined quantities.
    Try to cover each type

*/

/*
acceleration
area
energy
frequency
force
length
mass
mass_flow
power
pressure
reciprocal_time
time
torque
velocity
volume
*/

namespace pqs = boost::pqs;

void dims_check_test1()
{
    pqs::length::m  length(1);
    pqs::area::m2 area = length * length;
// 'time' id causes issues on some gcc, hence add '_' suffix 
    pqs::time::s    time_(1);
    pqs::velocity::m_div_s velocity = length / time_;
    pqs::acceleration::m_div_s2 acceleration = velocity / time_;
    pqs::mass::kg mass(1);
    pqs::force::N force = mass * acceleration;
    pqs::energy::J  energy = force * length;
    pqs::torque::N_m tq = force * length;
    pqs::power::W  power = energy / time_;
    pqs::volume::m3 volume = area * length;
    pqs::density::kg_div_m3 d = mass / volume;
    pqs::frequency::Hz  freq = 1 / time_;
    pqs::pressure::Pa  pressure = force / area;
    pqs::mass_flow::kg_div_s mass_flow = mass / time_;
    pqs::reciprocal_time::div_s reciprocal_time = 1/time_;
}


void dims_check_test2()
{
    pqs::current::mA current(1);
    pqs::resistance::kR resistance(2);
    pqs::voltage::V voltage = current * resistance;
    pqs::power::W power = voltage * current;
    pqs::power::mW power1 = pqs::pow<2>(voltage) / resistance;
    pqs::power::MW power2 = pqs::pow<2>(current) * resistance;
    
    BOOST_PQS_REAL_TYPE const & pi = pqs::math::constant::pi;
    using boost::pqs::physics::magnetic_constant;
    int num_turns = 5;
    pqs::length::mm coil_radius(25);
    pqs::magnetomotive_force::A mmf 
    = current * num_turns;
   
    pqs::magnetic_field_strength::mA_div_m mfs 
    = mmf /( 2 * pi * coil_radius) ;

    pqs::magnetic_flux_density::mT  B 
    = magnetic_constant::mu0 * mfs;
    pqs::magnetic_flux::mWb flux
    = B * pi * pqs::pow<2>(coil_radius);
}



using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs dim_checks" );
    test->add(BOOST_TEST_CASE(dims_check_test1));
    test->add(BOOST_TEST_CASE(dims_check_test2));
    return test;
}
