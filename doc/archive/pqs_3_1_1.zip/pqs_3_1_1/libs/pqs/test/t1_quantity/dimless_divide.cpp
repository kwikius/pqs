// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/frequency.hpp>
#include <boost/pqs/t1_quantity/types/reciprocal_time.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>

/*
    dimensionless divide ( ***working but unfinished ***
*/
namespace pqs = boost::pqs;
//helper
namespace{
    template <typename PQA,typename PQB>
    struct xdivides{
        typedef typename boost::pqs::meta::binary_operation<
            PQA,boost::pqs::meta::divides,PQB
        >::type type;
    };
}

// coherent / coherent
void coh_coh_divides_test()
{
    pqs::resistance::R r1(24);
    pqs::resistance::R r2(12);
    typedef xdivides<
        pqs::resistance::R,
        pqs::resistance::R
    >::type result_type1;
    BOOST_CHECK( (boost::is_same<result_type1,BOOST_PQS_REAL_TYPE>::value ==true));
    result_type1 result1 = r1 / r2;
    BOOST_CHECK_CLOSE(result1, BOOST_PQS_REAL_TYPE(2.) ,1e-12);

    pqs::resistance::kR r3(24);
    pqs::resistance::mR r4(12);
    typedef xdivides<
        pqs::resistance::kR,
        pqs::resistance::mR
    >::type result_type2;
    BOOST_CHECK( (boost::is_same<result_type2,BOOST_PQS_REAL_TYPE>::value ==true));
    result_type2 result2 = r3 / r4;
    BOOST_CHECK_CLOSE(result2, 2e6 ,1e-6);

    pqs::resistance::mR r5(24);
    pqs::resistance::kR r6(12);
    typedef xdivides<
        pqs::resistance::mR,
        pqs::resistance::kR
    >::type result_type3;
    BOOST_CHECK( (boost::is_same<result_type3,BOOST_PQS_REAL_TYPE>::value ==true));
    result_type3 result3 = r5 / r6;
    BOOST_CHECK_CLOSE(result3, 2.e-6,1e-12);
}
// coherent / incoherent
void coh_incoh_divides_test()
{
   
}

// incoherent / coherent
void incoh_coh_divides_test()
{
  
}

// inco / inco
void incoh_incoh_divides_test()
{
  
}


using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs dimless_divide" );

    test->add(BOOST_TEST_CASE(coh_coh_divides_test));
    test->add(BOOST_TEST_CASE(coh_incoh_divides_test));
    test->add(BOOST_TEST_CASE(incoh_coh_divides_test));
    test->add(BOOST_TEST_CASE(incoh_incoh_divides_test));
    return test;
    
}
