// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/frequency.hpp>
#include <boost/pqs/t1_quantity/types/reciprocal_time.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/conductance.hpp>
/*
    dimensionless multiply ( ***working but unfinished ***)
*/
namespace pqs = boost::pqs;
//helper
namespace{
    template <typename PQA,typename PQB>
    struct xtimes{
        typedef typename boost::pqs::meta::binary_operation<
            PQA,boost::pqs::meta::times,PQB
        >::type type;
    };
}

// coherent * coherent
void coh_coh_multiply_test()
{
    pqs::resistance::R r1(24);
    pqs::conductance::S s1(12);
    typedef xtimes<
        pqs::resistance::R,
        pqs::conductance::S
    >::type result_type1;
    BOOST_CHECK( (boost::is_same<result_type1,BOOST_PQS_REAL_TYPE>::value ==true));
    result_type1 result1 = r1 * s1;
    BOOST_CHECK_CLOSE(result1, 288. ,1e-12);

    pqs::resistance::kR r2(24);
    pqs::conductance::kS s2(12);
    typedef xtimes<
        pqs::resistance::kR,
        pqs::conductance::kS
    >::type result_type2;
    BOOST_CHECK( (boost::is_same<result_type2,BOOST_PQS_REAL_TYPE>::value ==true));
    result_type2 result2 = r2 * s2;
    BOOST_CHECK_CLOSE(result2, 288.e6 ,1e-6);

    pqs::resistance::kR r3(24);
    pqs::conductance::mS s3(12);
    typedef xtimes<
        pqs::resistance::kR,
        pqs::conductance::mS
    >::type result_type3;
    BOOST_CHECK( (boost::is_same<result_type3,BOOST_PQS_REAL_TYPE>::value ==true));
    result_type3 result3 = r3 * s3;
    BOOST_CHECK_CLOSE(result3, 288.,1e-12);

    
}
// coherent * incoherent
void coh_incoh_multiply_test()
{
   // pqs::time::
    
 
}

// incoherent * coherent
void incoh_coh_multiply_test()
{
  
}


void incoh_incoh_multiply_test()
{
  
}


using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs dimless_multiply" );

    test->add(BOOST_TEST_CASE(coh_coh_multiply_test));
    test->add(BOOST_TEST_CASE(coh_incoh_multiply_test));
    test->add(BOOST_TEST_CASE(incoh_coh_multiply_test));
    test->add(BOOST_TEST_CASE(incoh_incoh_multiply_test));
    return test;
    
}
