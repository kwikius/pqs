
// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.
/*
    basic test of Input / output
    note :input probably needs work to make pqs input 
    standard conforming

*/
#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/io/input.hpp>
#include <boost/pqs/t1_quantity/types/out/time.hpp>
#include <boost/pqs/t1_quantity/types/out/length.hpp>
#include <fstream>


namespace pqs = boost::pqs;

void  io_test()
{
    pqs::time::min t1(1.5);
    pqs::time::s t2(22.2);
    pqs::length::ft  l1(.222);
    {
        std::ofstream out("data.txt");
        out << t1 << t2 << l1 ;
    }
    std::ifstream in("data.txt");
    pqs::time::min t3;
    pqs::time::s t4;
    pqs::length::ft  l2(1);
    in >> t3 >> t4 >> l2;    

    BOOST_CHECK(!in.bad());
    BOOST_CHECK(t1 == t3);
    BOOST_CHECK(t2 ==t4);
    BOOST_CHECK(l1 == l2);
 }


using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs io_test" );
    test->add(BOOST_TEST_CASE(io_test));
    return test;
}
