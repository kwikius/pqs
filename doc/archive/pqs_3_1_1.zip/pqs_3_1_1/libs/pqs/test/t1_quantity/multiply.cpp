// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/power.hpp>
#include <boost/pqs/t1_quantity/types/current.hpp>
#include <boost/pqs/t1_quantity/types/voltage.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/force.hpp>
#include <boost/pqs/t1_quantity/types/energy.hpp>

/*
    dimensionful multiply
*/
namespace pqs = boost::pqs;
//helper
namespace{
    template <typename PQA,typename PQB>
    struct xtimes{
        typedef typename boost::pqs::meta::binary_operation<
            PQA,boost::pqs::meta::times,PQB
        >::type type;
    };
}

// coherent * coherent
void coh_coh_multiply_test()
{
    pqs::current::A  i(10);
    pqs::voltage::V v(240);
    pqs::power::W p = v * i;
    BOOST_CHECK_EQUAL(p.numeric_value(),
        (BOOST_PQS_REAL_TYPE(240) * BOOST_PQS_REAL_TYPE(10)));
 
    pqs::current::mA i1(10);
    pqs::voltage::mV v1(240);
    pqs::power::uW p1 = v1 * i1;
    BOOST_CHECK_EQUAL(p.numeric_value(),
        (BOOST_PQS_REAL_TYPE(240) * BOOST_PQS_REAL_TYPE(10)));
   
}
// coherent * incoherent
void coh_incoh_multiply_test()
{
    pqs::time::ms T1(99.);
    // for simpler mental calc start from coherent type
    pqs::length::dm L1x(100.); 
    pqs::length::ft L1 = L1x; 
    typedef xtimes<
        pqs::time::ms,pqs::length::ft
    >::type result_type;
    result_type R1 = T1 * L1;

    int mult = result_type::unit::multiplier::numerator;
    BOOST_CHECK(mult == 1);
    int exp_nume = result_type::unit::exponent::numerator;
    BOOST_CHECK(exp_nume == -4);
    int exp_denom = result_type::unit::exponent::denominator;
    BOOST_CHECK(exp_denom == 1);

    BOOST_CHECK_CLOSE(R1.numeric_value(), 
        BOOST_PQS_REAL_TYPE(100. * 99), 
        BOOST_PQS_REAL_TYPE(1e-12)
    );
}

// incoherent * coherent
void incoh_coh_multiply_test()
{
    pqs::time::ms T1(99.);
    // for simpler mental calc start from coherent type
    pqs::length::dm L1x(100.); 
    pqs::length::ft L1 = L1x; 
    typedef xtimes<
        pqs::length::ft,pqs::time::ms
    >::type result_type;
    result_type R1 = L1 * T1 ;

    int mult = result_type::unit::multiplier::numerator;
    BOOST_CHECK(mult == 1);
    int exp_nume = result_type::unit::exponent::numerator;
    BOOST_CHECK(exp_nume == -4);
    int exp_denom = result_type::unit::exponent::denominator;
    BOOST_CHECK(exp_denom == 1);

    BOOST_CHECK_CLOSE(R1.numeric_value(), 
        BOOST_PQS_REAL_TYPE( 99. )  * BOOST_PQS_REAL_TYPE(100. ), 
        BOOST_PQS_REAL_TYPE(1e-12)
    );
}


void incoh_incoh_multiply_test()
{
    // for simpler mental calc start from coherent types
    pqs::force::N F1x(99.);
    pqs::length::dm L1x(100.); 
    // and convert to incoherent types
    pqs::force::kgf F1 = F1x;
    pqs::length::ft L1 = L1x; 
    typedef xtimes<
        pqs::force::kgf,pqs::length::ft
    >::type result_type;
    int mult = result_type::unit::multiplier::numerator;
    BOOST_CHECK(mult == 1);
    int exp_nume = result_type::unit::exponent::numerator;
    BOOST_CHECK(exp_nume == -1);
    int exp_denom = result_type::unit::exponent::denominator;
    BOOST_CHECK(exp_denom == 1);

    result_type  R1 = F1 * L1;
    BOOST_CHECK_CLOSE(R1.numeric_value(), 
        BOOST_PQS_REAL_TYPE( 99. ) * BOOST_PQS_REAL_TYPE(100. ), 
        BOOST_PQS_REAL_TYPE(1e-12)
    );
}


using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs multiply" );

    test->add(BOOST_TEST_CASE(coh_coh_multiply_test));
    test->add(BOOST_TEST_CASE(coh_incoh_multiply_test));
    test->add(BOOST_TEST_CASE(incoh_coh_multiply_test));
    test->add(BOOST_TEST_CASE(incoh_incoh_multiply_test));
    return test;
    
}
