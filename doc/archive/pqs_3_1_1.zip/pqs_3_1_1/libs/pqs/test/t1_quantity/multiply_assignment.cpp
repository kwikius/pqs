// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>

/*
    test *= numeric for t1_quantity
*/
namespace pqs=boost::pqs;
void multiply_assign_test()
{
    pqs::length::m L1(3.);
    L1 *=2;
    BOOST_CHECK_EQUAL(L1.numeric_value() , BOOST_PQS_REAL_TYPE(3.) * 2);

    pqs::length::mm L2(-2310);
    L2 *= 2343.;
    BOOST_CHECK_EQUAL(L2.numeric_value() ,BOOST_PQS_REAL_TYPE(-2310) * 2343.);

    pqs::length::in L3(-12);
    L3 *= 0.1;
    BOOST_CHECK_EQUAL(L3.numeric_value() ,BOOST_PQS_REAL_TYPE(-12) * 0.1 );

    pqs::length::in L4(0.314142);
    L4 *= 3.14142;
    BOOST_CHECK_EQUAL(L4.numeric_value() ,BOOST_PQS_REAL_TYPE(0.314142) * 3.14142);
}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs multiply_assignment" );
    test->add(BOOST_TEST_CASE(multiply_assign_test));
    
    return test;
}
