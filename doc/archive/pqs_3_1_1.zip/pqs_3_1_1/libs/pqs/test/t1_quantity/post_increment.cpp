// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/force.hpp>

/*
    test post_increment for t1_quantity
*/

namespace pqs = boost::pqs;
void post_increment_test()
{
    pqs::resistance::MR R1(4.7);
    pqs::resistance::MR Rold = R1;
    BOOST_CHECK_EQUAL( Rold.numeric_value(),R1.numeric_value());
    pqs::resistance::MR R2 = R1++;
    BOOST_CHECK_EQUAL(R1.numeric_value(),Rold.numeric_value() + 1 );
    BOOST_CHECK_EQUAL(R2.numeric_value(), Rold.numeric_value());

    pqs::force::kip F1(987.51);
    pqs::force::kip Fold = F1;
    BOOST_CHECK_EQUAL( Fold.numeric_value(), F1.numeric_value());
    pqs::force::kip F2 = F1++;
    BOOST_CHECK(F2.numeric_value() == Fold.numeric_value());
    BOOST_CHECK(F1.numeric_value() == Fold.numeric_value()+ 1  );
}


using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs post_increment" );
    test->add(BOOST_TEST_CASE(post_increment_test));
    return test;
}
