// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
#include <boost/pqs/t1_quantity/types/area.hpp>
#include <boost/pqs/t1_quantity/types/volume.hpp>
//#include <iostream>
/*
Docs state:
template <
    BOOST_PQS_INT32 N,BOOST_PQS_INT32 D,
    typename AbstractQuantity,typename Unit,typename Value_type
>
typename binary_operation<
    t1_quantity<AbstractQuantity,Unit,Value_type >,
    pow, rational<N,D>
>::type
pow(t1_quantity<AbstractQuantity,Unit,Value_type > const & x );

1 Returns:

If N / D == 0 the type of the result is int. the value is 1.
If N / D == 1 the type of the result is the type of x and 
its numeric_value() == x.numeric_value.
In all other cases x is used to initialise a quantity t 
which has similar units to x except that t is a coherent-quantity.
 The dimension of the result r is the dimension of t multiplied by N/D. 
r will be an anonymous_quantity. 
The type of the value_type of r is as if BOOST_PQS_REAL_TYPE was multiplied by the value_type of x.

r.numeric_value() == std::pow(t.numeric_value,static_cast<result_value_type>(N)/D);

*/
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_same.hpp>

/*
    check T is an int rather than just something convertible
*/
template <typename T,typename T1>
typename boost::enable_if<
    boost::is_same<T,T1>,
    T1
>::type
check_is_same(T1 t1)
{
    return t1;
}

namespace pqs = boost::pqs;
void test_pow0()
{
//    check_is_same<int>(1.); //FWIW uncomment to check the function works
    pqs::length::m L1(200);
    int v1 = check_is_same<int>(pqs::pow<0>(L1));
    BOOST_CHECK( v1 == 1);
    pqs::area::ft2 A1(20);
    int v2 = check_is_same<int>(pqs::pow<0>(A1));
    BOOST_CHECK( v2 == 1);

    int v1a = check_is_same<int>(pqs::pow<0,1>(L1));
    BOOST_CHECK( v1a == 1);

    int v2a = check_is_same<int>(pqs::pow<0,2>(A1));
    BOOST_CHECK( v2a == 1);

    pqs::length_<int>::m L2(200);
    int v3 = check_is_same<int>(pqs::pow<0>(L2));
    BOOST_CHECK( v3 == 1);
    pqs::area_<long>::ft2 A2(20);
    int v4 = check_is_same<int>(pqs::pow<0>(A2));
    BOOST_CHECK( v4 == 1);

    int v3a = check_is_same<int>(pqs::pow<-0,8>(L2));
    BOOST_CHECK( v3a == 1);
    int v4a = check_is_same<int>(pqs::pow<0,-3>(A2));
    BOOST_CHECK( v4a == 1);
}

void test_pow1()
{
    pqs::length::m L1(200);
    pqs::length::m r1 
    = check_is_same<
        pqs::length::m
    >( pqs::pow<1,1>(L1) );
    BOOST_CHECK( r1 == L1);
    BOOST_CHECK( r1.numeric_value() == L1.numeric_value());

    pqs::length::m r1a 
    = check_is_same<
        pqs::length::m
    >( pqs::pow<-1,-1>(L1) );
    BOOST_CHECK( r1 == L1);
    BOOST_CHECK( r1a.numeric_value() == L1.numeric_value());

    pqs::length::m r1b
    = check_is_same<
        pqs::length::m
    >( pqs::pow<10,10>(L1) );
    BOOST_CHECK( r1b == L1);
    BOOST_CHECK( r1b.numeric_value() == L1.numeric_value());

    pqs::length::m r1c
    = check_is_same<
        pqs::length::m
    >( pqs::pow<-10,-10>(L1) );
    BOOST_CHECK( r1c == L1);
    BOOST_CHECK( r1c.numeric_value() == L1.numeric_value());

    pqs::area::ft2 A1(20);
    pqs::area::ft2 v2 
    = check_is_same<
        pqs::area::ft2
    >(pqs::pow<1>(A1));
    BOOST_CHECK( v2 == A1);
    BOOST_CHECK( v2.numeric_value() == A1.numeric_value());

    pqs::length_<int>::m L2(200);
    pqs::length_<int>::m r3
    = check_is_same<
        pqs::length_<int>::m 
    >( pqs::pow<1>(L2));
    BOOST_CHECK( r3 == L2);
    BOOST_CHECK( r3.numeric_value() == L2.numeric_value());
    pqs::area_<long>::ft2 A2(20);
    pqs::area_<long>::ft2 v4 = check_is_same<
        pqs::area_<long>::ft2
    >(pqs::pow<1>(A2));
    BOOST_CHECK( v4.numeric_value() == A2.numeric_value());

}

void test_power_functions()
{
//power functions
///////////////////////////////////
    pqs::length::m  L1(10.);
   
    BOOST_CHECK_CLOSE ( 
        (pqs::pow<-1>(L1)).numeric_value() , 
        (1/L1).numeric_value(), 
        FP_MAX_DIFFERENCE
    ); 


    // should be exactly this calc
    BOOST_CHECK ( ((pqs::pow<3,2>(L1)).numeric_value() == std::pow(10., 3./2)));

    pqs::area::m2   A1 = pqs::pow<2>(L1);
    BOOST_CHECK( (A1.numeric_value() == 100.));

    pqs::volume::m3 V1 = pqs::pow<3,1>(L1);
    BOOST_CHECK(( V1.numeric_value() == 1000.));

   //inevitable loss of accuracy in roots
    pqs::area::m2 A2 = pqs::pow<2,3>(V1);
    BOOST_CHECK_CLOSE (A2.numeric_value() , 100., FP_MAX_DIFFERENCE);

    pqs::length::m L2 = pqs::pow<1,3>(V1);
    BOOST_CHECK_CLOSE (L2.numeric_value(),10., FP_MAX_DIFFERENCE);

    // should be exact calc
    pqs::area::mm2 A3 = pqs::pow<2,1>(L1);
    BOOST_CHECK( A3.numeric_value() == 100000000.);
    pqs::volume::km3 V3 = pqs::pow<3,1>(L1);
    BOOST_CHECK( V3.numeric_value() == 1e-6);

    pqs::area::in2 A4 = pqs::length::cm(100) * pqs::length::cm(100);
    pqs::length::in L4 = pqs::sqrt(A4);
    BOOST_CHECK_CLOSE( L4.numeric_value(), 100. / 2.54, 0.01);
    pqs::length::cm L4A = L4;
    BOOST_CHECK_CLOSE(L4A.numeric_value(),100., FP_MAX_DIFFERENCE);
}


using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs pow" );
    test->add(BOOST_TEST_CASE(test_pow0));
    test->add(BOOST_TEST_CASE(test_pow1));
    test->add(BOOST_TEST_CASE(test_power_functions));
    return test;
}

