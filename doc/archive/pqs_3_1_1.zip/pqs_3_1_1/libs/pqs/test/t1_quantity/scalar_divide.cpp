// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/mass.hpp>
#include <boost/pqs/t1_quantity/types/force.hpp>
#include <boost/pqs/t1_quantity/types/time.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
#include <boost/pqs/t1_quantity/types/reciprocal_time.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/conductance.hpp>
/*
    division by a scalar
*/
namespace pqs = boost::pqs;
void scalar_divide_test()
{
    pqs::mass::kg M1(1.1);
    pqs::mass::kg M2 = M1 / 25;
    // not sure if we can guarantee this?
    // may need to use BOOST_CHECK_CLOSE?
    BOOST_CHECK_EQUAL(M2.numeric_value(),
        (BOOST_PQS_REAL_TYPE(1.1) / BOOST_PQS_REAL_TYPE(25))
    );

    // similar comment
    pqs::force::kgf F1(100);
    pqs::force::kgf F2  = F1 / 0.3;
    BOOST_CHECK_EQUAL(F2.numeric_value(),
        (BOOST_PQS_REAL_TYPE(100) / BOOST_PQS_REAL_TYPE(0.3))
    );
}

//value_type / pq acts differently when pq is incoherent
void reciprocal_scalar_divide_test()
{
    pqs::conductance::mS  S1(100.);
    BOOST_PQS_REAL_TYPE  v = BOOST_PQS_REAL_TYPE(2.);
    pqs::resistance::kR  R1 = v / S1; 

    //for simplicity initialize incoherent type from coherent type
    boost::pqs::length::km L1x (250);
    boost::pqs::length::mi L1 = L1x;

    // check conversion of incoherent to anonymous coherent type
    // in division of value_type by pq
    typedef pqs::meta::binary_operation<
       BOOST_PQS_REAL_TYPE,
        pqs::meta::divides,
        boost::pqs::length::mi
    >::type result_type;
    // anonymous check
    BOOST_CHECK(
        (boost::is_same<
            result_type::abstract_quantity::id,
            pqs::meta::anonymous_abstract_quantity_id
        >::value == true)
    );
    typedef result_type::unit::multiplier mux;
    BOOST_CHECK( mux::numerator == 1 );
    BOOST_CHECK( mux::denominator == 1 );
    result_type result = v / L1;
    BOOST_CHECK_CLOSE(result.numeric_value(), v/(BOOST_PQS_REAL_TYPE(250.)), 1e-9);    
}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs scaslar_divide" );

    test->add(BOOST_TEST_CASE(scalar_divide_test));
    test->add(BOOST_TEST_CASE(reciprocal_scalar_divide_test));
    return test;
    
}
