// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/mass.hpp>
#include <boost/pqs/t1_quantity/types/force.hpp>
/*
    multiplication by a scalar
*/
namespace pqs = boost::pqs;
void scalar_multiply_test()
{
    pqs::mass::kg M1(1.1);
    pqs::mass::kg M2 = M1 * 25;
    // not sure if we can guarantee this?
    // may need to use BOOST_CHECK_CLOSE?
    BOOST_CHECK_EQUAL(M2.numeric_value(),
        (BOOST_PQS_REAL_TYPE(1.1) * BOOST_PQS_REAL_TYPE(25))
    );
    //check other orientation
    pqs::mass::kg M2a = 25 * M1;
    // not sure if we can guarantee this?
    // may need to use BOOST_CHECK_CLOSE?
    BOOST_CHECK_EQUAL(M2a.numeric_value(),
        (BOOST_PQS_REAL_TYPE(25) * BOOST_PQS_REAL_TYPE(1.1) )
    );

    // similar comment
    pqs::force::kgf F1(100);
    pqs::force::kgf F2  = F1 * 0.3;
    BOOST_CHECK_EQUAL(F2.numeric_value(),
        (BOOST_PQS_REAL_TYPE(100) * BOOST_PQS_REAL_TYPE(0.3))
    );
     //check other orientation
    pqs::force::kgf F2a  = 0.3 * F1 ;
    BOOST_CHECK_EQUAL(F2.numeric_value(),
        (BOOST_PQS_REAL_TYPE(0.3) * BOOST_PQS_REAL_TYPE(100))
    );
    
}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs scalar_multiply" );

    test->add(BOOST_TEST_CASE(scalar_multiply_test));
   
    return test;
    
}
