// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/t1_quantity/types/resistance.hpp>
#include <boost/pqs/t1_quantity/types/magnetic_permeability.hpp>

/*
    test unary_plus for t1_quantity
*/

namespace pqs = boost::pqs;
void unary_plus_test()
{
   pqs::resistance::MR R1(4.7);
   pqs::resistance::MR R2 = +R1;
   BOOST_CHECK_EQUAL(R1.numeric_value(),R2.numeric_value());
   pqs::magnetic_permeability_<int>::mH_div_m mp1(987.51);
   pqs::magnetic_permeability::mH_div_m mp2 = +mp1;
   BOOST_CHECK(mp1.numeric_value() == mp2.numeric_value());
   BOOST_CHECK(mp1.numeric_value() == 988);
}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs unary_plus" );
    test->add(BOOST_TEST_CASE(unary_plus_test));
    return test;
}
