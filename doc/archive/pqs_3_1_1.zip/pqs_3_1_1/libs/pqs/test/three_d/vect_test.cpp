// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*
    Preliminary tests on three_d vects
*/

#include <libs/pqs/test/test.hpp>
#include <boost/pqs/three_d/vect.hpp>
#include <boost/pqs/t1_quantity/types/length.hpp>
namespace pqs = boost::pqs;

void vect_test1()
{
    typedef pqs::three_d::vect<double> vect;
    vect v1(1.,2.,3.);
    BOOST_CHECK(v1.x == 1.);
    BOOST_CHECK(v1.y == 2.);
    BOOST_CHECK(v1.z == 3.);
    vect v2 = v1 * 2;
    BOOST_CHECK(v2.x == 2.);
    BOOST_CHECK(v2.y == 4.);
    BOOST_CHECK(v2.z == 6.);
    vect v3 = v1 + v2;
    BOOST_CHECK(v3.x == 3.);
    BOOST_CHECK(v3.y == 6.);
    BOOST_CHECK(v3.z == 9.);
    vect v4 = v1 - v2;
    BOOST_CHECK(v4.x == -1.);
    BOOST_CHECK(v4.y == -2.);
    BOOST_CHECK(v4.z == -3.);
    
    typedef pqs::three_d::vect<int> vect1;

    vect1 v5(1,2,3);
    vect  v6 = v5 + v1;
    BOOST_CHECK(v6.x == 2.);
    BOOST_CHECK(v6.y == 4.);
    BOOST_CHECK(v6.z == 6.); 
}

void vect_t1_quantity_test1()
{
    typedef pqs::length::mm len;
    typedef pqs::three_d::vect<len> vect;
    vect v1(len(1.),len(2.),len(3.));
    BOOST_CHECK(v1.x.numeric_value() == 1.);
    BOOST_CHECK(v1.y.numeric_value() == 2.);
    BOOST_CHECK(v1.z.numeric_value() == 3.);
    vect v2 =v1 * 2.;
    BOOST_CHECK(v2.x.numeric_value() == 2.);
    BOOST_CHECK(v2.y.numeric_value() == 4.);
    BOOST_CHECK(v2.z.numeric_value() == 6.);
    vect v3 = v1 + v2;
    BOOST_CHECK(v3.x.numeric_value() == 3.);
    BOOST_CHECK(v3.y.numeric_value() == 6.);
    BOOST_CHECK(v3.z.numeric_value() == 9.);
    vect v4 = v1 - v2;
    BOOST_CHECK(v4.x.numeric_value() == -1.);
    BOOST_CHECK(v4.y.numeric_value() == -2.);
    BOOST_CHECK(v4.z.numeric_value() == -3.);
    
    typedef pqs::length_<int>::mm len1;
    typedef pqs::three_d::vect<
        len1
    > vect1;

    vect1 v5(len1(1),len1(2),len1(3));
    vect  v6 = v5 + v1;
    BOOST_CHECK(v6.x.numeric_value() == 2.);
    BOOST_CHECK(v6.y.numeric_value() == 4.);
    BOOST_CHECK(v6.z.numeric_value() == 6.); 
}

using boost::unit_test_framework::test_suite;
test_suite*
init_unit_test_suite( BOOST_PQS_INT32, char* [] ) 
{
    test_suite* test 
    = BOOST_TEST_SUITE( "Unit test boost/pqs angle_test" );
    test->add(BOOST_TEST_CASE(vect_test1));
    test->add(BOOST_TEST_CASE(vect_t1_quantity_test1));
    return test;
}
