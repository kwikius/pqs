#ifndef BOOST_PQS_TEST_MY_UDT_HPP_INCLUDED
#define BOOST_PQS_TEST_MY_UDT_HPP_INCLUDED

// Copyright Andrew Little 2005
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See libs/pqs for documentation.

/*  
    dummy udt representing a value_type
    for test purposes.
    However the to_arithmetic struct at the end of the header
    is a useful example of how other UDT's must be treated
*/

#include <boost/pqs/meta/binary_operation.hpp>
#include <boost/pqs/meta/to_arithmetic.hpp>
#include <boost/implicit_cast.hpp>
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
#include <boost/typeof/typeof.hpp>
#endif
#include <iostream>

namespace my{
    template <typename T>
    struct udt;
}
#ifdef BOOST_PQS_USE_BOOST_TYPEOF_BINARY_OPERATION
#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP()
BOOST_TYPEOF_REGISTER_TEMPLATE(my::udt,1);
#endif
namespace boost{namespace pqs{namespace meta{

    template <typename T1, typename Op, typename T2>
    struct binary_operation<
        ::my::udt<T1>, Op, ::my::udt<T2> 
    >{
        typedef ::my::udt<
            typename binary_operation<T1,Op,T2>::type
        > type;
    };

}}}//boost::pqs::meta

namespace my{

    template <typename T>
    struct udt{
        typedef T value_type;
    private:
        T m_value;
    public:
        T get_value()const{ return m_value;}

        udt():m_value(0){} // no division by zero wanted
        explicit udt(T const & in) : m_value(in){}

      /*  template <typename T1>
        udt ( T1 const & in, typename boost::enable_if<
                    boost::is_convertible<T1,T>, int*
                >::type =0
        ): m_value(in){}*/

        template <typename T1>
        udt(udt<T1>  const &in ,typename boost::enable_if<
                    boost::is_convertible<T1,T>, int*
                >::type =0): m_value(in.get_value()){}

        template <typename T1>
        udt& operator +=( udt<T1> const & rhs)
        {
            this->m_value += rhs.m_value;
            return *this;
        }

        template <typename T1>
        udt<
            typename boost::pqs::meta::binary_operation<
                T, boost::pqs::meta::plus,T1
            >::type
        >
        operator +(  udt<T1> const & in)const
        {
            udt<
                typename boost::pqs::meta::binary_operation<
                    T, boost::pqs::meta::plus,T1
                >::type
            > result(m_value + in.get_value());
            return result;
        }

        template <typename T1>
        udt& operator -=( udt<T1> const & rhs)
        {
            this->m_value -= rhs.m_value;
            return *this;
        }

        template <typename T1>
        udt<
            typename boost::pqs::meta::binary_operation<
                T, boost::pqs::meta::minus,T1
            >::type
        >
        operator -(  udt<T1> const & in)const
        {
            udt<
                typename boost::pqs::meta::binary_operation<
                    T, boost::pqs::meta::minus,T1
                >::type
            > result(m_value - in.get_value());
            return result;
        }

        template <typename T1>
        udt& operator *=( udt<T1> const & rhs)
        {
            this->m_value *= rhs.m_value;
            return *this;
        }

        template <typename T1>
        udt<
            typename boost::pqs::meta::binary_operation<
                T, boost::pqs::meta::times,T1
            >::type
        >
        operator *(  udt<T1> const & in)const
        {
            udt<
                typename boost::pqs::meta::binary_operation<
                    T, boost::pqs::meta::times,T1
                >::type
            > result(m_value * in.get_value());
            return result;
        }

        template <typename T1>
        typename boost::enable_if<
            boost::pqs::meta::is_value_type<T1>,
            udt<
                typename boost::pqs::meta::binary_operation<
                    T, boost::pqs::meta::times,T1
                >::type
            >
        >::type
        operator *(  T1 const & in)const
        {
            udt<
                typename boost::pqs::meta::binary_operation<
                    T, boost::pqs::meta::times,T1
                >::type
            > result(m_value * in());
            return result;
        }

        template <typename T1>
        udt& operator /=( udt<T1> const & rhs)
        {
            this->m_value /= rhs.m_value;
            return /this;
        }

        template <typename T1>
        udt<
            typename boost::pqs::meta::binary_operation<
                T, boost::pqs::meta::divides,T1
            >::type
        >
        operator /(  udt<T1> const & in)const
        {
            udt<
                typename boost::pqs::meta::binary_operation<
                    T, boost::pqs::meta::divides,T1
                >::type
            > result(m_value / in.get_value());
            return result;
        }        
    }; 
// some distinguishing output 
    template <typename CharType,typename T>
    std::basic_ostream<CharType>& 
    operator <<(std::basic_ostream<CharType>& os, udt<T> const & u)
    {
        os << "{" << u.get_value() << "}";
        return os;
    }
}
/*
    A specialisation of to_arithmetic currently required for udt's.
    The requirement is 2 way that is
        udt(to_arithmetic()(udt(x)); should work
    It may be possible to eliminate this though there will still be
    some requirements on udt's
*/

namespace boost{namespace pqs{namespace meta{

    template <typename T>
    struct to_arithmetic<
        my::udt<T>
    >{
        typedef T type;

        type 
        operator()( my::udt<T> const & in)
        {
            return in.get_value();
        }
    };

}}}

#endif
